#Requires -Version 5.1
<#
.SYNOPSIS
    Task Scheduler Manager — Terminal UI for Windows Task Scheduler
    Author  : Cybopsec
    Version : 2.0.0
.DESCRIPTION
    Manages scheduled tasks with fallback command chains and configurable
    full-failure handlers. Requires admin rights for some operations.
#>

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# ─── Config ──────────────────────────────────────────────────────────────────
$Script:BaseDir    = Join-Path $env:APPDATA 'CybopsecTaskManager'
$Script:WrapperDir = Join-Path $Script:BaseDir 'Wrappers'
$Script:LogDir     = Join-Path $Script:BaseDir 'Logs'
$Script:LogFile    = Join-Path $Script:BaseDir 'task_manager.log'
$Script:TaskFolder = '\CybopsecManaged'

foreach ($d in @($Script:BaseDir, $Script:WrapperDir, $Script:LogDir)) {
    if (-not (Test-Path $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
}

# ─── Logging ─────────────────────────────────────────────────────────────────
function Write-Log {
    param([string]$Level, [string]$Message)
    $entry = '[{0}] [{1,-5}] {2}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Level, $Message
    Add-Content -Path $Script:LogFile -Value $entry
}
function Log-Info  { param($m) Write-Log 'INFO'  $m }
function Log-Warn  { param($m) Write-Log 'WARN'  $m }
function Log-Error { param($m) Write-Log 'ERROR' $m }

# ─── UI helpers ───────────────────────────────────────────────────────────────
function Show-Header {
    Clear-Host
    Write-Host ('╔' + '═' * 54 + '╗') -ForegroundColor Cyan
    Write-Host '║       TASK SCHEDULER MANAGER  v2.0  // Cybopsec      ║' -ForegroundColor Cyan
    Write-Host ('╚' + '═' * 54 + '╝') -ForegroundColor Cyan
    Write-Host ''
}

function Write-Divider { Write-Host ('─' * 56) -ForegroundColor DarkBlue }
function Write-OK      { param($m) Write-Host "[✔] $m" -ForegroundColor Green  }
function Write-Warn    { param($m) Write-Host "[!] $m" -ForegroundColor Yellow }
function Write-Err     { param($m) Write-Host "[✘] $m" -ForegroundColor Red    }
function Write-Info    { param($m) Write-Host "[i] $m" -ForegroundColor Cyan   }
function Pause-Screen  { Read-Host "`nPress [Enter] to continue" | Out-Null }

# ─── Admin check ─────────────────────────────────────────────────────────────
function Test-Admin {
    ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
    ).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

# ─── Validation ───────────────────────────────────────────────────────────────
function Test-ExecutablePath {
    param([string]$Path)
    if (-not $Path) { return $false }
    return (Test-Path $Path -PathType Leaf)
}

function Test-NotEmpty {
    param([string]$Value)
    return ($Value.Trim() -ne '')
}

# ─── Trigger builder ──────────────────────────────────────────────────────────
function New-TriggerFromMenu {
    Write-Host "`n  Trigger type:" -ForegroundColor White
    Write-Host "    1) Once"
    Write-Host "    2) Daily"
    Write-Host "    3) Weekly"
    Write-Host "    4) Monthly"
    Write-Host "    5) At startup"
    Write-Host "    6) At logon"
    $tc = Read-Host "  Choice [1-6]"

    switch ($tc) {
        '1' {
            $dt = Read-Host "  Start datetime (e.g. '2025-12-01 03:00')"
            return New-ScheduledTaskTrigger -Once -At ([datetime]$dt)
        }
        '2' {
            $t = Read-Host "  Daily at time (e.g. '02:00')"
            $i = Read-Host "  Every N days [1]"
            if (-not $i) { $i = 1 }
            return New-ScheduledTaskTrigger -Daily -At $t -DaysInterval ([int]$i)
        }
        '3' {
            $t  = Read-Host "  Weekly at time (e.g. '02:00')"
            $wd = Read-Host "  Days (e.g. Monday,Wednesday)"
            $days = $wd -split ',' | ForEach-Object { $_.Trim() }
            return New-ScheduledTaskTrigger -Weekly -At $t -DaysOfWeek $days
        }
        '4' {
            $t  = Read-Host "  Monthly at time (e.g. '02:00')"
            $d  = Read-Host "  Day of month (1-31)"
            $ms = Read-Host "  Months (e.g. January,July — blank = all)"
            if (-not $ms) {
                return New-ScheduledTaskTrigger -Monthly -At $t -DaysOfMonth ([int]$d)
            }
            $mArr = $ms -split ',' | ForEach-Object { $_.Trim() }
            return New-ScheduledTaskTrigger -Monthly -At $t -DaysOfMonth ([int]$d) -MonthsOfYear $mArr
        }
        '5' { return New-ScheduledTaskTrigger -AtStartup }
        '6' { return New-ScheduledTaskTrigger -AtLogOn   }
        default {
            Write-Err "Invalid trigger choice — defaulting to daily at 02:00"
            return New-ScheduledTaskTrigger -Daily -At '02:00'
        }
    }
}

# ─── Wrapper script builder ───────────────────────────────────────────────────
function New-WrapperScript {
    param(
        [string]$JobName,
        [string]$PrimaryExe,
        [string]$PrimaryArgs,
        [string]$FallbackExe,
        [string]$FallbackArgs,
        [string]$FailAction,     # notify | log | shutdown | restart | custom
        [string]$CustomCmd
    )

    $wrapperPath = Join-Path $Script:WrapperDir "$JobName.ps1"
    $jobLog      = Join-Path $Script:LogDir     "$JobName.log"

    $lines = @()
    $lines += '#Requires -Version 5.1'
    $lines += "# Auto-generated wrapper: $JobName"
    $lines += 'Set-StrictMode -Version Latest'
    $lines += '$ErrorActionPreference = "Continue"'
    $lines += ''
    $lines += "`$JobName = '$JobName'"
    $lines += "`$JobLog  = '$jobLog'"
    $lines += ''
    $lines += 'function Write-JobLog {'
    $lines += '    param([string]$Msg)'
    $lines += '    $ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss"'
    $lines += '    Add-Content -Path $JobLog -Value "[$ts] [$JobName] $Msg"'
    $lines += '}'
    $lines += ''

    # ── Primary ───────────────────────────────────────────────────────────────
    $lines += 'Write-JobLog "START primary: ' + $PrimaryExe + ' ' + $PrimaryArgs + '"'
    $lines += 'try {'
    $lines += "    `$proc = Start-Process -FilePath '$PrimaryExe' ``"
    if ($PrimaryArgs) {
        $lines += "        -ArgumentList '$PrimaryArgs' ``"
    }
    $lines += '        -NoNewWindow -PassThru -Wait'
    $lines += '    if ($proc.ExitCode -eq 0) {'
    $lines += '        Write-JobLog "PRIMARY SUCCESS"'
    $lines += '        exit 0'
    $lines += '    }'
    $lines += '    Write-JobLog "WARN primary exited with code $($proc.ExitCode)"'
    $lines += '} catch {'
    $lines += '    Write-JobLog "WARN primary threw exception: $_"'
    $lines += '}'
    $lines += ''

    # ── Fallback ─────────────────────────────────────────────────────────────
    if ($FallbackExe) {
        $lines += 'Write-JobLog "START fallback: ' + $FallbackExe + ' ' + $FallbackArgs + '"'
        $lines += 'try {'
        $lines += "    `$proc2 = Start-Process -FilePath '$FallbackExe' ``"
        if ($FallbackArgs) {
            $lines += "        -ArgumentList '$FallbackArgs' ``"
        }
        $lines += '        -NoNewWindow -PassThru -Wait'
        $lines += '    if ($proc2.ExitCode -eq 0) {'
        $lines += '        Write-JobLog "FALLBACK SUCCESS"'
        $lines += '        exit 0'
        $lines += '    }'
        $lines += '    Write-JobLog "ERROR fallback exited with code $($proc2.ExitCode)"'
        $lines += '} catch {'
        $lines += '    Write-JobLog "ERROR fallback threw exception: $_"'
        $lines += '}'
        $lines += ''
    } else {
        $lines += 'Write-JobLog "ERROR primary failed — no fallback configured"'
    }

    $lines += 'Write-JobLog "FULL_FAIL reached — executing failure handler: ' + $FailAction + '"'
    $lines += ''

    # ── Full-fail handler ─────────────────────────────────────────────────────
    switch ($FailAction) {
        'notify' {
            $lines += '# Windows Toast / BalloonTip notification'
            $lines += 'try {'
            $lines += '    Add-Type -AssemblyName System.Windows.Forms'
            $lines += '    $balloon = New-Object System.Windows.Forms.NotifyIcon'
            $lines += '    $balloon.Icon = [System.Drawing.SystemIcons]::Error'
            $lines += '    $balloon.BalloonTipIcon  = "Error"'
            $lines += '    $balloon.BalloonTipTitle = "Cron Job Failure"'
            $lines += "    `$balloon.BalloonTipText = `"[$JobName] All attempts failed @ `$(Get-Date)`""
            $lines += '    $balloon.Visible = $true'
            $lines += '    $balloon.ShowBalloonTip(10000)'
            $lines += '    Write-JobLog "FULL_FAIL: notification sent"'
            $lines += '} catch { Write-JobLog "FULL_FAIL: notification failed: $_" }'
        }
        'log' {
            $lines += 'Write-JobLog "FULL_FAIL: all attempts exhausted — logged only"'
            $lines += 'Add-Content -Path $JobLog -Value ("=" * 50)'
        }
        'shutdown' {
            $lines += 'Write-JobLog "FULL_FAIL: initiating system shutdown"'
            $lines += 'try { Stop-Computer -Force } catch { Write-JobLog "FULL_FAIL: shutdown failed: $_" }'
        }
        'restart' {
            $lines += 'Write-JobLog "FULL_FAIL: initiating system restart"'
            $lines += 'try { Restart-Computer -Force } catch { Write-JobLog "FULL_FAIL: restart failed: $_" }'
        }
        'custom' {
            $lines += "# Custom failure handler"
            $lines += 'try {'
            $lines += "    $CustomCmd"
            $lines += '    Write-JobLog "FULL_FAIL: custom handler executed"'
            $lines += '} catch { Write-JobLog "FULL_FAIL: custom handler threw: $_" }'
        }
        default {
            $lines += 'Write-JobLog "FULL_FAIL: unknown handler type — logged only"'
        }
    }

    $lines += 'exit 2'

    $lines -join "`n" | Set-Content -Path $wrapperPath -Encoding UTF8
    return $wrapperPath
}

# ─── Ensure Task Folder ───────────────────────────────────────────────────────
function Ensure-TaskFolder {
    $svc = New-Object -ComObject 'Schedule.Service'
    $svc.Connect()
    $root = $svc.GetFolder('\')
    try { $root.GetFolder($Script:TaskFolder) | Out-Null }
    catch { $root.CreateFolder($Script:TaskFolder) | Out-Null }
}

# ─── Features ─────────────────────────────────────────────────────────────────

function Show-Tasks {
    Show-Header
    Write-Host "  MANAGED SCHEDULED TASKS`n" -ForegroundColor White

    try {
        $tasks = Get-ScheduledTask -TaskPath "$Script:TaskFolder\" -ErrorAction SilentlyContinue
        if (-not $tasks) {
            Write-Warn "No managed tasks found in $Script:TaskFolder."
        } else {
            $i = 1
            foreach ($t in $tasks) {
                $state = switch ($t.State) {
                    0 { 'Unknown'  }; 1 { 'Disabled' }; 2 { 'Queued' }
                    3 { 'Ready'    }; 4 { 'Running'  }; default { $t.State }
                }
                $color = if ($state -eq 'Running') { 'Green' } elseif ($state -eq 'Disabled') { 'Red' } else { 'Yellow' }
                Write-Host ("  {0,2}) " -f $i) -NoNewline -ForegroundColor Yellow
                Write-Host ("{0,-30}" -f $t.TaskName) -NoNewline -ForegroundColor White
                Write-Host " [$state]" -ForegroundColor $color
                $i++
            }
            Write-Host "`n" -NoNewline
            Write-Info "Total: $($tasks.Count) task(s)"
        }
    } catch {
        Write-Err "Could not query Task Scheduler: $_"
        Log-Error "Show-Tasks: $_"
    }
    Pause-Screen
}

function Add-ManagedTask {
    Show-Header
    Write-Host "  ADD MANAGED TASK`n" -ForegroundColor White

    # ── Job name ──────────────────────────────────────────────────────────────
    do {
        $jobName = Read-Host "  Task label (alphanumeric, underscores)"
    } while ($jobName -notmatch '^[a-zA-Z0-9_-]+$')

    # ── Trigger ───────────────────────────────────────────────────────────────
    $trigger = New-TriggerFromMenu

    # ── Primary executable ────────────────────────────────────────────────────
    Write-Divider
    do {
        $primaryExe = Read-Host "  Primary interpreter path (e.g. C:\Python312\python.exe)"
        if (-not (Test-ExecutablePath $primaryExe)) {
            Write-Err "'$primaryExe' not found."
        }
    } while (-not (Test-ExecutablePath $primaryExe))

    $primaryArgs = Read-Host "  Primary script/arguments (e.g. C:\scripts\backup.py --full)"

    # ── Fallback ──────────────────────────────────────────────────────────────
    Write-Divider
    Write-Info "Optional: fallback command if primary fails."
    $useFallback = Read-Host "  Add fallback? [y/N]"
    $fallbackExe = ''; $fallbackArgs = ''
    if ($useFallback -match '^[Yy]$') {
        do {
            $fallbackExe = Read-Host "  Fallback interpreter path"
            if (-not (Test-ExecutablePath $fallbackExe)) {
                Write-Err "'$fallbackExe' not found."
            }
        } while (-not (Test-ExecutablePath $fallbackExe))
        $fallbackArgs = Read-Host "  Fallback script/arguments"
    }

    # ── Full-fail handler ─────────────────────────────────────────────────────
    Write-Divider
    Write-Host "  On total failure:" -ForegroundColor White
    Write-Host "    1) notify   — Windows balloon/toast notification"
    Write-Host "    2) log      — log only (default)"
    Write-Host "    3) shutdown — shutdown the system"
    Write-Host "    4) restart  — restart the system"
    Write-Host "    5) custom   — run a custom PowerShell snippet"
    $fc = Read-Host "  Choice [1-5, default=2]"
    $failAction = 'log'; $customCmd = ''
    switch ($fc) {
        '1' { $failAction = 'notify'   }
        '3' { $failAction = 'shutdown'; Write-Warn "System will shut down on failure!" }
        '4' { $failAction = 'restart';  Write-Warn "System will restart on failure!"   }
        '5' { $failAction = 'custom'
              $customCmd = Read-Host "  PowerShell snippet (single line)" }
    }

    # ── Build wrapper ─────────────────────────────────────────────────────────
    Write-Divider
    Write-Info "Building wrapper script..."
    try {
        $wrapperPath = New-WrapperScript `
            -JobName      $jobName      `
            -PrimaryExe   $primaryExe   `
            -PrimaryArgs  $primaryArgs  `
            -FallbackExe  $fallbackExe  `
            -FallbackArgs $fallbackArgs `
            -FailAction   $failAction   `
            -CustomCmd    $customCmd

        # Register task
        Ensure-TaskFolder
        $action   = New-ScheduledTaskAction `
                        -Execute 'powershell.exe' `
                        -Argument "-NonInteractive -NoProfile -ExecutionPolicy Bypass -File `"$wrapperPath`""
        $settings = New-ScheduledTaskSettingsSet `
                        -ExecutionTimeLimit (New-TimeSpan -Hours 2) `
                        -StartWhenAvailable `
                        -RunOnlyIfNetworkAvailable:$false

        Register-ScheduledTask `
            -TaskName  $jobName `
            -TaskPath  $Script:TaskFolder `
            -Action    $action `
            -Trigger   $trigger `
            -Settings  $settings `
            -RunLevel  Highest `
            -Force | Out-Null

        Write-OK "Task '$jobName' registered in $Script:TaskFolder."
        Write-Info "Wrapper : $wrapperPath"
        Write-Info "Job log : $(Join-Path $Script:LogDir "$jobName.log")"
        Log-Info "Added task '$jobName' with fail-action '$failAction'"

    } catch {
        Write-Err "Failed to create task: $_"
        Log-Error "Add-ManagedTask '$jobName': $_"
    }
    Pause-Screen
}

function Remove-ManagedTask {
    Show-Header
    Write-Host "  REMOVE MANAGED TASK`n" -ForegroundColor White

    try {
        $tasks = @(Get-ScheduledTask -TaskPath "$Script:TaskFolder\" -ErrorAction SilentlyContinue)
        if (-not $tasks.Count) {
            Write-Warn "No managed tasks found."; Pause-Screen; return
        }

        $i = 1
        foreach ($t in $tasks) {
            Write-Host ("  {0,2}) {1}" -f $i, $t.TaskName) -ForegroundColor Yellow
            $i++
        }

        $pick = Read-Host "`n  Select task to remove (0 to cancel)"
        if ($pick -eq '0' -or -not $pick) { return }

        $idx = [int]$pick - 1
        if ($idx -lt 0 -or $idx -ge $tasks.Count) {
            Write-Err "Invalid selection."; Pause-Screen; return
        }

        $target = $tasks[$idx]
        $confirm = Read-Host "  Remove '$($target.TaskName)'? [y/N]"
        if ($confirm -notmatch '^[Yy]$') { Write-Info "Cancelled."; Pause-Screen; return }

        Unregister-ScheduledTask -TaskName $target.TaskName -TaskPath $Script:TaskFolder -Confirm:$false
        Write-OK "Task '$($target.TaskName)' removed."
        Log-Info "Removed task '$($target.TaskName)'"

        # Offer to remove wrapper
        $wPath = Join-Path $Script:WrapperDir "$($target.TaskName).ps1"
        if (Test-Path $wPath) {
            $delw = Read-Host "  Delete wrapper script '$wPath'? [y/N]"
            if ($delw -match '^[Yy]$') {
                Remove-Item $wPath -Force
                Write-OK "Wrapper deleted."
                Log-Info "Wrapper deleted: $wPath"
            }
        }

    } catch {
        Write-Err "Remove failed: $_"
        Log-Error "Remove-ManagedTask: $_"
    }
    Pause-Screen
}

function Enable-DisableTask {
    Show-Header
    Write-Host "  ENABLE / DISABLE TASK`n" -ForegroundColor White

    try {
        $tasks = @(Get-ScheduledTask -TaskPath "$Script:TaskFolder\" -ErrorAction SilentlyContinue)
        if (-not $tasks.Count) { Write-Warn "No tasks found."; Pause-Screen; return }

        $i = 1
        foreach ($t in $tasks) {
            $st = if ($t.State -eq 1) { '[Disabled]' } else { '[Enabled] ' }
            Write-Host ("  {0,2}) {1} {2}" -f $i, $st, $t.TaskName) -ForegroundColor Yellow
            $i++
        }

        $pick = Read-Host "`n  Select task (0 to cancel)"
        if ($pick -eq '0') { return }
        $idx = [int]$pick - 1
        if ($idx -lt 0 -or $idx -ge $tasks.Count) { Write-Err "Invalid."; Pause-Screen; return }

        $t = $tasks[$idx]
        if ($t.State -eq 1) {
            Enable-ScheduledTask -TaskName $t.TaskName -TaskPath $Script:TaskFolder | Out-Null
            Write-OK "Enabled '$($t.TaskName)'"
            Log-Info "Enabled task '$($t.TaskName)'"
        } else {
            Disable-ScheduledTask -TaskName $t.TaskName -TaskPath $Script:TaskFolder | Out-Null
            Write-OK "Disabled '$($t.TaskName)'"
            Log-Info "Disabled task '$($t.TaskName)'"
        }
    } catch {
        Write-Err "Enable/Disable failed: $_"
        Log-Error "Enable-DisableTask: $_"
    }
    Pause-Screen
}

function Invoke-TestRun {
    Show-Header
    Write-Host "  TEST RUN A TASK`n" -ForegroundColor White

    try {
        $tasks = @(Get-ScheduledTask -TaskPath "$Script:TaskFolder\" -ErrorAction SilentlyContinue)
        if (-not $tasks.Count) { Write-Warn "No managed tasks found."; Pause-Screen; return }

        $i = 1
        foreach ($t in $tasks) {
            Write-Host ("  {0,2}) {1}" -f $i, $t.TaskName) -ForegroundColor Yellow
            $i++
        }

        $pick = Read-Host "`n  Select task to test-run (0 to cancel)"
        if ($pick -eq '0') { return }
        $idx = [int]$pick - 1
        if ($idx -lt 0 -or $idx -ge $tasks.Count) { Write-Err "Invalid."; Pause-Screen; return }

        $t = $tasks[$idx]
        Write-Info "Starting task '$($t.TaskName)' immediately..."
        Start-ScheduledTask -TaskName $t.TaskName -TaskPath $Script:TaskFolder
        Write-OK "Task triggered. Check the job log for results:"
        Write-Host "  $(Join-Path $Script:LogDir "$($t.TaskName).log")" -ForegroundColor Cyan

    } catch {
        Write-Err "Test run failed: $_"
        Log-Error "Invoke-TestRun: $_"
    }
    Pause-Screen
}

function Show-Logs {
    Show-Header
    Write-Host "  VIEW JOB LOGS`n" -ForegroundColor White

    $logs = @(Get-ChildItem -Path $Script:LogDir -Filter '*.log' -ErrorAction SilentlyContinue | Sort-Object Name)
    if (-not $logs.Count) { Write-Warn "No logs found."; Pause-Screen; return }

    $i = 1
    foreach ($l in $logs) {
        Write-Host ("  {0,2}) {1}" -f $i, $l.Name) -ForegroundColor Yellow
        $i++
    }

    $pick = Read-Host "`n  Select log to tail (0 to cancel)"
    if ($pick -eq '0') { return }
    $idx = [int]$pick - 1
    if ($idx -lt 0 -or $idx -ge $logs.Count) { Write-Err "Invalid."; Pause-Screen; return }

    $target = $logs[$idx].FullName
    Write-Host "`nTailing $target — Ctrl-C to stop`n" -ForegroundColor Cyan

    # PowerShell tail -f equivalent
    $pos = (Get-Item $target).Length
    while ($true) {
        Start-Sleep -Milliseconds 500
        $newSize = (Get-Item $target).Length
        if ($newSize -gt $pos) {
            $stream = [System.IO.File]::Open($target, 'Open', 'Read', 'ReadWrite')
            $stream.Seek($pos, 'Begin') | Out-Null
            $reader = New-Object System.IO.StreamReader($stream)
            Write-Host $reader.ReadToEnd() -NoNewline
            $reader.Close(); $stream.Close()
            $pos = $newSize
        }
    }
}

# ─── Main ─────────────────────────────────────────────────────────────────────
function Main {
    if (-not (Test-Admin)) {
        Write-Warn "Not running as Administrator — some operations may fail."
        Write-Warn "Re-launch PowerShell as Administrator for full functionality."
        Start-Sleep -Seconds 2
    }

    Log-Info "task_manager started (user: $env:USERNAME)"

    while ($true) {
        Show-Header
        Write-Host "  1) List managed tasks"       -ForegroundColor Yellow
        Write-Host "  2) Add task (with fallback & failure handler)" -ForegroundColor Yellow
        Write-Host "  3) Remove task"              -ForegroundColor Yellow
        Write-Host "  4) Enable / Disable task"    -ForegroundColor Yellow
        Write-Host "  5) Test-run a task now"      -ForegroundColor Yellow
        Write-Host "  6) View / tail job logs"     -ForegroundColor Yellow
        Write-Host "  0) Exit`n"                   -ForegroundColor Yellow
        Write-Divider

        $choice = Read-Host "`n  Select option"
        switch ($choice) {
            '1' { Show-Tasks         }
            '2' { Add-ManagedTask    }
            '3' { Remove-ManagedTask }
            '4' { Enable-DisableTask }
            '5' { Invoke-TestRun     }
            '6' { Show-Logs          }
            '0' {
                Log-Info "task_manager exited"
                Write-Host "`nGoodbye.`n" -ForegroundColor Cyan
                return
            }
            default {
                Write-Err "Invalid option '$choice'."
                Start-Sleep -Seconds 1
            }
        }
    }
}

Main
