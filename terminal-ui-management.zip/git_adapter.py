"""
git_adapter.py — Git SCM Adapter
=================================
Full implementation of SCMProvider backed by native git CLI calls.
No libgit2 / pygit2 dependency — uses subprocess so this works anywhere
git is installed, keeps the install footprint zero.

PR management is local-first (stored in .git/scmtool/prs/) and can be
extended to sync with GitHub/GitLab/Gitea via remote adapters.
"""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Iterator, Optional

from core.scm_provider import (
    SCMProvider, SCMType, SCMError, SCMNotFoundError, SCMConflictError,
    SCMPermissionError, SCMValidationError,
    Author, Branch, Commit, CICheck, ConflictStatus, DiffStat, FileChange,
    FileChangeType, MergeResult, MergeStrategy, PRComment, PRState,
    PullRequest, Remote, RepoInfo, Review, ReviewDecision, Tag,
)


# ─── Helpers ──────────────────────────────────────────────────────────────────

def _parse_iso(s: str) -> datetime:
    try:
        return datetime.fromisoformat(s.replace("Z", "+00:00"))
    except ValueError:
        return datetime.utcnow()


def _parse_author_line(line: str) -> Author:
    """Parse 'Name <email> timestamp tz' or 'Name <email>'."""
    m = re.match(r'^(.*?)\s+<([^>]*)>\s*(\d+)?\s*([+-]\d{4})?$', line.strip())
    if m:
        name, email, ts, _ = m.groups()
        when = datetime.utcfromtimestamp(int(ts)) if ts else datetime.utcnow()
        return Author(name=name.strip(), email=email.strip(), when=when)
    return Author(name=line.strip(), email="", when=datetime.utcnow())


class GitAdapter(SCMProvider):
    """Git SCM adapter — subprocess-backed, zero external deps."""

    PR_STORE = ".git/scmtool/prs"

    def __init__(self, repo_path: str, actor: str = "scmtool"):
        super().__init__(repo_path, actor)
        self._git_dir: Optional[str] = None
        self._pr_dir  = Path(repo_path) / self.PR_STORE
        # Lazy-create PR store
        if self.is_valid_repo():
            self._pr_dir.mkdir(parents=True, exist_ok=True)

    # ── Internal subprocess wrapper ───────────────────────────────────────────

    def _git(self, *args: str, check: bool = True,
             capture: bool = True, cwd: Optional[str] = None,
             input: Optional[str] = None) -> subprocess.CompletedProcess:
        cmd = ["git", "-C", cwd or self.repo_path] + list(args)
        try:
            result = subprocess.run(
                cmd,
                capture_output=capture,
                text=True,
                input=input,
                env={**os.environ, "GIT_TERMINAL_PROMPT": "0"},
            )
        except FileNotFoundError:
            raise SCMError("git executable not found in PATH")

        if check and result.returncode != 0:
            stderr = result.stderr.strip()
            if "not a git repository" in stderr:
                raise SCMNotFoundError(f"Not a git repository: {self.repo_path}")
            if "pathspec" in stderr and "did not match" in stderr:
                raise SCMNotFoundError(stderr)
            if "Permission denied" in stderr:
                raise SCMPermissionError(stderr)
            if "CONFLICT" in stderr or "conflict" in stderr.lower():
                raise SCMConflictError(stderr)
            raise SCMError(stderr or f"git {args[0]} failed", result.returncode, stderr)
        return result

    def _git_out(self, *args: str, **kwargs) -> str:
        return self._git(*args, **kwargs).stdout.strip()

    # ── Lifecycle ─────────────────────────────────────────────────────────────

    @property
    def scm_type(self) -> SCMType:
        return SCMType.GIT

    def is_valid_repo(self) -> bool:
        try:
            r = self._git("rev-parse", "--git-dir", check=False)
            return r.returncode == 0
        except Exception:
            return False

    def get_repo_info(self) -> RepoInfo:
        name = Path(self.repo_path).name
        default = self._default_branch()
        remotes = self.list_remotes()
        is_bare = self._git_out("rev-parse", "--is-bare-repository") == "true"

        # Size in KB
        try:
            du = subprocess.run(
                ["du", "-sk", self.repo_path], capture_output=True, text=True
            )
            size_kb = int(du.stdout.split()[0]) if du.returncode == 0 else 0
        except Exception:
            size_kb = 0

        desc_path = Path(self.repo_path) / ".git" / "description"
        description = desc_path.read_text().strip() if desc_path.exists() else None
        if description and description.startswith("Unnamed repository"):
            description = None

        return RepoInfo(
            path=self.repo_path,
            scm_type=SCMType.GIT,
            name=name,
            default_branch=default,
            remotes=remotes,
            description=description,
            is_bare=is_bare,
            size_kb=size_kb,
        )

    def _default_branch(self) -> str:
        for candidate in ("main", "master", "trunk", "develop"):
            try:
                self._git("rev-parse", "--verify", candidate, check=True)
                return candidate
            except SCMError:
                pass
        try:
            return self._git_out("symbolic-ref", "--short", "HEAD")
        except SCMError:
            return "HEAD"

    # ── Commits ───────────────────────────────────────────────────────────────

    def get_commit(self, ref: str = "HEAD") -> Commit:
        fmt = "%H%n%h%n%s%n%b%n<<END>>%n%an%n%ae%n%at%n%cn%n%ce%n%ct%n%P%n%D"
        try:
            raw = self._git_out("show", "-s", f"--format={fmt}", ref)
        except SCMError as e:
            raise SCMNotFoundError(f"Commit '{ref}' not found") from e

        parts = raw.split("\n<<END>>\n", 1)
        header = parts[0].splitlines()
        rest   = parts[1].splitlines() if len(parts) > 1 else []

        sha       = header[0] if len(header) > 0 else ""
        short_sha = header[1] if len(header) > 1 else sha[:7]
        subject   = header[2] if len(header) > 2 else ""
        body      = header[3] if len(header) > 3 else ""
        message   = f"{subject}\n\n{body}".strip() if body else subject

        an = rest[0] if len(rest) > 0 else ""
        ae = rest[1] if len(rest) > 1 else ""
        at = rest[2] if len(rest) > 2 else "0"
        cn = rest[3] if len(rest) > 3 else an
        ce = rest[4] if len(rest) > 4 else ae
        ct = rest[5] if len(rest) > 5 else at
        parents_str = rest[6].strip() if len(rest) > 6 else ""
        refs_str    = rest[7].strip() if len(rest) > 7 else ""

        author    = Author(an, ae, datetime.utcfromtimestamp(int(at or 0)))
        committer = Author(cn, ce, datetime.utcfromtimestamp(int(ct or 0)))
        parents   = [p for p in parents_str.split() if p]
        refs      = [r.strip() for r in refs_str.split(",") if r.strip()]

        # Diff stats
        try:
            stat_raw = self._git_out("show", "--stat", "--format=", ref)
            last_line = [l for l in stat_raw.splitlines() if l.strip()][-1] if stat_raw.strip() else ""
            add_m = re.search(r'(\d+) insertion', last_line)
            del_m = re.search(r'(\d+) deletion',  last_line)
            fil_m = re.search(r'(\d+) file',       last_line)
            stats = {
                "additions": int(add_m.group(1)) if add_m else 0,
                "deletions": int(del_m.group(1)) if del_m else 0,
                "files":     int(fil_m.group(1)) if fil_m else 0,
            }
        except Exception:
            stats = {}

        return Commit(sha=sha, short_sha=short_sha, message=message,
                      author=author, committer=committer,
                      parents=parents, refs=refs, stats=stats)

    def log(
        self,
        ref: str = "HEAD",
        max_count: int = 50,
        path: Optional[str] = None,
        author: Optional[str] = None,
        since: Optional[datetime] = None,
        until: Optional[datetime] = None,
    ) -> Iterator[Commit]:
        args = ["log", f"--max-count={max_count}",
                "--format=%H", ref]
        if author: args += [f"--author={author}"]
        if since:  args += [f"--since={since.isoformat()}"]
        if until:  args += [f"--until={until.isoformat()}"]
        if path:   args += ["--", path]

        try:
            shas_raw = self._git_out(*args)
        except SCMError:
            return

        for sha in shas_raw.splitlines():
            if sha.strip():
                try:
                    yield self.get_commit(sha.strip())
                except SCMError:
                    pass

    def diff(self, from_ref: str, to_ref: str, path: Optional[str] = None) -> DiffStat:
        args = ["diff", "--numstat", from_ref, to_ref]
        if path: args += ["--", path]
        raw = self._git_out(*args, check=False)

        changes: list[FileChange] = []
        total_add = total_del = 0

        for line in raw.splitlines():
            if not line.strip(): continue
            parts = line.split("\t", 2)
            if len(parts) < 3: continue
            add_s, del_s, fpath = parts
            binary = add_s == "-"
            add = 0 if binary else int(add_s)
            dels = 0 if binary else int(del_s)
            total_add += add; total_del += dels

            # Detect renames "old => new"
            old_path = None
            if " => " in fpath:
                old_p, new_p = fpath.split(" => ", 1)
                old_path = old_p.strip()
                fpath = new_p.strip()
                ctype = FileChangeType.RENAMED
            else:
                ctype = FileChangeType.MODIFIED

            changes.append(FileChange(
                path=fpath, old_path=old_path,
                change_type=ctype,
                additions=add, deletions=dels, binary=binary,
            ))

        # Also pick up added/deleted files
        name_status = self._git_out("diff", "--name-status", from_ref, to_ref,
                                    check=False)
        type_map: dict[str, FileChangeType] = {}
        for line in name_status.splitlines():
            if not line.strip(): continue
            parts = line.split("\t", 1)
            if len(parts) < 2: continue
            status_char = parts[0][0]
            fname = parts[1].strip()
            type_map[fname] = {
                "A": FileChangeType.ADDED,
                "M": FileChangeType.MODIFIED,
                "D": FileChangeType.DELETED,
                "R": FileChangeType.RENAMED,
                "C": FileChangeType.COPIED,
            }.get(status_char, FileChangeType.UNKNOWN)

        for fc in changes:
            if fc.path in type_map:
                fc.change_type = type_map[fc.path]

        # Count truly added/deleted files not in numstat
        stat_raw = self._git_out("diff", "--stat", from_ref, to_ref, check=False)
        last = [l for l in stat_raw.splitlines() if l.strip()]
        files_changed = len(changes)
        if last:
            fm = re.search(r'(\d+) file', last[-1])
            if fm: files_changed = int(fm.group(1))

        return DiffStat(
            files_changed=files_changed,
            insertions=total_add,
            deletions=total_del,
            changes=changes,
        )

    # ── Branches ──────────────────────────────────────────────────────────────

    def list_branches(self, include_remote: bool = True) -> list[Branch]:
        fmt = "%(refname:short)|%(objectname:short)|%(upstream:short)|%(upstream:track)"
        args = ["branch", "--format", fmt]
        if include_remote: args.append("-a")
        raw = self._git_out(*args, check=False)
        branches: list[Branch] = []
        default = self._default_branch()
        current = self.current_branch()

        for line in raw.splitlines():
            if not line.strip(): continue
            parts = line.split("|")
            name     = parts[0].strip().lstrip("* ")
            sha      = parts[1].strip() if len(parts) > 1 else ""
            upstream = parts[2].strip() if len(parts) > 2 else ""
            track    = parts[3].strip() if len(parts) > 3 else ""
            is_remote = name.startswith("remotes/")
            if is_remote: name = name[len("remotes/"):]

            ahead = behind = 0
            m = re.search(r'ahead (\d+)', track)
            if m: ahead = int(m.group(1))
            m = re.search(r'behind (\d+)', track)
            if m: behind = int(m.group(1))

            branches.append(Branch(
                name=name, commit_sha=sha,
                is_remote=is_remote,
                upstream=upstream or None,
                ahead=ahead, behind=behind,
                is_default=(name == default),
                protected=(name in (default, "main", "master", "trunk")),
            ))
        return branches

    def get_branch(self, name: str) -> Branch:
        for b in self.list_branches():
            if b.name == name or b.name.endswith(f"/{name}"):
                return b
        raise SCMNotFoundError(f"Branch '{name}' not found")

    def create_branch(self, name: str, from_ref: str = "HEAD") -> Branch:
        if not re.match(r'^[\w./_-]+$', name):
            raise SCMValidationError(f"Invalid branch name: {name!r}")
        self._git("branch", name, from_ref)
        self._emit_audit("create_branch", {"name": name, "from": from_ref})
        return self.get_branch(name)

    def delete_branch(self, name: str, force: bool = False) -> None:
        flag = "-D" if force else "-d"
        self._git("branch", flag, name)
        self._emit_audit("delete_branch", {"name": name, "force": force})

    def current_branch(self) -> str:
        try:
            return self._git_out("symbolic-ref", "--short", "HEAD")
        except SCMError:
            return self._git_out("rev-parse", "--short", "HEAD")

    def checkout(self, ref: str) -> None:
        self._git("checkout", ref)
        self._emit_audit("checkout", {"ref": ref})

    # ── Tags ──────────────────────────────────────────────────────────────────

    def list_tags(self) -> list[Tag]:
        fmt = "%(refname:short)|%(objectname:short)|%(subject)|%(taggername)|%(taggeremail)|%(taggerdate:iso)"
        raw = self._git_out("tag", "--format", fmt, "--sort=-version:refname",
                            check=False)
        tags: list[Tag] = []
        for line in raw.splitlines():
            if not line.strip(): continue
            parts = line.split("|")
            name     = parts[0]
            sha      = parts[1] if len(parts) > 1 else ""
            msg      = parts[2] if len(parts) > 2 else None
            t_name   = parts[3] if len(parts) > 3 else ""
            t_email  = parts[4] if len(parts) > 4 else ""
            t_date   = parts[5] if len(parts) > 5 else ""
            tagger   = Author(t_name, t_email, _parse_iso(t_date)) if t_name else None
            annotated = bool(tagger)
            tags.append(Tag(name=name, commit_sha=sha, message=msg or None,
                            tagger=tagger, is_annotated=annotated))
        return tags

    def create_tag(self, name: str, ref: str = "HEAD",
                   message: Optional[str] = None) -> Tag:
        if message:
            self._git("tag", "-a", name, ref, "-m", message)
        else:
            self._git("tag", name, ref)
        self._emit_audit("create_tag", {"name": name, "ref": ref})
        for t in self.list_tags():
            if t.name == name: return t
        return Tag(name=name, commit_sha=ref)

    def delete_tag(self, name: str) -> None:
        self._git("tag", "-d", name)
        self._emit_audit("delete_tag", {"name": name})

    # ── Remotes ───────────────────────────────────────────────────────────────

    def list_remotes(self) -> list[Remote]:
        raw = self._git_out("remote", "-v", check=False)
        seen: dict[str, dict] = {}
        for line in raw.splitlines():
            m = re.match(r'^(\S+)\s+(\S+)\s+\((\w+)\)$', line)
            if not m: continue
            rname, url, rtype = m.groups()
            if rname not in seen: seen[rname] = {"fetch": "", "push": ""}
            seen[rname][rtype] = url
        return [Remote(name=n, fetch_url=v["fetch"], push_url=v["push"])
                for n, v in seen.items()]

    def fetch(self, remote: str = "origin", prune: bool = True) -> None:
        args = ["fetch", remote]
        if prune: args.append("--prune")
        self._git(*args)
        self._emit_audit("fetch", {"remote": remote})

    def pull(self, remote: str = "origin", branch: Optional[str] = None,
             strategy: MergeStrategy = MergeStrategy.MERGE) -> MergeResult:
        args = ["pull"]
        if strategy == MergeStrategy.REBASE: args.append("--rebase")
        elif strategy == MergeStrategy.FAST_FORWARD: args.append("--ff-only")
        args.append(remote)
        if branch: args.append(branch)
        try:
            self._git(*args)
            sha = self._git_out("rev-parse", "HEAD")
            self._emit_audit("pull", {"remote": remote, "branch": branch})
            return MergeResult(success=True, merge_sha=sha, strategy_used=strategy)
        except SCMConflictError as e:
            return MergeResult(success=False, error=str(e))

    def push(self, remote: str = "origin", branch: Optional[str] = None,
             force: bool = False, tags: bool = False) -> None:
        if branch is None: branch = self.current_branch()
        args = ["push", remote, branch]
        if force: args.append("--force-with-lease")
        if tags:  args.append("--tags")
        self._git(*args)
        self._emit_audit("push", {"remote": remote, "branch": branch, "force": force})

    # ── Merge ─────────────────────────────────────────────────────────────────

    def merge(self, source_branch: str, strategy: MergeStrategy = MergeStrategy.MERGE,
              message: Optional[str] = None) -> MergeResult:
        try:
            if strategy == MergeStrategy.SQUASH:
                self._git("merge", "--squash", source_branch)
                commit_msg = message or f"Squash merge {source_branch}"
                self._git("commit", "-m", commit_msg)
            elif strategy == MergeStrategy.FAST_FORWARD:
                self._git("merge", "--ff-only", source_branch)
            elif strategy == MergeStrategy.REBASE:
                return self.rebase(source_branch)
            else:
                args = ["merge", "--no-ff"]
                if message: args += ["-m", message]
                args.append(source_branch)
                self._git(*args)

            sha = self._git_out("rev-parse", "HEAD")
            self._emit_audit("merge", {"source": source_branch, "strategy": strategy.value})
            return MergeResult(success=True, merge_sha=sha, strategy_used=strategy)

        except SCMConflictError as e:
            conflict_files = self._get_conflict_files()
            self._emit_audit("merge", {"source": source_branch}, result="failure", error=str(e))
            return MergeResult(success=False, conflicts=conflict_files, error=str(e))

    def _get_conflict_files(self) -> list[str]:
        raw = self._git_out("diff", "--name-only", "--diff-filter=U", check=False)
        return [l.strip() for l in raw.splitlines() if l.strip()]

    def can_merge(self, source_branch: str, target_branch: str) -> ConflictStatus:
        """Dry-run via merge-tree to detect conflicts without touching working tree."""
        try:
            base = self._git_out("merge-base", source_branch, target_branch, check=False)
            if not base: return ConflictStatus.UNKNOWN
            result = self._git("merge-tree", base.strip(), target_branch, source_branch,
                               check=False)
            if "<<<<<" in result.stdout or "CONFLICT" in result.stdout:
                return ConflictStatus.CONFLICTS
            return ConflictStatus.NONE
        except Exception:
            return ConflictStatus.UNKNOWN

    def rebase(self, onto: str) -> MergeResult:
        try:
            self._git("rebase", onto)
            sha = self._git_out("rev-parse", "HEAD")
            self._emit_audit("rebase", {"onto": onto})
            return MergeResult(success=True, merge_sha=sha, strategy_used=MergeStrategy.REBASE)
        except SCMConflictError as e:
            self._git("rebase", "--abort", check=False)
            return MergeResult(success=False, error=str(e))

    def cherry_pick(self, sha: str) -> MergeResult:
        try:
            self._git("cherry-pick", sha)
            new_sha = self._git_out("rev-parse", "HEAD")
            self._emit_audit("cherry_pick", {"sha": sha})
            return MergeResult(success=True, merge_sha=new_sha)
        except SCMConflictError as e:
            self._git("cherry-pick", "--abort", check=False)
            return MergeResult(success=False, error=str(e))

    # ── Pull Requests (local store) ────────────────────────────────────────────

    def _pr_path(self, pr_id: str) -> Path:
        return self._pr_dir / f"{pr_id}.json"

    def _load_pr(self, pr_id: str) -> PullRequest:
        path = self._pr_path(pr_id)
        if not path.exists():
            raise SCMNotFoundError(f"Pull request '{pr_id}' not found")
        data = json.loads(path.read_text())
        return self._pr_from_dict(data)

    def _save_pr(self, pr: PullRequest) -> None:
        self._pr_path(pr.id).write_text(json.dumps(self._pr_to_dict(pr), indent=2))

    def _pr_to_dict(self, pr: PullRequest) -> dict:
        def author_d(a: Author) -> dict:
            return {"name": a.name, "email": a.email, "when": a.when.isoformat()}
        def comment_d(c: PRComment) -> dict:
            return {"id": c.id, "author": author_d(c.author), "body": c.body,
                    "created_at": c.created_at.isoformat(),
                    "file_path": c.file_path, "line": c.line, "resolved": c.resolved}
        def review_d(r: Review) -> dict:
            return {"id": r.id, "author": author_d(r.author),
                    "decision": r.decision.value, "body": r.body,
                    "created_at": r.created_at.isoformat(),
                    "comments": [comment_d(c) for c in r.comments]}
        return {
            "id": pr.id, "title": pr.title, "description": pr.description,
            "source_branch": pr.source_branch, "target_branch": pr.target_branch,
            "author": author_d(pr.author),
            "state": pr.state.value,
            "created_at": pr.created_at.isoformat(),
            "updated_at": pr.updated_at.isoformat(),
            "reviewers": pr.reviewers, "labels": pr.labels,
            "comments": [comment_d(c) for c in pr.comments],
            "reviews": [review_d(r) for r in pr.reviews],
            "conflicts": pr.conflicts.value,
            "mergeable": pr.mergeable,
            "merge_strategy": pr.merge_strategy.value,
            "metadata": pr.metadata,
        }

    def _pr_from_dict(self, d: dict) -> PullRequest:
        def mk_author(a: dict) -> Author:
            return Author(a["name"], a["email"], _parse_iso(a.get("when", "")))
        def mk_comment(c: dict) -> PRComment:
            return PRComment(id=c["id"], author=mk_author(c["author"]),
                             body=c["body"], created_at=_parse_iso(c["created_at"]),
                             file_path=c.get("file_path"), line=c.get("line"),
                             resolved=c.get("resolved", False))
        def mk_review(r: dict) -> Review:
            return Review(id=r["id"], author=mk_author(r["author"]),
                          decision=ReviewDecision(r["decision"]), body=r["body"],
                          created_at=_parse_iso(r["created_at"]),
                          comments=[mk_comment(c) for c in r.get("comments", [])])
        return PullRequest(
            id=d["id"], title=d["title"], description=d["description"],
            source_branch=d["source_branch"], target_branch=d["target_branch"],
            author=mk_author(d["author"]),
            state=PRState(d["state"]),
            created_at=_parse_iso(d["created_at"]),
            updated_at=_parse_iso(d["updated_at"]),
            reviewers=d.get("reviewers", []),
            labels=d.get("labels", []),
            comments=[mk_comment(c) for c in d.get("comments", [])],
            reviews=[mk_review(r) for r in d.get("reviews", [])],
            conflicts=ConflictStatus(d.get("conflicts", "unknown")),
            mergeable=d.get("mergeable", True),
            merge_strategy=MergeStrategy(d.get("merge_strategy", "merge")),
            metadata=d.get("metadata", {}),
        )

    def list_pull_requests(self, state: PRState = PRState.OPEN) -> list[PullRequest]:
        prs = []
        for f in self._pr_dir.glob("*.json"):
            try:
                pr = self._pr_from_dict(json.loads(f.read_text()))
                if state is None or pr.state == state:
                    prs.append(pr)
            except Exception:
                pass
        return sorted(prs, key=lambda p: p.created_at, reverse=True)

    def get_pull_request(self, pr_id: str) -> PullRequest:
        return self._load_pr(pr_id)

    def create_pull_request(
        self, title: str, description: str,
        source_branch: str, target_branch: str,
        reviewers: list[str] = None, labels: list[str] = None,
        draft: bool = False,
    ) -> PullRequest:
        if not title.strip():
            raise SCMValidationError("PR title cannot be empty")
        try: self.get_branch(source_branch)
        except SCMNotFoundError:
            raise SCMValidationError(f"Source branch '{source_branch}' does not exist")
        try: self.get_branch(target_branch)
        except SCMNotFoundError:
            raise SCMValidationError(f"Target branch '{target_branch}' does not exist")

        conflicts = self.can_merge(source_branch, target_branch)
        pr = PullRequest(
            id=str(uuid.uuid4())[:8],
            title=title, description=description,
            source_branch=source_branch, target_branch=target_branch,
            author=Author(self.actor, "", datetime.utcnow()),
            state=PRState.DRAFT if draft else PRState.OPEN,
            reviewers=reviewers or [],
            labels=labels or [],
            conflicts=conflicts,
            mergeable=(conflicts == ConflictStatus.NONE),
        )
        self._save_pr(pr)
        self._emit_audit("create_pr", {"id": pr.id, "title": title,
                                        "source": source_branch, "target": target_branch})
        return pr

    def update_pull_request(self, pr_id: str, **kwargs) -> PullRequest:
        pr = self._load_pr(pr_id)
        allowed = {"title", "description", "reviewers", "labels", "merge_strategy", "state"}
        for k, v in kwargs.items():
            if k in allowed:
                if k == "state": v = PRState(v)
                if k == "merge_strategy": v = MergeStrategy(v)
                setattr(pr, k, v)
        pr.updated_at = datetime.utcnow()
        pr.conflicts = self.can_merge(pr.source_branch, pr.target_branch)
        pr.mergeable = (pr.conflicts == ConflictStatus.NONE)
        self._save_pr(pr)
        self._emit_audit("update_pr", {"id": pr_id, **kwargs})
        return pr

    def close_pull_request(self, pr_id: str) -> PullRequest:
        return self.update_pull_request(pr_id, state="closed")

    def merge_pull_request(
        self, pr_id: str,
        strategy: MergeStrategy = MergeStrategy.MERGE,
        message: Optional[str] = None,
        delete_branch: bool = False,
    ) -> MergeResult:
        pr = self._load_pr(pr_id)
        if pr.state != PRState.OPEN:
            raise SCMValidationError(f"PR #{pr_id} is {pr.state.value}, not open")

        current = self.current_branch()
        try:
            self.checkout(pr.target_branch)
            result = self.merge(
                pr.source_branch, strategy=strategy,
                message=message or f"Merge PR #{pr.id}: {pr.title}",
            )
            if result.success:
                pr.state = PRState.MERGED
                pr.updated_at = datetime.utcnow()
                self._save_pr(pr)
                if delete_branch:
                    try: self.delete_branch(pr.source_branch)
                    except SCMError: pass
                self._emit_audit("merge_pr", {"id": pr_id, "strategy": strategy.value})
        finally:
            if self.current_branch() != current:
                try: self.checkout(current)
                except SCMError: pass
        return result

    def add_review(self, pr_id: str, decision: ReviewDecision, body: str = "") -> Review:
        pr = self._load_pr(pr_id)
        review = Review(
            id=str(uuid.uuid4())[:8],
            author=Author(self.actor, "", datetime.utcnow()),
            decision=decision, body=body,
        )
        pr.reviews.append(review)
        pr.updated_at = datetime.utcnow()
        self._save_pr(pr)
        self._emit_audit("add_review", {"pr_id": pr_id, "decision": decision.value})
        return review

    def add_comment(self, pr_id: str, body: str,
                    file_path: Optional[str] = None, line: Optional[int] = None) -> PRComment:
        pr = self._load_pr(pr_id)
        comment = PRComment(
            id=str(uuid.uuid4())[:8],
            author=Author(self.actor, "", datetime.utcnow()),
            body=body, file_path=file_path, line=line,
        )
        pr.comments.append(comment)
        pr.updated_at = datetime.utcnow()
        self._save_pr(pr)
        self._emit_audit("add_comment", {"pr_id": pr_id})
        return comment

    # ── Stash ─────────────────────────────────────────────────────────────────

    def stash_push(self, message: Optional[str] = None) -> str:
        args = ["stash", "push"]
        if message: args += ["-m", message]
        self._git(*args)
        return self._git_out("stash", "list", "--format=%gD", check=False).splitlines()[0]

    def stash_list(self) -> list[dict]:
        raw = self._git_out("stash", "list", "--format=%gd|%gs|%gD", check=False)
        result = []
        for line in raw.splitlines():
            if not line.strip(): continue
            parts = line.split("|", 2)
            result.append({
                "index": parts[0], "message": parts[1] if len(parts) > 1 else "",
                "ref": parts[2] if len(parts) > 2 else "",
            })
        return result

    def stash_pop(self, index: int = 0) -> None:
        self._git("stash", "pop", f"stash@{{{index}}}")

    def stash_drop(self, index: int = 0) -> None:
        self._git("stash", "drop", f"stash@{{{index}}}")

    # ── Working tree ──────────────────────────────────────────────────────────

    def status(self) -> list[FileChange]:
        raw = self._git_out("status", "--porcelain=v1", "-u", check=False)
        changes = []
        type_map = {
            "A": FileChangeType.ADDED, "M": FileChangeType.MODIFIED,
            "D": FileChangeType.DELETED, "R": FileChangeType.RENAMED,
            "C": FileChangeType.COPIED, "U": FileChangeType.UNMERGED,
        }
        for line in raw.splitlines():
            if len(line) < 4: continue
            xy = line[:2]
            fpath = line[3:].strip()
            old_path = None
            if " -> " in fpath:
                old_path, fpath = fpath.split(" -> ", 1)
            x_char = xy[0].strip()
            ctype = type_map.get(x_char, FileChangeType.UNKNOWN)
            changes.append(FileChange(path=fpath, old_path=old_path, change_type=ctype))
        return changes

    def stage(self, paths: list[str]) -> None:
        self._git("add", "--", *paths)

    def unstage(self, paths: list[str]) -> None:
        self._git("reset", "HEAD", "--", *paths)

    def commit(self, message: str, amend: bool = False) -> Commit:
        args = ["commit", "-m", message]
        if amend: args.append("--amend")
        self._git(*args)
        sha = self._git_out("rev-parse", "HEAD")
        self._emit_audit("commit", {"message": message[:80]})
        return self.get_commit(sha)

    def discard(self, paths: list[str]) -> None:
        self._git("checkout", "--", *paths)

    # ── Hooks ─────────────────────────────────────────────────────────────────

    def install_hook(self, hook_name: str, script_path: str) -> None:
        hooks_dir = Path(self.repo_path) / ".git" / "hooks"
        hooks_dir.mkdir(exist_ok=True)
        dest = hooks_dir / hook_name
        shutil.copy2(script_path, dest)
        dest.chmod(0o750)
        self._emit_audit("install_hook", {"hook": hook_name})

    def list_hooks(self) -> list[str]:
        hooks_dir = Path(self.repo_path) / ".git" / "hooks"
        if not hooks_dir.exists(): return []
        return [f.name for f in hooks_dir.iterdir()
                if f.is_file() and not f.name.endswith(".sample") and os.access(f, os.X_OK)]

    # ── Extras ────────────────────────────────────────────────────────────────

    def get_file_at_ref(self, path: str, ref: str = "HEAD") -> str:
        return self._git_out("show", f"{ref}:{path}")

    def blame(self, path: str, ref: str = "HEAD") -> str:
        return self._git_out("blame", "--date=short", ref, "--", path)

    def shortlog(self, ref: str = "HEAD", max_count: int = 20) -> str:
        return self._git_out("shortlog", "-s", "-n", f"--max-count={max_count}", ref,
                             check=False)

    def gc(self) -> None:
        self._git("gc", "--auto", "--quiet")
