#!/usr/bin/env bash
# =============================================================================
# gitcron_manager.sh — Git-Native Task & Pipeline Scheduler
# Author  : Cybopsec
# Version : 3.0.0
#
# Architecture:
#   cron / time-based triggers  ──┐
#   git hooks (all 30+ hooks)   ──┤──► wrapper engine ──► primary
#   manual / test-run           ──┘         │               │ fail
#                                           │            fallback
#                                           │               │ fail
#                                      git log/tag      fail-handler
#                                      audit trail      (notify/log/
#                                                        shutdown/custom)
#
# Requires: bash 4+, git 2.x, crontab, tput
# =============================================================================

set -euo pipefail
IFS=$'\n\t'

# ─── Paths ────────────────────────────────────────────────────────────────────
BASE_DIR="${HOME}/.gitcron"
WRAPPER_DIR="${BASE_DIR}/wrappers"
LOG_DIR="${BASE_DIR}/logs"
REPO_DIR="${BASE_DIR}/repos"
PIPELINE_DIR="${BASE_DIR}/pipelines"
BACKUP_DIR="${BASE_DIR}/backups"
MGR_LOG="${BASE_DIR}/manager.log"

for d in "$WRAPPER_DIR" "$LOG_DIR" "$REPO_DIR" "$PIPELINE_DIR" "$BACKUP_DIR"; do
  mkdir -p "$d"
done

# ─── All standard git hooks ───────────────────────────────────────────────────
# Format: "hook-name|description|trigger-phase"
GIT_HOOKS=(
  "applypatch-msg|Validate patch message|apply-patch"
  "pre-applypatch|Before patch is applied|apply-patch"
  "post-applypatch|After patch is applied|apply-patch"
  "pre-commit|Before commit is created|commit"
  "prepare-commit-msg|Populate commit message template|commit"
  "commit-msg|Validate commit message|commit"
  "post-commit|After commit is created|commit"
  "pre-rebase|Before rebase begins|rebase"
  "post-checkout|After checkout or clone|checkout"
  "post-merge|After successful merge|merge"
  "pre-push|Before push to remote|push"
  "pre-receive|Remote: before refs are updated|receive"
  "update|Remote: before each ref is updated|receive"
  "post-receive|Remote: after refs updated|receive"
  "post-update|Remote: after all refs updated|receive"
  "reference-transaction|During reference transaction|refs"
  "push-to-checkout|Remote: non-bare push|push"
  "pre-auto-gc|Before automatic garbage collection|maintenance"
  "post-rewrite|After rebase or amend rewrites|rewrite"
  "sendemail-validate|Before git send-email|email"
  "fsmonitor-watchman|Filesystem monitor integration|monitor"
  "p4-changelist|Perforce changelist integration|p4"
  "p4-prepare-changelist|Perforce before changelist edit|p4"
  "p4-post-changelist|Perforce after changelist submit|p4"
  "p4-pre-submit|Perforce before submit|p4"
  "post-index-change|After index is written|index"
)

# ─── Colour / TUI ─────────────────────────────────────────────────────────────
if tput setaf 1 &>/dev/null 2>&1; then
  RED=$(tput setaf 1)  GRN=$(tput setaf 2)  YLW=$(tput setaf 3)
  BLU=$(tput setaf 4)  MAG=$(tput setaf 5)  CYN=$(tput setaf 6)
  WHT=$(tput setaf 7)  BLD=$(tput bold)     DIM=$(tput dim)
  RST=$(tput sgr0)
else
  RED='' GRN='' YLW='' BLU='' MAG='' CYN='' WHT='' BLD='' DIM='' RST=''
fi

# ─── Logging ──────────────────────────────────────────────────────────────────
_log() {
  local level="$1"; shift
  printf '[%s] [%-5s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$level" "$*" \
    | tee -a "$MGR_LOG"
}
log_info()  { _log INFO  "$*"; }
log_warn()  { _log WARN  "$*"; }
log_err()   { _log ERROR "$*"; }

# ─── UI helpers ───────────────────────────────────────────────────────────────
header() {
  clear
  printf '%s' "$BLD$CYN"
  printf '╔══════════════════════════════════════════════════════════════╗\n'
  printf '║       GITCRON MANAGER  v3.0  //  Cybopsec                   ║\n'
  printf '║       Git-Native Pipeline & Task Scheduler                   ║\n'
  printf '╚══════════════════════════════════════════════════════════════╝\n'
  printf '%s\n' "$RST"
}

sub_header() {
  printf '\n%s  ── %s ──%s\n\n' "$BLD$WHT" "$1" "$RST"
}

ok()     { printf '%s[✔]%s %s\n'   "$GRN$BLD" "$RST" "$*"; }
warn()   { printf '%s[!]%s %s\n'   "$YLW$BLD" "$RST" "$*"; }
err()    { printf '%s[✘]%s %s\n'   "$RED$BLD" "$RST" "$*" >&2; }
info()   { printf '%s[i]%s %s\n'   "$BLU$BLD" "$RST" "$*"; }
git_ic() { printf '%s[git]%s %s\n' "$MAG$BLD" "$RST" "$*"; }
div()    { printf '%s%s%s\n' "$BLU" "$(printf '─%.0s' {1..62})" "$RST"; }
pause()  { printf '\n'; read -rp "${BLD}Press [Enter] to continue...${RST} "; }

# ─── Validation ───────────────────────────────────────────────────────────────
is_git_repo()   { git -C "$1" rev-parse --git-dir &>/dev/null 2>&1; }
is_executable() { [[ -f "$1" && -x "$1" ]]; }
nonempty()      { [[ -n "${1// /}" ]]; }

validate_cron() {
  [[ "$1" =~ ^@(reboot|hourly|daily|weekly|monthly|yearly|annually)$ ]] && return 0
  [[ "$1" =~ ^([0-9*,\-/]+[[:space:]]+){4}[0-9*,\-/]+$ ]] && return 0
  return 1
}

# ─── Git helpers ──────────────────────────────────────────────────────────────
git_log_event() {
  # Write a structured event into the repo's git notes / tag for audit trail
  local repo="$1" event="$2" status="$3" detail="$4"
  local ts; ts=$(date '+%Y-%m-%dT%H:%M:%S')
  local msg="[GITCRON] ts=${ts} event=${event} status=${status} detail=${detail}"

  if is_git_repo "$repo"; then
    (
      cd "$repo"
      # Write to a dedicated gitcron-events branch ref note
      git notes --ref=gitcron-events append -m "$msg" HEAD 2>/dev/null || true
    )
  fi
}

get_repo_list() {
  find "$REPO_DIR" -maxdepth 2 -name '.git' -type d 2>/dev/null \
    | sed 's|/.git||' | sort
}

get_tracked_repos() {
  # Returns repos registered in our tracking file
  local track="${BASE_DIR}/tracked_repos.txt"
  [[ -f "$track" ]] && cat "$track" || true
}

register_repo() {
  local path="$1"
  local track="${BASE_DIR}/tracked_repos.txt"
  grep -qxF "$path" "$track" 2>/dev/null || echo "$path" >> "$track"
}

unregister_repo() {
  local path="$1"
  local track="${BASE_DIR}/tracked_repos.txt"
  [[ -f "$track" ]] && sed -i "\|^${path}$|d" "$track"
}

# ─── Hook engine ──────────────────────────────────────────────────────────────
# Installs a dispatcher hook that reads a per-hook pipeline definition
# and executes stages with primary→fallback→fail-handler logic
install_hook_dispatcher() {
  local repo="$1"
  local hook_name="$2"
  local hooks_dir="${repo}/.git/hooks"

  mkdir -p "$hooks_dir"

  local hook_script="${hooks_dir}/${hook_name}"
  local pipeline_file="${PIPELINE_DIR}/$(basename "$repo")_${hook_name}.pipeline"

  cat > "$hook_script" <<HOOK
#!/usr/bin/env bash
# GitCron dispatcher: ${hook_name}
# Managed by gitcron_manager.sh
set -uo pipefail

HOOK_NAME="${hook_name}"
REPO_PATH="${repo}"
PIPELINE_FILE="${pipeline_file}"
LOG_FILE="${LOG_DIR}/$(basename "$repo")_${hook_name}.log"
TS="\$(date '+%Y-%m-%d %H:%M:%S')"

_hlog() { printf '[%s] [%s] %s\n' "\$TS" "\$HOOK_NAME" "\$*" >> "\$LOG_FILE"; }

_hlog "=== Hook fired: \$HOOK_NAME ==="

# Pass all hook args through (some hooks receive args: ref names, SHAs, etc.)
HOOK_ARGS=("\$@")

if [[ ! -f "\$PIPELINE_FILE" ]]; then
  _hlog "No pipeline file found at \$PIPELINE_FILE — hook is a no-op"
  exit 0
fi

# ── Read and execute each stage from the pipeline file ────────────────────
# Pipeline file format (one stage per line):
#   STAGE|primary_exe|primary_args|fallback_exe|fallback_args|fail_action|custom_cmd
stage_num=0
overall_exit=0

while IFS='|' read -r stage pexe pargs fexe fargs faction fcmd; do
  [[ "$stage" == '#'* || -z "$stage" ]] && continue
  stage_num=\$((stage_num + 1))
  _hlog "STAGE \${stage_num} [\${stage}] starting"

  # ── Primary ──────────────────────────────────────────────────────────────
  _hlog "  primary: \${pexe} \${pargs}"
  if "\${pexe}" \${pargs} "\${HOOK_ARGS[@]+"}\${HOOK_ARGS[@]}"}" >> "\$LOG_FILE" 2>&1; then
    _hlog "  primary SUCCESS"
    continue
  fi

  _hlog "  WARN primary failed — trying fallback"

  # ── Fallback ─────────────────────────────────────────────────────────────
  if [[ -n "\${fexe}" ]]; then
    _hlog "  fallback: \${fexe} \${fargs}"
    if "\${fexe}" \${fargs} "\${HOOK_ARGS[@]+"}\${HOOK_ARGS[@]}"}" >> "\$LOG_FILE" 2>&1; then
      _hlog "  fallback SUCCESS"
      continue
    fi
    _hlog "  ERROR fallback also failed"
  else
    _hlog "  No fallback configured for stage \${stage}"
  fi

  _hlog "  FULL_FAIL stage=\${stage} handler=\${faction}"
  overall_exit=2

  # ── Full-fail handler ─────────────────────────────────────────────────────
  case "\${faction}" in
    notify)
      FAIL_MSG="[GITCRON FAIL] Hook=\${HOOK_NAME} Stage=\${stage} @ \${TS}"
      command -v notify-send &>/dev/null && \
        notify-send -u critical "GitCron Hook Failure" "\$FAIL_MSG" 2>/dev/null || true
      command -v wall &>/dev/null && echo "\$FAIL_MSG" | wall 2>/dev/null || true
      _hlog "  fail-handler: notification sent"
      ;;
    abort)
      _hlog "  fail-handler: ABORT — blocking git operation"
      exit 1  # Non-zero exit blocks the git operation on blocking hooks
      ;;
    log)
      _hlog "  fail-handler: log only"
      printf '\\n%s\\n' "=== FULL FAILURE @ \${TS} stage=\${stage} ===" >> "\$LOG_FILE"
      ;;
    shutdown)
      _hlog "  fail-handler: system shutdown"
      sudo shutdown -h now "gitcron \${HOOK_NAME} \${stage} failure" || \
        _hlog "  shutdown failed — check sudo"
      exit 2
      ;;
    custom)
      _hlog "  fail-handler: custom"
      eval "\${fcmd}" >> "\$LOG_FILE" 2>&1 || \
        _hlog "  custom handler also failed"
      ;;
    *)
      _hlog "  fail-handler: unknown '\${faction}' — logged only"
      ;;
  esac

done < "\$PIPELINE_FILE"

# Record event in git notes for audit trail
cd "\$REPO_PATH" 2>/dev/null && \
  git notes --ref=gitcron-events append \
    -m "[GITCRON] hook=\${HOOK_NAME} stages=\${stage_num} exit=\${overall_exit} ts=\${TS}" \
    HEAD 2>/dev/null || true

exit \$overall_exit
HOOK

  chmod 750 "$hook_script"
  _log INFO "Installed hook dispatcher: $hook_script"
}

# ─── Pipeline file editor ─────────────────────────────────────────────────────
add_pipeline_stage() {
  local pipeline_file="$1"
  local stage_name="$2"

  sub_header "Pipeline Stage: ${stage_name}"

  # Primary
  local pexe
  while true; do
    read -rp "  ${BLD}Primary executable path${RST}: " pexe
    is_executable "$pexe" && break
    err "'$pexe' not found or not executable."
  done
  local pargs
  read -rp "  ${BLD}Primary arguments${RST} (script path + flags): " pargs

  # Fallback
  div
  info "Optional: fallback if primary fails."
  local use_fb; read -rp "  Add fallback? [y/N]: " use_fb
  local fexe="" fargs=""
  if [[ "$use_fb" =~ ^[Yy]$ ]]; then
    while true; do
      read -rp "  ${BLD}Fallback executable path${RST}: " fexe
      is_executable "$fexe" && break
      err "'$fexe' not found or not executable."
    done
    read -rp "  ${BLD}Fallback arguments${RST}: " fargs
  fi

  # Fail action
  div
  printf '  %sOn full failure for this stage:%s\n' "$BLD" "$RST"
  printf '    1) notify  — desktop/wall alert\n'
  printf '    2) abort   — block the git operation (exit 1)\n'
  printf '    3) log     — silent log only (default)\n'
  printf '    4) shutdown— shutdown system\n'
  printf '    5) custom  — run custom command\n'
  local fc; read -rp "  Choice [1-5, default=3]: " fc
  local faction="log" fcmd=""
  case "$fc" in
    1) faction="notify"   ;;
    2) faction="abort"    ;;
    4) faction="shutdown" ;;
    5) faction="custom"
       read -rp "  ${BLD}Custom failure command${RST}: " fcmd ;;
  esac

  # Append to pipeline file
  printf '%s|%s|%s|%s|%s|%s|%s\n' \
    "$stage_name" "$pexe" "$pargs" "$fexe" "$fargs" "$faction" "$fcmd" \
    >> "$pipeline_file"

  ok "Stage '$stage_name' added to pipeline."
}

# ─── Cron wrapper builder ─────────────────────────────────────────────────────
build_cron_wrapper() {
  local job_name="$1"
  local repo_path="${2:-}"  # optional: bind job to a repo for git logging
  local primary_exe="$3"
  local primary_args="$4"
  local fallback_exe="$5"
  local fallback_args="$6"
  local fail_action="$7"
  local custom_cmd="$8"

  local wrapper="${WRAPPER_DIR}/${job_name}.sh"
  local job_log="${LOG_DIR}/${job_name}.log"

  cat > "$wrapper" <<WRAPPER
#!/usr/bin/env bash
# GitCron wrapper: ${job_name}
set -uo pipefail
JOB_NAME="${job_name}"
REPO_PATH="${repo_path}"
JOB_LOG="${job_log}"
TS="\$(date '+%Y-%m-%d %H:%M:%S')"

_wlog() { printf '[%s] [%s] %s\n' "\$TS" "\$JOB_NAME" "\$*" >> "\$JOB_LOG"; }

_git_audit() {
  local status="\$1" detail="\$2"
  if [[ -n "\$REPO_PATH" ]] && git -C "\$REPO_PATH" rev-parse --git-dir &>/dev/null 2>&1; then
    git -C "\$REPO_PATH" notes --ref=gitcron-events append \
      -m "[GITCRON] job=\${JOB_NAME} status=\${status} detail=\${detail} ts=\${TS}" \
      HEAD 2>/dev/null || true
  fi
}

_wlog "=== START ==="

# ── Primary ────────────────────────────────────────────────────────────────
_wlog "primary: ${primary_exe} ${primary_args}"
if "${primary_exe}" ${primary_args} >> "\$JOB_LOG" 2>&1; then
  _wlog "PRIMARY SUCCESS"
  _git_audit "success" "primary"
  exit 0
fi
_wlog "WARN primary failed"

WRAPPER

  if [[ -n "$fallback_exe" ]]; then
    cat >> "$wrapper" <<WRAPPER
# ── Fallback ───────────────────────────────────────────────────────────────
_wlog "fallback: ${fallback_exe} ${fallback_args}"
if "${fallback_exe}" ${fallback_args} >> "\$JOB_LOG" 2>&1; then
  _wlog "FALLBACK SUCCESS"
  _git_audit "success" "fallback"
  exit 0
fi
_wlog "ERROR fallback failed"

WRAPPER
  fi

  cat >> "$wrapper" <<WRAPPER
_wlog "FULL_FAIL handler=${fail_action}"
_git_audit "FULL_FAIL" "${fail_action}"

WRAPPER

  case "$fail_action" in
    notify)
      cat >> "$wrapper" <<'WRAPPER'
FAIL_MSG="[GITCRON FAIL] ${JOB_NAME} @ ${TS}"
command -v notify-send &>/dev/null && \
  notify-send -u critical "GitCron Failure" "$FAIL_MSG" 2>/dev/null || true
command -v wall &>/dev/null && echo "$FAIL_MSG" | wall 2>/dev/null || true
_wlog "fail-handler: notification sent"
exit 2
WRAPPER
      ;;
    log)
      cat >> "$wrapper" <<'WRAPPER'
printf '\n%s\n' "=== FULL FAILURE @ ${TS} ===" >> "$JOB_LOG"
_wlog "fail-handler: log only"
exit 2
WRAPPER
      ;;
    shutdown)
      cat >> "$wrapper" <<'WRAPPER'
_wlog "fail-handler: initiating shutdown"
sudo shutdown -h now "gitcron ${JOB_NAME} failure" || _wlog "shutdown failed"
exit 2
WRAPPER
      ;;
    custom)
      cat >> "$wrapper" <<WRAPPER
_wlog "fail-handler: custom"
${custom_cmd} >> "\$JOB_LOG" 2>&1 || _wlog "custom handler also failed"
exit 2
WRAPPER
      ;;
  esac

  chmod 750 "$wrapper"
  echo "$wrapper"
}

# ══════════════════════════════════════════════════════════════════════════════
#  MENU FUNCTIONS
# ══════════════════════════════════════════════════════════════════════════════

# ─── [1] Repo Management ──────────────────────────────────────────────────────
menu_repos() {
  while true; do
    header
    sub_header "Repository Management"
    printf '  %s1)%s Clone a repository\n'          "$YLW$BLD" "$RST"
    printf '  %s2)%s Init a new repository\n'       "$YLW$BLD" "$RST"
    printf '  %s3)%s Track an existing repository\n' "$YLW$BLD" "$RST"
    printf '  %s4)%s List tracked repositories\n'   "$YLW$BLD" "$RST"
    printf '  %s5)%s Repository status overview\n'  "$YLW$BLD" "$RST"
    printf '  %s6)%s View git log for a repo\n'     "$YLW$BLD" "$RST"
    printf '  %s7)%s View GitCron audit notes\n'    "$YLW$BLD" "$RST"
    printf '  %s0)%s Back\n\n'                      "$YLW$BLD" "$RST"
    div
    local c; read -rp "  Choice: " c
    case "$c" in
      1) _repo_clone   ;;
      2) _repo_init    ;;
      3) _repo_track   ;;
      4) _repo_list    ;;
      5) _repo_status  ;;
      6) _repo_log     ;;
      7) _repo_notes   ;;
      0) return        ;;
      *) err "Invalid."; sleep 1 ;;
    esac
  done
}

_repo_clone() {
  header; sub_header "Clone Repository"
  local url; read -rp "  Remote URL: " url
  nonempty "$url" || { err "URL required."; pause; return; }
  local name; name=$(basename "${url%.git}")
  local dest="${REPO_DIR}/${name}"
  git_ic "Cloning $url → $dest"
  if git clone "$url" "$dest"; then
    register_repo "$dest"
    ok "Cloned and registered: $dest"
    log_info "Cloned $url → $dest"
  else
    err "Clone failed."
    log_err "Clone failed: $url"
  fi
  pause
}

_repo_init() {
  header; sub_header "Init Repository"
  local name; read -rp "  Repository name: " name
  nonempty "$name" || { err "Name required."; pause; return; }
  local dest="${REPO_DIR}/${name}"
  mkdir -p "$dest"
  if git init "$dest"; then
    register_repo "$dest"
    ok "Initialized: $dest"
    log_info "Init repo: $dest"
  else
    err "Init failed."
  fi
  pause
}

_repo_track() {
  header; sub_header "Track Existing Repository"
  local path; read -rp "  Absolute path to repo: " path
  if is_git_repo "$path"; then
    register_repo "$path"
    ok "Now tracking: $path"
    log_info "Tracking repo: $path"
  else
    err "'$path' is not a git repository."
  fi
  pause
}

_repo_list() {
  header; sub_header "Tracked Repositories"
  local repos; repos=$(get_tracked_repos)
  if [[ -z "$repos" ]]; then
    warn "No repositories tracked yet."
  else
    local i=1
    while IFS= read -r r; do
      local branch="(unknown)"
      is_git_repo "$r" && branch=$(git -C "$r" branch --show-current 2>/dev/null || echo "detached")
      printf '  %s%2d)%s %-40s  %s[%s]%s\n' \
        "$YLW$BLD" "$i" "$RST" "$r" "$CYN" "$branch" "$RST"
      i=$((i+1))
    done <<< "$repos"
  fi
  pause
}

_repo_status() {
  header; sub_header "Repository Status Overview"
  local repos; repos=$(get_tracked_repos)
  [[ -z "$repos" ]] && { warn "No repos tracked."; pause; return; }
  while IFS= read -r r; do
    printf '\n%s%s%s\n' "$BLD$CYN" "$r" "$RST"
    if is_git_repo "$r"; then
      git -C "$r" status -sb 2>/dev/null || true
      local ahead_behind
      ahead_behind=$(git -C "$r" rev-list --count --left-right '@{upstream}...HEAD' 2>/dev/null || echo "no remote")
      printf '  %sremote delta:%s %s\n' "$DIM" "$RST" "$ahead_behind"
    else
      err "Not a valid git repo."
    fi
  done <<< "$repos"
  pause
}

_repo_log() {
  header; sub_header "Git Log"
  local repos; repos=$(get_tracked_repos)
  [[ -z "$repos" ]] && { warn "No repos tracked."; pause; return; }
  local i=1
  while IFS= read -r r; do
    printf '  %s%2d)%s %s\n' "$YLW$BLD" "$i" "$RST" "$r"
    i=$((i+1))
  done <<< "$repos"
  local pick; read -rp $'\n'"  Select repo: " pick
  local target; target=$(sed -n "${pick}p" <<< "$repos")
  [[ -z "$target" ]] && { err "Invalid."; pause; return; }
  git -C "$target" log --oneline --graph --decorate --color=always -20 | less -R
}

_repo_notes() {
  header; sub_header "GitCron Audit Notes"
  local repos; repos=$(get_tracked_repos)
  [[ -z "$repos" ]] && { warn "No repos tracked."; pause; return; }
  local i=1
  while IFS= read -r r; do
    printf '  %s%2d)%s %s\n' "$YLW$BLD" "$i" "$RST" "$r"
    i=$((i+1))
  done <<< "$repos"
  local pick; read -rp $'\n'"  Select repo: " pick
  local target; target=$(sed -n "${pick}p" <<< "$repos")
  [[ -z "$target" ]] && { err "Invalid."; pause; return; }
  git_ic "GitCron audit notes for $target"
  git -C "$target" notes --ref=gitcron-events list 2>/dev/null | while read -r sha; do
    printf '\n%s--- %s ---%s\n' "$DIM" "$sha" "$RST"
    git -C "$target" notes --ref=gitcron-events show "$sha" 2>/dev/null || true
  done | less
}

# ─── [2] Hook Pipeline Manager ────────────────────────────────────────────────
menu_hooks() {
  while true; do
    header
    sub_header "Git Hook Pipeline Manager"
    printf '  %s1)%s Install hook pipeline on a repo\n'   "$YLW$BLD" "$RST"
    printf '  %s2)%s Add stage to existing pipeline\n'    "$YLW$BLD" "$RST"
    printf '  %s3)%s View pipeline file\n'               "$YLW$BLD" "$RST"
    printf '  %s4)%s List installed hooks on a repo\n'   "$YLW$BLD" "$RST"
    printf '  %s5)%s Remove hook from a repo\n'          "$YLW$BLD" "$RST"
    printf '  %s6)%s Browse all available git hooks\n'   "$YLW$BLD" "$RST"
    printf '  %s0)%s Back\n\n'                           "$YLW$BLD" "$RST"
    div
    local c; read -rp "  Choice: " c
    case "$c" in
      1) _hook_install   ;;
      2) _hook_add_stage ;;
      3) _hook_view      ;;
      4) _hook_list      ;;
      5) _hook_remove    ;;
      6) _hook_browse    ;;
      0) return          ;;
      *) err "Invalid."; sleep 1 ;;
    esac
  done
}

_pick_repo() {
  local repos; repos=$(get_tracked_repos)
  [[ -z "$repos" ]] && { err "No repos tracked. Add one first."; return 1; }
  local i=1
  while IFS= read -r r; do
    printf '  %s%2d)%s %s\n' "$YLW$BLD" "$i" "$RST" "$r"
    i=$((i+1))
  done <<< "$repos"
  local pick; read -rp $'\n'"  Select repo: " pick
  local target; target=$(sed -n "${pick}p" <<< "$repos")
  [[ -z "$target" ]] && { err "Invalid selection."; return 1; }
  echo "$target"
}

_pick_hook() {
  printf '\n  Available git hooks:\n\n'
  local i=1
  for entry in "${GIT_HOOKS[@]}"; do
    IFS='|' read -r hname hdesc _hphase <<< "$entry"
    printf '  %s%2d)%s %-30s %s%s%s\n' \
      "$YLW$BLD" "$i" "$RST" "$hname" "$DIM" "$hdesc" "$RST"
    i=$((i+1))
  done
  local pick; read -rp $'\n'"  Select hook number: " pick
  local entry="${GIT_HOOKS[$((pick-1))]}"
  [[ -z "$entry" ]] && { err "Invalid."; return 1; }
  IFS='|' read -r hname _ _ <<< "$entry"
  echo "$hname"
}

_hook_install() {
  header; sub_header "Install Hook Pipeline"
  local repo; repo=$(_pick_repo) || { pause; return; }
  local hook; hook=$(_pick_hook)   || { pause; return; }

  local pipeline_file="${PIPELINE_DIR}/$(basename "$repo")_${hook}.pipeline"

  if [[ -f "$pipeline_file" ]]; then
    warn "Pipeline file already exists: $pipeline_file"
    read -rp "  Overwrite? [y/N]: " ow
    [[ "$ow" =~ ^[Yy]$ ]] || { info "Cancelled."; pause; return; }
    > "$pipeline_file"
  else
    printf '# GitCron pipeline: %s hook on %s\n' "$hook" "$repo" > "$pipeline_file"
    printf '# Format: STAGE|pexe|pargs|fexe|fargs|fail_action|custom_cmd\n\n' >> "$pipeline_file"
  fi

  install_hook_dispatcher "$repo" "$hook"
  ok "Hook dispatcher installed: ${repo}/.git/hooks/${hook}"

  # Add first stage
  local stage_name; read -rp "  First stage name: " stage_name
  nonempty "$stage_name" && add_pipeline_stage "$pipeline_file" "$stage_name"

  info "Pipeline file: $pipeline_file"
  log_info "Installed hook '$hook' on '$repo'"
  pause
}

_hook_add_stage() {
  header; sub_header "Add Pipeline Stage"
  local repo; repo=$(_pick_repo) || { pause; return; }
  local hook; hook=$(_pick_hook)   || { pause; return; }

  local pipeline_file="${PIPELINE_DIR}/$(basename "$repo")_${hook}.pipeline"
  if [[ ! -f "$pipeline_file" ]]; then
    err "No pipeline file found. Install the hook first."
    pause; return
  fi

  local stage_name; read -rp "  New stage name: " stage_name
  nonempty "$stage_name" || { err "Stage name required."; pause; return; }
  add_pipeline_stage "$pipeline_file" "$stage_name"
  log_info "Added stage '$stage_name' to $hook pipeline on $repo"
  pause
}

_hook_view() {
  header; sub_header "View Pipeline File"
  local repo; repo=$(_pick_repo) || { pause; return; }
  local hook; hook=$(_pick_hook)   || { pause; return; }

  local pipeline_file="${PIPELINE_DIR}/$(basename "$repo")_${hook}.pipeline"
  if [[ ! -f "$pipeline_file" ]]; then
    warn "No pipeline file found."
    pause; return
  fi

  printf '\n%s%s%s\n\n' "$BLD$CYN" "$pipeline_file" "$RST"
  local i=0
  while IFS='|' read -r stage pexe pargs fexe fargs faction fcmd; do
    [[ "$stage" == '#'* || -z "$stage" ]] && { printf '%s%s%s\n' "$DIM" "$stage" "$RST"; continue; }
    i=$((i+1))
    printf '  %s[Stage %d]%s %s%s%s\n'      "$GRN$BLD" "$i" "$RST" "$BLD" "$stage" "$RST"
    printf '    primary  : %s %s\n'          "$pexe" "$pargs"
    [[ -n "$fexe" ]] && \
    printf '    fallback : %s %s\n'          "$fexe" "$fargs"
    printf '    on-fail  : %s%s%s\n'         "$YLW" "$faction" "$RST"
    [[ -n "$fcmd" ]] && \
    printf '    custom   : %s\n'             "$fcmd"
    printf '\n'
  done < "$pipeline_file"
  pause
}

_hook_list() {
  header; sub_header "Installed Hooks"
  local repo; repo=$(_pick_repo) || { pause; return; }
  local hooks_dir="${repo}/.git/hooks"
  printf '\n  Hooks in %s:\n\n' "$hooks_dir"
  for entry in "${GIT_HOOKS[@]}"; do
    IFS='|' read -r hname _ _ <<< "$entry"
    local path="${hooks_dir}/${hname}"
    if [[ -f "$path" ]]; then
      local managed=""
      grep -q "GitCron dispatcher" "$path" 2>/dev/null && managed=" ${GRN}[gitcron]${RST}"
      printf '  %s[✔]%s %-30s%b\n' "$GRN$BLD" "$RST" "$hname" "$managed"
    fi
  done
  pause
}

_hook_remove() {
  header; sub_header "Remove Hook"
  local repo; repo=$(_pick_repo) || { pause; return; }
  local hook; hook=$(_pick_hook)   || { pause; return; }
  local hook_path="${repo}/.git/hooks/${hook}"

  if [[ ! -f "$hook_path" ]]; then
    warn "Hook '$hook' not installed on this repo."
    pause; return
  fi

  read -rp "  Remove hook '$hook' from $(basename "$repo")? [y/N]: " confirm
  [[ "$confirm" =~ ^[Yy]$ ]] || { info "Cancelled."; pause; return; }

  rm -f "$hook_path"
  ok "Hook '$hook' removed."

  local pipeline_file="${PIPELINE_DIR}/$(basename "$repo")_${hook}.pipeline"
  if [[ -f "$pipeline_file" ]]; then
    read -rp "  Also delete pipeline file? [y/N]: " delp
    [[ "$delp" =~ ^[Yy]$ ]] && rm -f "$pipeline_file" && ok "Pipeline file deleted."
  fi
  log_info "Removed hook '$hook' from '$repo'"
  pause
}

_hook_browse() {
  header; sub_header "All Available Git Hooks"
  local prev_phase=""
  for entry in "${GIT_HOOKS[@]}"; do
    IFS='|' read -r hname hdesc hphase <<< "$entry"
    if [[ "$hphase" != "$prev_phase" ]]; then
      printf '\n  %s[%s]%s\n' "$MAG$BLD" "$hphase" "$RST"
      prev_phase="$hphase"
    fi
    printf '    %-30s %s%s%s\n' "$hname" "$DIM" "$hdesc" "$RST"
  done
  pause
}

# ─── [3] Cron Job Manager ─────────────────────────────────────────────────────
menu_cron() {
  while true; do
    header
    sub_header "Cron Job Manager"
    printf '  %s1)%s List cron jobs\n'                    "$YLW$BLD" "$RST"
    printf '  %s2)%s Add cron job (with git audit trail)\n' "$YLW$BLD" "$RST"
    printf '  %s3)%s Remove cron job\n'                   "$YLW$BLD" "$RST"
    printf '  %s4)%s Backup / Restore crontab\n'          "$YLW$BLD" "$RST"
    printf '  %s5)%s Test-run a managed job\n'            "$YLW$BLD" "$RST"
    printf '  %s0)%s Back\n\n'                            "$YLW$BLD" "$RST"
    div
    local c; read -rp "  Choice: " c
    case "$c" in
      1) _cron_list    ;;
      2) _cron_add     ;;
      3) _cron_remove  ;;
      4) _cron_backup  ;;
      5) _cron_test    ;;
      0) return        ;;
      *) err "Invalid."; sleep 1 ;;
    esac
  done
}

_get_crontab() { crontab -l 2>/dev/null || true; }
_set_crontab() { echo "$1" | crontab -; }

_cron_list() {
  header; sub_header "Active Cron Jobs"
  local raw; raw=$(_get_crontab)
  if [[ -z "$raw" ]]; then
    warn "No cron jobs for $(whoami)."
  else
    local i=0
    while IFS= read -r line; do
      [[ "$line" =~ ^# || -z "${line// /}" ]] && continue
      i=$((i+1))
      local managed=""
      [[ "$line" == *"${WRAPPER_DIR}"* ]] && managed=" ${GRN}[gitcron]${RST}"
      printf '  %s%2d)%s %s%b\n' "$YLW$BLD" "$i" "$RST" "$line" "$managed"
    done <<< "$raw"
    printf '\n'; info "Total: $i job(s)"
  fi
  pause
}

_cron_add() {
  header; sub_header "Add Cron Job"

  # Schedule
  local schedule
  while true; do
    read -rp "  ${BLD}Schedule${RST} (e.g. '0 2 * * *' or @daily): " schedule
    validate_cron "$schedule" && break
    err "Invalid cron schedule."
  done

  # Job name
  local job_name
  while true; do
    read -rp "  ${BLD}Job label${RST} (alphanum + _ - only): " job_name
    [[ "$job_name" =~ ^[a-zA-Z0-9_-]+$ ]] && break
    err "Invalid label."
  done

  # Bind to repo?
  div
  info "Optionally bind to a tracked repo for git audit trail."
  local use_repo; read -rp "  Bind to a git repo? [y/N]: " use_repo
  local repo_path=""
  if [[ "$use_repo" =~ ^[Yy]$ ]]; then
    repo_path=$(_pick_repo) || repo_path=""
  fi

  # Primary
  div
  local pexe
  while true; do
    read -rp "  ${BLD}Primary interpreter path${RST}: " pexe
    is_executable "$pexe" && break
    err "'$pexe' not found or not executable."
  done
  local pargs; read -rp "  ${BLD}Primary script/arguments${RST}: " pargs

  # Fallback
  div
  local use_fb; read -rp "  Add fallback? [y/N]: " use_fb
  local fexe="" fargs=""
  if [[ "$use_fb" =~ ^[Yy]$ ]]; then
    while true; do
      read -rp "  ${BLD}Fallback interpreter path${RST}: " fexe
      is_executable "$fexe" && break
      err "'$fexe' not found."
    done
    read -rp "  ${BLD}Fallback arguments${RST}: " fargs
  fi

  # Fail handler
  div
  printf '  %sOn full failure:%s\n' "$BLD" "$RST"
  printf '    1) notify  2) log (default)  3) shutdown  4) custom\n'
  local fc; read -rp "  Choice [1-4]: " fc
  local faction="log" fcmd=""
  case "$fc" in
    1) faction="notify"   ;;
    3) faction="shutdown"; warn "Shutdown on failure!" ;;
    4) faction="custom"; read -rp "  ${BLD}Custom command${RST}: " fcmd ;;
  esac

  # Build
  div
  info "Building wrapper..."
  local wrapper
  wrapper=$(build_cron_wrapper "$job_name" "$repo_path" \
    "$pexe" "$pargs" "$fexe" "$fargs" "$faction" "$fcmd")

  local entry="${schedule} ${wrapper}"
  local current; current=$(_get_crontab)
  grep -qF "$wrapper" <<< "$current" 2>/dev/null && {
    warn "Duplicate entry detected — aborting."
    log_warn "Duplicate cron add: $job_name"
    pause; return
  }

  local updated="${current:+${current}$'\n'}${entry}"
  _set_crontab "$updated" && {
    ok "Job '$job_name' installed."
    info "Wrapper  : $wrapper"
    info "Job log  : ${LOG_DIR}/${job_name}.log"
    [[ -n "$repo_path" ]] && info "Git repo : $repo_path"
    log_info "Added cron job '$job_name'"
  } || {
    err "Failed to write crontab."
    log_err "Crontab write failed for $job_name"
  }
  pause
}

_cron_remove() {
  header; sub_header "Remove Cron Job"
  local raw; raw=$(_get_crontab)
  [[ -z "$raw" ]] && { warn "No jobs to remove."; pause; return; }

  local -a jobs=()
  while IFS= read -r line; do
    [[ "$line" =~ ^# || -z "${line// /}" ]] && continue
    jobs+=("$line")
  done <<< "$raw"

  local i=1
  for j in "${jobs[@]}"; do
    printf '  %s%2d)%s %s\n' "$YLW$BLD" "$i" "$RST" "$j"
    i=$((i+1))
  done

  local pick; read -rp $'\n'"  Remove job # (0 to cancel): " pick
  [[ "$pick" == "0" || -z "$pick" ]] && return
  [[ ! "$pick" =~ ^[0-9]+$ ]] || (( pick < 1 || pick > ${#jobs[@]} )) && {
    err "Invalid."; pause; return
  }

  local target="${jobs[$((pick-1))]}"
  read -rp "  Confirm removal? [y/N]: " confirm
  [[ "$confirm" =~ ^[Yy]$ ]] || { info "Cancelled."; pause; return; }

  local new_ct=""
  for j in "${jobs[@]}"; do
    [[ "$j" == "$target" ]] && continue
    new_ct+="${j}"$'\n'
  done

  _set_crontab "${new_ct%$'\n'}" && {
    ok "Job removed."
    log_info "Removed cron: $target"

    # Cleanup wrapper
    if [[ "$target" == *"${WRAPPER_DIR}/"* ]]; then
      local wp; wp=$(grep -oP "${WRAPPER_DIR}/[^\s]+" <<< "$target" || true)
      [[ -f "$wp" ]] && {
        read -rp "  Delete wrapper '$wp'? [y/N]: " dw
        [[ "$dw" =~ ^[Yy]$ ]] && rm -f "$wp" && ok "Wrapper deleted."
      }
    fi
  } || err "Failed to update crontab."
  pause
}

_cron_backup() {
  header; sub_header "Backup / Restore Crontab"
  printf '  1) Backup now\n  2) Restore from backup\n  0) Back\n\n'
  local c; read -rp "  Choice: " c
  case "$c" in
    1)
      local bfile="${BACKUP_DIR}/crontab_$(date '+%Y%m%d_%H%M%S').bak"
      _get_crontab > "$bfile"
      ok "Backed up to $bfile"
      log_info "Crontab backup: $bfile"
      ;;
    2)
      local -a bfiles=()
      while IFS= read -r f; do bfiles+=("$f"); done \
        < <(find "$BACKUP_DIR" -name 'crontab_*.bak' | sort -r)
      [[ ${#bfiles[@]} -eq 0 ]] && { warn "No backups found."; pause; return; }
      local i=1
      for f in "${bfiles[@]}"; do
        printf '  %s%2d)%s %s\n' "$YLW$BLD" "$i" "$RST" "$(basename "$f")"
        i=$((i+1))
      done
      local pick; read -rp $'\n'"  Select backup: " pick
      [[ "$pick" =~ ^[0-9]+$ ]] && (( pick >= 1 && pick <= ${#bfiles[@]} )) && {
        _set_crontab "$(cat "${bfiles[$((pick-1))]}")"
        ok "Restored from ${bfiles[$((pick-1))]}"
        log_info "Crontab restored"
      } || err "Invalid."
      ;;
  esac
  pause
}

_cron_test() {
  header; sub_header "Test-Run a Managed Job"
  local -a wrappers=()
  while IFS= read -r f; do wrappers+=("$f"); done \
    < <(find "$WRAPPER_DIR" -name '*.sh' 2>/dev/null | sort)
  [[ ${#wrappers[@]} -eq 0 ]] && { warn "No managed wrappers found."; pause; return; }

  local i=1
  for w in "${wrappers[@]}"; do
    printf '  %s%2d)%s %s\n' "$YLW$BLD" "$i" "$RST" "$(basename "$w")"
    i=$((i+1))
  done

  local pick; read -rp $'\n'"  Select wrapper (0 to cancel): " pick
  [[ "$pick" == "0" || -z "$pick" ]] && return
  [[ ! "$pick" =~ ^[0-9]+$ ]] || (( pick < 1 || pick > ${#wrappers[@]} )) && {
    err "Invalid."; pause; return
  }

  local target="${wrappers[$((pick-1))]}"
  printf '\n%sRunning: %s%s\n\n' "$BLD$GRN" "$(basename "$target")" "$RST"
  bash "$target" && ok "Test completed successfully." || {
    local rc=$?
    err "Test failed (exit $rc)."
  }
  pause
}

# ─── [4] Logs ─────────────────────────────────────────────────────────────────
menu_logs() {
  header; sub_header "View / Tail Logs"

  local -a logs=()
  while IFS= read -r f; do logs+=("$f"); done \
    < <(find "$LOG_DIR" -name '*.log' 2>/dev/null | sort)
  logs+=("$MGR_LOG")

  [[ ${#logs[@]} -eq 0 ]] && { warn "No logs found."; pause; return; }

  local i=1
  for f in "${logs[@]}"; do
    printf '  %s%2d)%s %s\n' "$YLW$BLD" "$i" "$RST" "$(basename "$f")"
    i=$((i+1))
  done

  local pick; read -rp $'\n'"  Select log (0 to cancel): " pick
  [[ "$pick" == "0" || -z "$pick" ]] && return
  [[ ! "$pick" =~ ^[0-9]+$ ]] || (( pick < 1 || pick > ${#logs[@]} )) && {
    err "Invalid."; pause; return
  }

  local target="${logs[$((pick-1))]}"
  printf '\n%sTailing: %s%s  (Ctrl-C to stop)\n\n' "$BLD$CYN" "$(basename "$target")" "$RST"
  tail -f "$target"
}

# ─── [5] Git Operations ───────────────────────────────────────────────────────
menu_git_ops() {
  while true; do
    header
    sub_header "Git Operations"
    printf '  %s1)%s Pull all tracked repos\n'        "$YLW$BLD" "$RST"
    printf '  %s2)%s Push a repo\n'                   "$YLW$BLD" "$RST"
    printf '  %s3)%s Commit staged changes\n'         "$YLW$BLD" "$RST"
    printf '  %s4)%s Create / checkout branch\n'      "$YLW$BLD" "$RST"
    printf '  %s5)%s Tag a release\n'                 "$YLW$BLD" "$RST"
    printf '  %s6)%s Stash / pop\n'                   "$YLW$BLD" "$RST"
    printf '  %s7)%s Manually fire a hook pipeline\n' "$YLW$BLD" "$RST"
    printf '  %s0)%s Back\n\n'                        "$YLW$BLD" "$RST"
    div
    local c; read -rp "  Choice: " c
    case "$c" in
      1) _git_pull_all   ;;
      2) _git_push       ;;
      3) _git_commit     ;;
      4) _git_branch     ;;
      5) _git_tag        ;;
      6) _git_stash      ;;
      7) _git_fire_hook  ;;
      0) return          ;;
      *) err "Invalid."; sleep 1 ;;
    esac
  done
}

_git_pull_all() {
  header; sub_header "Pull All Tracked Repos"
  local repos; repos=$(get_tracked_repos)
  [[ -z "$repos" ]] && { warn "No repos."; pause; return; }
  while IFS= read -r r; do
    printf '\n%s→ %s%s\n' "$BLD$CYN" "$r" "$RST"
    if is_git_repo "$r"; then
      git -C "$r" pull --ff-only 2>&1 && ok "Pulled." || warn "Pull failed or nothing to pull."
    else
      err "Not a git repo."
    fi
  done <<< "$repos"
  pause
}

_git_push() {
  header; sub_header "Push Repo"
  local repo; repo=$(_pick_repo) || { pause; return; }
  local remote; read -rp "  Remote [origin]: " remote
  [[ -z "$remote" ]] && remote="origin"
  local branch; branch=$(git -C "$repo" branch --show-current 2>/dev/null)
  read -rp "  Branch [$branch]: " b_in
  [[ -n "$b_in" ]] && branch="$b_in"
  git_ic "git push $remote $branch"
  git -C "$repo" push "$remote" "$branch" && ok "Pushed." || err "Push failed."
  pause
}

_git_commit() {
  header; sub_header "Commit Staged Changes"
  local repo; repo=$(_pick_repo) || { pause; return; }
  git -C "$repo" status -s
  read -rp $'\n'"  Commit message: " msg
  nonempty "$msg" || { err "Message required."; pause; return; }
  git -C "$repo" commit -m "$msg" && ok "Committed." || err "Commit failed."
  pause
}

_git_branch() {
  header; sub_header "Branch Management"
  local repo; repo=$(_pick_repo) || { pause; return; }
  printf '  Current branches:\n'
  git -C "$repo" branch -a --color=always
  printf '\n  1) Create new branch\n  2) Checkout existing\n  0) Back\n\n'
  local c; read -rp "  Choice: " c
  case "$c" in
    1)
      local name; read -rp "  New branch name: " name
      git -C "$repo" checkout -b "$name" && ok "Created and checked out '$name'." || err "Failed."
      ;;
    2)
      local name; read -rp "  Branch name: " name
      git -C "$repo" checkout "$name" && ok "Checked out '$name'." || err "Failed."
      ;;
  esac
  pause
}

_git_tag() {
  header; sub_header "Create Tag"
  local repo; repo=$(_pick_repo) || { pause; return; }
  local tag; read -rp "  Tag name (e.g. v1.0.0): " tag
  nonempty "$tag" || { err "Tag required."; pause; return; }
  local msg; read -rp "  Tag message: " msg
  git -C "$repo" tag -a "$tag" -m "$msg" && ok "Tag '$tag' created." || err "Tagging failed."
  read -rp "  Push tag to origin? [y/N]: " push
  [[ "$push" =~ ^[Yy]$ ]] && git -C "$repo" push origin "$tag"
  pause
}

_git_stash() {
  header; sub_header "Stash / Pop"
  local repo; repo=$(_pick_repo) || { pause; return; }
  printf '  1) Stash  2) Pop  3) List\n\n'
  local c; read -rp "  Choice: " c
  case "$c" in
    1) git -C "$repo" stash && ok "Stashed."   ;;
    2) git -C "$repo" stash pop && ok "Popped." ;;
    3) git -C "$repo" stash list               ;;
  esac
  pause
}

_git_fire_hook() {
  header; sub_header "Manually Fire Hook Pipeline"
  local repo; repo=$(_pick_repo) || { pause; return; }
  local hook; hook=$(_pick_hook)   || { pause; return; }
  local hook_script="${repo}/.git/hooks/${hook}"

  if [[ ! -f "$hook_script" ]]; then
    err "Hook '$hook' not installed on this repo."
    pause; return
  fi

  warn "This will execute the hook pipeline directly (no git operation)."
  read -rp "  Continue? [y/N]: " confirm
  [[ "$confirm" =~ ^[Yy]$ ]] || { info "Cancelled."; pause; return; }

  printf '\n%sFiring hook: %s on %s%s\n\n' "$BLD$GRN" "$hook" "$(basename "$repo")" "$RST"
  bash "$hook_script" && ok "Pipeline completed successfully." || {
    err "Pipeline exited with error code $?."
  }
  pause
}

# ─── Dependency check ─────────────────────────────────────────────────────────
check_deps() {
  local missing=()
  for cmd in git crontab tput grep find less; do
    command -v "$cmd" &>/dev/null || missing+=("$cmd")
  done
  if [[ ${#missing[@]} -gt 0 ]]; then
    printf '%s[FATAL] Missing dependencies: %s%s\n' \
      "$RED$BLD" "${missing[*]}" "$RST" >&2
    exit 1
  fi
}

# ─── Main ─────────────────────────────────────────────────────────────────────
main() {
  check_deps
  log_info "gitcron_manager v3.0 started (user: $(whoami))"

  while true; do
    header
    printf '  %s1)%s Repository Management\n'          "$YLW$BLD" "$RST"
    printf '  %s2)%s Git Hook Pipeline Manager\n'      "$YLW$BLD" "$RST"
    printf '  %s3)%s Cron Job Manager\n'               "$YLW$BLD" "$RST"
    printf '  %s4)%s View / Tail Logs\n'               "$YLW$BLD" "$RST"
    printf '  %s5)%s Git Operations\n'                 "$YLW$BLD" "$RST"
    printf '  %s0)%s Exit\n\n'                         "$YLW$BLD" "$RST"
    div
    local c; read -rp "  ${BLD}Select module:${RST} " c
    case "$c" in
      1) menu_repos   ;;
      2) menu_hooks   ;;
      3) menu_cron    ;;
      4) menu_logs    ;;
      5) menu_git_ops ;;
      0)
        log_info "gitcron_manager exited"
        printf '\n%sGoodbye.%s\n\n' "$BLD$CYN" "$RST"
        exit 0
        ;;
      *) err "Invalid option '$c'."; sleep 1 ;;
    esac
  done
}

main "$@"
