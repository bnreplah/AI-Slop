"""
registry.py — SCM Provider Registry & Factory
===============================================
Auto-detects which SCM backs a given path and returns the right adapter.
New adapters register themselves here; callers never import adapters directly.
"""

from __future__ import annotations

import os
import subprocess
from pathlib import Path
from typing import Optional, Type

from core.scm_provider import SCMProvider, SCMType, SCMError


_REGISTRY: dict[SCMType, Type[SCMProvider]] = {}


def register(scm_type: SCMType):
    """Class decorator to register an adapter."""
    def decorator(cls: Type[SCMProvider]) -> Type[SCMProvider]:
        _REGISTRY[scm_type] = cls
        return cls
    return decorator


def _probe_git(path: str) -> bool:
    try:
        r = subprocess.run(
            ["git", "-C", path, "rev-parse", "--git-dir"],
            capture_output=True, text=True,
        )
        return r.returncode == 0
    except FileNotFoundError:
        return False


def _probe_svn(path: str) -> bool:
    return (Path(path) / ".svn").exists() or any(
        (Path(path) / d).exists() for d in [".svn"]
    )


def _probe_hg(path: str) -> bool:
    return (Path(path) / ".hg").exists()


def _probe_fossil(path: str) -> bool:
    return any(Path(path).glob("*.fossil"))


def detect_scm_type(path: str) -> SCMType:
    """Walk up the directory tree probing for SCM markers."""
    p = Path(path).resolve()
    while p != p.parent:
        if _probe_git(str(p)):    return SCMType.GIT
        if _probe_svn(str(p)):    return SCMType.SVN
        if _probe_hg(str(p)):     return SCMType.MERCURIAL
        if _probe_fossil(str(p)): return SCMType.FOSSIL
        p = p.parent
    return SCMType.UNKNOWN


def get_provider(
    path: str = ".",
    scm_type: Optional[SCMType] = None,
    actor: str = "scmtool",
    **kwargs,
) -> SCMProvider:
    """
    Return the appropriate SCMProvider for the given path.

    Parameters
    ----------
    path      : Local working directory or repo path.
    scm_type  : Force a specific adapter. If None, auto-detect.
    actor     : Identity for audit logging.
    **kwargs  : Passed through to the adapter constructor (e.g. svn_root).

    Raises
    ------
    SCMError  : If no adapter is found or the path isn't a valid repo.
    """
    # Lazy import to avoid circular imports at module load
    from adapters.git_adapter import GitAdapter
    from adapters.svn_adapter import SVNAdapter

    # Populate registry on first call
    if not _REGISTRY:
        _REGISTRY[SCMType.GIT] = GitAdapter
        _REGISTRY[SCMType.SVN] = SVNAdapter

    detected = scm_type or detect_scm_type(path)

    if detected == SCMType.UNKNOWN:
        raise SCMError(
            f"No supported SCM found at '{path}'. "
            f"Supported: {', '.join(t.value for t in _REGISTRY)}"
        )

    adapter_cls = _REGISTRY.get(detected)
    if adapter_cls is None:
        raise SCMError(
            f"No adapter registered for SCM type '{detected.value}'. "
            f"Registered: {', '.join(t.value for t in _REGISTRY)}"
        )

    return adapter_cls(repo_path=str(Path(path).resolve()), actor=actor, **kwargs)


def list_available_adapters() -> dict[str, bool]:
    """
    Return a dict of {scm_type_name: is_available} based on
    whether the required CLI tool is found in PATH.
    """
    tools = {
        "git":    "git",
        "svn":    "svn",
        "hg":     "hg",
        "fossil": "fossil",
        "p4":     "p4",
    }
    result = {}
    for name, cli in tools.items():
        try:
            subprocess.run([cli, "--version"], capture_output=True, check=False)
            result[name] = True
        except FileNotFoundError:
            result[name] = False
    return result
