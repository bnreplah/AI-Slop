"""SCM Tool — core package."""
