# SCM Tool — Open Source SCM Management TUI
**Author:** Cybopsec | **Version:** 1.0.0 | **License:** MIT

A fully self-contained, terminal-based SCM (Source Control Management) tool
with native Git support, SVN foundations, and a clean provider abstraction
layer for extending to any SCM protocol.

---

## Architecture

```
scmtool/
├── scmtool.py              ← Entry point / full TUI
├── core/
│   ├── scm_provider.py     ← Abstract provider interface (all dataclasses, errors, contract)
│   └── registry.py         ← Auto-detection + adapter factory
├── adapters/
│   ├── git_adapter.py      ← Full Git implementation (subprocess, zero deps)
│   └── svn_adapter.py      ← SVN implementation (subprocess, zero deps)
├── hooks/                  ← Hook scripts managed by the tool
├── config/                 ← Runtime config
└── tests/                  ← Test suite
```

### Provider abstraction layer

Every SCM adapter implements `SCMProvider` from `core/scm_provider.py`.
The TUI never imports adapter classes directly — it always goes through
`core/registry.get_provider()` which auto-detects the SCM type and
returns the right adapter.

To add a new SCM backend (Mercurial, Perforce, Fossil, etc.):

```python
# adapters/hg_adapter.py
from core.scm_provider import SCMProvider, SCMType

class HgAdapter(SCMProvider):
    @property
    def scm_type(self): return SCMType.MERCURIAL
    # ... implement abstract methods

# core/registry.py — add to _REGISTRY:
from adapters.hg_adapter import HgAdapter
_REGISTRY[SCMType.MERCURIAL] = HgAdapter
```

That's it. The entire TUI picks it up automatically.

---

## Features

### Pull Request Management
- Create, list, review, and merge PRs entirely from the terminal
- PRs are stored locally in `.git/scmtool/prs/` as JSON — no server required
- Conflict pre-check via `git merge-tree` before creating or merging
- Four merge strategies: merge commit, squash, rebase, fast-forward
- Review workflow: approve, request changes, comment (general + inline)
- Per-PR audit trail written to `git notes --ref=gitcron-events`

### Branch Management
- List local + remote branches with ahead/behind tracking info
- Create, delete (with protection checks), checkout
- Branch comparison (full diff stat)
- Cherry-pick commits across branches

### Commit Log & History
- Filterable log (author, date range, path)
- Full commit inspection (stats, parents, refs)
- View any file at any ref (`git show ref:path`)
- `git blame` output with built-in pager
- Contributor shortlog

### Remote Operations
- Fetch (with pruning), pull (merge/rebase/ff strategies), push
- Force push uses `--force-with-lease` (safer than `--force`)
- Tag push support

### Working Tree
- Status with file type coloring
- Stage, unstage, commit, amend, discard
- Full stash management (push/list/pop/drop)

### Tags
- Lightweight and annotated tags
- Push tags to remotes on creation

### Extensibility Points
- `SCMProvider.register_audit_hook(callback)` — attach any function to
  receive `AuditEvent` on every mutating operation
- `core/registry.register(SCMType.FOO)` decorator — plug in new adapters
- PR store is JSON on disk — easy to sync to GitHub/GitLab via a thin
  remote adapter layer

---

## Requirements

- Python 3.9+
- `git` in PATH (for Git repos)
- `svn` in PATH (for SVN repos, optional)
- No pip installs — pure stdlib

---

## Usage

```bash
# Make executable and run from any directory
chmod +x scmtool.py
./scmtool.py

# Or run with Python directly
python3 scmtool.py

# The tool auto-detects the SCM type of the current working directory.
# You can also open any repo path from within the tool (Option 1).
```

---

## Extending to Other SCM Protocols

### What to implement

The `SCMProvider` abstract class has three tiers:

| Tier | Methods | Required |
|------|---------|----------|
| Core | `get_commit`, `log`, `diff`, `list_branches`, `status`, etc. | Yes — must implement |
| Remote | `fetch`, `pull`, `push` | Yes if applicable |
| Optional | `stash_*`, `cherry_pick`, `rebase`, PR methods | Override or leave as `raise SCMNotSupportedError` |

### Mercurial example skeleton

```python
class HgAdapter(SCMProvider):
    @property
    def scm_type(self): return SCMType.MERCURIAL
    def is_valid_repo(self): return (Path(self.repo_path) / ".hg").exists()
    def get_commit(self, ref):
        raw = subprocess.check_output(["hg", "log", "-r", ref, "--template", ...])
        ...
    def list_branches(self, include_remote=True):
        raw = subprocess.check_output(["hg", "branches"])
        ...
```

### Perforce / Helix example

Perforce has a fundamentally different model (depot paths, changelists).
Map the interface as follows:

| SCMProvider concept | Perforce equivalent |
|--------------------|---------------------|
| `Branch`           | Stream or label      |
| `Commit`           | Changelist           |
| `PullRequest`      | Shelved changelist   |
| `stash_push`       | `p4 shelve`          |
| `fetch`            | `p4 sync`            |
| `push` / `commit`  | `p4 submit`          |

---

## PR Storage Format

PRs are stored in `.git/scmtool/prs/<id>.json`:

```json
{
  "id": "a1b2c3d4",
  "title": "Add feature X",
  "description": "...",
  "source_branch": "feature/x",
  "target_branch": "main",
  "state": "open",
  "author": {"name": "Ben", "email": "...", "when": "..."},
  "reviews": [...],
  "comments": [...],
  "conflicts": "none",
  "merge_strategy": "merge"
}
```

Because PRs live inside `.git/`, they travel with the repository and are
visible to all clones that use this tool.

---

## Security Notes

- Force pushes use `--force-with-lease` to prevent clobbering unknown remote changes.
- Protected branches (main, master, trunk, default branch) require explicit
  confirmation before deletion.
- All mutating operations emit `AuditEvent` objects that callers can
  subscribe to for logging, SIEM integration, or policy enforcement.
- No credentials are stored by the tool — relies on git credential helpers,
  SSH agent, or `.netrc` as configured by the user.

---

## Roadmap

- [ ] Mercurial adapter
- [ ] Perforce adapter
- [ ] GitHub/GitLab/Gitea remote PR sync (thin wrapper over local store)
- [ ] Hook pipeline integration (from `gitcron_manager.sh`)
- [ ] CI/CD check status display in PR view
- [ ] Config file per-repo (`.scmtool/config.json`)
- [ ] TUI theming / color scheme selection
- [ ] Export PR history to Markdown/HTML
