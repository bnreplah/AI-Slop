#!/usr/bin/env bash
# =============================================================================
# cron_manager.sh — Terminal UI for Cron Job Management
# Author : Cybopsec
# Version: 2.0.0
# Requires: bash 4+, crontab, tput
# =============================================================================

set -euo pipefail
IFS=$'\n\t'

# ─── Colour / TUI primitives ─────────────────────────────────────────────────
if tput setaf 1 &>/dev/null; then
  RED=$(tput setaf 1); GRN=$(tput setaf 2); YLW=$(tput setaf 3)
  BLU=$(tput setaf 4); CYN=$(tput setaf 6); WHT=$(tput setaf 7)
  BLD=$(tput bold);   RST=$(tput sgr0)
else
  RED=''; GRN=''; YLW=''; BLU=''; CYN=''; WHT=''; BLD=''; RST=''
fi

# ─── Logging ─────────────────────────────────────────────────────────────────
LOG_DIR="${HOME}/.cron_manager"
LOG_FILE="${LOG_DIR}/cron_manager.log"
mkdir -p "$LOG_DIR"

log() {
  local level="$1"; shift
  printf '[%s] [%-5s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$level" "$*" \
    | tee -a "$LOG_FILE"
}
log_info()  { log INFO  "$*"; }
log_warn()  { log WARN  "$*"; }
log_error() { log ERROR "$*"; }

# ─── UI helpers ──────────────────────────────────────────────────────────────
header() {
  clear
  printf '%s%s' "$BLD$CYN"
  printf '╔══════════════════════════════════════════════════════╗\n'
  printf '║           CRON JOB MANAGER  v2.0  // Cybopsec       ║\n'
  printf '╚══════════════════════════════════════════════════════╝\n'
  printf '%s\n' "$RST"
}

msg_ok()   { printf '%s[✔]%s %s\n' "$GRN$BLD" "$RST" "$*"; }
msg_warn() { printf '%s[!]%s %s\n' "$YLW$BLD" "$RST" "$*"; }
msg_err()  { printf '%s[✘]%s %s\n' "$RED$BLD" "$RST" "$*" >&2; }
msg_info() { printf '%s[i]%s %s\n' "$BLU$BLD" "$RST" "$*"; }
divider()  { printf '%s%s%s\n' "$BLU" "$(printf '─%.0s' {1..56})" "$RST"; }

pause()    { printf '\n'; read -rp "${BLD}Press [Enter] to continue...${RST} "; }

# ─── Input validation helpers ─────────────────────────────────────────────────
validate_cron_schedule() {
  # Accepts standard 5-field cron or @reboot/@hourly/@daily/@weekly/@monthly
  local s="$1"
  if [[ "$s" =~ ^@(reboot|hourly|daily|weekly|monthly|yearly|annually)$ ]]; then
    return 0
  fi
  # 5-field pattern: basic sanity — each field non-empty, only cron chars
  if [[ "$s" =~ ^([0-9*,\-/]+[[:space:]]+){4}[0-9*,\-/]+$ ]]; then
    return 0
  fi
  return 1
}

validate_executable() {
  local path="$1"
  [[ -f "$path" && -x "$path" ]]
}

validate_nonempty() {
  [[ -n "${1// /}" ]]
}

# ─── Crontab helpers ──────────────────────────────────────────────────────────
get_crontab() {
  crontab -l 2>/dev/null || true
}

set_crontab() {
  echo "$1" | crontab -
}

# ─── Features ─────────────────────────────────────────────────────────────────

list_jobs() {
  header
  printf '%s  CURRENT CRON JOBS%s\n\n' "$BLD$WHT" "$RST"
  local raw
  raw=$(get_crontab)

  if [[ -z "$raw" ]]; then
    msg_warn "No cron jobs found for $(whoami)."
  else
    local idx=0
    while IFS= read -r line; do
      [[ "$line" =~ ^#  ]] && continue
      [[ -z "${line// /}" ]] && continue
      idx=$((idx + 1))
      printf '  %s%2d)%s %s\n' "$YLW$BLD" "$idx" "$RST" "$line"
    done <<< "$raw"
    printf '\n'
    msg_info "Total active jobs: $idx"
  fi
  pause
}

# Build a wrapper script that:
#   1. Tries primary command
#   2. On failure, tries fallback command
#   3. On fallback failure, executes the full-fail handler and sends alert
build_wrapper() {
  local wrapper_dir="${LOG_DIR}/wrappers"
  mkdir -p "$wrapper_dir"

  local job_name="$1"
  local primary_prog="$2"   # e.g. /usr/bin/python3
  local primary_args="$3"   # e.g. /opt/scripts/backup.py
  local fallback_prog="$4"
  local fallback_args="$5"
  local fail_action="$6"    # notify | log | shutdown | custom
  local custom_cmd="$7"     # used when fail_action=custom

  local wrapper="${wrapper_dir}/${job_name}.sh"
  local job_log="${LOG_DIR}/${job_name}.log"

  cat > "$wrapper" <<WRAPPER
#!/usr/bin/env bash
# Auto-generated wrapper: ${job_name}
# Managed by cron_manager.sh

set -uo pipefail
JOB_NAME="${job_name}"
JOB_LOG="${job_log}"
TIMESTAMP="\$(date '+%Y-%m-%d %H:%M:%S')"

_log() { printf '[%s] [%s] %s\n' "\$TIMESTAMP" "\$JOB_NAME" "\$*" >> "\$JOB_LOG"; }

# ── Primary ────────────────────────────────────────────────────────────────
_log "START primary: ${primary_prog} ${primary_args}"
if "${primary_prog}" ${primary_args} >> "\$JOB_LOG" 2>&1; then
  _log "PRIMARY SUCCESS"
  exit 0
fi

_log "WARN primary failed — attempting fallback"

# ── Fallback ───────────────────────────────────────────────────────────────
WRAPPER

  if [[ -n "$fallback_prog" ]]; then
    cat >> "$wrapper" <<WRAPPER
_log "START fallback: ${fallback_prog} ${fallback_args}"
if "${fallback_prog}" ${fallback_args} >> "\$JOB_LOG" 2>&1; then
  _log "FALLBACK SUCCESS"
  exit 0
fi

_log "ERROR fallback also failed — executing full-fail handler"
WRAPPER
  else
    cat >> "$wrapper" <<WRAPPER
_log "ERROR primary failed — no fallback configured"
WRAPPER
  fi

  # Full-fail handler
  case "$fail_action" in
    notify)
      cat >> "$wrapper" <<WRAPPER
# Send desktop/wall notification (works on most Linux with notify-send or wall)
FAIL_MSG="[CRON FAIL] Job '\${JOB_NAME}' fully failed at \${TIMESTAMP}"
if command -v notify-send &>/dev/null; then
  notify-send -u critical "Cron Failure" "\$FAIL_MSG" 2>/dev/null || true
fi
command -v wall &>/dev/null && echo "\$FAIL_MSG" | wall 2>/dev/null || true
_log "FULL_FAIL: notification dispatched"
exit 2
WRAPPER
      ;;
    log)
      cat >> "$wrapper" <<WRAPPER
_log "FULL_FAIL: all attempts exhausted — logged only"
# Append prominent failure marker to job log
printf '\n%s\n' "======= FULL FAILURE @ \${TIMESTAMP} =======" >> "\$JOB_LOG"
exit 2
WRAPPER
      ;;
    shutdown)
      cat >> "$wrapper" <<WRAPPER
_log "FULL_FAIL: initiating system shutdown per policy"
# Requires sudo or root; adjust as needed
sudo shutdown -h now "Cron job \${JOB_NAME} failed critically" || \
  _log "FULL_FAIL: shutdown command failed — check sudo permissions"
exit 2
WRAPPER
      ;;
    custom)
      cat >> "$wrapper" <<WRAPPER
_log "FULL_FAIL: executing custom handler"
${custom_cmd} >> "\$JOB_LOG" 2>&1 || _log "FULL_FAIL: custom handler also failed"
exit 2
WRAPPER
      ;;
    *)
      cat >> "$wrapper" <<WRAPPER
_log "FULL_FAIL: unknown handler — logged only"
exit 2
WRAPPER
      ;;
  esac

  chmod 750 "$wrapper"
  echo "$wrapper"
}

add_job() {
  header
  printf '%s  ADD CRON JOB%s\n\n' "$BLD$WHT" "$RST"

  # ── Schedule ──────────────────────────────────────────────────────────────
  local schedule
  while true; do
    read -rp "  ${BLD}Cron schedule${RST} (e.g. '0 2 * * *' or @daily): " schedule
    if validate_cron_schedule "$schedule"; then
      break
    fi
    msg_err "Invalid cron schedule format. Try '*/5 * * * *' or '@hourly'."
  done

  # ── Job name ──────────────────────────────────────────────────────────────
  local job_name
  while true; do
    read -rp "  ${BLD}Job label${RST} (no spaces, used for logs): " job_name
    if [[ "$job_name" =~ ^[a-zA-Z0-9_-]+$ ]]; then
      break
    fi
    msg_err "Label must be alphanumeric with underscores/hyphens only."
  done

  # ── Primary interpreter ────────────────────────────────────────────────────
  local primary_prog
  while true; do
    read -rp "  ${BLD}Primary interpreter path${RST} (e.g. /usr/bin/python3): " primary_prog
    if validate_executable "$primary_prog"; then
      break
    fi
    msg_err "'$primary_prog' not found or not executable."
  done

  # ── Primary script/args ────────────────────────────────────────────────────
  local primary_args
  read -rp "  ${BLD}Primary script/arguments${RST} (e.g. /opt/scripts/backup.py --full): " primary_args

  divider
  msg_info "Optional: configure a fallback command to run if primary fails."
  local use_fallback
  read -rp "  Add fallback command? [y/N]: " use_fallback

  local fallback_prog="" fallback_args=""
  if [[ "$use_fallback" =~ ^[Yy]$ ]]; then
    while true; do
      read -rp "  ${BLD}Fallback interpreter path${RST}: " fallback_prog
      if validate_executable "$fallback_prog"; then
        break
      fi
      msg_err "'$fallback_prog' not found or not executable."
    done
    read -rp "  ${BLD}Fallback script/arguments${RST}: " fallback_args
  fi

  # ── Full-fail handler ──────────────────────────────────────────────────────
  divider
  printf '  %sOn total failure, what should happen?%s\n' "$BLD" "$RST"
  printf '    1) notify  — desktop/wall notification\n'
  printf '    2) log     — log only (default)\n'
  printf '    3) shutdown — shutdown the system\n'
  printf '    4) custom  — run a custom command\n'
  local fail_choice fail_action custom_cmd=""
  read -rp "  Choice [1-4, default=2]: " fail_choice
  case "$fail_choice" in
    1) fail_action="notify"   ;;
    3) fail_action="shutdown"
       msg_warn "Shutdown on failure selected — ensure proper sudo permissions." ;;
    4) fail_action="custom"
       read -rp "  ${BLD}Custom failure command${RST}: " custom_cmd ;;
    *) fail_action="log"      ;;
  esac

  # ── Build wrapper & install ───────────────────────────────────────────────
  divider
  msg_info "Building job wrapper..."
  local wrapper_path
  wrapper_path=$(build_wrapper \
    "$job_name" "$primary_prog" "$primary_args" \
    "$fallback_prog" "$fallback_args" \
    "$fail_action" "$custom_cmd")

  local new_entry="${schedule} ${wrapper_path}"
  local current
  current=$(get_crontab)

  # Duplicate check
  if grep -qF "$wrapper_path" <<< "$current" 2>/dev/null; then
    msg_warn "A cron entry for this wrapper already exists — aborting duplicate."
    log_warn "Duplicate add attempted for $job_name"
    pause; return
  fi

  local updated
  if [[ -z "$current" ]]; then
    updated="$new_entry"
  else
    updated="${current}"$'\n'"${new_entry}"
  fi

  if set_crontab "$updated"; then
    msg_ok "Cron job '${job_name}' installed."
    msg_info "Wrapper : $wrapper_path"
    msg_info "Job log : ${LOG_DIR}/${job_name}.log"
    log_info "Added job '$job_name': $new_entry"
  else
    msg_err "Failed to write crontab — check permissions."
    log_error "Failed to write crontab for $job_name"
  fi

  pause
}

remove_job() {
  header
  printf '%s  REMOVE CRON JOB%s\n\n' "$BLD$WHT" "$RST"

  local raw
  raw=$(get_crontab)
  if [[ -z "$raw" ]]; then
    msg_warn "No cron jobs to remove."
    pause; return
  fi

  # Display numbered list (skip comments/blanks)
  local -a jobs=()
  while IFS= read -r line; do
    [[ "$line" =~ ^# || -z "${line// /}" ]] && continue
    jobs+=("$line")
  done <<< "$raw"

  local i=1
  for job in "${jobs[@]}"; do
    printf '  %s%2d)%s %s\n' "$YLW$BLD" "$i" "$RST" "$job"
    i=$((i+1))
  done

  local choice
  read -rp $'\n'"  ${BLD}Enter job number to remove (0 to cancel):${RST} " choice

  if [[ "$choice" == "0" || -z "$choice" ]]; then
    msg_info "Cancelled."; pause; return
  fi

  if ! [[ "$choice" =~ ^[0-9]+$ ]] || (( choice < 1 || choice > ${#jobs[@]} )); then
    msg_err "Invalid selection."; pause; return
  fi

  local target="${jobs[$((choice-1))]}"
  printf '\n  Removing: %s%s%s\n' "$YLW" "$target" "$RST"
  read -rp "  Confirm? [y/N]: " confirm
  [[ "$confirm" =~ ^[Yy]$ ]] || { msg_info "Cancelled."; pause; return; }

  # Rebuild crontab without the selected line
  local new_crontab=""
  for job in "${jobs[@]}"; do
    [[ "$job" == "$target" ]] && continue
    new_crontab+="${job}"$'\n'
  done
  new_crontab="${new_crontab%$'\n'}"

  if set_crontab "$new_crontab"; then
    msg_ok "Job removed."
    log_info "Removed job: $target"

    # Offer to remove wrapper file if it was manager-generated
    if [[ "$target" == *"${LOG_DIR}/wrappers/"* ]]; then
      local wpath
      wpath=$(echo "$target" | grep -oP "${LOG_DIR}/wrappers/[^\s]+")
      if [[ -f "$wpath" ]]; then
        read -rp "  Also delete wrapper script '$wpath'? [y/N]: " delw
        if [[ "$delw" =~ ^[Yy]$ ]]; then
          rm -f "$wpath"
          msg_ok "Wrapper deleted."
          log_info "Wrapper deleted: $wpath"
        fi
      fi
    fi
  else
    msg_err "Failed to update crontab."
    log_error "Failed to remove: $target"
  fi

  pause
}

view_logs() {
  header
  printf '%s  JOB LOGS%s\n\n' "$BLD$WHT" "$RST"

  local -a logfiles=()
  while IFS= read -r f; do
    logfiles+=("$f")
  done < <(find "$LOG_DIR" -maxdepth 1 -name '*.log' 2>/dev/null | sort)

  if [[ ${#logfiles[@]} -eq 0 ]]; then
    msg_warn "No log files found in $LOG_DIR"
    pause; return
  fi

  local i=1
  for f in "${logfiles[@]}"; do
    printf '  %s%2d)%s %s\n' "$YLW$BLD" "$i" "$RST" "$(basename "$f")"
    i=$((i+1))
  done

  local choice
  read -rp $'\n'"  ${BLD}Select log to tail (0 to cancel):${RST} " choice
  [[ "$choice" == "0" || -z "$choice" ]] && return

  if ! [[ "$choice" =~ ^[0-9]+$ ]] || (( choice < 1 || choice > ${#logfiles[@]} )); then
    msg_err "Invalid selection."; pause; return
  fi

  local target="${logfiles[$((choice-1))]}"
  printf '\n%sTailing %s — Ctrl-C to stop%s\n\n' "$BLD$CYN" "$target" "$RST"
  tail -f "$target"
}

backup_crontab() {
  header
  printf '%s  BACKUP / RESTORE CRONTAB%s\n\n' "$BLD$WHT" "$RST"
  printf '  1) Backup current crontab\n  2) Restore from backup\n  0) Back\n\n'
  local c; read -rp "  Choice: " c
  case "$c" in
    1)
      local bfile="${LOG_DIR}/crontab_backup_$(date '+%Y%m%d_%H%M%S').bak"
      get_crontab > "$bfile"
      msg_ok "Backed up to $bfile"
      log_info "Crontab backed up: $bfile"
      ;;
    2)
      local -a bfiles=()
      while IFS= read -r f; do bfiles+=("$f"); done \
        < <(find "$LOG_DIR" -name 'crontab_backup_*.bak' | sort -r)
      if [[ ${#bfiles[@]} -eq 0 ]]; then
        msg_warn "No backups found."; pause; return
      fi
      local i=1
      for f in "${bfiles[@]}"; do
        printf '  %s%2d)%s %s\n' "$YLW$BLD" "$i" "$RST" "$(basename "$f")"
        i=$((i+1))
      done
      local pick; read -rp $'\n'"  Select backup to restore: " pick
      if [[ "$pick" =~ ^[0-9]+$ ]] && (( pick >= 1 && pick <= ${#bfiles[@]} )); then
        set_crontab "$(cat "${bfiles[$((pick-1))]}")"
        msg_ok "Crontab restored from ${bfiles[$((pick-1))]}"
        log_info "Restored crontab from ${bfiles[$((pick-1))]}"
      else
        msg_err "Invalid selection."
      fi
      ;;
  esac
  pause
}

test_job() {
  header
  printf '%s  TEST RUN A JOB%s\n\n' "$BLD$WHT" "$RST"
  msg_info "Select a managed wrapper to execute immediately for testing.\n"

  local -a wrappers=()
  while IFS= read -r f; do wrappers+=("$f"); done \
    < <(find "${LOG_DIR}/wrappers" -name '*.sh' 2>/dev/null | sort)

  if [[ ${#wrappers[@]} -eq 0 ]]; then
    msg_warn "No managed wrappers found."; pause; return
  fi

  local i=1
  for w in "${wrappers[@]}"; do
    printf '  %s%2d)%s %s\n' "$YLW$BLD" "$i" "$RST" "$(basename "$w")"
    i=$((i+1))
  done

  local pick; read -rp $'\n'"  Select wrapper to run (0 to cancel): " pick
  [[ "$pick" == "0" || -z "$pick" ]] && return

  if ! [[ "$pick" =~ ^[0-9]+$ ]] || (( pick < 1 || pick > ${#wrappers[@]} )); then
    msg_err "Invalid selection."; pause; return
  fi

  local target="${wrappers[$((pick-1))]}"
  printf '\n%sRunning: %s%s\n\n' "$BLD$GRN" "$target" "$RST"
  if bash "$target"; then
    msg_ok "Test run completed successfully."
  else
    local rc=$?
    msg_err "Test run failed with exit code $rc."
  fi
  pause
}

# ─── Main loop ────────────────────────────────────────────────────────────────
main() {
  # Dependency check
  for cmd in crontab tput grep find; do
    if ! command -v "$cmd" &>/dev/null; then
      printf '%s[FATAL] Required command not found: %s%s\n' "$RED" "$cmd" "$RST" >&2
      exit 1
    fi
  done

  log_info "cron_manager started (user: $(whoami))"

  while true; do
    header
    printf '  %s1)%s List jobs\n' "$YLW$BLD" "$RST"
    printf '  %s2)%s Add job (with fallback & failure handler)\n' "$YLW$BLD" "$RST"
    printf '  %s3)%s Remove job\n' "$YLW$BLD" "$RST"
    printf '  %s4)%s View / tail logs\n' "$YLW$BLD" "$RST"
    printf '  %s5)%s Backup / Restore crontab\n' "$YLW$BLD" "$RST"
    printf '  %s6)%s Test run a managed job\n' "$YLW$BLD" "$RST"
    printf '  %s0)%s Exit\n\n' "$YLW$BLD" "$RST"
    divider

    local choice
    read -rp "  ${BLD}Select option:${RST} " choice

    case "$choice" in
      1) list_jobs     ;;
      2) add_job       ;;
      3) remove_job    ;;
      4) view_logs     ;;
      5) backup_crontab;;
      6) test_job      ;;
      0) log_info "cron_manager exited"
         printf '\n%sGoodbye.%s\n\n' "$BLD$CYN" "$RST"
         exit 0 ;;
      *) msg_err "Invalid option '$choice'." ; sleep 1 ;;
    esac
  done
}

main "$@"
