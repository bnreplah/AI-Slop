"""
scm_provider.py — Abstract SCM Provider Interface
==================================================
All SCM adapters (Git, SVN, Mercurial, Perforce, etc.) implement this
interface. The TUI and pipeline engine only ever talk to this contract,
making backends fully swappable.

Design principles:
  - Every method returns a typed dataclass or raises SCMError
  - No adapter-specific types leak into callers
  - All operations are atomic where the underlying SCM allows it
  - Audit events are emitted on every mutating operation
"""

from __future__ import annotations

import hashlib
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum, auto
from typing import Any, Callable, Iterator, Optional


# ─── Enumerations ─────────────────────────────────────────────────────────────

class SCMType(Enum):
    GIT        = "git"
    SVN        = "svn"
    MERCURIAL  = "hg"
    PERFORCE   = "p4"
    FOSSIL     = "fossil"
    UNKNOWN    = "unknown"


class PRState(Enum):
    OPEN    = "open"
    CLOSED  = "closed"
    MERGED  = "merged"
    DRAFT   = "draft"


class ReviewDecision(Enum):
    APPROVED          = "approved"
    CHANGES_REQUESTED = "changes_requested"
    COMMENTED         = "commented"
    PENDING           = "pending"


class MergeStrategy(Enum):
    MERGE        = "merge"          # --no-ff merge commit
    SQUASH       = "squash"         # squash all commits into one
    REBASE       = "rebase"         # rebase then fast-forward
    FAST_FORWARD = "fast_forward"   # only if already up-to-date


class ConflictStatus(Enum):
    NONE         = "none"
    CONFLICTS    = "conflicts"
    UNKNOWN      = "unknown"


class FileChangeType(Enum):
    ADDED    = "A"
    MODIFIED = "M"
    DELETED  = "D"
    RENAMED  = "R"
    COPIED   = "C"
    UNMERGED = "U"
    UNKNOWN  = "?"


# ─── Core dataclasses ─────────────────────────────────────────────────────────

@dataclass
class Author:
    name:  str
    email: str
    when:  datetime = field(default_factory=datetime.utcnow)

    def __str__(self) -> str:
        return f"{self.name} <{self.email}>"


@dataclass
class Commit:
    sha:        str
    short_sha:  str
    message:    str
    author:     Author
    committer:  Author
    parents:    list[str]         = field(default_factory=list)
    refs:       list[str]         = field(default_factory=list)
    stats:      dict[str, int]    = field(default_factory=dict)  # {additions, deletions, files}

    @property
    def subject(self) -> str:
        return self.message.splitlines()[0]

    @property
    def body(self) -> str:
        lines = self.message.splitlines()
        return "\n".join(lines[2:]) if len(lines) > 2 else ""


@dataclass
class FileChange:
    path:        str
    old_path:    Optional[str]       = None   # populated for renames
    change_type: FileChangeType      = FileChangeType.UNKNOWN
    additions:   int                 = 0
    deletions:   int                 = 0
    binary:      bool                = False
    diff:        Optional[str]       = None   # unified diff text, lazy-loaded


@dataclass
class Branch:
    name:         str
    commit_sha:   str
    is_remote:    bool           = False
    upstream:     Optional[str]  = None
    ahead:        int            = 0
    behind:       int            = 0
    is_default:   bool           = False
    protected:    bool           = False


@dataclass
class Tag:
    name:       str
    commit_sha: str
    message:    Optional[str]  = None
    tagger:     Optional[Author] = None
    is_annotated: bool = False


@dataclass
class Remote:
    name:     str
    fetch_url: str
    push_url:  str


@dataclass
class PullRequest:
    id:             str
    title:          str
    description:    str
    source_branch:  str
    target_branch:  str
    author:         Author
    state:          PRState               = PRState.OPEN
    created_at:     datetime              = field(default_factory=datetime.utcnow)
    updated_at:     datetime              = field(default_factory=datetime.utcnow)
    reviewers:      list[str]             = field(default_factory=list)
    labels:         list[str]             = field(default_factory=list)
    comments:       list["PRComment"]     = field(default_factory=list)
    reviews:        list["Review"]        = field(default_factory=list)
    checks:         list["CICheck"]       = field(default_factory=list)
    conflicts:      ConflictStatus        = ConflictStatus.UNKNOWN
    mergeable:      bool                  = True
    merge_strategy: MergeStrategy         = MergeStrategy.MERGE
    metadata:       dict[str, Any]        = field(default_factory=dict)

    @property
    def short_id(self) -> str:
        return f"#{self.id}"

    @property
    def review_decision(self) -> ReviewDecision:
        if not self.reviews:
            return ReviewDecision.PENDING
        decisions = [r.decision for r in self.reviews]
        if ReviewDecision.CHANGES_REQUESTED in decisions:
            return ReviewDecision.CHANGES_REQUESTED
        if all(d == ReviewDecision.APPROVED for d in decisions):
            return ReviewDecision.APPROVED
        return ReviewDecision.COMMENTED


@dataclass
class PRComment:
    id:        str
    author:    Author
    body:      str
    created_at: datetime = field(default_factory=datetime.utcnow)
    file_path:  Optional[str] = None
    line:       Optional[int] = None
    resolved:   bool = False

    @property
    def is_inline(self) -> bool:
        return self.file_path is not None


@dataclass
class Review:
    id:        str
    author:    Author
    decision:  ReviewDecision
    body:      str
    created_at: datetime = field(default_factory=datetime.utcnow)
    comments:  list[PRComment] = field(default_factory=list)


@dataclass
class CICheck:
    name:       str
    status:     str           # pending | running | success | failure | cancelled
    url:        Optional[str] = None
    conclusion: Optional[str] = None
    started_at: Optional[datetime] = None
    ended_at:   Optional[datetime] = None

    @property
    def icon(self) -> str:
        icons = {
            "success":   "✔",
            "failure":   "✘",
            "pending":   "◌",
            "running":   "↻",
            "cancelled": "⊘",
        }
        return icons.get(self.status, "?")


@dataclass
class MergeResult:
    success:       bool
    merge_sha:     Optional[str]   = None
    conflicts:     list[str]       = field(default_factory=list)
    error:         Optional[str]   = None
    strategy_used: Optional[MergeStrategy] = None


@dataclass
class DiffStat:
    files_changed: int = 0
    insertions:    int = 0
    deletions:     int = 0
    changes:       list[FileChange] = field(default_factory=list)


@dataclass
class RepoInfo:
    path:          str
    scm_type:      SCMType
    name:          str
    default_branch: str
    remotes:       list[Remote]   = field(default_factory=list)
    description:   Optional[str] = None
    is_bare:       bool           = False
    size_kb:       int            = 0


# ─── Error hierarchy ──────────────────────────────────────────────────────────

class SCMError(Exception):
    """Base for all SCM errors."""
    def __init__(self, message: str, code: int = 0, stderr: str = ""):
        super().__init__(message)
        self.code   = code
        self.stderr = stderr


class SCMNotFoundError(SCMError):
    """Repo, branch, commit, or PR not found."""


class SCMConflictError(SCMError):
    """Merge or operation resulted in conflicts."""
    def __init__(self, message: str, conflicting_files: list[str] = None, **kw):
        super().__init__(message, **kw)
        self.conflicting_files = conflicting_files or []


class SCMPermissionError(SCMError):
    """Insufficient permissions for the operation."""


class SCMValidationError(SCMError):
    """Input validation failed before sending to SCM."""


class SCMNotSupportedError(SCMError):
    """This adapter does not support this operation."""


# ─── Audit event ──────────────────────────────────────────────────────────────

@dataclass
class AuditEvent:
    operation:  str
    scm_type:   SCMType
    repo_path:  str
    actor:      str
    timestamp:  datetime          = field(default_factory=datetime.utcnow)
    params:     dict[str, Any]    = field(default_factory=dict)
    result:     str               = "success"   # success | failure
    error:      Optional[str]     = None

    @property
    def fingerprint(self) -> str:
        raw = f"{self.operation}{self.repo_path}{self.actor}{self.timestamp.isoformat()}"
        return hashlib.sha256(raw.encode()).hexdigest()[:16]


AuditCallback = Callable[[AuditEvent], None]


# ─── Abstract provider ────────────────────────────────────────────────────────

class SCMProvider(ABC):
    """
    Abstract base class for all SCM adapters.

    Implementors must override every @abstractmethod.
    Optional operations raise SCMNotSupportedError by default —
    adapters override only what their backend supports.
    """

    def __init__(self, repo_path: str, actor: str = "scmtool"):
        self.repo_path     = repo_path
        self.actor         = actor
        self._audit_hooks: list[AuditCallback] = []

    # ── Lifecycle ─────────────────────────────────────────────────────────────

    @property
    @abstractmethod
    def scm_type(self) -> SCMType: ...

    @abstractmethod
    def is_valid_repo(self) -> bool:
        """Return True if repo_path is a valid repo for this adapter."""

    @abstractmethod
    def get_repo_info(self) -> RepoInfo:
        """Return metadata about the repository."""

    # ── Commits ───────────────────────────────────────────────────────────────

    @abstractmethod
    def get_commit(self, ref: str) -> Commit:
        """Resolve any ref (SHA, branch, tag, HEAD~N, etc.) to a Commit."""

    @abstractmethod
    def log(
        self,
        ref: str = "HEAD",
        max_count: int = 50,
        path: Optional[str] = None,
        author: Optional[str] = None,
        since: Optional[datetime] = None,
        until: Optional[datetime] = None,
    ) -> Iterator[Commit]:
        """Stream commits in reverse-chronological order."""

    @abstractmethod
    def diff(self, from_ref: str, to_ref: str, path: Optional[str] = None) -> DiffStat:
        """Return a diff between two refs, optionally scoped to a path."""

    # ── Branches ──────────────────────────────────────────────────────────────

    @abstractmethod
    def list_branches(self, include_remote: bool = True) -> list[Branch]:
        """List all branches (local + optionally remote)."""

    @abstractmethod
    def get_branch(self, name: str) -> Branch:
        """Get a single branch by name."""

    @abstractmethod
    def create_branch(self, name: str, from_ref: str = "HEAD") -> Branch:
        """Create and return a new branch."""

    @abstractmethod
    def delete_branch(self, name: str, force: bool = False) -> None:
        """Delete a branch. Raise SCMError if unmerged and force=False."""

    @abstractmethod
    def current_branch(self) -> str:
        """Return the name of the currently checked-out branch."""

    @abstractmethod
    def checkout(self, ref: str) -> None:
        """Check out a branch or commit."""

    # ── Tags ──────────────────────────────────────────────────────────────────

    @abstractmethod
    def list_tags(self) -> list[Tag]:
        """List all tags."""

    @abstractmethod
    def create_tag(self, name: str, ref: str = "HEAD", message: Optional[str] = None) -> Tag:
        """Create a lightweight or annotated tag."""

    @abstractmethod
    def delete_tag(self, name: str) -> None:
        """Delete a tag locally."""

    # ── Remotes ───────────────────────────────────────────────────────────────

    @abstractmethod
    def list_remotes(self) -> list[Remote]:
        """List configured remotes."""

    @abstractmethod
    def fetch(self, remote: str = "origin", prune: bool = True) -> None:
        """Fetch from a remote."""

    @abstractmethod
    def pull(self, remote: str = "origin", branch: Optional[str] = None,
             strategy: MergeStrategy = MergeStrategy.MERGE) -> MergeResult:
        """Pull (fetch + merge/rebase) from a remote."""

    @abstractmethod
    def push(self, remote: str = "origin", branch: Optional[str] = None,
             force: bool = False, tags: bool = False) -> None:
        """Push to a remote."""

    # ── Merge & Rebase ────────────────────────────────────────────────────────

    @abstractmethod
    def merge(self, source_branch: str, strategy: MergeStrategy = MergeStrategy.MERGE,
              message: Optional[str] = None) -> MergeResult:
        """Merge source_branch into the current branch."""

    @abstractmethod
    def can_merge(self, source_branch: str, target_branch: str) -> ConflictStatus:
        """Dry-run merge to check for conflicts without changing state."""

    def rebase(self, onto: str) -> MergeResult:
        raise SCMNotSupportedError(f"{self.scm_type.value} adapter does not support rebase")

    def cherry_pick(self, sha: str) -> MergeResult:
        raise SCMNotSupportedError(f"{self.scm_type.value} adapter does not support cherry-pick")

    # ── Pull Requests (optional — remote-platform operations) ─────────────────

    def list_pull_requests(self, state: PRState = PRState.OPEN) -> list[PullRequest]:
        raise SCMNotSupportedError(f"{self.scm_type.value} adapter does not support pull requests")

    def get_pull_request(self, pr_id: str) -> PullRequest:
        raise SCMNotSupportedError(f"{self.scm_type.value} adapter does not support pull requests")

    def create_pull_request(
        self,
        title: str,
        description: str,
        source_branch: str,
        target_branch: str,
        reviewers: list[str] = None,
        labels: list[str] = None,
        draft: bool = False,
    ) -> PullRequest:
        raise SCMNotSupportedError(f"{self.scm_type.value} adapter does not support pull requests")

    def update_pull_request(self, pr_id: str, **kwargs) -> PullRequest:
        raise SCMNotSupportedError(f"{self.scm_type.value} adapter does not support pull requests")

    def close_pull_request(self, pr_id: str) -> PullRequest:
        raise SCMNotSupportedError(f"{self.scm_type.value} adapter does not support pull requests")

    def merge_pull_request(
        self,
        pr_id: str,
        strategy: MergeStrategy = MergeStrategy.MERGE,
        message: Optional[str] = None,
        delete_branch: bool = False,
    ) -> MergeResult:
        raise SCMNotSupportedError(f"{self.scm_type.value} adapter does not support pull requests")

    def add_review(self, pr_id: str, decision: ReviewDecision, body: str = "") -> Review:
        raise SCMNotSupportedError(f"{self.scm_type.value} adapter does not support reviews")

    def add_comment(self, pr_id: str, body: str,
                    file_path: Optional[str] = None, line: Optional[int] = None) -> PRComment:
        raise SCMNotSupportedError(f"{self.scm_type.value} adapter does not support comments")

    # ── Stash / shelve ────────────────────────────────────────────────────────

    def stash_push(self, message: Optional[str] = None) -> str:
        raise SCMNotSupportedError(f"{self.scm_type.value} adapter does not support stash")

    def stash_list(self) -> list[dict]:
        raise SCMNotSupportedError(f"{self.scm_type.value} adapter does not support stash")

    def stash_pop(self, index: int = 0) -> None:
        raise SCMNotSupportedError(f"{self.scm_type.value} adapter does not support stash")

    def stash_drop(self, index: int = 0) -> None:
        raise SCMNotSupportedError(f"{self.scm_type.value} adapter does not support stash")

    # ── Working tree ──────────────────────────────────────────────────────────

    @abstractmethod
    def status(self) -> list[FileChange]:
        """Return working tree / index status."""

    def stage(self, paths: list[str]) -> None:
        raise SCMNotSupportedError(f"{self.scm_type.value} adapter does not support staging")

    def unstage(self, paths: list[str]) -> None:
        raise SCMNotSupportedError(f"{self.scm_type.value} adapter does not support unstaging")

    def commit(self, message: str, amend: bool = False) -> Commit:
        raise SCMNotSupportedError(f"{self.scm_type.value} adapter does not support commit")

    def discard(self, paths: list[str]) -> None:
        raise SCMNotSupportedError(f"{self.scm_type.value} adapter does not support discard")

    # ── Hooks ─────────────────────────────────────────────────────────────────

    def install_hook(self, hook_name: str, script_path: str) -> None:
        raise SCMNotSupportedError(f"{self.scm_type.value} adapter does not support hooks")

    def list_hooks(self) -> list[str]:
        raise SCMNotSupportedError(f"{self.scm_type.value} adapter does not support hooks")

    # ── Audit ─────────────────────────────────────────────────────────────────

    def register_audit_hook(self, callback: AuditCallback) -> None:
        self._audit_hooks.append(callback)

    def _emit_audit(self, operation: str, params: dict = None,
                    result: str = "success", error: str = None) -> None:
        event = AuditEvent(
            operation=operation,
            scm_type=self.scm_type,
            repo_path=self.repo_path,
            actor=self.actor,
            params=params or {},
            result=result,
            error=error,
        )
        for hook in self._audit_hooks:
            try:
                hook(event)
            except Exception:
                pass  # audit hooks must never break the main flow

    # ── Utility ───────────────────────────────────────────────────────────────

    def __repr__(self) -> str:
        return f"<{self.__class__.__name__} repo={self.repo_path!r}>"
