#Requires -Version 5.1
<#
.SYNOPSIS
    GitCron Manager (PowerShell) — Git-Native Pipeline & Task Scheduler
    Author  : Cybopsec
    Version : 3.0.0

.DESCRIPTION
    Architecture:
      Task Scheduler (time triggers)  ──┐
      Git hooks (all standard hooks)  ──┤──► wrapper engine ──► primary
      Manual / test-run               ──┘         │               │ fail
                                                  │            fallback
                                                  │               │ fail
                                             git notes        fail-handler
                                             audit trail      (notify/log/
                                                               shutdown/restart/custom)

    Requires: PowerShell 5.1+, Git for Windows, Windows Task Scheduler
    Run as Administrator for full Task Scheduler access.
#>

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# ─── Paths ────────────────────────────────────────────────────────────────────
$Script:BaseDir      = Join-Path $env:APPDATA 'GitCronManager'
$Script:WrapperDir   = Join-Path $Script:BaseDir 'Wrappers'
$Script:LogDir       = Join-Path $Script:BaseDir 'Logs'
$Script:PipelineDir  = Join-Path $Script:BaseDir 'Pipelines'
$Script:BackupDir    = Join-Path $Script:BaseDir 'Backups'
$Script:TrackFile    = Join-Path $Script:BaseDir 'tracked_repos.txt'
$Script:MgrLog       = Join-Path $Script:BaseDir 'manager.log'
$Script:TaskFolder   = '\GitCronManaged'

foreach ($d in @($Script:BaseDir, $Script:WrapperDir, $Script:LogDir,
                  $Script:PipelineDir, $Script:BackupDir)) {
    if (-not (Test-Path $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
}

# ─── All standard git hooks ───────────────────────────────────────────────────
$Script:GitHooks = @(
    [PSCustomObject]@{ Name='applypatch-msg';         Desc='Validate patch message';                Phase='apply-patch' }
    [PSCustomObject]@{ Name='pre-applypatch';         Desc='Before patch is applied';              Phase='apply-patch' }
    [PSCustomObject]@{ Name='post-applypatch';        Desc='After patch is applied';               Phase='apply-patch' }
    [PSCustomObject]@{ Name='pre-commit';             Desc='Before commit is created';             Phase='commit'      }
    [PSCustomObject]@{ Name='prepare-commit-msg';     Desc='Populate commit message template';     Phase='commit'      }
    [PSCustomObject]@{ Name='commit-msg';             Desc='Validate commit message';              Phase='commit'      }
    [PSCustomObject]@{ Name='post-commit';            Desc='After commit is created';              Phase='commit'      }
    [PSCustomObject]@{ Name='pre-rebase';             Desc='Before rebase begins';                 Phase='rebase'      }
    [PSCustomObject]@{ Name='post-checkout';          Desc='After checkout or clone';              Phase='checkout'    }
    [PSCustomObject]@{ Name='post-merge';             Desc='After successful merge';               Phase='merge'       }
    [PSCustomObject]@{ Name='pre-push';               Desc='Before push to remote';               Phase='push'        }
    [PSCustomObject]@{ Name='pre-receive';            Desc='Remote: before refs updated';          Phase='receive'     }
    [PSCustomObject]@{ Name='update';                 Desc='Remote: before each ref updated';      Phase='receive'     }
    [PSCustomObject]@{ Name='post-receive';           Desc='Remote: after refs updated';           Phase='receive'     }
    [PSCustomObject]@{ Name='post-update';            Desc='Remote: after all refs updated';       Phase='receive'     }
    [PSCustomObject]@{ Name='reference-transaction';  Desc='During reference transaction';         Phase='refs'        }
    [PSCustomObject]@{ Name='push-to-checkout';       Desc='Remote: non-bare push';                Phase='push'        }
    [PSCustomObject]@{ Name='pre-auto-gc';            Desc='Before automatic garbage collection';  Phase='maintenance' }
    [PSCustomObject]@{ Name='post-rewrite';           Desc='After rebase or amend rewrites';       Phase='rewrite'     }
    [PSCustomObject]@{ Name='sendemail-validate';     Desc='Before git send-email';               Phase='email'       }
    [PSCustomObject]@{ Name='fsmonitor-watchman';     Desc='Filesystem monitor integration';       Phase='monitor'     }
    [PSCustomObject]@{ Name='post-index-change';      Desc='After index is written';              Phase='index'       }
)

# ─── Logging ──────────────────────────────────────────────────────────────────
function Write-MgrLog {
    param([string]$Level, [string]$Message)
    $entry = '[{0}] [{1,-5}] {2}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Level, $Message
    Add-Content -Path $Script:MgrLog -Value $entry -Encoding UTF8
}
function Log-Info  { param($m) Write-MgrLog 'INFO'  $m }
function Log-Warn  { param($m) Write-MgrLog 'WARN'  $m }
function Log-Error { param($m) Write-MgrLog 'ERROR' $m }

# ─── UI helpers ───────────────────────────────────────────────────────────────
function Show-Header {
    Clear-Host
    Write-Host ('╔' + '═' * 62 + '╗') -ForegroundColor Cyan
    Write-Host '║       GITCRON MANAGER  v3.0  //  Cybopsec                     ║' -ForegroundColor Cyan
    Write-Host '║       Git-Native Pipeline & Task Scheduler (PowerShell)        ║' -ForegroundColor Cyan
    Write-Host ('╚' + '═' * 62 + '╝') -ForegroundColor Cyan
    Write-Host ''
}

function Show-SubHeader { param($t) Write-Host ("`n  ── $t ──`n") -ForegroundColor White }
function Write-Divider  { Write-Host ('─' * 64) -ForegroundColor DarkBlue }
function Write-OK       { param($m) Write-Host "[✔] $m" -ForegroundColor Green  }
function Write-Warn     { param($m) Write-Host "[!] $m" -ForegroundColor Yellow }
function Write-Err      { param($m) Write-Host "[✘] $m" -ForegroundColor Red    }
function Write-Info     { param($m) Write-Host "[i] $m" -ForegroundColor Cyan   }
function Write-Git      { param($m) Write-Host "[git] $m" -ForegroundColor Magenta }
function Pause-Screen   { Read-Host "`nPress [Enter] to continue" | Out-Null }

# ─── Admin check ──────────────────────────────────────────────────────────────
function Test-Admin {
    ([Security.Principal.WindowsPrincipal]
     [Security.Principal.WindowsIdentity]::GetCurrent()
    ).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

# ─── Git helpers ──────────────────────────────────────────────────────────────
function Test-GitRepo {
    param([string]$Path)
    if (-not (Test-Path $Path)) { return $false }
    try {
        $null = & git -C $Path rev-parse --git-dir 2>&1
        return ($LASTEXITCODE -eq 0)
    } catch { return $false }
}

function Get-TrackedRepos {
    if (Test-Path $Script:TrackFile) {
        Get-Content $Script:TrackFile | Where-Object { $_.Trim() -ne '' }
    }
}

function Register-Repo {
    param([string]$Path)
    $existing = Get-TrackedRepos
    if ($existing -notcontains $Path) {
        Add-Content -Path $Script:TrackFile -Value $Path -Encoding UTF8
    }
}

function Unregister-Repo {
    param([string]$Path)
    if (Test-Path $Script:TrackFile) {
        $lines = Get-Content $Script:TrackFile | Where-Object { $_ -ne $Path }
        Set-Content -Path $Script:TrackFile -Value $lines -Encoding UTF8
    }
}

function Write-GitAudit {
    param([string]$RepoPath, [string]$Event, [string]$Status, [string]$Detail)
    if (-not (Test-GitRepo $RepoPath)) { return }
    $msg = "[GITCRON] event=$Event status=$Status detail=$Detail ts=$(Get-Date -Format 'o')"
    try {
        & git -C $RepoPath notes --ref=gitcron-events append -m $msg HEAD 2>$null
    } catch {}
}

function Pick-Repo {
    $repos = @(Get-TrackedRepos)
    if ($repos.Count -eq 0) { Write-Err "No repositories tracked. Add one first."; return $null }
    $i = 1
    foreach ($r in $repos) {
        Write-Host ("  {0,2}) {1}" -f $i, $r) -ForegroundColor Yellow
        $i++
    }
    $pick = Read-Host "`n  Select repo"
    $idx  = [int]$pick - 1
    if ($idx -lt 0 -or $idx -ge $repos.Count) { Write-Err "Invalid selection."; return $null }
    return $repos[$idx]
}

function Pick-Hook {
    Write-Host "`n  Available git hooks:`n"
    $prevPhase = ''
    $i = 1
    foreach ($h in $Script:GitHooks) {
        if ($h.Phase -ne $prevPhase) {
            Write-Host "  [$($h.Phase)]" -ForegroundColor Magenta
            $prevPhase = $h.Phase
        }
        Write-Host ("    {0,2}) {1,-35} {2}" -f $i, $h.Name, $h.Desc) -ForegroundColor Yellow
        $i++
    }
    $pick = Read-Host "`n  Select hook number"
    $idx  = [int]$pick - 1
    if ($idx -lt 0 -or $idx -ge $Script:GitHooks.Count) { Write-Err "Invalid."; return $null }
    return $Script:GitHooks[$idx].Name
}

# ─── Hook dispatcher builder ──────────────────────────────────────────────────
# Generates a .ps1 dispatcher that reads a pipeline file and runs
# primary → fallback → fail-handler per stage, with git audit notes
function Install-HookDispatcher {
    param([string]$RepoPath, [string]$HookName)

    $hooksDir      = Join-Path $RepoPath '.git\hooks'
    $hookScript    = Join-Path $hooksDir $HookName
    $pipelineFile  = Join-Path $Script:PipelineDir "$(Split-Path $RepoPath -Leaf)_$HookName.pipeline"
    $jobLog        = Join-Path $Script:LogDir       "$(Split-Path $RepoPath -Leaf)_$HookName.log"
    $repoPathEsc   = $RepoPath -replace "'", "''"

    if (-not (Test-Path $hooksDir)) { New-Item -ItemType Directory -Path $hooksDir -Force | Out-Null }

    # Git on Windows calls hooks as executables. We create a cmd shim that
    # calls powershell, plus the actual .ps1 dispatcher.
    $shimPath = "$hookScript"   # no extension — git expects no extension on hooks
    $ps1Path  = "$hookScript.ps1"

    # PowerShell dispatcher
    $dispatcher = @"
#Requires -Version 5.1
# GitCron hook dispatcher: $HookName
# Managed by gitcron_manager.ps1
Set-StrictMode -Version Latest
`$ErrorActionPreference = 'Continue'

`$HookName     = '$HookName'
`$RepoPath     = '$repoPathEsc'
`$PipelineFile = '$($pipelineFile -replace "'","''")'
`$LogFile      = '$($jobLog -replace "'","''")'
`$Ts           = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
`$HookArgs     = `$args   # pass-through: pre-push etc. receive args

function Write-HLog {
    param([string]`$Msg)
    `$ts2 = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    Add-Content -Path `$LogFile -Value "[`$ts2] [`$HookName] `$Msg" -Encoding UTF8
}

Write-HLog "=== Hook fired: `$HookName ==="

if (-not (Test-Path `$PipelineFile)) {
    Write-HLog "No pipeline file found — hook is a no-op"
    exit 0
}

`$stageNum    = 0
`$overallExit = 0

foreach (`$line in (Get-Content `$PipelineFile)) {
    if (`$line -match '^#' -or `$line.Trim() -eq '') { continue }
    `$parts = `$line -split '\|', 7
    if (`$parts.Count -lt 6) { continue }

    `$stage, `$pExe, `$pArgs, `$fExe, `$fArgs, `$fAction, `$fCmd = `$parts
    `$stageNum++
    Write-HLog "STAGE `$stageNum [`$stage] starting"

    # ── Primary ───────────────────────────────────────────────────────────────
    Write-HLog "  primary: `$pExe `$pArgs"
    try {
        `$proc = Start-Process -FilePath `$pExe -ArgumentList `$pArgs ``
                               -NoNewWindow -PassThru -Wait -RedirectStandardOutput `$LogFile -ErrorAction Stop
        if (`$proc.ExitCode -eq 0) { Write-HLog "  PRIMARY SUCCESS"; continue }
        Write-HLog "  WARN primary exited `$(`$proc.ExitCode)"
    } catch { Write-HLog "  WARN primary threw: `$_" }

    # ── Fallback ──────────────────────────────────────────────────────────────
    if (`$fExe -and `$fExe.Trim() -ne '') {
        Write-HLog "  fallback: `$fExe `$fArgs"
        try {
            `$proc2 = Start-Process -FilePath `$fExe -ArgumentList `$fArgs ``
                                    -NoNewWindow -PassThru -Wait -ErrorAction Stop
            if (`$proc2.ExitCode -eq 0) { Write-HLog "  FALLBACK SUCCESS"; continue }
            Write-HLog "  ERROR fallback exited `$(`$proc2.ExitCode)"
        } catch { Write-HLog "  ERROR fallback threw: `$_" }
    } else {
        Write-HLog "  No fallback configured for stage `$stage"
    }

    Write-HLog "  FULL_FAIL stage=`$stage handler=`$fAction"
    `$overallExit = 2

    # ── Full-fail handler ─────────────────────────────────────────────────────
    switch (`$fAction.Trim()) {
        'notify' {
            try {
                Add-Type -AssemblyName System.Windows.Forms
                `$balloon = New-Object System.Windows.Forms.NotifyIcon
                `$balloon.Icon = [System.Drawing.SystemIcons]::Error
                `$balloon.BalloonTipIcon  = 'Error'
                `$balloon.BalloonTipTitle = 'GitCron Hook Failure'
                `$balloon.BalloonTipText  = "[`$HookName] Stage `$stage failed @ `$Ts"
                `$balloon.Visible = `$true
                `$balloon.ShowBalloonTip(10000)
                Write-HLog "  fail-handler: notification sent"
            } catch { Write-HLog "  notification failed: `$_" }
        }
        'abort' {
            Write-HLog "  fail-handler: ABORT — blocking git operation"
            exit 1
        }
        'log' {
            Add-Content -Path `$LogFile -Value ("=" * 50) -Encoding UTF8
            Write-HLog "  fail-handler: log only"
        }
        'shutdown' {
            Write-HLog "  fail-handler: system shutdown"
            try { Stop-Computer -Force } catch { Write-HLog "  shutdown failed: `$_" }
            exit 2
        }
        'restart' {
            Write-HLog "  fail-handler: system restart"
            try { Restart-Computer -Force } catch { Write-HLog "  restart failed: `$_" }
            exit 2
        }
        'custom' {
            Write-HLog "  fail-handler: custom"
            try { Invoke-Expression `$fCmd 2>&1 | Add-Content `$LogFile -Encoding UTF8 }
            catch { Write-HLog "  custom failed: `$_" }
        }
        default { Write-HLog "  fail-handler: unknown '`$fAction' — logged only" }
    }
}

# Git audit note
try {
    & git -C `$RepoPath notes --ref=gitcron-events append ``
        -m "[GITCRON] hook=`$HookName stages=`$stageNum exit=`$overallExit ts=`$Ts" HEAD 2>`$null
} catch {}

exit `$overallExit
"@

    Set-Content -Path $ps1Path -Value $dispatcher -Encoding UTF8

    # Shim: no-extension wrapper git actually calls on Windows
    $shim = @"
@echo off
powershell.exe -NonInteractive -NoProfile -ExecutionPolicy Bypass -File "%~dp0$HookName.ps1" %*
"@
    Set-Content -Path $shimPath -Value $shim -Encoding ASCII

    Log-Info "Installed hook dispatcher: $hookScript"
    return $ps1Path
}

# ─── Pipeline stage builder ───────────────────────────────────────────────────
function Add-PipelineStage {
    param([string]$PipelineFile, [string]$StageName)

    Show-SubHeader "Pipeline Stage: $StageName"

    # Primary
    do {
        $pExe = Read-Host "  Primary executable path (e.g. C:\Python312\python.exe)"
        if (-not (Test-Path $pExe -PathType Leaf)) { Write-Err "'$pExe' not found." }
    } while (-not (Test-Path $pExe -PathType Leaf))
    $pArgs = Read-Host "  Primary script/arguments"

    # Fallback
    Write-Divider
    $useFb = Read-Host "  Add fallback? [y/N]"
    $fExe = ''; $fArgs = ''
    if ($useFb -match '^[Yy]$') {
        do {
            $fExe = Read-Host "  Fallback executable path"
            if (-not (Test-Path $fExe -PathType Leaf)) { Write-Err "'$fExe' not found." }
        } while (-not (Test-Path $fExe -PathType Leaf))
        $fArgs = Read-Host "  Fallback arguments"
    }

    # Fail action
    Write-Divider
    Write-Host "  On full failure for this stage:" -ForegroundColor White
    Write-Host "    1) notify    2) abort (block git)    3) log (default)"
    Write-Host "    4) shutdown  5) restart              6) custom"
    $fc = Read-Host "  Choice [1-6]"
    $fAction = 'log'; $fCmd = ''
    switch ($fc) {
        '1' { $fAction = 'notify'   }
        '2' { $fAction = 'abort'    }
        '4' { $fAction = 'shutdown'; Write-Warn "System will shut down on failure!" }
        '5' { $fAction = 'restart';  Write-Warn "System will restart on failure!"   }
        '6' { $fAction = 'custom';   $fCmd = Read-Host "  PowerShell snippet" }
    }

    $line = "$StageName|$pExe|$pArgs|$fExe|$fArgs|$fAction|$fCmd"
    Add-Content -Path $PipelineFile -Value $line -Encoding UTF8
    Write-OK "Stage '$StageName' added to pipeline."
}

# ─── Cron/Task wrapper builder ────────────────────────────────────────────────
function New-TaskWrapper {
    param(
        [string]$JobName,
        [string]$RepoPath,
        [string]$PrimaryExe,
        [string]$PrimaryArgs,
        [string]$FallbackExe,
        [string]$FallbackArgs,
        [string]$FailAction,
        [string]$CustomCmd
    )

    $wrapperPath = Join-Path $Script:WrapperDir "$JobName.ps1"
    $jobLog      = Join-Path $Script:LogDir     "$JobName.log"
    $repoEsc     = $RepoPath -replace "'", "''"

    $lines = @()
    $lines += '#Requires -Version 5.1'
    $lines += "# GitCron wrapper: $JobName"
    $lines += 'Set-StrictMode -Version Latest'
    $lines += '$ErrorActionPreference = "Continue"'
    $lines += ''
    $lines += "`$JobName  = '$JobName'"
    $lines += "`$RepoPath = '$repoEsc'"
    $lines += "`$JobLog   = '$($jobLog -replace "'","''")'"
    $lines += ''
    $lines += 'function Write-WLog {'
    $lines += '    param([string]$Msg)'
    $lines += '    $ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss"'
    $lines += '    Add-Content -Path $JobLog -Value "[$ts] [$JobName] $Msg" -Encoding UTF8'
    $lines += '}'
    $lines += ''
    $lines += 'function Write-GitAudit {'
    $lines += '    param([string]$Status, [string]$Detail)'
    $lines += '    if (-not $RepoPath) { return }'
    $lines += '    try {'
    $lines += '        $msg = "[GITCRON] job=$JobName status=$Status detail=$Detail ts=$(Get-Date -Format o)"'
    $lines += '        & git -C $RepoPath notes --ref=gitcron-events append -m $msg HEAD 2>$null'
    $lines += '    } catch {}'
    $lines += '}'
    $lines += ''
    $lines += 'Write-WLog "=== START ==="'
    $lines += ''

    # Primary
    $lines += "Write-WLog `"primary: $PrimaryExe $PrimaryArgs`""
    $lines += 'try {'
    $lines += "    `$p = Start-Process -FilePath '$PrimaryExe' ``"
    if ($PrimaryArgs) { $lines += "        -ArgumentList '$PrimaryArgs' ``" }
    $lines += '        -NoNewWindow -PassThru -Wait'
    $lines += '    if ($p.ExitCode -eq 0) { Write-WLog "PRIMARY SUCCESS"; Write-GitAudit "success" "primary"; exit 0 }'
    $lines += '    Write-WLog "WARN primary exited $($p.ExitCode)"'
    $lines += '} catch { Write-WLog "WARN primary threw: $_" }'
    $lines += ''

    # Fallback
    if ($FallbackExe) {
        $lines += "Write-WLog `"fallback: $FallbackExe $FallbackArgs`""
        $lines += 'try {'
        $lines += "    `$f = Start-Process -FilePath '$FallbackExe' ``"
        if ($FallbackArgs) { $lines += "        -ArgumentList '$FallbackArgs' ``" }
        $lines += '        -NoNewWindow -PassThru -Wait'
        $lines += '    if ($f.ExitCode -eq 0) { Write-WLog "FALLBACK SUCCESS"; Write-GitAudit "success" "fallback"; exit 0 }'
        $lines += '    Write-WLog "ERROR fallback exited $($f.ExitCode)"'
        $lines += '} catch { Write-WLog "ERROR fallback threw: $_" }'
        $lines += ''
    }

    $lines += "Write-WLog `"FULL_FAIL handler=$FailAction`""
    $lines += "Write-GitAudit 'FULL_FAIL' '$FailAction'"

    switch ($FailAction) {
        'notify' {
            $lines += 'try {'
            $lines += '    Add-Type -AssemblyName System.Windows.Forms'
            $lines += '    $b = New-Object System.Windows.Forms.NotifyIcon'
            $lines += '    $b.Icon = [System.Drawing.SystemIcons]::Error'
            $lines += '    $b.BalloonTipIcon = "Error"; $b.BalloonTipTitle = "GitCron Failure"'
            $lines += "    `$b.BalloonTipText = `"[$JobName] Failed @ `$(Get-Date)`""
            $lines += '    $b.Visible = $true; $b.ShowBalloonTip(10000)'
            $lines += '    Write-WLog "fail-handler: notification sent"'
            $lines += '} catch { Write-WLog "notification failed: $_" }'
        }
        'log' {
            $lines += 'Add-Content -Path $JobLog -Value ("=" * 50) -Encoding UTF8'
            $lines += 'Write-WLog "fail-handler: log only"'
        }
        'shutdown' {
            $lines += 'Write-WLog "fail-handler: shutdown"'
            $lines += 'try { Stop-Computer -Force } catch { Write-WLog "shutdown failed: $_" }'
        }
        'restart' {
            $lines += 'Write-WLog "fail-handler: restart"'
            $lines += 'try { Restart-Computer -Force } catch { Write-WLog "restart failed: $_" }'
        }
        'custom' {
            $lines += 'Write-WLog "fail-handler: custom"'
            $lines += "try { $CustomCmd 2>&1 | Add-Content `$JobLog -Encoding UTF8 }"
            $lines += 'catch { Write-WLog "custom failed: $_" }'
        }
        default { $lines += 'Write-WLog "fail-handler: unknown — logged only"' }
    }

    $lines += 'exit 2'
    $lines -join "`n" | Set-Content -Path $wrapperPath -Encoding UTF8
    return $wrapperPath
}

# ─── Task Scheduler helpers ───────────────────────────────────────────────────
function Ensure-TaskFolder {
    $svc = New-Object -ComObject 'Schedule.Service'
    $svc.Connect()
    $root = $svc.GetFolder('\')
    try { $root.GetFolder($Script:TaskFolder) | Out-Null }
    catch { $root.CreateFolder($Script:TaskFolder) | Out-Null }
}

function Get-ManagedTasks {
    try { @(Get-ScheduledTask -TaskPath "$Script:TaskFolder\" -ErrorAction SilentlyContinue) }
    catch { @() }
}

function New-TriggerFromMenu {
    Write-Host "`n  Trigger type:" -ForegroundColor White
    Write-Host "    1) Once    2) Daily    3) Weekly    4) Monthly"
    Write-Host "    5) At startup          6) At logon"
    $tc = Read-Host "  Choice [1-6]"
    switch ($tc) {
        '1' { $dt = Read-Host "  Datetime (e.g. '2026-01-01 03:00')"
              return New-ScheduledTaskTrigger -Once -At ([datetime]$dt) }
        '2' { $t = Read-Host "  Time (e.g. '02:00')"
              $i = Read-Host "  Every N days [1]"; if (-not $i) { $i = 1 }
              return New-ScheduledTaskTrigger -Daily -At $t -DaysInterval ([int]$i) }
        '3' { $t = Read-Host "  Time"
              $wd = (Read-Host "  Days (e.g. Monday,Wednesday)") -split ',' | ForEach-Object { $_.Trim() }
              return New-ScheduledTaskTrigger -Weekly -At $t -DaysOfWeek $wd }
        '4' { $t = Read-Host "  Time"
              $d = Read-Host "  Day of month (1-31)"
              return New-ScheduledTaskTrigger -Monthly -At $t -DaysOfMonth ([int]$d) }
        '5' { return New-ScheduledTaskTrigger -AtStartup }
        '6' { return New-ScheduledTaskTrigger -AtLogOn   }
        default { Write-Warn "Defaulting to daily at 02:00"
                  return New-ScheduledTaskTrigger -Daily -At '02:00' }
    }
}

# ══════════════════════════════════════════════════════════════════════════════
#  MODULE: Repository Management
# ══════════════════════════════════════════════════════════════════════════════
function Menu-Repos {
    while ($true) {
        Show-Header; Show-SubHeader "Repository Management"
        Write-Host "  1) Clone a repository"
        Write-Host "  2) Init a new repository"
        Write-Host "  3) Track an existing repository"
        Write-Host "  4) List tracked repositories"
        Write-Host "  5) Repository status overview"
        Write-Host "  6) View git log for a repo"
        Write-Host "  7) View GitCron audit notes"
        Write-Host "  0) Back`n"
        Write-Divider
        $c = Read-Host "`n  Choice"
        switch ($c) {
            '1' { Invoke-RepoClone   }
            '2' { Invoke-RepoInit    }
            '3' { Invoke-RepoTrack   }
            '4' { Show-RepoList      }
            '5' { Show-RepoStatus    }
            '6' { Show-RepoLog       }
            '7' { Show-AuditNotes    }
            '0' { return }
            default { Write-Err "Invalid."; Start-Sleep 1 }
        }
    }
}

function Invoke-RepoClone {
    Show-Header; Show-SubHeader "Clone Repository"
    $url = Read-Host "  Remote URL"
    if (-not $url) { Write-Err "URL required."; Pause-Screen; return }
    $name = [System.IO.Path]::GetFileNameWithoutExtension($url)
    $dest = Join-Path $env:USERPROFILE "GitCronRepos\$name"
    Write-Git "Cloning $url → $dest"
    try {
        & git clone $url $dest
        if ($LASTEXITCODE -eq 0) {
            Register-Repo $dest; Write-OK "Cloned and registered: $dest"
            Log-Info "Cloned $url → $dest"
        } else { Write-Err "Clone failed." }
    } catch { Write-Err "Clone error: $_" }
    Pause-Screen
}

function Invoke-RepoInit {
    Show-Header; Show-SubHeader "Init Repository"
    $name = Read-Host "  Repository name"
    if (-not $name) { Write-Err "Name required."; Pause-Screen; return }
    $dest = Join-Path $env:USERPROFILE "GitCronRepos\$name"
    New-Item -ItemType Directory -Path $dest -Force | Out-Null
    & git init $dest
    if ($LASTEXITCODE -eq 0) {
        Register-Repo $dest; Write-OK "Initialized: $dest"; Log-Info "Init: $dest"
    } else { Write-Err "Init failed." }
    Pause-Screen
}

function Invoke-RepoTrack {
    Show-Header; Show-SubHeader "Track Existing Repository"
    $path = Read-Host "  Absolute path to repo"
    if (Test-GitRepo $path) {
        Register-Repo $path; Write-OK "Tracking: $path"; Log-Info "Track: $path"
    } else { Write-Err "'$path' is not a valid git repository." }
    Pause-Screen
}

function Show-RepoList {
    Show-Header; Show-SubHeader "Tracked Repositories"
    $repos = @(Get-TrackedRepos)
    if ($repos.Count -eq 0) { Write-Warn "No repositories tracked." }
    else {
        $i = 1
        foreach ($r in $repos) {
            $branch = '(unknown)'
            if (Test-GitRepo $r) {
                $b = & git -C $r branch --show-current 2>$null
                if ($b) { $branch = $b }
            }
            Write-Host ("  {0,2}) {1,-50} " -f $i, $r) -NoNewline -ForegroundColor Yellow
            Write-Host "[$branch]" -ForegroundColor Cyan
            $i++
        }
    }
    Pause-Screen
}

function Show-RepoStatus {
    Show-Header; Show-SubHeader "Repository Status Overview"
    $repos = @(Get-TrackedRepos)
    if ($repos.Count -eq 0) { Write-Warn "No repos."; Pause-Screen; return }
    foreach ($r in $repos) {
        Write-Host "`n  $r" -ForegroundColor Cyan
        if (Test-GitRepo $r) {
            & git -C $r status -sb 2>&1 | ForEach-Object { Write-Host "    $_" }
            try {
                $delta = & git -C $r rev-list --count --left-right '@{upstream}...HEAD' 2>$null
                Write-Host "    remote delta: $delta" -ForegroundColor DarkGray
            } catch {}
        } else { Write-Err "  Not a git repo." }
    }
    Pause-Screen
}

function Show-RepoLog {
    Show-Header; Show-SubHeader "Git Log"
    $repo = Pick-Repo; if (-not $repo) { Pause-Screen; return }
    & git -C $repo log --oneline --graph --decorate --color -20
    Pause-Screen
}

function Show-AuditNotes {
    Show-Header; Show-SubHeader "GitCron Audit Notes"
    $repo = Pick-Repo; if (-not $repo) { Pause-Screen; return }
    Write-Git "Audit notes for $repo"
    try {
        $shas = & git -C $repo notes --ref=gitcron-events list 2>$null
        if (-not $shas) { Write-Warn "No audit notes found." }
        else {
            foreach ($sha in $shas) {
                Write-Host "`n--- $sha ---" -ForegroundColor DarkGray
                & git -C $repo notes --ref=gitcron-events show $sha 2>$null
            }
        }
    } catch { Write-Err "Could not read notes: $_" }
    Pause-Screen
}

# ══════════════════════════════════════════════════════════════════════════════
#  MODULE: Hook Pipeline Manager
# ══════════════════════════════════════════════════════════════════════════════
function Menu-Hooks {
    while ($true) {
        Show-Header; Show-SubHeader "Git Hook Pipeline Manager"
        Write-Host "  1) Install hook pipeline on a repo"
        Write-Host "  2) Add stage to existing pipeline"
        Write-Host "  3) View pipeline file"
        Write-Host "  4) List installed hooks on a repo"
        Write-Host "  5) Remove hook from a repo"
        Write-Host "  6) Browse all available git hooks"
        Write-Host "  0) Back`n"
        Write-Divider
        $c = Read-Host "`n  Choice"
        switch ($c) {
            '1' { Install-HookPipeline  }
            '2' { Add-HookStage         }
            '3' { View-Pipeline         }
            '4' { List-RepoHooks        }
            '5' { Remove-RepoHook       }
            '6' { Browse-Hooks          }
            '0' { return }
            default { Write-Err "Invalid."; Start-Sleep 1 }
        }
    }
}

function Install-HookPipeline {
    Show-Header; Show-SubHeader "Install Hook Pipeline"
    $repo = Pick-Repo;  if (-not $repo) { Pause-Screen; return }
    $hook = Pick-Hook;  if (-not $hook) { Pause-Screen; return }

    $pipelineFile = Join-Path $Script:PipelineDir "$(Split-Path $repo -Leaf)_$hook.pipeline"

    if (Test-Path $pipelineFile) {
        Write-Warn "Pipeline already exists: $pipelineFile"
        $ow = Read-Host "  Overwrite? [y/N]"
        if ($ow -notmatch '^[Yy]$') { Write-Info "Cancelled."; Pause-Screen; return }
        Clear-Content $pipelineFile
    } else {
        "# GitCron pipeline: $hook on $repo`n# Format: STAGE|pExe|pArgs|fExe|fArgs|failAction|customCmd`n" |
            Set-Content $pipelineFile -Encoding UTF8
    }

    $ps1 = Install-HookDispatcher -RepoPath $repo -HookName $hook
    Write-OK "Hook dispatcher installed: $ps1"

    $stageName = Read-Host "  First stage name"
    if ($stageName) { Add-PipelineStage -PipelineFile $pipelineFile -StageName $stageName }

    Write-Info "Pipeline: $pipelineFile"
    Log-Info "Installed hook '$hook' on '$repo'"
    Pause-Screen
}

function Add-HookStage {
    Show-Header; Show-SubHeader "Add Pipeline Stage"
    $repo = Pick-Repo; if (-not $repo) { Pause-Screen; return }
    $hook = Pick-Hook; if (-not $hook) { Pause-Screen; return }
    $pf   = Join-Path $Script:PipelineDir "$(Split-Path $repo -Leaf)_$hook.pipeline"
    if (-not (Test-Path $pf)) { Write-Err "No pipeline file. Install the hook first."; Pause-Screen; return }
    $name = Read-Host "  New stage name"
    if ($name) { Add-PipelineStage -PipelineFile $pf -StageName $name }
    Pause-Screen
}

function View-Pipeline {
    Show-Header; Show-SubHeader "View Pipeline"
    $repo = Pick-Repo; if (-not $repo) { Pause-Screen; return }
    $hook = Pick-Hook; if (-not $hook) { Pause-Screen; return }
    $pf   = Join-Path $Script:PipelineDir "$(Split-Path $repo -Leaf)_$hook.pipeline"
    if (-not (Test-Path $pf)) { Write-Warn "No pipeline file found."; Pause-Screen; return }

    Write-Host "`n  $pf`n" -ForegroundColor Cyan
    $i = 0
    foreach ($line in (Get-Content $pf)) {
        if ($line -match '^#' -or $line.Trim() -eq '') { Write-Host "  $line" -ForegroundColor DarkGray; continue }
        $p = $line -split '\|', 7
        $i++
        Write-Host "`n  [Stage $i] $($p[0])" -ForegroundColor Green
        Write-Host "    primary  : $($p[1]) $($p[2])"
        if ($p[3]) { Write-Host "    fallback : $($p[3]) $($p[4])" }
        Write-Host "    on-fail  : $($p[5])" -ForegroundColor Yellow
        if ($p.Count -gt 6 -and $p[6]) { Write-Host "    custom   : $($p[6])" }
    }
    Pause-Screen
}

function List-RepoHooks {
    Show-Header; Show-SubHeader "Installed Hooks"
    $repo = Pick-Repo; if (-not $repo) { Pause-Screen; return }
    $hooksDir = Join-Path $repo '.git\hooks'
    Write-Host "`n  Hooks in $hooksDir`n"
    foreach ($h in $Script:GitHooks) {
        $p = Join-Path $hooksDir $h.Name
        if (Test-Path $p) {
            $managed = if ((Get-Content $p -Raw) -match 'GitCron') { ' [gitcron]' } else { '' }
            Write-Host ("  [✔] {0,-35}{1}" -f $h.Name, $managed) -ForegroundColor Green
        }
    }
    Pause-Screen
}

function Remove-RepoHook {
    Show-Header; Show-SubHeader "Remove Hook"
    $repo = Pick-Repo; if (-not $repo) { Pause-Screen; return }
    $hook = Pick-Hook; if (-not $hook) { Pause-Screen; return }
    $hp   = Join-Path $repo ".git\hooks\$hook"
    if (-not (Test-Path $hp)) { Write-Warn "Hook '$hook' not installed."; Pause-Screen; return }
    $c = Read-Host "  Remove '$hook' from $(Split-Path $repo -Leaf)? [y/N]"
    if ($c -notmatch '^[Yy]$') { Write-Info "Cancelled."; Pause-Screen; return }
    Remove-Item $hp -Force
    $ps1 = "$hp.ps1"
    if (Test-Path $ps1) { Remove-Item $ps1 -Force }
    Write-OK "Hook removed."
    $pf = Join-Path $Script:PipelineDir "$(Split-Path $repo -Leaf)_$hook.pipeline"
    if (Test-Path $pf) {
        $dp = Read-Host "  Delete pipeline file too? [y/N]"
        if ($dp -match '^[Yy]$') { Remove-Item $pf -Force; Write-OK "Pipeline deleted." }
    }
    Log-Info "Removed hook '$hook' from '$repo'"
    Pause-Screen
}

function Browse-Hooks {
    Show-Header; Show-SubHeader "All Available Git Hooks"
    $prev = ''
    foreach ($h in $Script:GitHooks) {
        if ($h.Phase -ne $prev) { Write-Host "`n  [$($h.Phase)]" -ForegroundColor Magenta; $prev = $h.Phase }
        Write-Host ("    {0,-35} {1}" -f $h.Name, $h.Desc) -ForegroundColor Yellow
    }
    Pause-Screen
}

# ══════════════════════════════════════════════════════════════════════════════
#  MODULE: Task Scheduler Manager
# ══════════════════════════════════════════════════════════════════════════════
function Menu-Tasks {
    while ($true) {
        Show-Header; Show-SubHeader "Task Scheduler Manager"
        Write-Host "  1) List managed tasks"
        Write-Host "  2) Add task (with git audit trail)"
        Write-Host "  3) Remove task"
        Write-Host "  4) Enable / Disable task"
        Write-Host "  5) Test-run a task now"
        Write-Host "  6) Backup / Restore task list"
        Write-Host "  0) Back`n"
        Write-Divider
        $c = Read-Host "`n  Choice"
        switch ($c) {
            '1' { Show-Tasks         }
            '2' { Add-ManagedTask    }
            '3' { Remove-ManagedTask }
            '4' { Toggle-Task        }
            '5' { Test-RunTask       }
            '6' { Backup-Tasks       }
            '0' { return }
            default { Write-Err "Invalid."; Start-Sleep 1 }
        }
    }
}

function Show-Tasks {
    Show-Header; Show-SubHeader "Managed Scheduled Tasks"
    $tasks = Get-ManagedTasks
    if ($tasks.Count -eq 0) { Write-Warn "No managed tasks found." }
    else {
        $i = 1
        foreach ($t in $tasks) {
            $stateColor = switch ($t.State) { 1 { 'Red' } 4 { 'Green' } default { 'Yellow' } }
            $stateName  = switch ($t.State) { 0{'Unknown'} 1{'Disabled'} 2{'Queued'} 3{'Ready'} 4{'Running'} default{$t.State} }
            Write-Host ("  {0,2}) {1,-40}" -f $i, $t.TaskName) -NoNewline -ForegroundColor Yellow
            Write-Host " [$stateName]" -ForegroundColor $stateColor
            $i++
        }
        Write-Info "Total: $($tasks.Count) task(s)"
    }
    Pause-Screen
}

function Add-ManagedTask {
    Show-Header; Show-SubHeader "Add Managed Task"

    do { $jobName = Read-Host "  Task label (alphanumeric + _-)" }
    while ($jobName -notmatch '^[a-zA-Z0-9_-]+$')

    $trigger = New-TriggerFromMenu

    Write-Divider
    $useRepo = Read-Host "  Bind to a tracked repo for git audit? [y/N]"
    $repoPath = ''
    if ($useRepo -match '^[Yy]$') {
        $repoPath = Pick-Repo
        if (-not $repoPath) { $repoPath = '' }
    }

    Write-Divider
    do {
        $pExe = Read-Host "  Primary executable path"
        if (-not (Test-Path $pExe -PathType Leaf)) { Write-Err "'$pExe' not found." }
    } while (-not (Test-Path $pExe -PathType Leaf))
    $pArgs = Read-Host "  Primary arguments"

    Write-Divider
    $useFb = Read-Host "  Add fallback? [y/N]"
    $fExe = ''; $fArgs = ''
    if ($useFb -match '^[Yy]$') {
        do {
            $fExe = Read-Host "  Fallback executable"
            if (-not (Test-Path $fExe -PathType Leaf)) { Write-Err "'$fExe' not found." }
        } while (-not (Test-Path $fExe -PathType Leaf))
        $fArgs = Read-Host "  Fallback arguments"
    }

    Write-Divider
    Write-Host "  On full failure:  1)notify  2)log  3)shutdown  4)restart  5)custom"
    $fc = Read-Host "  Choice [default=2]"
    $fAction = 'log'; $fCmd = ''
    switch ($fc) {
        '1' { $fAction = 'notify'   }
        '3' { $fAction = 'shutdown'; Write-Warn "System will shut down on failure!" }
        '4' { $fAction = 'restart';  Write-Warn "System will restart on failure!"   }
        '5' { $fAction = 'custom';   $fCmd = Read-Host "  PowerShell snippet" }
    }

    Write-Info "Building wrapper..."
    try {
        $wp = New-TaskWrapper $jobName $repoPath $pExe $pArgs $fExe $fArgs $fAction $fCmd
        Ensure-TaskFolder

        $action   = New-ScheduledTaskAction -Execute 'powershell.exe' `
                        -Argument "-NonInteractive -NoProfile -ExecutionPolicy Bypass -File `"$wp`""
        $settings = New-ScheduledTaskSettingsSet -ExecutionTimeLimit (New-TimeSpan -Hours 2) `
                        -StartWhenAvailable -RunOnlyIfNetworkAvailable:$false

        Register-ScheduledTask -TaskName $jobName -TaskPath $Script:TaskFolder `
            -Action $action -Trigger $trigger -Settings $settings -RunLevel Highest -Force | Out-Null

        Write-OK "Task '$jobName' registered."
        Write-Info "Wrapper  : $wp"
        Write-Info "Job log  : $(Join-Path $Script:LogDir "$jobName.log")"
        if ($repoPath) { Write-Info "Git repo : $repoPath" }
        Log-Info "Added task '$jobName'"
    } catch { Write-Err "Failed: $_"; Log-Error "Add task '$jobName': $_" }
    Pause-Screen
}

function Remove-ManagedTask {
    Show-Header; Show-SubHeader "Remove Task"
    $tasks = @(Get-ManagedTasks)
    if ($tasks.Count -eq 0) { Write-Warn "No tasks."; Pause-Screen; return }
    $i = 1
    foreach ($t in $tasks) { Write-Host ("  {0,2}) {1}" -f $i, $t.TaskName) -ForegroundColor Yellow; $i++ }
    $pick = Read-Host "`n  Select (0 to cancel)"
    if ($pick -eq '0') { return }
    $idx = [int]$pick - 1
    if ($idx -lt 0 -or $idx -ge $tasks.Count) { Write-Err "Invalid."; Pause-Screen; return }
    $t = $tasks[$idx]
    $c = Read-Host "  Remove '$($t.TaskName)'? [y/N]"
    if ($c -notmatch '^[Yy]$') { Write-Info "Cancelled."; Pause-Screen; return }
    Unregister-ScheduledTask -TaskName $t.TaskName -TaskPath $Script:TaskFolder -Confirm:$false
    Write-OK "Task removed."
    $wp = Join-Path $Script:WrapperDir "$($t.TaskName).ps1"
    if (Test-Path $wp) {
        $dw = Read-Host "  Delete wrapper '$wp'? [y/N]"
        if ($dw -match '^[Yy]$') { Remove-Item $wp -Force; Write-OK "Wrapper deleted." }
    }
    Log-Info "Removed task '$($t.TaskName)'"
    Pause-Screen
}

function Toggle-Task {
    Show-Header; Show-SubHeader "Enable / Disable Task"
    $tasks = @(Get-ManagedTasks)
    if ($tasks.Count -eq 0) { Write-Warn "No tasks."; Pause-Screen; return }
    $i = 1
    foreach ($t in $tasks) {
        $st = if ($t.State -eq 1) { '[Disabled]' } else { '[Enabled] ' }
        Write-Host ("  {0,2}) {1} {2}" -f $i, $st, $t.TaskName) -ForegroundColor Yellow
        $i++
    }
    $pick = Read-Host "`n  Select (0 to cancel)"
    if ($pick -eq '0') { return }
    $idx = [int]$pick - 1
    if ($idx -lt 0 -or $idx -ge $tasks.Count) { Write-Err "Invalid."; Pause-Screen; return }
    $t = $tasks[$idx]
    if ($t.State -eq 1) {
        Enable-ScheduledTask  -TaskName $t.TaskName -TaskPath $Script:TaskFolder | Out-Null
        Write-OK "Enabled '$($t.TaskName)'"
    } else {
        Disable-ScheduledTask -TaskName $t.TaskName -TaskPath $Script:TaskFolder | Out-Null
        Write-OK "Disabled '$($t.TaskName)'"
    }
    Pause-Screen
}

function Test-RunTask {
    Show-Header; Show-SubHeader "Test-Run Task"
    $tasks = @(Get-ManagedTasks)
    if ($tasks.Count -eq 0) { Write-Warn "No tasks."; Pause-Screen; return }
    $i = 1
    foreach ($t in $tasks) { Write-Host ("  {0,2}) {1}" -f $i, $t.TaskName) -ForegroundColor Yellow; $i++ }
    $pick = Read-Host "`n  Select (0 to cancel)"
    if ($pick -eq '0') { return }
    $idx = [int]$pick - 1
    if ($idx -lt 0 -or $idx -ge $tasks.Count) { Write-Err "Invalid."; Pause-Screen; return }
    $t = $tasks[$idx]
    Write-Info "Starting '$($t.TaskName)' immediately..."
    Start-ScheduledTask -TaskName $t.TaskName -TaskPath $Script:TaskFolder
    Write-OK "Task triggered. Log: $(Join-Path $Script:LogDir "$($t.TaskName).log")"
    Pause-Screen
}

function Backup-Tasks {
    Show-Header; Show-SubHeader "Backup / Restore Tasks"
    Write-Host "  1) Export all managed tasks to XML"
    Write-Host "  2) Import tasks from XML backup"
    Write-Host "  0) Back`n"
    $c = Read-Host "  Choice"
    switch ($c) {
        '1' {
            $tasks = @(Get-ManagedTasks)
            if ($tasks.Count -eq 0) { Write-Warn "No tasks to back up." }
            else {
                $bFile = Join-Path $Script:BackupDir "tasks_$(Get-Date -Format 'yyyyMMdd_HHmmss').xml"
                $tasks | Export-Clixml -Path $bFile
                Write-OK "Backed up to $bFile"; Log-Info "Task backup: $bFile"
            }
        }
        '2' {
            $bFiles = @(Get-ChildItem $Script:BackupDir -Filter 'tasks_*.xml' | Sort-Object Name -Descending)
            if ($bFiles.Count -eq 0) { Write-Warn "No backups found." }
            else {
                $i = 1
                foreach ($f in $bFiles) { Write-Host ("  {0,2}) {1}" -f $i, $f.Name) -ForegroundColor Yellow; $i++ }
                $pick = Read-Host "`n  Select"
                $idx  = [int]$pick - 1
                if ($idx -ge 0 -and $idx -lt $bFiles.Count) {
                    Write-Info "Restore from '$($bFiles[$idx].Name)' — re-register tasks manually after review."
                    Import-Clixml $bFiles[$idx].FullName | Format-List
                } else { Write-Err "Invalid." }
            }
        }
    }
    Pause-Screen
}

# ══════════════════════════════════════════════════════════════════════════════
#  MODULE: Git Operations
# ══════════════════════════════════════════════════════════════════════════════
function Menu-GitOps {
    while ($true) {
        Show-Header; Show-SubHeader "Git Operations"
        Write-Host "  1) Pull all tracked repos"
        Write-Host "  2) Push a repo"
        Write-Host "  3) Commit staged changes"
        Write-Host "  4) Create / checkout branch"
        Write-Host "  5) Tag a release"
        Write-Host "  6) Stash / pop"
        Write-Host "  7) Manually fire a hook pipeline"
        Write-Host "  0) Back`n"
        Write-Divider
        $c = Read-Host "`n  Choice"
        switch ($c) {
            '1' { Pull-AllRepos    }
            '2' { Push-Repo        }
            '3' { Commit-Repo      }
            '4' { Branch-Repo      }
            '5' { Tag-Repo         }
            '6' { Stash-Repo       }
            '7' { Fire-HookManual  }
            '0' { return }
            default { Write-Err "Invalid."; Start-Sleep 1 }
        }
    }
}

function Pull-AllRepos {
    Show-Header; Show-SubHeader "Pull All Tracked Repos"
    $repos = @(Get-TrackedRepos)
    if ($repos.Count -eq 0) { Write-Warn "No repos."; Pause-Screen; return }
    foreach ($r in $repos) {
        Write-Host "`n  → $r" -ForegroundColor Cyan
        if (Test-GitRepo $r) {
            & git -C $r pull --ff-only 2>&1 | ForEach-Object { Write-Host "    $_" }
            if ($LASTEXITCODE -eq 0) { Write-OK "Pulled." } else { Write-Warn "Pull had issues." }
        } else { Write-Err "Not a git repo." }
    }
    Pause-Screen
}

function Push-Repo {
    Show-Header; Show-SubHeader "Push Repo"
    $repo = Pick-Repo; if (-not $repo) { Pause-Screen; return }
    $remote = Read-Host "  Remote [origin]"; if (-not $remote) { $remote = 'origin' }
    $branch = & git -C $repo branch --show-current 2>$null
    $b = Read-Host "  Branch [$branch]"; if ($b) { $branch = $b }
    Write-Git "git push $remote $branch"
    & git -C $repo push $remote $branch
    if ($LASTEXITCODE -eq 0) { Write-OK "Pushed." } else { Write-Err "Push failed." }
    Pause-Screen
}

function Commit-Repo {
    Show-Header; Show-SubHeader "Commit Staged Changes"
    $repo = Pick-Repo; if (-not $repo) { Pause-Screen; return }
    & git -C $repo status -s
    $msg = Read-Host "`n  Commit message"
    if (-not $msg) { Write-Err "Message required."; Pause-Screen; return }
    & git -C $repo commit -m $msg
    if ($LASTEXITCODE -eq 0) { Write-OK "Committed." } else { Write-Err "Commit failed." }
    Pause-Screen
}

function Branch-Repo {
    Show-Header; Show-SubHeader "Branch Management"
    $repo = Pick-Repo; if (-not $repo) { Pause-Screen; return }
    & git -C $repo branch -a
    Write-Host "`n  1) Create  2) Checkout  0) Back"
    $c = Read-Host "  Choice"
    switch ($c) {
        '1' { $n = Read-Host "  New branch name"
              & git -C $repo checkout -b $n
              if ($LASTEXITCODE -eq 0) { Write-OK "Created '$n'." } }
        '2' { $n = Read-Host "  Branch name"
              & git -C $repo checkout $n
              if ($LASTEXITCODE -eq 0) { Write-OK "Checked out '$n'." } }
    }
    Pause-Screen
}

function Tag-Repo {
    Show-Header; Show-SubHeader "Create Tag"
    $repo = Pick-Repo; if (-not $repo) { Pause-Screen; return }
    $tag = Read-Host "  Tag (e.g. v1.0.0)"
    $msg = Read-Host "  Message"
    & git -C $repo tag -a $tag -m $msg
    if ($LASTEXITCODE -eq 0) {
        Write-OK "Tag '$tag' created."
        $push = Read-Host "  Push to origin? [y/N]"
        if ($push -match '^[Yy]$') { & git -C $repo push origin $tag }
    } else { Write-Err "Tagging failed." }
    Pause-Screen
}

function Stash-Repo {
    Show-Header; Show-SubHeader "Stash / Pop"
    $repo = Pick-Repo; if (-not $repo) { Pause-Screen; return }
    Write-Host "  1) Stash   2) Pop   3) List"
    $c = Read-Host "  Choice"
    switch ($c) {
        '1' { & git -C $repo stash;      if ($LASTEXITCODE -eq 0) { Write-OK "Stashed."  } }
        '2' { & git -C $repo stash pop;  if ($LASTEXITCODE -eq 0) { Write-OK "Popped."   } }
        '3' { & git -C $repo stash list }
    }
    Pause-Screen
}

function Fire-HookManual {
    Show-Header; Show-SubHeader "Manually Fire Hook Pipeline"
    $repo = Pick-Repo; if (-not $repo) { Pause-Screen; return }
    $hook = Pick-Hook; if (-not $hook) { Pause-Screen; return }
    $ps1  = Join-Path $repo ".git\hooks\$hook.ps1"
    if (-not (Test-Path $ps1)) { Write-Err "Hook '$hook' not installed."; Pause-Screen; return }
    Write-Warn "This executes the pipeline directly (no git operation)."
    $c = Read-Host "  Continue? [y/N]"
    if ($c -notmatch '^[Yy]$') { Write-Info "Cancelled."; Pause-Screen; return }
    Write-Host "`nFiring: $hook on $(Split-Path $repo -Leaf)`n" -ForegroundColor Green
    & powershell.exe -NonInteractive -NoProfile -ExecutionPolicy Bypass -File $ps1
    if ($LASTEXITCODE -eq 0) { Write-OK "Pipeline completed." } else { Write-Err "Pipeline exited $LASTEXITCODE." }
    Pause-Screen
}

# ══════════════════════════════════════════════════════════════════════════════
#  MODULE: Logs
# ══════════════════════════════════════════════════════════════════════════════
function Menu-Logs {
    Show-Header; Show-SubHeader "View / Tail Logs"
    $logs = @(Get-ChildItem $Script:LogDir -Filter '*.log' -ErrorAction SilentlyContinue | Sort-Object Name)
    $logs += Get-Item $Script:MgrLog -ErrorAction SilentlyContinue
    $logs  = @($logs | Where-Object { $_ })

    if ($logs.Count -eq 0) { Write-Warn "No logs found."; Pause-Screen; return }
    $i = 1
    foreach ($f in $logs) { Write-Host ("  {0,2}) {1}" -f $i, $f.Name) -ForegroundColor Yellow; $i++ }
    $pick = Read-Host "`n  Select log (0 to cancel)"
    if ($pick -eq '0') { return }
    $idx = [int]$pick - 1
    if ($idx -lt 0 -or $idx -ge $logs.Count) { Write-Err "Invalid."; Pause-Screen; return }

    $target = $logs[$idx].FullName
    Write-Host "`nTailing: $($logs[$idx].Name)  — Ctrl-C to stop`n" -ForegroundColor Cyan

    $pos = (Get-Item $target).Length
    while ($true) {
        Start-Sleep -Milliseconds 400
        $newSize = (Get-Item $target).Length
        if ($newSize -gt $pos) {
            $fs = [System.IO.File]::Open($target, 'Open', 'Read', 'ReadWrite')
            $fs.Seek($pos, 'Begin') | Out-Null
            $sr = New-Object System.IO.StreamReader($fs)
            Write-Host $sr.ReadToEnd() -NoNewline
            $sr.Close(); $fs.Close()
            $pos = $newSize
        }
    }
}

# ══════════════════════════════════════════════════════════════════════════════
#  MAIN
# ══════════════════════════════════════════════════════════════════════════════
function Main {
    if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
        Write-Host "[FATAL] git not found in PATH. Install Git for Windows." -ForegroundColor Red
        exit 1
    }
    if (-not (Test-Admin)) {
        Write-Warn "Not running as Administrator — Task Scheduler operations may fail."
        Write-Warn "Re-launch as Administrator for full functionality."
        Start-Sleep 2
    }

    Log-Info "gitcron_manager v3.0 started (user: $env:USERNAME)"

    while ($true) {
        Show-Header
        Write-Host "  1) Repository Management"       -ForegroundColor Yellow
        Write-Host "  2) Git Hook Pipeline Manager"   -ForegroundColor Yellow
        Write-Host "  3) Task Scheduler Manager"      -ForegroundColor Yellow
        Write-Host "  4) View / Tail Logs"            -ForegroundColor Yellow
        Write-Host "  5) Git Operations"              -ForegroundColor Yellow
        Write-Host "  0) Exit`n"                      -ForegroundColor Yellow
        Write-Divider

        $choice = Read-Host "`n  Select module"
        switch ($choice) {
            '1' { Menu-Repos   }
            '2' { Menu-Hooks   }
            '3' { Menu-Tasks   }
            '4' { Menu-Logs    }
            '5' { Menu-GitOps  }
            '0' { Log-Info "gitcron_manager exited"
                  Write-Host "`nGoodbye.`n" -ForegroundColor Cyan; return }
            default { Write-Err "Invalid option '$choice'."; Start-Sleep 1 }
        }
    }
}

Main
