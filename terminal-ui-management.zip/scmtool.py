#!/usr/bin/env python3
"""
scmtool.py — SCM Management Tool TUI
======================================
Author  : Cybopsec
Version : 1.0.0

A self-contained terminal UI for managing git (and other SCM) repositories,
pull requests, merges, reviews, branches, tags, hooks, and pipelines.

Requires: Python 3.9+, git (optional: svn)
No pip installs needed — all stdlib.
"""

from __future__ import annotations

import json
import os
import shutil
import signal
import subprocess
import sys
import textwrap
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Optional

# Ensure our modules are importable
sys.path.insert(0, str(Path(__file__).parent))

from core.scm_provider import (
    SCMError, SCMNotFoundError, SCMNotSupportedError, SCMValidationError,
    MergeStrategy, PRState, ReviewDecision, ConflictStatus,
)
from core.registry import get_provider, detect_scm_type, list_available_adapters


# ─── Terminal primitives ──────────────────────────────────────────────────────

def _supports_color() -> bool:
    return hasattr(sys.stdout, "isatty") and sys.stdout.isatty()


if _supports_color():
    R  = "\033[0m"       # reset
    B  = "\033[1m"       # bold
    D  = "\033[2m"       # dim
    IT = "\033[3m"       # italic

    FG = {
        "red":     "\033[31m", "green":   "\033[32m", "yellow": "\033[33m",
        "blue":    "\033[34m", "magenta": "\033[35m", "cyan":   "\033[36m",
        "white":   "\033[37m", "bright_red":   "\033[91m",
        "bright_green": "\033[92m", "bright_yellow": "\033[93m",
        "bright_blue":  "\033[94m", "bright_cyan":   "\033[96m",
    }
    BG = {
        "red": "\033[41m", "blue": "\033[44m", "green": "\033[42m",
        "dark": "\033[40m",
    }
else:
    R = B = D = IT = ""
    FG = {k: "" for k in ["red","green","yellow","blue","magenta","cyan","white",
                           "bright_red","bright_green","bright_yellow","bright_blue","bright_cyan"]}
    BG = {k: "" for k in ["red","blue","green","dark"]}


def c(text: str, *codes: str) -> str:
    """Wrap text in ANSI codes."""
    if not codes: return text
    prefix = "".join(codes)
    return f"{prefix}{text}{R}"


def term_width() -> int:
    try:
        return os.get_terminal_size().columns
    except Exception:
        return 80


def clear() -> None:
    os.system("clear" if os.name != "nt" else "cls")


def divider(char: str = "─", color: str = "blue") -> None:
    w = min(term_width(), 80)
    print(c(char * w, FG[color]))


def header(title: str, subtitle: str = "") -> None:
    clear()
    w = min(term_width(), 80)
    print(c("╔" + "═" * (w - 2) + "╗", FG["cyan"], B))
    title_line = f"  {title}"
    pad = w - 2 - len(title_line)
    print(c("║" + title_line + " " * pad + "║", FG["cyan"], B))
    if subtitle:
        sub_line = f"  {subtitle}"
        pad2 = w - 2 - len(sub_line)
        print(c("║" + sub_line + " " * pad2 + "║", FG["cyan"], D))
    print(c("╚" + "═" * (w - 2) + "╝", FG["cyan"], B))
    print()


def sub_header(title: str) -> None:
    print(f"\n{c('  ── ' + title + ' ──', FG['white'], B)}\n")


def ok(msg: str)   -> None: print(c(f"  [✔] {msg}", FG["bright_green"], B))
def warn(msg: str) -> None: print(c(f"  [!] {msg}", FG["yellow"], B))
def err(msg: str)  -> None: print(c(f"  [✘] {msg}", FG["bright_red"], B), file=sys.stderr)
def info(msg: str) -> None: print(c(f"  [i] {msg}", FG["bright_cyan"]))
def git_msg(msg: str) -> None: print(c(f"  [git] {msg}", FG["magenta"], B))


def pause() -> None:
    try:
        input(f"\n  {c('Press [Enter] to continue...', B)}")
    except (KeyboardInterrupt, EOFError):
        pass


def ask(prompt: str, default: str = "", required: bool = False) -> str:
    full = f"  {c(prompt, B)}"
    if default:
        full += c(f" [{default}]", D)
    full += ": "
    while True:
        try:
            val = input(full).strip() or default
        except (KeyboardInterrupt, EOFError):
            return default
        if required and not val:
            err("This field is required.")
            continue
        return val


def ask_choice(prompt: str, choices: list[str], default: str = "") -> str:
    opts = "/".join(choices)
    full = f"  {c(prompt, B)} {c(f'({opts})', D)}"
    if default:
        full += c(f" [{default}]", D)
    full += ": "
    while True:
        try:
            val = input(full).strip().lower() or default.lower()
        except (KeyboardInterrupt, EOFError):
            return default
        if val in [c.lower() for c in choices]:
            return val
        err(f"Choose one of: {opts}")


def ask_int(prompt: str, min_val: int = 1, max_val: int = 9999,
            allow_zero: bool = True) -> Optional[int]:
    while True:
        raw = ask(prompt)
        if not raw: return None
        try:
            n = int(raw)
            if allow_zero and n == 0: return 0
            if min_val <= n <= max_val: return n
            err(f"Enter a number between {min_val} and {max_val}.")
        except ValueError:
            err("Enter a valid integer.")


def ask_multiline(prompt: str) -> str:
    print(f"  {c(prompt, B)} {c('(empty line to finish)', D)}")
    lines = []
    while True:
        try:
            line = input("  > ")
            if not line.strip() and lines:
                break
            lines.append(line)
        except (KeyboardInterrupt, EOFError):
            break
    return "\n".join(lines)


def pick_from_list(items: list[Any], label_fn: Callable[[Any], str],
                   prompt: str = "Select", allow_zero: bool = True) -> Optional[Any]:
    """Display a numbered list and return the selected item."""
    if not items:
        warn("No items to display.")
        return None
    for i, item in enumerate(items, 1):
        label = label_fn(item)
        print(f"  {c(f'{i:>3})', FG['yellow'], B)} {label}")
    if allow_zero:
        print(f"  {c('  0)', FG['yellow'], B)} {c('Cancel', D)}")
    n = ask_int(prompt, min_val=0, max_val=len(items))
    if n is None or n == 0:
        return None
    return items[n - 1]


def confirm(prompt: str, default: bool = False) -> bool:
    choices = ["Y", "n"] if default else ["y", "N"]
    val = ask_choice(prompt, choices, default="y" if default else "n")
    return val.lower() == "y"


def pager(text: str, title: str = "") -> None:
    """Display long text with a simple pager."""
    lines = text.splitlines()
    height = max(20, (os.get_terminal_size().lines if hasattr(os, "get_terminal_size") else 24) - 4)
    pos = 0
    while True:
        clear()
        if title:
            print(c(f"  {title}", FG["cyan"], B))
            divider()
        chunk = lines[pos:pos + height]
        for line in chunk:
            # Colorize diff lines
            if line.startswith("+++") or line.startswith("---"):
                print(c(line, FG["cyan"]))
            elif line.startswith("+"):
                print(c(line, FG["bright_green"]))
            elif line.startswith("-"):
                print(c(line, FG["bright_red"]))
            elif line.startswith("@@"):
                print(c(line, FG["magenta"]))
            else:
                print(line)
        print()
        total = len(lines)
        pct = int((pos + height) / max(total, 1) * 100)
        nav = c(f"  Lines {pos+1}–{min(pos+height, total)}/{total} ({pct}%)  "
                f"[n]ext [p]rev [q]uit", D)
        print(nav, end="", flush=True)
        try:
            cmd = input(" ").strip().lower()
        except (KeyboardInterrupt, EOFError):
            break
        if cmd in ("q", ""):
            break
        elif cmd == "n" and pos + height < total:
            pos += height
        elif cmd == "p" and pos > 0:
            pos = max(0, pos - height)


# ─── State ────────────────────────────────────────────────────────────────────

class AppState:
    def __init__(self):
        self.repo_path:   str             = os.getcwd()
        self.provider:    Any             = None
        self.actor:       str             = os.environ.get("USER", os.environ.get("USERNAME", "user"))
        self.config_path: Path            = Path.home() / ".scmtool" / "config.json"
        self.recent_repos: list[str]      = []
        self._load_config()

    def _load_config(self) -> None:
        self.config_path.parent.mkdir(parents=True, exist_ok=True)
        if self.config_path.exists():
            try:
                data = json.loads(self.config_path.read_text())
                self.actor        = data.get("actor",       self.actor)
                self.recent_repos = data.get("recent_repos", [])
            except Exception:
                pass

    def save_config(self) -> None:
        data = {"actor": self.actor, "recent_repos": self.recent_repos[-10:]}
        self.config_path.write_text(json.dumps(data, indent=2))

    def load_repo(self, path: str) -> bool:
        try:
            self.provider = get_provider(path, actor=self.actor)
            self.repo_path = path
            if path not in self.recent_repos:
                self.recent_repos.insert(0, path)
                self.recent_repos = self.recent_repos[:10]
            self.save_config()
            return True
        except SCMError as e:
            err(str(e))
            return False

    @property
    def has_repo(self) -> bool:
        return self.provider is not None

    def require_repo(self) -> bool:
        if not self.has_repo:
            warn("No repository loaded. Open one first (option 1 from the main menu).")
            pause()
            return False
        return True


STATE = AppState()


# ─── Repo info bar ────────────────────────────────────────────────────────────

def repo_bar() -> str:
    if not STATE.has_repo:
        return c("  No repository loaded", FG["yellow"], D)
    try:
        branch = STATE.provider.current_branch()
        scm    = STATE.provider.scm_type.value
        name   = Path(STATE.repo_path).name
        return (c(f"  {scm.upper()}", FG["magenta"], B) + " " +
                c(name, FG["white"], B) + "  " +
                c("⎇ " + branch, FG["cyan"]))
    except Exception:
        return c(f"  {STATE.repo_path}", D)


# ══════════════════════════════════════════════════════════════════════════════
#  SCREEN: Open / Clone Repository
# ══════════════════════════════════════════════════════════════════════════════

def screen_open_repo() -> None:
    header("Open Repository", "Open, clone, or init a repository")
    print(f"  {c('1)', FG['yellow'], B)} Open existing path")
    print(f"  {c('2)', FG['yellow'], B)} Clone from URL")
    print(f"  {c('3)', FG['yellow'], B)} Init new repository")
    print(f"  {c('4)', FG['yellow'], B)} Recent repositories")
    print(f"  {c('0)', FG['yellow'], B)} {c('Back', D)}\n")
    divider()

    choice = ask("Choice")
    if choice == "1":
        path = ask("Repository path", default=os.getcwd(), required=True)
        if STATE.load_repo(path):
            ok(f"Loaded: {path}")
        pause()

    elif choice == "2":
        url  = ask("Remote URL", required=True)
        dest = ask("Destination path", required=True)
        try:
            git_msg(f"Cloning {url}...")
            subprocess.run(["git", "clone", url, dest], check=True)
            if STATE.load_repo(dest):
                ok(f"Cloned to {dest}")
        except subprocess.CalledProcessError as e:
            err(f"Clone failed: {e}")
        pause()

    elif choice == "3":
        path = ask("New repo path", required=True)
        Path(path).mkdir(parents=True, exist_ok=True)
        try:
            subprocess.run(["git", "init", path], check=True)
            if STATE.load_repo(path):
                ok(f"Initialized: {path}")
        except subprocess.CalledProcessError as e:
            err(f"Init failed: {e}")
        pause()

    elif choice == "4":
        if not STATE.recent_repos:
            warn("No recent repositories.")
            pause()
            return
        repo = pick_from_list(
            STATE.recent_repos,
            label_fn=lambda r: c(r, FG["white"]),
            prompt="Select repo",
        )
        if repo and STATE.load_repo(repo):
            ok(f"Loaded: {repo}")
        pause()


# ══════════════════════════════════════════════════════════════════════════════
#  SCREEN: Repository Overview
# ══════════════════════════════════════════════════════════════════════════════

def screen_repo_overview() -> None:
    if not STATE.require_repo(): return
    p = STATE.provider
    header("Repository Overview", repo_bar())

    try:
        info_obj = p.get_repo_info()
        print(f"  {c('Name', B):30s} {info_obj.name}")
        print(f"  {c('SCM Type', B):30s} {info_obj.scm_type.value.upper()}")
        print(f"  {c('Path', B):30s} {info_obj.path}")
        print(f"  {c('Default Branch', B):30s} {c(info_obj.default_branch, FG['cyan'])}")
        print(f"  {c('Bare', B):30s} {'Yes' if info_obj.is_bare else 'No'}")
        if info_obj.size_kb:
            print(f"  {c('Size', B):30s} {info_obj.size_kb:,} KB")
        if info_obj.description:
            print(f"  {c('Description', B):30s} {info_obj.description}")

        divider()
        print(f"\n  {c('Remotes', B, FG['white'])}")
        for r in info_obj.remotes:
            print(f"    {c(r.name, FG['cyan'], B):20s} {r.fetch_url}")

        divider()
        print(f"\n  {c('Recent Commits', B, FG['white'])}")
        for commit in p.log(max_count=5):
            date_s = commit.author.when.strftime("%Y-%m-%d")
            print(
                f"    {c(commit.short_sha, FG['yellow'], B)}  "
                f"{c(date_s, D)}  "
                f"{c(commit.author.name[:18], FG['cyan'])}  "
                f"{commit.subject[:42]}"
            )

        divider()
        print(f"\n  {c('Working Tree Status', B, FG['white'])}")
        changes = p.status()
        if not changes:
            ok("Working tree clean")
        else:
            for fc in changes[:10]:
                icon = {
                    "A": c("+", FG["bright_green"]),
                    "M": c("~", FG["yellow"]),
                    "D": c("-", FG["bright_red"]),
                    "U": c("!", FG["bright_red"]),
                }.get(fc.change_type.value, c("?", D))
                print(f"    {icon}  {fc.path}")
            if len(changes) > 10:
                info(f"  ...and {len(changes)-10} more")

    except SCMError as e:
        err(str(e))
    pause()


# ══════════════════════════════════════════════════════════════════════════════
#  SCREEN: Pull Requests
# ══════════════════════════════════════════════════════════════════════════════

def _pr_state_badge(state) -> str:
    colors = {
        PRState.OPEN:   (FG["bright_green"], "OPEN"),
        PRState.MERGED: (FG["magenta"],      "MERGED"),
        PRState.CLOSED: (FG["bright_red"],   "CLOSED"),
        PRState.DRAFT:  (FG["yellow"],        "DRAFT"),
    }
    col, label = colors.get(state, (FG["white"], state.value.upper()))
    return c(f"[{label}]", col, B)


def _conflict_badge(status) -> str:
    if status == ConflictStatus.NONE:      return c("[✔ no conflicts]", FG["bright_green"])
    if status == ConflictStatus.CONFLICTS: return c("[✘ conflicts]",    FG["bright_red"], B)
    return c("[? unknown]", FG["yellow"])


def _review_badge(pr) -> str:
    rd = pr.review_decision
    if rd == ReviewDecision.APPROVED:          return c("[✔ approved]",   FG["bright_green"])
    if rd == ReviewDecision.CHANGES_REQUESTED: return c("[✘ changes req]", FG["bright_red"])
    if rd == ReviewDecision.COMMENTED:         return c("[💬 reviewed]",   FG["cyan"])
    return c("[⏳ pending]", FG["yellow"])


def screen_pull_requests() -> None:
    if not STATE.require_repo(): return

    while True:
        header("Pull Requests", repo_bar())
        print(f"  {c('1)', FG['yellow'], B)} List open PRs")
        print(f"  {c('2)', FG['yellow'], B)} List all PRs")
        print(f"  {c('3)', FG['yellow'], B)} Create PR")
        print(f"  {c('4)', FG['yellow'], B)} Review / merge a PR")
        print(f"  {c('5)', FG['yellow'], B)} View PR diff")
        print(f"  {c('6)', FG['yellow'], B)} Add comment to PR")
        print(f"  {c('0)', FG['yellow'], B)} {c('Back', D)}\n")
        divider()

        choice = ask("Choice")
        if   choice == "1": _pr_list(PRState.OPEN)
        elif choice == "2": _pr_list(None)
        elif choice == "3": _pr_create()
        elif choice == "4": _pr_review_merge()
        elif choice == "5": _pr_diff()
        elif choice == "6": _pr_comment()
        elif choice == "0": return


def _pr_list_items(state: Optional[PRState]) -> list:
    try:
        return STATE.provider.list_pull_requests(state=state)
    except SCMNotSupportedError:
        warn("This SCM adapter does not support pull requests.")
        pause()
        return []


def _pr_list(state: Optional[PRState]) -> None:
    header("Pull Requests", repo_bar())
    label = state.value.upper() if state else "ALL"
    sub_header(f"{label} Pull Requests")

    prs = _pr_list_items(state)
    if not prs:
        warn("No pull requests found.")
        pause()
        return

    for pr in prs:
        rd    = _review_badge(pr)
        st    = _pr_state_badge(pr.state)
        cf    = _conflict_badge(pr.conflicts)
        date  = pr.created_at.strftime("%Y-%m-%d")
        print(
            f"  {c(pr.short_id, FG['yellow'], B):10s}  {st}  {rd}  {cf}\n"
            f"  {B}{pr.title[:60]}{R}\n"
            f"  {c(pr.source_branch, FG['cyan'])} → {c(pr.target_branch, FG['cyan'])}"
            f"  {c(pr.author.name, D)}  {c(date, D)}\n"
        )
        divider(char="·", color="blue")
    pause()


def _pick_pr(state: Optional[PRState] = PRState.OPEN) -> Optional[Any]:
    prs = _pr_list_items(state)
    if not prs: return None
    return pick_from_list(
        prs,
        label_fn=lambda pr: (
            f"{c(pr.short_id, FG['yellow'], B):10s}  "
            f"{_pr_state_badge(pr.state)}  "
            f"{pr.title[:50]}  "
            f"{c(pr.source_branch, FG['cyan'])}→{c(pr.target_branch, FG['cyan'])}"
        ),
        prompt="Select PR",
    )


def _pr_create() -> None:
    header("Create Pull Request", repo_bar())
    p = STATE.provider
    try:
        branches = [b.name for b in p.list_branches(include_remote=False)]
        current  = p.current_branch()
        default  = p.get_repo_info().default_branch
    except SCMError as e:
        err(str(e)); pause(); return

    title   = ask("PR Title", required=True)
    src     = ask("Source branch", default=current)
    target  = ask("Target branch", default=default)
    desc    = ask_multiline("Description")
    draft   = confirm("Mark as draft?")
    rvw_raw = ask("Reviewers (comma-separated, optional)")
    reviewers = [r.strip() for r in rvw_raw.split(",") if r.strip()]

    divider()
    info(f"Checking conflict status for {src} → {target}...")
    try:
        conflicts = p.can_merge(src, target)
        print(f"  Conflict check: {_conflict_badge(conflicts)}")
    except Exception:
        conflicts = ConflictStatus.UNKNOWN

    if not confirm("Create this PR?"):
        info("Cancelled."); pause(); return

    try:
        pr = p.create_pull_request(
            title=title, description=desc,
            source_branch=src, target_branch=target,
            reviewers=reviewers, draft=draft,
        )
        ok(f"PR #{pr.id} created: {pr.title}")
    except (SCMError, SCMValidationError) as e:
        err(str(e))
    pause()


def _pr_review_merge() -> None:
    header("Review / Merge PR", repo_bar())
    pr = _pick_pr(state=None)
    if not pr: return

    p = STATE.provider
    header(f"PR #{pr.id}", repo_bar())
    print(f"  {c(pr.title, B, FG['white'])}\n")
    print(f"  {c(pr.source_branch, FG['cyan'])} → {c(pr.target_branch, FG['cyan'])}")
    print(f"  Author   : {pr.author.name}")
    print(f"  State    : {_pr_state_badge(pr.state)}")
    print(f"  Conflicts: {_conflict_badge(pr.conflicts)}")
    print(f"  Reviews  : {_review_badge(pr)}")
    if pr.description:
        divider()
        for line in pr.description.splitlines()[:8]:
            print(f"  {line}")
    if pr.reviews:
        divider()
        sub_header("Reviews")
        for rv in pr.reviews:
            icon = {"approved": "✔", "changes_requested": "✘"}.get(rv.decision.value, "💬")
            print(f"    {c(icon, FG['cyan'])} {rv.author.name}  {c(rv.decision.value, FG['yellow'])}  {rv.body[:60]}")
    if pr.comments:
        divider()
        sub_header("Comments")
        for cm in pr.comments[-5:]:
            loc = f"  {cm.file_path}:{cm.line}" if cm.is_inline else ""
            print(f"    {c(cm.author.name, FG['cyan'])}{loc}: {cm.body[:80]}")

    divider()
    print(f"\n  {c('a)', FG['yellow'], B)} Approve")
    print(f"  {c('r)', FG['yellow'], B)} Request changes")
    print(f"  {c('m)', FG['yellow'], B)} Merge PR")
    print(f"  {c('c)', FG['yellow'], B)} Close PR")
    print(f"  {c('0)', FG['yellow'], B)} {c('Back', D)}\n")

    act = ask("Action")
    try:
        if act == "a":
            body = ask("Approval message (optional)")
            rv = p.add_review(pr.id, ReviewDecision.APPROVED, body)
            ok(f"Approved PR #{pr.id}")
        elif act == "r":
            body = ask("Feedback", required=True)
            p.add_review(pr.id, ReviewDecision.CHANGES_REQUESTED, body)
            ok(f"Changes requested on PR #{pr.id}")
        elif act == "m":
            _pr_merge_flow(pr)
            return
        elif act == "c":
            if confirm("Close this PR?"):
                p.close_pull_request(pr.id)
                ok(f"PR #{pr.id} closed.")
    except (SCMError, SCMNotSupportedError) as e:
        err(str(e))
    pause()


def _pr_merge_flow(pr) -> None:
    header(f"Merge PR #{pr.id}", repo_bar())
    p = STATE.provider

    print(f"  Merging: {c(pr.source_branch, FG['cyan'])} → {c(pr.target_branch, FG['cyan'])}\n")
    print(f"  Strategy:")
    strategies = [
        ("1", "merge",        MergeStrategy.MERGE,        "Standard merge commit"),
        ("2", "squash",       MergeStrategy.SQUASH,       "Squash all commits"),
        ("3", "rebase",       MergeStrategy.REBASE,       "Rebase then fast-forward"),
        ("4", "fast_forward", MergeStrategy.FAST_FORWARD, "Fast-forward only"),
    ]
    for key, _, _, desc in strategies:
        print(f"    {c(key+')', FG['yellow'], B)} {desc}")

    choice = ask("Strategy", default="1")
    strat  = next((s[2] for s in strategies if s[0] == choice), MergeStrategy.MERGE)
    msg    = ask("Merge commit message (optional)")
    del_br = confirm("Delete source branch after merge?", default=False)

    if pr.conflicts == ConflictStatus.CONFLICTS:
        warn("This PR has detected conflicts!")
        if not confirm("Merge anyway?", default=False):
            info("Cancelled."); pause(); return

    if not confirm(f"Confirm merge using '{strat.value}' strategy?"):
        info("Cancelled."); pause(); return

    try:
        result = p.merge_pull_request(
            pr.id, strategy=strat,
            message=msg or None, delete_branch=del_br,
        )
        if result.success:
            ok(f"PR #{pr.id} merged! SHA: {result.merge_sha}")
        else:
            err(f"Merge failed: {result.error}")
            if result.conflicts:
                warn("Conflicting files:")
                for f in result.conflicts:
                    print(f"    {c(f, FG['bright_red'])}")
    except (SCMError, SCMNotSupportedError) as e:
        err(str(e))
    pause()


def _pr_diff() -> None:
    header("PR Diff", repo_bar())
    pr = _pick_pr(state=None)
    if not pr: return
    p = STATE.provider
    try:
        stat = p.diff(pr.target_branch, pr.source_branch)
        summary = (
            f"  {c(str(stat.files_changed), FG['yellow'], B)} files changed  "
            f"{c('+' + str(stat.insertions), FG['bright_green'], B)}  "
            f"{c('-' + str(stat.deletions), FG['bright_red'], B)}\n"
        )
        detail_lines = [summary, ""]
        for fc in stat.changes:
            type_sym = {
                "A": c("A", FG["bright_green"]), "M": c("M", FG["yellow"]),
                "D": c("D", FG["bright_red"]),   "R": c("R", FG["cyan"]),
            }.get(fc.change_type.value, "?")
            detail_lines.append(
                f"  {type_sym}  {fc.path}"
                + (f"  {c(f'+{fc.additions}', FG['bright_green'])} "
                   f"{c(f'-{fc.deletions}', FG['bright_red'])}"
                   if not fc.binary else "  [binary]")
            )
        pager("\n".join(detail_lines), title=f"Diff: PR #{pr.id}")
    except (SCMError, SCMNotSupportedError) as e:
        err(str(e))
        pause()


def _pr_comment() -> None:
    header("Add Comment", repo_bar())
    pr = _pick_pr(state=None)
    if not pr: return
    body = ask_multiline("Comment body")
    if not body.strip():
        info("Empty comment — cancelled."); pause(); return
    inline = confirm("Is this an inline (file-level) comment?", default=False)
    fp = lno = None
    if inline:
        fp  = ask("File path")
        lno = ask_int("Line number", min_val=1)
    try:
        STATE.provider.add_comment(pr.id, body, file_path=fp, line=lno)
        ok(f"Comment added to PR #{pr.id}")
    except (SCMError, SCMNotSupportedError) as e:
        err(str(e))
    pause()


# ══════════════════════════════════════════════════════════════════════════════
#  SCREEN: Branches
# ══════════════════════════════════════════════════════════════════════════════

def screen_branches() -> None:
    if not STATE.require_repo(): return

    while True:
        header("Branch Management", repo_bar())
        print(f"  {c('1)', FG['yellow'], B)} List branches")
        print(f"  {c('2)', FG['yellow'], B)} Create branch")
        print(f"  {c('3)', FG['yellow'], B)} Delete branch")
        print(f"  {c('4)', FG['yellow'], B)} Checkout branch")
        print(f"  {c('5)', FG['yellow'], B)} Compare branches (diff)")
        print(f"  {c('6)', FG['yellow'], B)} Cherry-pick commit")
        print(f"  {c('0)', FG['yellow'], B)} {c('Back', D)}\n")
        divider()

        choice = ask("Choice")
        if   choice == "1": _branch_list()
        elif choice == "2": _branch_create()
        elif choice == "3": _branch_delete()
        elif choice == "4": _branch_checkout()
        elif choice == "5": _branch_compare()
        elif choice == "6": _branch_cherry_pick()
        elif choice == "0": return


def _branch_list() -> None:
    header("Branches", repo_bar())
    try:
        branches = STATE.provider.list_branches(include_remote=True)
        current  = STATE.provider.current_branch()
        local    = [b for b in branches if not b.is_remote]
        remote   = [b for b in branches if b.is_remote]

        sub_header(f"Local ({len(local)})")
        for b in local:
            cur  = c("●", FG["bright_green"]) if b.name == current else " "
            def_ = c("[default]", FG["cyan"]) if b.is_default else ""
            prot = c("[protected]", FG["yellow"]) if b.protected else ""
            trk  = ""
            if b.ahead or b.behind:
                trk = c(f"↑{b.ahead} ↓{b.behind}", FG["magenta"])
            print(f"  {cur} {c(b.name, B):40s} {b.commit_sha:8s} {trk} {def_} {prot}")

        if remote:
            sub_header(f"Remote ({len(remote)})")
            for b in remote:
                print(f"    {c(b.name, D):40s} {b.commit_sha:8s}")
    except SCMError as e:
        err(str(e))
    pause()


def _branch_create() -> None:
    header("Create Branch", repo_bar())
    p = STATE.provider
    try:
        current = p.current_branch()
    except SCMError:
        current = "HEAD"

    name    = ask("New branch name", required=True)
    from_ref = ask("From ref", default=current)

    try:
        branch = p.create_branch(name, from_ref)
        ok(f"Branch '{branch.name}' created at {branch.commit_sha}")
        if confirm("Checkout the new branch?", default=True):
            p.checkout(name)
            ok(f"Checked out '{name}'")
    except (SCMError, SCMValidationError) as e:
        err(str(e))
    pause()


def _branch_delete() -> None:
    header("Delete Branch", repo_bar())
    p = STATE.provider
    try:
        branches = [b for b in p.list_branches(include_remote=False)
                    if not b.is_default and b.name != p.current_branch()]
    except SCMError as e:
        err(str(e)); pause(); return

    b = pick_from_list(branches, lambda b: (
        c(b.name, B) + (c(" [protected]", FG["yellow"]) if b.protected else "")
    ), prompt="Select branch to delete")
    if not b: return

    if b.protected:
        warn(f"'{b.name}' is a protected branch!")
        if not confirm("Force delete?", default=False):
            info("Cancelled."); pause(); return

    force = b.protected or confirm("Force delete (even if unmerged)?", default=False)
    try:
        p.delete_branch(b.name, force=force)
        ok(f"Branch '{b.name}' deleted.")
    except SCMError as e:
        err(str(e))
    pause()


def _branch_checkout() -> None:
    header("Checkout", repo_bar())
    p = STATE.provider
    try:
        branches = p.list_branches(include_remote=True)
    except SCMError as e:
        err(str(e)); pause(); return

    b = pick_from_list(branches, lambda b: c(b.name, B), prompt="Select branch")
    if not b: return
    try:
        p.checkout(b.name)
        ok(f"Checked out '{b.name}'")
    except SCMError as e:
        err(str(e))
    pause()


def _branch_compare() -> None:
    header("Compare Branches", repo_bar())
    p = STATE.provider
    try:
        branches = [b.name for b in p.list_branches()]
        current  = p.current_branch()
        default  = p.get_repo_info().default_branch
    except SCMError as e:
        err(str(e)); pause(); return

    fr = ask("From branch", default=default)
    to = ask("To branch",   default=current)
    try:
        stat = p.diff(fr, to)
        lines = [
            f"  {c(fr, FG['cyan'])} → {c(to, FG['cyan'])}\n",
            f"  {c(str(stat.files_changed), FG['yellow'], B)} files  "
            f"{c('+' + str(stat.insertions), FG['bright_green'], B)}  "
            f"{c('-' + str(stat.deletions), FG['bright_red'], B)}\n",
        ]
        for fc in stat.changes:
            sym = {"A": "+", "D": "-", "M": "~", "R": "→"}.get(fc.change_type.value, "?")
            col = {"A": FG["bright_green"], "D": FG["bright_red"]}.get(fc.change_type.value, FG["yellow"])
            lines.append(f"  {c(sym, col)} {fc.path}")
        pager("\n".join(lines), title=f"Diff {fr}..{to}")
    except SCMError as e:
        err(str(e))
        pause()


def _branch_cherry_pick() -> None:
    header("Cherry-pick Commit", repo_bar())
    p = STATE.provider
    sha = ask("Commit SHA to cherry-pick", required=True)
    try:
        commit = p.get_commit(sha)
        print(f"\n  {c(commit.short_sha, FG['yellow'], B)}  {commit.subject}")
        print(f"  by {commit.author.name}  {commit.author.when.strftime('%Y-%m-%d')}\n")
        if not confirm("Cherry-pick this commit?"):
            info("Cancelled."); pause(); return
        result = p.cherry_pick(sha)
        if result.success:
            ok(f"Cherry-picked as {result.merge_sha}")
        else:
            err(f"Cherry-pick failed: {result.error}")
    except (SCMError, SCMNotSupportedError) as e:
        err(str(e))
    pause()


# ══════════════════════════════════════════════════════════════════════════════
#  SCREEN: Commits & Log
# ══════════════════════════════════════════════════════════════════════════════

def screen_log() -> None:
    if not STATE.require_repo(): return

    while True:
        header("Commit Log", repo_bar())
        print(f"  {c('1)', FG['yellow'], B)} View log")
        print(f"  {c('2)', FG['yellow'], B)} Inspect a commit")
        print(f"  {c('3)', FG['yellow'], B)} View file at commit")
        print(f"  {c('4)', FG['yellow'], B)} Blame a file")
        print(f"  {c('5)', FG['yellow'], B)} Contributor stats")
        print(f"  {c('0)', FG['yellow'], B)} {c('Back', D)}\n")
        divider()

        choice = ask("Choice")
        if   choice == "1": _log_view()
        elif choice == "2": _log_inspect()
        elif choice == "3": _log_file_at_ref()
        elif choice == "4": _log_blame()
        elif choice == "5": _log_stats()
        elif choice == "0": return


def _log_view() -> None:
    header("Commit Log", repo_bar())
    p = STATE.provider
    author_f = ask("Filter by author (optional)")
    n        = ask_int("Number of commits", min_val=1, max_val=500) or 30

    try:
        commits = list(p.log(max_count=n, author=author_f or None))
        if not commits:
            warn("No commits found."); pause(); return

        lines = []
        for commit in commits:
            date = commit.author.when.strftime("%Y-%m-%d %H:%M")
            refs = c(" " + " ".join(commit.refs), FG["yellow"]) if commit.refs else ""
            add  = commit.stats.get("additions", 0)
            dele = commit.stats.get("deletions", 0)
            stat = c(f" +{add} -{dele}", D) if (add or dele) else ""
            lines.append(
                f"{c(commit.short_sha, FG['yellow'], B)}  {c(date, D)}  "
                f"{c(commit.author.name[:20], FG['cyan'])}{refs}\n"
                f"  {commit.subject[:70]}{stat}\n"
            )
        pager("\n".join(lines), title="Commit Log")
    except SCMError as e:
        err(str(e))
        pause()


def _log_inspect() -> None:
    header("Inspect Commit", repo_bar())
    ref = ask("Commit SHA or ref", default="HEAD")
    try:
        commit = STATE.provider.get_commit(ref)
        lines = [
            f"{c('SHA', B):20s} {commit.sha}",
            f"{c('Author', B):20s} {commit.author}  {commit.author.when.strftime('%Y-%m-%d %H:%M:%S')}",
            f"{c('Committer', B):20s} {commit.committer}",
            f"{c('Parents', B):20s} {', '.join(commit.parents) or 'none'}",
            "",
            c("Message", B, FG["white"]),
            "",
        ]
        for line in commit.message.splitlines():
            lines.append(f"  {line}")
        if commit.stats:
            lines += [
                "", c("Stats", B, FG["white"]),
                f"  Files changed : {commit.stats.get('files', 0)}",
                f"  Insertions    : {c('+' + str(commit.stats.get('additions', 0)), FG['bright_green'])}",
                f"  Deletions     : {c('-' + str(commit.stats.get('deletions', 0)), FG['bright_red'])}",
            ]
        pager("\n".join(lines), title=f"Commit {commit.short_sha}")
    except (SCMError, SCMNotFoundError) as e:
        err(str(e))
        pause()


def _log_file_at_ref() -> None:
    header("File at Commit", repo_bar())
    path = ask("File path", required=True)
    ref  = ask("Ref", default="HEAD")
    try:
        content = STATE.provider.get_file_at_ref(path, ref)
        pager(content, title=f"{path} @ {ref}")
    except (SCMError, SCMNotFoundError, SCMNotSupportedError) as e:
        err(str(e))
        pause()


def _log_blame() -> None:
    header("Git Blame", repo_bar())
    path = ask("File path", required=True)
    try:
        blame = STATE.provider.blame(path)
        pager(blame, title=f"blame: {path}")
    except (SCMError, SCMNotSupportedError) as e:
        err(str(e))
        pause()


def _log_stats() -> None:
    header("Contributor Stats", repo_bar())
    try:
        stats = STATE.provider.shortlog()
        pager(stats, title="Contributor Stats")
    except (SCMError, SCMNotSupportedError) as e:
        err(str(e))
        pause()


# ══════════════════════════════════════════════════════════════════════════════
#  SCREEN: Tags
# ══════════════════════════════════════════════════════════════════════════════

def screen_tags() -> None:
    if not STATE.require_repo(): return

    while True:
        header("Tags", repo_bar())
        print(f"  {c('1)', FG['yellow'], B)} List tags")
        print(f"  {c('2)', FG['yellow'], B)} Create tag")
        print(f"  {c('3)', FG['yellow'], B)} Delete tag")
        print(f"  {c('0)', FG['yellow'], B)} {c('Back', D)}\n")
        divider()

        choice = ask("Choice")
        if   choice == "1": _tag_list()
        elif choice == "2": _tag_create()
        elif choice == "3": _tag_delete()
        elif choice == "0": return


def _tag_list() -> None:
    header("Tags", repo_bar())
    try:
        tags = STATE.provider.list_tags()
        if not tags:
            warn("No tags found."); pause(); return
        for t in tags:
            ann = c("[annotated]", FG["cyan"]) if t.is_annotated else ""
            msg = c(f"  {t.message}", D) if t.message else ""
            tgr = c(f"  by {t.tagger.name}", FG["magenta"]) if t.tagger else ""
            print(f"  {c(t.name, B, FG['yellow']):30s} {t.commit_sha:10s} {ann}{tgr}{msg}")
    except SCMError as e:
        err(str(e))
    pause()


def _tag_create() -> None:
    header("Create Tag", repo_bar())
    name = ask("Tag name (e.g. v1.2.0)", required=True)
    ref  = ask("Tag ref", default="HEAD")
    msg  = ask("Annotation message (blank for lightweight)")
    push_remote = ask("Push to remote (blank to skip)")
    try:
        tag = STATE.provider.create_tag(name, ref, message=msg or None)
        ok(f"Tag '{tag.name}' created")
        if push_remote:
            STATE.provider.push(remote=push_remote, tags=True)
            ok(f"Tags pushed to {push_remote}")
    except (SCMError, SCMNotSupportedError) as e:
        err(str(e))
    pause()


def _tag_delete() -> None:
    header("Delete Tag", repo_bar())
    try:
        tags = STATE.provider.list_tags()
    except SCMError as e:
        err(str(e)); pause(); return
    t = pick_from_list(tags, lambda t: c(t.name, B, FG["yellow"]), prompt="Select tag")
    if not t: return
    if not confirm(f"Delete tag '{t.name}'?"): return
    try:
        STATE.provider.delete_tag(t.name)
        ok(f"Tag '{t.name}' deleted.")
    except SCMError as e:
        err(str(e))
    pause()


# ══════════════════════════════════════════════════════════════════════════════
#  SCREEN: Remote Operations
# ══════════════════════════════════════════════════════════════════════════════

def screen_remotes() -> None:
    if not STATE.require_repo(): return

    while True:
        header("Remote Operations", repo_bar())
        print(f"  {c('1)', FG['yellow'], B)} List remotes")
        print(f"  {c('2)', FG['yellow'], B)} Fetch")
        print(f"  {c('3)', FG['yellow'], B)} Pull")
        print(f"  {c('4)', FG['yellow'], B)} Push")
        print(f"  {c('0)', FG['yellow'], B)} {c('Back', D)}\n")
        divider()

        choice = ask("Choice")
        if   choice == "1": _remote_list()
        elif choice == "2": _remote_fetch()
        elif choice == "3": _remote_pull()
        elif choice == "4": _remote_push()
        elif choice == "0": return


def _remote_list() -> None:
    header("Remotes", repo_bar())
    try:
        remotes = STATE.provider.list_remotes()
        if not remotes:
            warn("No remotes configured."); pause(); return
        for r in remotes:
            print(f"  {c(r.name, B, FG['cyan']):20s} fetch: {r.fetch_url}")
            print(f"  {'':20s} push:  {r.push_url}")
            print()
    except SCMError as e:
        err(str(e))
    pause()


def _remote_fetch() -> None:
    header("Fetch", repo_bar())
    remote = ask("Remote", default="origin")
    prune  = confirm("Prune deleted remote branches?", default=True)
    try:
        git_msg(f"Fetching from {remote}...")
        STATE.provider.fetch(remote, prune=prune)
        ok("Fetch complete.")
    except SCMError as e:
        err(str(e))
    pause()


def _remote_pull() -> None:
    header("Pull", repo_bar())
    remote = ask("Remote", default="origin")
    branch = ask("Branch (blank for current)")
    strats = [("1", MergeStrategy.MERGE, "Merge"), ("2", MergeStrategy.REBASE, "Rebase"),
              ("3", MergeStrategy.FAST_FORWARD, "Fast-forward only")]
    for k, _, label in strats:
        print(f"  {c(k+')', FG['yellow'], B)} {label}")
    sc = ask("Strategy", default="1")
    strat = next((s[1] for s in strats if s[0] == sc), MergeStrategy.MERGE)
    try:
        result = STATE.provider.pull(remote, branch=branch or None, strategy=strat)
        if result.success:
            ok(f"Pulled. HEAD: {result.merge_sha}")
        else:
            err(f"Pull failed: {result.error}")
    except SCMError as e:
        err(str(e))
    pause()


def _remote_push() -> None:
    header("Push", repo_bar())
    p      = STATE.provider
    remote = ask("Remote", default="origin")
    branch = ask("Branch (blank for current)")
    force  = confirm("Force push (--force-with-lease)?", default=False)
    tags   = confirm("Include tags?", default=False)
    if force:
        warn("Force push will overwrite remote history!")
        if not confirm("Confirm force push?", default=False):
            info("Cancelled."); pause(); return
    try:
        p.push(remote, branch=branch or None, force=force, tags=tags)
        ok("Push complete.")
    except SCMError as e:
        err(str(e))
    pause()


# ══════════════════════════════════════════════════════════════════════════════
#  SCREEN: Working Tree
# ══════════════════════════════════════════════════════════════════════════════

def screen_working_tree() -> None:
    if not STATE.require_repo(): return

    while True:
        header("Working Tree", repo_bar())
        print(f"  {c('1)', FG['yellow'], B)} Status")
        print(f"  {c('2)', FG['yellow'], B)} Stage files")
        print(f"  {c('3)', FG['yellow'], B)} Unstage files")
        print(f"  {c('4)', FG['yellow'], B)} Commit")
        print(f"  {c('5)', FG['yellow'], B)} Discard changes")
        print(f"  {c('6)', FG['yellow'], B)} Stash")
        print(f"  {c('0)', FG['yellow'], B)} {c('Back', D)}\n")
        divider()

        choice = ask("Choice")
        if   choice == "1": _wt_status()
        elif choice == "2": _wt_stage()
        elif choice == "3": _wt_unstage()
        elif choice == "4": _wt_commit()
        elif choice == "5": _wt_discard()
        elif choice == "6": _wt_stash()
        elif choice == "0": return


def _wt_status() -> None:
    header("Working Tree Status", repo_bar())
    try:
        changes = STATE.provider.status()
        if not changes:
            ok("Working tree clean.")
        else:
            for fc in changes:
                col = {
                    "A": FG["bright_green"], "M": FG["yellow"],
                    "D": FG["bright_red"],   "U": FG["bright_red"],
                }.get(fc.change_type.value, FG["white"])
                sym = {"A": "new  ", "M": "mod  ", "D": "del  ",
                       "U": "conflt"}.get(fc.change_type.value, "?    ")
                print(f"  {c(sym, col, B)} {fc.path}")
    except (SCMError, SCMNotSupportedError) as e:
        err(str(e))
    pause()


def _wt_stage() -> None:
    header("Stage Files", repo_bar())
    paths_raw = ask("Paths to stage (space-separated, '.' for all)", default=".")
    paths = paths_raw.split()
    try:
        STATE.provider.stage(paths)
        ok(f"Staged: {', '.join(paths)}")
    except (SCMError, SCMNotSupportedError) as e:
        err(str(e))
    pause()


def _wt_unstage() -> None:
    header("Unstage Files", repo_bar())
    paths_raw = ask("Paths to unstage (space-separated)")
    paths = paths_raw.split()
    if not paths:
        info("Nothing specified."); pause(); return
    try:
        STATE.provider.unstage(paths)
        ok(f"Unstaged: {', '.join(paths)}")
    except (SCMError, SCMNotSupportedError) as e:
        err(str(e))
    pause()


def _wt_commit() -> None:
    header("Commit", repo_bar())
    msg   = ask_multiline("Commit message")
    amend = confirm("Amend last commit?", default=False)
    if not msg.strip() and not amend:
        err("Commit message required."); pause(); return
    try:
        commit = STATE.provider.commit(msg, amend=amend)
        ok(f"Committed {commit.short_sha}: {commit.subject}")
    except (SCMError, SCMNotSupportedError) as e:
        err(str(e))
    pause()


def _wt_discard() -> None:
    header("Discard Changes", repo_bar())
    warn("This is DESTRUCTIVE — changes will be lost!")
    paths_raw = ask("Paths (space-separated, '.' for all)")
    paths = paths_raw.split()
    if not paths:
        info("Nothing specified."); pause(); return
    if not confirm(f"Discard changes in: {', '.join(paths)}?", default=False):
        info("Cancelled."); pause(); return
    try:
        STATE.provider.discard(paths)
        ok("Changes discarded.")
    except (SCMError, SCMNotSupportedError) as e:
        err(str(e))
    pause()


def _wt_stash() -> None:
    while True:
        header("Stash", repo_bar())
        print(f"  {c('1)', FG['yellow'], B)} Push stash")
        print(f"  {c('2)', FG['yellow'], B)} List stashes")
        print(f"  {c('3)', FG['yellow'], B)} Pop stash")
        print(f"  {c('4)', FG['yellow'], B)} Drop stash")
        print(f"  {c('0)', FG['yellow'], B)} {c('Back', D)}\n")
        divider()

        choice = ask("Choice")
        if choice == "1":
            msg = ask("Stash message (optional)")
            try:
                STATE.provider.stash_push(message=msg or None)
                ok("Stashed working tree.")
            except (SCMError, SCMNotSupportedError) as e:
                err(str(e))
            pause()
        elif choice == "2":
            try:
                stashes = STATE.provider.stash_list()
                if not stashes:
                    warn("No stashes.")
                else:
                    for s in stashes:
                        print(f"  {c(s['index'], FG['yellow'], B):15s} {s['message']}")
            except (SCMError, SCMNotSupportedError) as e:
                err(str(e))
            pause()
        elif choice == "3":
            idx = ask_int("Stash index", min_val=0) or 0
            try:
                STATE.provider.stash_pop(idx)
                ok("Stash applied and removed.")
            except (SCMError, SCMNotSupportedError) as e:
                err(str(e))
            pause()
        elif choice == "4":
            idx = ask_int("Stash index", min_val=0) or 0
            try:
                STATE.provider.stash_drop(idx)
                ok("Stash dropped.")
            except (SCMError, SCMNotSupportedError) as e:
                err(str(e))
            pause()
        elif choice == "0":
            return


# ══════════════════════════════════════════════════════════════════════════════
#  SCREEN: Settings
# ══════════════════════════════════════════════════════════════════════════════

def screen_settings() -> None:
    while True:
        header("Settings", f"Config: {STATE.config_path}")
        print(f"  {c('1)', FG['yellow'], B)} Set actor / username  [{STATE.actor}]")
        print(f"  {c('2)', FG['yellow'], B)} Available SCM adapters")
        print(f"  {c('3)', FG['yellow'], B)} Detect SCM type at path")
        print(f"  {c('0)', FG['yellow'], B)} {c('Back', D)}\n")
        divider()

        choice = ask("Choice")
        if choice == "1":
            name = ask("Actor name", default=STATE.actor)
            if name:
                STATE.actor = name
                STATE.save_config()
                ok(f"Actor set to '{name}'")
            pause()
        elif choice == "2":
            header("Available Adapters")
            adapters = list_available_adapters()
            for name, avail in adapters.items():
                status = c("[✔ available]", FG["bright_green"]) if avail \
                         else c("[✘ not found]", FG["bright_red"])
                print(f"  {c(name, B):15s} {status}")
            pause()
        elif choice == "3":
            path = ask("Path to check", default=os.getcwd())
            scm_type = detect_scm_type(path)
            if scm_type.value == "unknown":
                warn(f"No SCM detected at {path}")
            else:
                ok(f"Detected: {scm_type.value.upper()} at {path}")
            pause()
        elif choice == "0":
            return


# ══════════════════════════════════════════════════════════════════════════════
#  MAIN MENU
# ══════════════════════════════════════════════════════════════════════════════

def main_menu() -> None:
    signal.signal(signal.SIGINT, lambda *_: None)   # graceful Ctrl-C

    while True:
        header(
            "SCM TOOL  v1.0  //  Cybopsec",
            repo_bar() if STATE.has_repo else "  No repository loaded",
        )

        print(f"  {c('1)', FG['yellow'], B)} Open / Clone / Init repository")
        print(f"  {c('2)', FG['yellow'], B)} Repository overview")
        print(f"  {c('3)', FG['yellow'], B)} Pull requests")
        print(f"  {c('4)', FG['yellow'], B)} Branches")
        print(f"  {c('5)', FG['yellow'], B)} Commit log & file history")
        print(f"  {c('6)', FG['yellow'], B)} Tags")
        print(f"  {c('7)', FG['yellow'], B)} Remote operations (fetch/pull/push)")
        print(f"  {c('8)', FG['yellow'], B)} Working tree (stage/commit/stash)")
        print(f"  {c('9)', FG['yellow'], B)} Settings")
        print(f"  {c('0)', FG['yellow'], B)} {c('Exit', D)}\n")
        divider()

        choice = ask("Module")

        if   choice == "1": screen_open_repo()
        elif choice == "2": screen_repo_overview()
        elif choice == "3": screen_pull_requests()
        elif choice == "4": screen_branches()
        elif choice == "5": screen_log()
        elif choice == "6": screen_tags()
        elif choice == "7": screen_remotes()
        elif choice == "8": screen_working_tree()
        elif choice == "9": screen_settings()
        elif choice == "0":
            clear()
            print(c("\n  Goodbye.\n", FG["cyan"], B))
            sys.exit(0)


def main() -> None:
    # Try to auto-load the CWD if it's a repo
    cwd = os.getcwd()
    try:
        scm = detect_scm_type(cwd)
        if scm.value != "unknown":
            STATE.load_repo(cwd)
    except Exception:
        pass
    main_menu()


if __name__ == "__main__":
    main()
