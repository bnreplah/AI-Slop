"""
svn_adapter.py — SVN SCM Adapter
==================================
Full implementation of SCMProvider for Apache Subversion.
Uses svn CLI — no bindings needed.

SVN has no branches/tags in the traditional sense — they're just
directory conventions (trunk/, branches/, tags/). This adapter
maps those conventions onto the SCMProvider interface.
"""

from __future__ import annotations

import os
import re
import subprocess
import uuid
import xml.etree.ElementTree as ET
from datetime import datetime
from pathlib import Path
from typing import Iterator, Optional

from core.scm_provider import (
    SCMProvider, SCMType, SCMError, SCMNotFoundError, SCMNotSupportedError,
    SCMValidationError,
    Author, Branch, Commit, ConflictStatus, DiffStat, FileChange,
    FileChangeType, MergeResult, MergeStrategy, PRState, PullRequest,
    Remote, RepoInfo, Tag, PRComment, Review, ReviewDecision,
)


class SVNAdapter(SCMProvider):
    """
    SVN adapter.

    Layout assumptions (standard SVN repo structure):
        <root>/trunk/
        <root>/branches/<name>/
        <root>/tags/<name>/

    Set svn_root to the repo URL (file:///... or https://...).
    repo_path is the local working copy path.
    """

    def __init__(self, repo_path: str, svn_root: str = "",
                 actor: str = "scmtool", username: str = "",
                 password: str = ""):
        super().__init__(repo_path, actor)
        self.svn_root = svn_root
        self._username = username
        self._password = password

    def _svn(self, *args: str, check: bool = True,
             xml: bool = False) -> subprocess.CompletedProcess:
        cmd = ["svn"]
        if self._username: cmd += ["--username", self._username]
        if self._password: cmd += ["--password", self._password]
        if xml: cmd.append("--xml")
        cmd += list(args)
        cmd += ["--non-interactive", "--trust-server-cert"]
        try:
            result = subprocess.run(cmd, capture_output=True, text=True,
                                    cwd=self.repo_path)
        except FileNotFoundError:
            raise SCMError("svn executable not found in PATH")
        if check and result.returncode != 0:
            stderr = result.stderr.strip()
            if "E200009" in stderr or "not a working copy" in stderr:
                raise SCMNotFoundError(f"Not an SVN working copy: {self.repo_path}")
            raise SCMError(stderr or "svn command failed", result.returncode)
        return result

    def _svn_out(self, *args, **kwargs) -> str:
        return self._svn(*args, **kwargs).stdout.strip()

    def _parse_log_entry(self, entry: ET.Element) -> Commit:
        rev    = entry.get("revision", "0")
        author = entry.findtext("author") or "unknown"
        date_s = entry.findtext("date") or ""
        msg    = entry.findtext("msg") or ""
        when   = datetime.fromisoformat(date_s.replace("Z", "+00:00")) if date_s else datetime.utcnow()
        auth   = Author(author, "", when)
        return Commit(sha=rev, short_sha=f"r{rev}", message=msg,
                      author=auth, committer=auth)

    # ── Lifecycle ─────────────────────────────────────────────────────────────

    @property
    def scm_type(self) -> SCMType:
        return SCMType.SVN

    def is_valid_repo(self) -> bool:
        r = self._svn("info", check=False)
        return r.returncode == 0

    def get_repo_info(self) -> RepoInfo:
        raw = self._svn_out("info")
        root_url = ""
        for line in raw.splitlines():
            if line.startswith("Repository Root:"):
                root_url = line.split(":", 1)[1].strip()
        return RepoInfo(
            path=self.repo_path,
            scm_type=SCMType.SVN,
            name=Path(self.repo_path).name,
            default_branch="trunk",
            remotes=[Remote(name="origin", fetch_url=root_url, push_url=root_url)],
        )

    # ── Commits ───────────────────────────────────────────────────────────────

    def get_commit(self, ref: str) -> Commit:
        """ref is a revision number or 'HEAD'."""
        rev_arg = "HEAD" if ref in ("HEAD", "") else f"-r{ref}"
        try:
            r = self._svn("log", rev_arg, "--limit", "1", xml=True)
            root = ET.fromstring(r.stdout)
            entry = root.find("logentry")
            if entry is None: raise SCMNotFoundError(f"Revision {ref} not found")
            return self._parse_log_entry(entry)
        except ET.ParseError as e:
            raise SCMError(f"Failed to parse svn log: {e}")

    def log(self, ref: str = "HEAD", max_count: int = 50,
            path: Optional[str] = None, author: Optional[str] = None,
            since: Optional[datetime] = None,
            until: Optional[datetime] = None) -> Iterator[Commit]:
        args = ["log", "--limit", str(max_count)]
        if since and until:
            args += ["-r", f"{{{since.strftime('%Y-%m-%d')}}}:{{{until.strftime('%Y-%m-%d')}}}"]
        if path: args.append(path)
        try:
            r = self._svn(*args, xml=True)
            root = ET.fromstring(r.stdout)
            for entry in root.findall("logentry"):
                commit = self._parse_log_entry(entry)
                if author and commit.author.name != author:
                    continue
                yield commit
        except (ET.ParseError, SCMError):
            return

    def diff(self, from_ref: str, to_ref: str,
             path: Optional[str] = None) -> DiffStat:
        r1 = "BASE" if from_ref == "HEAD~1" else from_ref
        r2 = "HEAD" if to_ref == "HEAD" else to_ref
        args = ["diff", "-r", f"{r1}:{r2}"]
        if path: args.append(path)
        raw = self._svn_out(*args, check=False)
        additions = sum(1 for l in raw.splitlines() if l.startswith("+") and not l.startswith("+++"))
        deletions = sum(1 for l in raw.splitlines() if l.startswith("-") and not l.startswith("---"))
        return DiffStat(insertions=additions, deletions=deletions)

    # ── Branches (directory-based) ────────────────────────────────────────────

    def list_branches(self, include_remote: bool = True) -> list[Branch]:
        branches = [Branch(name="trunk", commit_sha="HEAD", is_default=True)]
        if not self.svn_root: return branches
        try:
            raw = self._svn_out("list", f"{self.svn_root}/branches", check=False)
            for line in raw.splitlines():
                name = line.strip().rstrip("/")
                if name:
                    branches.append(Branch(name=f"branches/{name}", commit_sha="HEAD"))
        except SCMError:
            pass
        return branches

    def get_branch(self, name: str) -> Branch:
        for b in self.list_branches():
            if b.name == name: return b
        raise SCMNotFoundError(f"Branch '{name}' not found")

    def create_branch(self, name: str, from_ref: str = "HEAD") -> Branch:
        if not self.svn_root:
            raise SCMError("svn_root must be set to create branches")
        src = f"{self.svn_root}/trunk" if from_ref in ("HEAD", "trunk") \
              else f"{self.svn_root}/{from_ref}"
        dst = f"{self.svn_root}/branches/{name}"
        self._svn("copy", src, dst, "-m", f"Create branch {name}")
        self._emit_audit("create_branch", {"name": name})
        return Branch(name=f"branches/{name}", commit_sha="HEAD")

    def delete_branch(self, name: str, force: bool = False) -> None:
        if not self.svn_root:
            raise SCMError("svn_root must be set to delete branches")
        target = f"{self.svn_root}/{name}" if "/" in name \
                 else f"{self.svn_root}/branches/{name}"
        self._svn("delete", target, "-m", f"Delete branch {name}")
        self._emit_audit("delete_branch", {"name": name})

    def current_branch(self) -> str:
        raw = self._svn_out("info")
        for line in raw.splitlines():
            if line.startswith("URL:"):
                url = line.split(":", 1)[1].strip()
                if "/trunk" in url: return "trunk"
                m = re.search(r'/branches/([^/]+)', url)
                if m: return f"branches/{m.group(1)}"
        return "trunk"

    def checkout(self, ref: str) -> None:
        if not self.svn_root:
            raise SCMError("svn_root required for checkout")
        url = f"{self.svn_root}/{ref}" if ref != "trunk" \
              else f"{self.svn_root}/trunk"
        self._svn("switch", url)
        self._emit_audit("checkout", {"ref": ref})

    # ── Tags ──────────────────────────────────────────────────────────────────

    def list_tags(self) -> list[Tag]:
        if not self.svn_root: return []
        try:
            raw = self._svn_out("list", f"{self.svn_root}/tags", check=False)
            return [Tag(name=l.strip().rstrip("/"), commit_sha="HEAD")
                    for l in raw.splitlines() if l.strip()]
        except SCMError:
            return []

    def create_tag(self, name: str, ref: str = "HEAD",
                   message: Optional[str] = None) -> Tag:
        if not self.svn_root:
            raise SCMError("svn_root required for tags")
        src = f"{self.svn_root}/trunk"
        dst = f"{self.svn_root}/tags/{name}"
        self._svn("copy", src, dst, "-m", message or f"Tag {name}")
        self._emit_audit("create_tag", {"name": name})
        return Tag(name=name, commit_sha="HEAD")

    def delete_tag(self, name: str) -> None:
        if not self.svn_root:
            raise SCMError("svn_root required for tags")
        self._svn("delete", f"{self.svn_root}/tags/{name}", "-m", f"Delete tag {name}")

    # ── Remotes ───────────────────────────────────────────────────────────────

    def list_remotes(self) -> list[Remote]:
        info = self._svn_out("info", check=False)
        for line in info.splitlines():
            if line.startswith("Repository Root:"):
                url = line.split(":", 1)[1].strip()
                return [Remote(name="origin", fetch_url=url, push_url=url)]
        return []

    def fetch(self, remote: str = "origin", prune: bool = True) -> None:
        self._svn("update")
        self._emit_audit("fetch")

    def pull(self, remote: str = "origin", branch: Optional[str] = None,
             strategy: MergeStrategy = MergeStrategy.MERGE) -> MergeResult:
        try:
            self._svn("update")
            self._emit_audit("pull")
            return MergeResult(success=True)
        except SCMError as e:
            return MergeResult(success=False, error=str(e))

    def push(self, remote: str = "origin", branch: Optional[str] = None,
             force: bool = False, tags: bool = False) -> None:
        # SVN commits ARE pushes — no explicit push needed
        raise SCMNotSupportedError("SVN has no separate push step; commit to push")

    # ── Merge ─────────────────────────────────────────────────────────────────

    def merge(self, source_branch: str, strategy: MergeStrategy = MergeStrategy.MERGE,
              message: Optional[str] = None) -> MergeResult:
        if not self.svn_root:
            raise SCMError("svn_root required for merge")
        src_url = f"{self.svn_root}/{source_branch}"
        try:
            self._svn("merge", src_url)
            self._emit_audit("merge", {"source": source_branch})
            return MergeResult(success=True)
        except SCMError as e:
            return MergeResult(success=False, error=str(e))

    def can_merge(self, source_branch: str, target_branch: str) -> ConflictStatus:
        if not self.svn_root: return ConflictStatus.UNKNOWN
        src_url = f"{self.svn_root}/{source_branch}"
        try:
            r = self._svn("merge", "--dry-run", src_url, check=False)
            if "C " in r.stdout or "conflict" in r.stdout.lower():
                return ConflictStatus.CONFLICTS
            return ConflictStatus.NONE
        except Exception:
            return ConflictStatus.UNKNOWN

    # ── Working tree ──────────────────────────────────────────────────────────

    def status(self) -> list[FileChange]:
        raw = self._svn_out("status", check=False)
        type_map = {
            "A": FileChangeType.ADDED, "M": FileChangeType.MODIFIED,
            "D": FileChangeType.DELETED, "C": FileChangeType.UNMERGED,
            "?": FileChangeType.UNKNOWN,
        }
        changes = []
        for line in raw.splitlines():
            if len(line) < 2: continue
            code = line[0]
            path = line[8:].strip()
            changes.append(FileChange(path=path,
                                      change_type=type_map.get(code, FileChangeType.UNKNOWN)))
        return changes

    def commit(self, message: str, amend: bool = False) -> Commit:
        if amend:
            raise SCMNotSupportedError("SVN does not support amending commits")
        self._svn("commit", "-m", message)
        self._emit_audit("commit", {"message": message[:80]})
        return self.get_commit("HEAD")

    # ── PR support (local store, same as git adapter) ─────────────────────────

    def list_pull_requests(self, state: PRState = PRState.OPEN) -> list[PullRequest]:
        return []   # TODO: wire to local store like GitAdapter

    # ── Hooks (SVN has pre/post-commit hooks at the server level) ─────────────

    def list_hooks(self) -> list[str]:
        raise SCMNotSupportedError(
            "SVN hooks are server-side. Manage them in the repository's hooks/ directory."
        )
