# ProxyChains Browser
### Cybopsec Security Research Tool

A full GUI browser built on Electron (Chromium) with native **proxychains-ng** and **Tor** integration. Configure proxy chains visually, monitor live hop status, and route all browser traffic through your chain — with DNS leak prevention built in.

---

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│                   ProxyChains Browser                    │
│  ┌──────────────┐    ┌────────────────────────────────┐  │
│  │  GUI Shell   │    │      BrowserView Partition     │  │
│  │  (Renderer)  │◄──►│  session: persist:proxied      │  │
│  │  Proxy Mgr   │    │  Proxy: set via session API    │  │
│  │  Tor Control │    │  UA: spoofed                   │  │
│  │  Chain Strip │    │  WebRTC: blocked               │  │
│  └──────┬───────┘    └────────────────────────────────┘  │
│         │ IPC (contextBridge)                             │
│  ┌──────▼───────┐                                        │
│  │  Main Process│                                        │
│  │  proxychains │──► OS-level wrap (--pcng flag)         │
│  │  .conf gen   │                                        │
│  │  Tor CtrlPort│──► SIGNAL NEWNYM / circuit status      │
│  │  TCP test    │                                        │
│  └──────────────┘                                        │
└─────────────────────────────────────────────────────────┘
```

**Two layers of proxy enforcement:**
1. **Electron session API** — sets SOCKS5/HTTP proxy on Chromium's network stack (always active)
2. **proxychains-ng wrapping** — launch with `--pcng` to wrap the Electron process at the OS level via LD_PRELOAD syscall interception (maximum enforcement)

---

## Prerequisites

| Dependency | Install | Purpose |
|---|---|---|
| Node.js ≥ 18 | https://nodejs.org | Electron runtime |
| `tor` | `sudo apt install tor` | Tor SOCKS5 daemon |
| `proxychains-ng` | `sudo apt install proxychains-ng` | OS-level chain (optional) |

---

## Installation

```bash
git clone https://github.com/cybopsec/proxychains-browser
cd proxychains-browser
npm install
chmod +x launch.sh
```

---

## Usage

### Standard launch (Electron manages proxy)
```bash
./launch.sh
# or
npm start
```

### OS-level proxychains-ng wrapping (maximum enforcement)
```bash
./launch.sh --pcng
```
This calls: `proxychains4 -f ~/.config/proxychains-browser/proxychains.conf electron .`

### Tor-only mode (auto-generates minimal config)
```bash
./launch.sh --tor-only
```

---

## Configuration

All settings are persisted to `~/.config/proxychains-browser/settings.json` and the generated `proxychains.conf` is written to the same directory.

### Chain Modes

| Mode | Behaviour |
|---|---|
| `strict_chain` | All hops must succeed in order — fails if any hop is down |
| `dynamic_chain` | Skips dead hops — more resilient |
| `random_chain` | Randomises hop order each connection |
| `round_robin_chain` | Rotates through hops |

### Proxy Types

- **SOCKS5** — recommended, supports UDP and auth
- **SOCKS4** — legacy, no auth
- **HTTP** — HTTP CONNECT tunnel, no UDP

### DNS Leak Prevention

Enable **Proxy DNS** to route DNS queries through the chain (`proxy_dns` directive in proxychains.conf). Without this, DNS resolves locally and leaks your real IP.

---

## Tor Integration

1. Install and start Tor: `sudo systemctl start tor`
2. Enable control port in `/etc/tor/torrc`:
   ```
   ControlPort 9051
   CookieAuthentication 1
   ```
3. In the **TOR** panel, enable Tor — it auto-adds `socks5 127.0.0.1:9050` as the first hop
4. Use **NEW CIRCUIT** to rotate your exit node via `SIGNAL NEWNYM`

---

## Security Notes

- **WebRTC is blocked** by default (prevents real IP leaks via media APIs)
- **User Agent** is spoofed to a generic Firefox/Windows string by default
- **Canvas fingerprinting** mitigation available in settings
- The **BrowserView** runs in a sandboxed partition (`persist:proxied`) separate from the GUI shell
- All IPC is via `contextBridge` — renderer has no direct Node.js access
- **No stored credentials** in plaintext — proxy passwords are stored in settings.json (consider encrypting the file at rest with `gpg`)

### OPSEC Checklist

- [ ] Enable `proxy_dns` to prevent DNS leaks
- [ ] Verify your exit IP at `https://check.torproject.org` or `https://ipinfo.io`
- [ ] Use `strict_chain` when hop availability is guaranteed
- [ ] Use `--pcng` for OS-level enforcement (catches all sockets, not just Chromium)
- [ ] Regularly rotate Tor circuits via NEW CIRCUIT button
- [ ] Consider `random_chain` with 3+ hops for attribution resistance

---

## File Structure

```
proxychains-browser/
├── src/
│   ├── main.js          # Electron main process
│   ├── preload.js       # contextBridge API surface
│   └── renderer/
│       ├── index.html   # GUI shell
│       └── app.js       # Renderer logic
├── launch.sh            # Launch wrapper with proxychains-ng support
├── package.json
└── README.md
```

---

## Generated proxychains.conf

The app generates `~/.config/proxychains-browser/proxychains.conf` from your GUI settings. You can use this conf file directly with any other tool:

```bash
proxychains4 -f ~/.config/proxychains-browser/proxychains.conf curl https://ipinfo.io
proxychains4 -f ~/.config/proxychains-browser/proxychains.conf nmap -sT target
```

---

## Building Distributable

```bash
# Linux AppImage
npm run build:linux

# macOS DMG
npm run build:mac

# Windows NSIS installer
npm run build:win
```

---

## License

MIT — Cybopsec. For authorized security research and privacy use only.
