/**
 * Preload — contextBridge API surface
 * Only exposes what the renderer strictly needs. No direct Node access.
 */
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('pcb', {
  // Settings
  getSettings:    ()  => ipcRenderer.invoke('settings:get'),
  saveSettings:   (s) => ipcRenderer.invoke('settings:save', s),
  resetSettings:  ()  => ipcRenderer.invoke('settings:reset'),
  getProxyConf:   ()  => ipcRenderer.invoke('proxychains:getConf'),

  // Navigation
  navGo:      (url) => ipcRenderer.invoke('nav:go', url),
  navBack:    ()    => ipcRenderer.invoke('nav:back'),
  navForward: ()    => ipcRenderer.invoke('nav:forward'),
  navReload:  ()    => ipcRenderer.invoke('nav:reload'),
  navStop:    ()    => ipcRenderer.invoke('nav:stop'),

  // Tor
  torNewCircuit: ()  => ipcRenderer.invoke('tor:newCircuit'),
  torStatus:     ()  => ipcRenderer.invoke('tor:status'),

  // Proxy
  testProxy: (p) => ipcRenderer.invoke('proxy:test', p),

  // App
  readLog:      () => ipcRenderer.invoke('log:read'),
  openProfile:  () => ipcRenderer.invoke('app:openProfile'),
  clearData:    () => ipcRenderer.invoke('app:clearData'),
  resizeView:   (h) => ipcRenderer.invoke('view:resize', h),

  // Events from main
  onNavUpdate: (cb) => ipcRenderer.on('nav:update', (_, data) => cb(data)),
  onChainStatus: (cb) => ipcRenderer.on('chain:status', (_, data) => cb(data)),
});
