/**
 * ProxyChains Browser — Renderer Process
 * All UI logic: settings, proxy list, chain strip, Tor, log
 */

'use strict';

// ─── State ────────────────────────────────────────────────────────────────────
let settings       = null;
let activePanelTab = 'proxies';
let panelOpen      = false;
let editingIndex   = -1;
let loadTimer      = null;

// ─── Init ─────────────────────────────────────────────────────────────────────
async function init() {
  settings = await pcb.getSettings();
  populateAll();
  updateChainStrip();
  updateStatusBar();
  updateTopIndicators();

  // Listen for navigation updates from main
  pcb.onNavUpdate(data => {
    if (data.url)   document.getElementById('url-bar').value = data.url;
    if (data.title) {
      document.getElementById('tab-title').textContent =
        data.title.length > 28 ? data.title.slice(0,28)+'…' : data.title;
      document.title = data.title + ' — ProxyChains Browser';
    }
    const lock = document.getElementById('url-lock');
    if (data.url) {
      lock.style.display = data.url.startsWith('https') ? '' : 'none';
      document.getElementById('url-bar').classList.toggle('has-lock', data.url.startsWith('https'));
    }
    if (data.loading !== undefined) setLoading(data.loading);
  });

  // Poll Tor status every 15 s
  checkTorStatus();
  setInterval(checkTorStatus, 15000);
}

// ─── Loading Bar ──────────────────────────────────────────────────────────────
function setLoading(on) {
  const fill = document.getElementById('load-bar-fill');
  if (on) {
    fill.style.width = '0%';
    fill.style.opacity = '1';
    let w = 0;
    clearInterval(loadTimer);
    loadTimer = setInterval(() => {
      w = Math.min(w + Math.random() * 12, 88);
      fill.style.width = w + '%';
    }, 200);
    setStatus('Loading…');
  } else {
    clearInterval(loadTimer);
    fill.style.width = '100%';
    setTimeout(() => { fill.style.opacity = '0'; fill.style.width = '0%'; }, 400);
    setStatus('Ready');
  }
}

function handleReload() {
  const btn = document.getElementById('btn-reload');
  btn.textContent = '✕';
  btn.onclick = () => { pcb.navStop(); btn.textContent = '⟳'; btn.onclick = handleReload; };
  pcb.navReload();
  setTimeout(() => { btn.textContent = '⟳'; btn.onclick = handleReload; }, 1500);
}

// ─── Populate Forms ───────────────────────────────────────────────────────────
function populateAll() {
  const s = settings;
  // Chain mode
  setVal('proxy-mode', s.proxyMode);
  setChecked('proxy-dns',  s.proxyDNS);
  setChecked('quiet-mode', s.quietMode);
  setVal('tcp-read', s.tcpReadTimeout);
  setVal('tcp-conn', s.tcpConnectTimeout);
  setVal('localnet-input', (s.localnet||[]).join('\n'));

  // Tor
  setChecked('tor-enabled',  s.tor.enabled);
  setVal('tor-socks', s.tor.socksPort);
  setVal('tor-ctrl',  s.tor.controlPort);
  setVal('tor-pass',  s.tor.controlPassword);
  setChecked('tor-newcirc', s.tor.newCircuitOnStartup);

  // Browser
  setVal('s-homepage',      s.browser.homepage);
  setChecked('s-spoof-ua',  s.browser.spoofUserAgent);
  setVal('s-ua',            s.browser.userAgent);
  setChecked('s-block-webrtc', s.browser.blockWebRTC);
  setChecked('s-block-canvas', s.browser.blockCanvas);
  setChecked('s-no-js',        s.browser.disableJavascript);

  renderProxyList();
  refreshConf();
}

function setVal(id, val) {
  const el = document.getElementById(id);
  if (el) el.value = val ?? '';
}
function setChecked(id, val) {
  const el = document.getElementById(id);
  if (el) el.checked = !!val;
}

// ─── Collect Settings from Form ───────────────────────────────────────────────
function collectSettings() {
  return {
    proxyMode:          document.getElementById('proxy-mode').value,
    proxyDNS:           document.getElementById('proxy-dns').checked,
    quietMode:          document.getElementById('quiet-mode').checked,
    tcpReadTimeout:     parseInt(document.getElementById('tcp-read').value) || 15000,
    tcpConnectTimeout:  parseInt(document.getElementById('tcp-conn').value) || 10000,
    localnet:           document.getElementById('localnet-input').value.split('\n').map(s=>s.trim()).filter(Boolean),
    proxies:            settings.proxies,
    tor: {
      enabled:            document.getElementById('tor-enabled').checked,
      socksPort:          parseInt(document.getElementById('tor-socks').value) || 9050,
      controlPort:        parseInt(document.getElementById('tor-ctrl').value) || 9051,
      controlPassword:    document.getElementById('tor-pass').value,
      newCircuitOnStartup: document.getElementById('tor-newcirc').checked
    },
    browser: {
      homepage:           document.getElementById('s-homepage').value,
      spoofUserAgent:     document.getElementById('s-spoof-ua').checked,
      userAgent:          document.getElementById('s-ua').value,
      blockWebRTC:        document.getElementById('s-block-webrtc').checked,
      blockCanvas:        document.getElementById('s-block-canvas').checked,
      disableJavascript:  document.getElementById('s-no-js').checked,
    }
  };
}

// ─── Save ─────────────────────────────────────────────────────────────────────
async function saveAll() {
  const s = collectSettings();
  settings = s;
  await pcb.saveSettings(s);
  updateChainStrip();
  updateStatusBar();
  updateTopIndicators();
  refreshConf();
  toast('Settings saved & applied ✓', 'green');
}

async function resetSettings() {
  if (!confirm('Reset all settings to defaults?')) return;
  settings = await pcb.resetSettings();
  populateAll();
  updateChainStrip();
  updateStatusBar();
  updateTopIndicators();
  toast('Settings reset to defaults', 'warn');
}

// ─── Proxy List Render ────────────────────────────────────────────────────────
function renderProxyList() {
  const list = document.getElementById('proxy-list');
  const proxies = settings.proxies || [];
  if (!proxies.length) {
    list.innerHTML = '<div style="color:var(--text3); font-size:11px; padding:8px 0;">No proxies configured. Add one below.</div>';
    return;
  }
  list.innerHTML = proxies.map((p, i) => `
    <div class="proxy-entry ${p.enabled ? '' : 'disabled'}" id="proxy-entry-${i}" draggable="true"
         ondragstart="dragStart(event,${i})" ondragover="dragOver(event)" ondrop="dragDrop(event,${i})">
      <span class="drag-handle" title="Drag to reorder">⠿</span>
      <input type="checkbox" ${p.enabled ? 'checked' : ''}
             onchange="toggleProxy(${i}, this.checked)" title="Enable/disable this hop">
      <div class="proxy-info">
        <div class="proxy-label">${escHtml(p.label || p.host)}</div>
        <div class="proxy-addr">${escHtml(p.host)}:${p.port}${p.user ? ' [auth]' : ''}</div>
      </div>
      <span class="proxy-type-badge ${p.type}">${p.type.toUpperCase()}</span>
      <span class="proxy-test-dot" id="pdot-${i}" title="Click to test" onclick="testSingleProxy(${i})"></span>
      <div class="proxy-actions">
        <button class="proxy-edit-btn" onclick="openEditModal(${i})" title="Edit">✎</button>
        <button class="proxy-del-btn"  onclick="deleteProxy(${i})" title="Delete">✕</button>
      </div>
    </div>
  `).join('');
}

function toggleProxy(i, enabled) {
  settings.proxies[i].enabled = enabled;
  const entry = document.getElementById(`proxy-entry-${i}`);
  entry?.classList.toggle('disabled', !enabled);
  updateChainStrip();
  updateTopIndicators();
  updateStatusBar();
  refreshConf();
}

function deleteProxy(i) {
  settings.proxies.splice(i, 1);
  renderProxyList();
  updateChainStrip();
  updateTopIndicators();
  updateStatusBar();
  refreshConf();
}

// ─── Add Proxy ────────────────────────────────────────────────────────────────
function showAddForm() {
  document.getElementById('add-proxy-form').classList.add('open');
}
function hideAddForm() {
  document.getElementById('add-proxy-form').classList.remove('open');
  ['np-label','np-host','np-port','np-user','np-pass'].forEach(id => setVal(id,''));
}

function addProxy() {
  const host = document.getElementById('np-host').value.trim();
  const port = parseInt(document.getElementById('np-port').value);
  if (!host || !port) { toast('Host and port are required', 'red'); return; }
  settings.proxies.push({
    type:    document.getElementById('np-type').value,
    host, port,
    user:    document.getElementById('np-user').value.trim(),
    pass:    document.getElementById('np-pass').value,
    label:   document.getElementById('np-label').value.trim() || host,
    enabled: true
  });
  hideAddForm();
  renderProxyList();
  updateChainStrip();
  updateTopIndicators();
  updateStatusBar();
  refreshConf();
  toast('Proxy added', 'green');
}

// ─── Edit Modal ───────────────────────────────────────────────────────────────
function openEditModal(i) {
  editingIndex = i;
  const p = settings.proxies[i];
  setVal('m-label', p.label || '');
  setVal('m-type',  p.type);
  setVal('m-host',  p.host);
  setVal('m-port',  p.port);
  setVal('m-user',  p.user || '');
  setVal('m-pass',  p.pass || '');
  document.getElementById('modal-title').textContent = 'EDIT PROXY';
  document.getElementById('modal-overlay').classList.add('open');
}

function closeModal() {
  document.getElementById('modal-overlay').classList.remove('open');
  editingIndex = -1;
}

function saveModal() {
  const host = document.getElementById('m-host').value.trim();
  const port = parseInt(document.getElementById('m-port').value);
  if (!host || !port) { toast('Host and port are required', 'red'); return; }
  const p = {
    type:    document.getElementById('m-type').value,
    host, port,
    user:    document.getElementById('m-user').value.trim(),
    pass:    document.getElementById('m-pass').value,
    label:   document.getElementById('m-label').value.trim() || host,
    enabled: editingIndex >= 0 ? settings.proxies[editingIndex].enabled : true
  };
  if (editingIndex >= 0) settings.proxies[editingIndex] = p;
  else settings.proxies.push(p);
  closeModal();
  renderProxyList();
  updateChainStrip();
  updateTopIndicators();
  updateStatusBar();
  refreshConf();
  toast('Proxy saved', 'green');
}

// ─── Drag & Drop Reorder ──────────────────────────────────────────────────────
let dragFrom = -1;
function dragStart(e, i) { dragFrom = i; e.dataTransfer.effectAllowed = 'move'; }
function dragOver(e)      { e.preventDefault(); e.dataTransfer.dropEffect = 'move'; }
function dragDrop(e, i)   {
  e.preventDefault();
  if (dragFrom < 0 || dragFrom === i) return;
  const arr = settings.proxies;
  const item = arr.splice(dragFrom, 1)[0];
  arr.splice(i, 0, item);
  dragFrom = -1;
  renderProxyList();
  updateChainStrip();
  refreshConf();
}

// ─── Proxy Testing ────────────────────────────────────────────────────────────
async function testSingleProxy(i) {
  const dot = document.getElementById(`pdot-${i}`);
  if (!dot) return;
  dot.style.background = 'var(--warn)';
  dot.style.animation = 'pulse 1s infinite';
  const res = await pcb.testProxy(settings.proxies[i]);
  dot.style.animation = '';
  if (res.ok) {
    dot.style.background = 'var(--accent3)';
    dot.title = `OK — ${res.latency}ms`;
    toast(`Proxy ${settings.proxies[i].host}: reachable (${res.latency}ms)`, 'green');
  } else {
    dot.style.background = 'var(--danger)';
    dot.title = `FAIL: ${res.error}`;
    toast(`Proxy ${settings.proxies[i].host}: ${res.error}`, 'red');
  }
}

async function testAllProxies() {
  toast('Testing all proxies…', 'blue');
  for (let i = 0; i < settings.proxies.length; i++) await testSingleProxy(i);
  toast('Proxy test complete', 'green');
}

// ─── Chain Strip ─────────────────────────────────────────────────────────────
function updateChainStrip() {
  const strip = document.getElementById('chain-strip');
  const enabled = (settings.proxies||[]).filter(p => p.enabled);

  if (!enabled.length) {
    strip.innerHTML = `<span style="color:var(--text3); font-family:var(--mono); font-size:10px; padding:0 8px;">
      No active proxies — traffic is DIRECT</span>`;
    return;
  }

  let html = `<div class="chain-node">
    <div class="chain-origin">
      <span class="label">YOU</span>
      <span style="color:var(--text)">localhost</span>
    </div>
    <div class="hop-arrow"></div>
  </div>`;

  enabled.forEach((p, i) => {
    const isTor = p.type === 'socks5' && p.port === 9050 && p.host === '127.0.0.1';
    html += `<div class="chain-node">
      <div class="chain-hop ${isTor ? 'tor-hop' : ''}" onclick="openEditModal(${settings.proxies.indexOf(p)})">
        <span class="hop-type">${isTor ? '🧅 TOR' : p.type.toUpperCase()}</span>
        <span class="hop-host">${p.host}</span>
        <span class="hop-port">:${p.port}</span>
        <span class="hop-status" id="strip-dot-${i}"></span>
      </div>
      ${i < enabled.length - 1 ? '<div class="hop-arrow"></div>' : ''}
    </div>`;
  });

  html += `<div class="chain-node">
    ${enabled.length > 0 ? '<div class="hop-arrow"></div>' : ''}
    <div class="chain-dest">
      <span class="label">TARGET</span>
      <span style="color:var(--accent)">INTERNET</span>
    </div>
  </div>`;

  strip.innerHTML = html;
}

// ─── Status Bar ───────────────────────────────────────────────────────────────
function updateStatusBar() {
  const s = settings;
  const enabled = (s.proxies||[]).filter(p => p.enabled);
  const pdot  = document.getElementById('s-proxy-dot');
  const plbl  = document.getElementById('s-proxy-label');
  const dnsd  = document.getElementById('s-dns-dot');
  const dnsl  = document.getElementById('s-dns-label');

  if (enabled.length) {
    pdot.className = 'status-dot green';
    plbl.textContent = `proxy: ${enabled.length} hop${enabled.length>1?'s':''} active`;
  } else {
    pdot.className = 'status-dot red';
    plbl.textContent = 'proxy: DIRECT';
  }

  if (s.proxyDNS && enabled.length) {
    dnsd.className = 'status-dot green';
    dnsl.textContent = 'dns: proxied';
  } else {
    dnsd.className = 'status-dot yellow';
    dnsl.textContent = 'dns: direct ⚠';
  }

  document.getElementById('s-mode').textContent = `mode: ${s.proxyMode}`;
  document.getElementById('s-hops').textContent = `${enabled.length} hop${enabled.length!==1?'s':''}`;
}

// ─── Top Indicators ───────────────────────────────────────────────────────────
function updateTopIndicators() {
  const s = settings;
  const enabled = (s.proxies||[]).filter(p => p.enabled);
  const cdot  = document.getElementById('chain-dot');
  const clbl  = document.getElementById('chain-label');
  const tdot  = document.getElementById('tor-dot');
  const tlbl  = document.getElementById('tor-label');

  if (enabled.length) {
    cdot.className = 'chain-dot active';
    clbl.textContent = `${enabled.length} HOP${enabled.length>1?'S':''}`;
  } else {
    cdot.className = 'chain-dot inactive';
    clbl.textContent = 'NO CHAIN';
  }

  const hasTor = enabled.some(p => p.port === 9050 && p.host === '127.0.0.1');
  if (s.tor.enabled || hasTor) {
    tdot.className = 'chain-dot active';
    tlbl.textContent = 'TOR ON';
  } else {
    tdot.className = 'chain-dot inactive';
    tlbl.textContent = 'TOR OFF';
  }
}

// ─── Conf Preview ─────────────────────────────────────────────────────────────
async function refreshConf() {
  const conf = await pcb.getProxyConf();
  const el = document.getElementById('conf-preview');
  if (el) el.textContent = conf || '# (not yet generated — save settings first)';
}

async function copyConf() {
  const conf = document.getElementById('conf-preview').textContent;
  await navigator.clipboard.writeText(conf);
  toast('Config copied to clipboard ✓', 'green');
}

// ─── Tor ──────────────────────────────────────────────────────────────────────
async function checkTorStatus() {
  const res = await pcb.torStatus();
  const el  = document.getElementById('tor-circuit-info');
  const st  = document.getElementById('tor-status-text');
  const td  = document.getElementById('tor-dot');
  const tl  = document.getElementById('tor-label');

  if (res.ok && res.established) {
    if (el) el.textContent = '✓ Circuit established\n' + (res.raw || '');
    if (st) st.textContent = '● ESTABLISHED';
    if (st) st.style.color = 'var(--accent3)';
    td.className = 'chain-dot active';
    tl.textContent = 'TOR ✓';
    document.getElementById('s-tor-dot').className = 'status-dot green';
    document.getElementById('s-tor-label').textContent = 'tor: connected';
  } else {
    if (el) el.textContent = res.error || 'Not reachable — is Tor running?\nStart with: sudo systemctl start tor';
    if (st) st.textContent = '○ OFFLINE';
    if (st) st.style.color = 'var(--text3)';
    const hasTor = (settings.proxies||[]).filter(p=>p.enabled).some(p=>p.port===9050);
    td.className = hasTor ? 'chain-dot warning' : 'chain-dot inactive';
    tl.textContent = hasTor ? 'TOR ?' : 'TOR OFF';
    document.getElementById('s-tor-dot').className = 'status-dot yellow';
    document.getElementById('s-tor-label').textContent = 'tor: not detected';
  }
}

async function newTorCircuit() {
  toast('Requesting new Tor circuit…', 'blue');
  const res = await pcb.torNewCircuit();
  const el = document.getElementById('tor-circuit-info');
  if (res.ok) {
    if (el) el.textContent = '✓ New circuit requested\n' + res.response;
    toast('New Tor circuit established ✓', 'green');
  } else {
    if (el) el.textContent = '✗ ' + res.error;
    toast('Circuit request failed: ' + res.error, 'red');
  }
}

function onTorToggle() {
  const enabled = document.getElementById('tor-enabled').checked;
  if (enabled) {
    // Auto-add Tor as first hop if not already present
    const hasTor = settings.proxies.some(p => p.host === '127.0.0.1' && p.port === 9050);
    if (!hasTor) {
      settings.proxies.unshift({
        type: 'socks5', host: '127.0.0.1',
        port: parseInt(document.getElementById('tor-socks').value) || 9050,
        user: '', pass: '', enabled: true, label: 'Tor (local)'
      });
      renderProxyList();
      updateChainStrip();
      refreshConf();
      toast('Tor SOCKS5 added as first hop', 'purple');
    }
  }
  updateTopIndicators();
}

function onModeChange() {
  // Live update the strip label
  updateStatusBar();
}

// ─── Panel ────────────────────────────────────────────────────────────────────
function togglePanel(tab) {
  if (panelOpen && activePanelTab === tab) { closePanel(); return; }
  openPanel(tab);
}

function openPanel(tab) {
  panelOpen = true;
  document.getElementById('side-panel').classList.add('open');
  switchPanelTab(tab);
  if (tab === 'log') refreshLog();
  if (tab === 'proxies') refreshConf();
  // Shrink browser view
  const panel = document.getElementById('side-panel');
  pcb.resizeView(130); // keep toolbar height; panel overlays
}

function closePanel() {
  panelOpen = false;
  document.getElementById('side-panel').classList.remove('open');
}

function switchPanelTab(tab) {
  activePanelTab = tab;
  document.querySelectorAll('.ptab').forEach(b => b.classList.toggle('active', b.dataset.panel === tab));
  document.querySelectorAll('.ptab-content').forEach(c => c.classList.toggle('active', c.id === `tab-${tab}`));
  document.getElementById('panel-title').textContent =
    ({proxies:'PROXY CHAINS', tor:'TOR INTEGRATION', settings:'BROWSER CONFIG', log:'SESSION LOG'})[tab] || tab.toUpperCase();
  if (tab === 'log') refreshLog();
}

// ─── Log ──────────────────────────────────────────────────────────────────────
async function refreshLog() {
  const raw = await pcb.readLog();
  const el  = document.getElementById('log-output');
  if (!el) return;
  el.innerHTML = raw.split('\n').map(line => {
    if (line.includes('[ERROR]')) return `<span class="log-error">${escHtml(line)}</span>`;
    if (line.includes('[WARN]'))  return `<span class="log-warn">${escHtml(line)}</span>`;
    return `<span class="log-info">${escHtml(line)}</span>`;
  }).join('\n');
  el.scrollTop = el.scrollHeight;
}

// ─── Data ─────────────────────────────────────────────────────────────────────
async function clearData() {
  if (!confirm('Clear all browser data (cookies, cache, storage)?')) return;
  await pcb.clearData();
  toast('Browser data cleared ✓', 'green');
}

// ─── Status helper ────────────────────────────────────────────────────────────
function setStatus(msg) {
  const el = document.getElementById('status-msg');
  if (el) el.textContent = msg;
}

// ─── Toast ────────────────────────────────────────────────────────────────────
let toastTimer = null;
function toast(msg, type='green') {
  const t = document.getElementById('toast');
  const colors = { green:'var(--accent3)', red:'var(--danger)', warn:'var(--warn)', blue:'var(--accent)', purple:'var(--accent2)' };
  t.textContent = msg;
  t.style.borderColor = colors[type] || colors.green;
  t.style.color = colors[type] || colors.green;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 2800);
}

// ─── Helpers ──────────────────────────────────────────────────────────────────
function escHtml(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// ─── Keyboard shortcuts ───────────────────────────────────────────────────────
document.addEventListener('keydown', e => {
  if (e.key === 'Escape' && panelOpen) closePanel();
  if ((e.ctrlKey||e.metaKey) && e.key === 'l') {
    document.getElementById('url-bar').focus();
    document.getElementById('url-bar').select();
    e.preventDefault();
  }
  if ((e.ctrlKey||e.metaKey) && e.shiftKey && e.key === 'P') {
    togglePanel('proxies'); e.preventDefault();
  }
});

// ─── Start ────────────────────────────────────────────────────────────────────
init();
