#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# ProxyChains Browser — Launch Script
# Cybopsec Security Research Tool
#
# Launches the Electron app, optionally wrapping the process itself in
# proxychains-ng for OS-level chain enforcement (useful when you want
# proxychains to intercept all outbound syscalls, not just Chromium's
# network stack).
#
# Usage:
#   ./launch.sh             — normal launch (Electron manages proxy via session API)
#   ./launch.sh --pcng      — wrap Electron in proxychains-ng (OS-level)
#   ./launch.sh --tor-only  — set only Tor SOCKS5, ignore stored chain config
#   ./launch.sh --help      — show this message
# ─────────────────────────────────────────────────────────────────────────────

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DATA_DIR="${HOME}/.config/proxychains-browser"
PC_CONF="${DATA_DIR}/proxychains.conf"
LOG_FILE="${DATA_DIR}/launch.log"

# ── Colour output ────────────────────────────────────────────────────────────
R='\033[0;31m'; G='\033[0;32m'; Y='\033[0;33m'; C='\033[0;36m'; N='\033[0m'
info()  { echo -e "${C}[PCB]${N} $*"; }
ok()    { echo -e "${G}[OK] ${N} $*"; }
warn()  { echo -e "${Y}[WARN]${N} $*"; }
error() { echo -e "${R}[ERR]${N} $*" >&2; }

# ── Parse args ───────────────────────────────────────────────────────────────
USE_PCNG=false
TOR_ONLY=false

for arg in "$@"; do
  case "$arg" in
    --pcng)      USE_PCNG=true ;;
    --tor-only)  TOR_ONLY=true ;;
    --help|-h)
      grep '^#' "$0" | sed 's/^# \{0,2\}//'
      exit 0
      ;;
  esac
done

# ── Dependency checks ────────────────────────────────────────────────────────
info "Checking dependencies…"

check_dep() {
  if command -v "$1" &>/dev/null; then
    ok "$1 found: $(command -v "$1")"
    return 0
  else
    warn "$1 not found — $2"
    return 1
  fi
}

check_dep node     "Install Node.js: https://nodejs.org"      || exit 1
check_dep npx      "Comes with npm"                            || exit 1
check_dep tor      "sudo apt install tor  /  brew install tor" || warn "Tor integration disabled"
$USE_PCNG && { check_dep proxychains4 "sudo apt install proxychains-ng" || \
               check_dep proxychains  "sudo apt install proxychains"    || \
               { error "proxychains not found; run without --pcng"; exit 1; }; }

# ── Ensure config dir ────────────────────────────────────────────────────────
mkdir -p "${DATA_DIR}"

# ── Tor: generate a minimal proxychains conf if --tor-only ───────────────────
if $TOR_ONLY; then
  info "Generating tor-only proxychains.conf…"
  cat > "${PC_CONF}" <<'TORCONF'
strict_chain
proxy_dns
quiet_mode
tcp_read_time_out 15000
tcp_connect_time_out 10000
localnet 127.0.0.0/255.0.0.0
localnet ::1/128

[ProxyList]
socks5 127.0.0.1 9050
TORCONF
  ok "tor-only config written to ${PC_CONF}"
fi

# ── Check Tor daemon ─────────────────────────────────────────────────────────
if command -v tor &>/dev/null; then
  if ! nc -z 127.0.0.1 9050 2>/dev/null; then
    warn "Tor SOCKS port 9050 not responding. Start Tor first:"
    warn "  sudo systemctl start tor   (systemd)"
    warn "  brew services start tor    (macOS)"
    warn "  tor &                      (manual)"
  else
    ok "Tor SOCKS5 detected on :9050"
    # Request new circuit if tor control port is open
    if nc -z 127.0.0.1 9051 2>/dev/null; then
      info "Requesting fresh Tor circuit…"
      (echo -e "AUTHENTICATE\r\nSIGNAL NEWNYM\r\nQUIT\r\n" | nc 127.0.0.1 9051 &>/dev/null) && ok "New Tor circuit requested" || true
    fi
  fi
fi

# ── Install npm deps if needed ────────────────────────────────────────────────
if [ ! -d "${SCRIPT_DIR}/node_modules/.bin/electron" ] && \
   [ ! -f "${SCRIPT_DIR}/node_modules/.bin/electron" ]; then
  info "Installing npm dependencies (first run)…"
  cd "${SCRIPT_DIR}"
  npm install 2>&1 | tee -a "${LOG_FILE}"
  ok "npm install complete"
fi

# ── Launch ───────────────────────────────────────────────────────────────────
cd "${SCRIPT_DIR}"

if $USE_PCNG; then
  # Determine correct proxychains binary name
  PC_BIN="proxychains4"
  command -v proxychains4 &>/dev/null || PC_BIN="proxychains"

  info "Launching with ${PC_BIN} (OS-level chain enforcement)…"
  info "Config: ${PC_CONF}"

  if [ -f "${PC_CONF}" ]; then
    exec "${PC_BIN}" -f "${PC_CONF}" npx electron src/main.js "$@" 2>&1 | tee -a "${LOG_FILE}"
  else
    warn "No proxychains.conf found at ${PC_CONF}"
    warn "Launch the app first to generate it, or use --tor-only"
    exec "${PC_BIN}" npx electron src/main.js "$@" 2>&1 | tee -a "${LOG_FILE}"
  fi
else
  info "Launching ProxyChains Browser (Electron-managed proxy)…"
  exec npx electron src/main.js 2>&1 | tee -a "${LOG_FILE}"
fi
