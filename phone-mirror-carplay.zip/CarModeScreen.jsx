/**
 * CarModeScreen.jsx
 * Full-screen car display UI — optimized for 800x480 to 1920x720 head unit displays
 * Activates on AirPlay detection (iOS) or Cast session start (Android)
 *
 * Stack: React Native / Expo (rendered as preview in React for web)
 * In production: replace StyleSheet refs with RN equivalents
 */

import { useState, useEffect, useRef } from "react";

// ─── Mock data / hooks (replace with real RN services) ───────────────────────
const useClock = () => {
  const [time, setTime] = useState(new Date());
  useEffect(() => {
    const t = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(t);
  }, []);
  return time;
};

const useCarState = () => {
  const [state, setState] = useState({
    speed: 0,
    rpm: 0,
    connected: false,
    castDevice: null,
    mediaTitle: "No media playing",
    mediaArtist: "",
    mediaPlaying: false,
    navInstruction: "Head north on Las Vegas Blvd",
    navDistance: "0.4 mi",
    navETA: "12 min",
    temp: 72,
    signal: 4,
    battery: 87,
  });

  // Simulate live data in preview
  useEffect(() => {
    const interval = setInterval(() => {
      setState((prev) => ({
        ...prev,
        speed: Math.max(0, Math.min(85, prev.speed + (Math.random() - 0.48) * 3)),
        rpm: Math.max(800, Math.min(6500, prev.rpm + (Math.random() - 0.5) * 200)),
        connected: true,
        castDevice: "Dashboard Display",
      }));
    }, 800);
    return () => clearInterval(interval);
  }, []);

  return [state, setState];
};

// ─── Sub-components ───────────────────────────────────────────────────────────

const SpeedGauge = ({ speed, rpm }) => {
  const maxSpeed = 120;
  const maxRPM = 7000;
  const speedAngle = (speed / maxSpeed) * 240 - 120;
  const rpmAngle = (rpm / maxRPM) * 240 - 120;

  const describeArc = (cx, cy, r, startAngle, endAngle) => {
    const toRad = (deg) => ((deg - 90) * Math.PI) / 180;
    const s = { x: cx + r * Math.cos(toRad(startAngle)), y: cy + r * Math.sin(toRad(startAngle)) };
    const e = { x: cx + r * Math.cos(toRad(endAngle)), y: cy + r * Math.sin(toRad(endAngle)) };
    const large = endAngle - startAngle > 180 ? 1 : 0;
    return `M ${s.x} ${s.y} A ${r} ${r} 0 ${large} 1 ${e.x} ${e.y}`;
  };

  const needlePoint = (cx, cy, r, angle) => {
    const rad = ((angle - 90) * Math.PI) / 180;
    return { x: cx + r * Math.cos(rad), y: cy + r * Math.sin(rad) };
  };

  const speedNeedle = needlePoint(80, 80, 55, speedAngle);
  const rpmNeedle = needlePoint(80, 80, 40, rpmAngle);

  return (
    <div style={styles.gaugeWrap}>
      <svg viewBox="0 0 160 160" width="160" height="160">
        {/* Outer ring */}
        <circle cx="80" cy="80" r="72" fill="none" stroke="#0a0f1a" strokeWidth="2" />

        {/* RPM track */}
        <path d={describeArc(80, 80, 56, -120, 120)} fill="none" stroke="#1a2030" strokeWidth="8" strokeLinecap="round" />
        <path d={describeArc(80, 80, 56, -120, rpmAngle)} fill="none" stroke="#00c8ff" strokeWidth="8" strokeLinecap="round" opacity="0.5" />

        {/* Speed track */}
        <path d={describeArc(80, 80, 70, -120, 120)} fill="none" stroke="#0d1520" strokeWidth="6" strokeLinecap="round" />
        <path d={describeArc(80, 80, 70, -120, speedAngle)} fill="none"
          stroke={speed > 70 ? "#ff4444" : speed > 45 ? "#ffaa00" : "#00e8a2"}
          strokeWidth="6" strokeLinecap="round" />

        {/* Speed needle */}
        <line x1="80" y1="80" x2={speedNeedle.x} y2={speedNeedle.y}
          stroke="#ffffff" strokeWidth="1.5" strokeLinecap="round" opacity="0.9" />

        {/* Center */}
        <circle cx="80" cy="80" r="6" fill="#00e8a2" />
        <circle cx="80" cy="80" r="3" fill="#0a0f1a" />

        {/* Speed readout */}
        <text x="80" y="104" textAnchor="middle" fill="#ffffff" fontSize="22" fontFamily="'Courier New', monospace" fontWeight="bold">
          {Math.round(speed)}
        </text>
        <text x="80" y="116" textAnchor="middle" fill="#4a6080" fontSize="7" fontFamily="monospace" letterSpacing="2">
          MPH
        </text>

        {/* RPM label */}
        <text x="80" y="60" textAnchor="middle" fill="#00c8ff" fontSize="6" fontFamily="monospace" opacity="0.7">
          {Math.round(rpm)} RPM
        </text>

        {/* Tick marks */}
        {Array.from({ length: 13 }).map((_, i) => {
          const angle = -120 + i * 20;
          const rad = ((angle - 90) * Math.PI) / 180;
          const inner = i % 3 === 0 ? 62 : 65;
          return (
            <line key={i}
              x1={80 + inner * Math.cos(rad)} y1={80 + inner * Math.sin(rad)}
              x2={80 + 70 * Math.cos(rad)} y2={80 + 70 * Math.sin(rad)}
              stroke={i % 3 === 0 ? "#4a6080" : "#1e2d40"} strokeWidth={i % 3 === 0 ? 1.5 : 0.8} />
          );
        })}
      </svg>
    </div>
  );
};

const NavWidget = ({ instruction, distance, eta }) => (
  <div style={styles.navWidget}>
    <div style={styles.navArrow}>
      <svg viewBox="0 0 40 40" width="36" height="36">
        <polygon points="20,4 34,28 20,22 6,28" fill="#00e8a2" opacity="0.9" />
      </svg>
    </div>
    <div style={styles.navText}>
      <div style={styles.navInstruction}>{instruction}</div>
      <div style={styles.navMeta}>
        <span style={styles.navDistance}>{distance}</span>
        <span style={styles.navDivider}>·</span>
        <span style={styles.navETA}>ETA {eta}</span>
      </div>
    </div>
  </div>
);

const MediaWidget = ({ title, artist, playing, onToggle }) => (
  <div style={styles.mediaWidget}>
    <div style={styles.mediaAlbumArt}>
      <svg viewBox="0 0 48 48" width="48" height="48">
        <circle cx="24" cy="24" r="22" fill="#0d1a2a" stroke="#00e8a2" strokeWidth="0.5" />
        <circle cx="24" cy="24" r="10" fill="#091422" stroke="#1a3040" strokeWidth="1" />
        <circle cx="24" cy="24" r="3" fill="#00e8a2" />
        {Array.from({ length: 8 }).map((_, i) => {
          const a = (i / 8) * Math.PI * 2;
          return <line key={i} x1={24 + 12 * Math.cos(a)} y1={24 + 12 * Math.sin(a)}
            x2={24 + 20 * Math.cos(a)} y2={24 + 20 * Math.sin(a)}
            stroke="#1a3040" strokeWidth="0.5" />;
        })}
      </svg>
    </div>
    <div style={styles.mediaInfo}>
      <div style={styles.mediaTitle}>{title || "—"}</div>
      <div style={styles.mediaArtist}>{artist || "Unknown"}</div>
    </div>
    <div style={styles.mediaControls}>
      <button style={styles.mediaBtn} onClick={() => {}}>⏮</button>
      <button style={{ ...styles.mediaBtn, ...styles.mediaBtnPrimary }} onClick={onToggle}>
        {playing ? "⏸" : "▶"}
      </button>
      <button style={styles.mediaBtn} onClick={() => {}}>⏭</button>
    </div>
  </div>
);

const StatusBar = ({ time, signal, battery, connected, castDevice, temp }) => {
  const h = time.getHours();
  const m = String(time.getMinutes()).padStart(2, "0");
  const ampm = h >= 12 ? "PM" : "AM";
  const h12 = h % 12 || 12;

  return (
    <div style={styles.statusBar}>
      <div style={styles.statusLeft}>
        <div style={styles.castBadge}>
          <span style={{ ...styles.castDot, background: connected ? "#00e8a2" : "#ff4444" }} />
          <span style={styles.castLabel}>{connected ? castDevice || "Connected" : "Not connected"}</span>
        </div>
      </div>
      <div style={styles.statusCenter}>
        <span style={styles.clockTime}>{h12}:{m}</span>
        <span style={styles.clockAMPM}>{ampm}</span>
      </div>
      <div style={styles.statusRight}>
        <span style={styles.statusIcon}>{temp}°F</span>
        <span style={styles.statusIcon}>{"▌".repeat(signal)}{"░".repeat(4 - signal)}</span>
        <span style={styles.batteryLabel}>{battery}%</span>
      </div>
    </div>
  );
};

const SecurityBadge = () => (
  <div style={styles.secBadge} title="ECDH session active · Origin validated">
    <svg viewBox="0 0 16 16" width="12" height="12">
      <path d="M8 1 L14 4 L14 9 C14 12 11 14.5 8 15 C5 14.5 2 12 2 9 L2 4 Z"
        fill="none" stroke="#00e8a2" strokeWidth="1.2" />
      <path d="M5.5 8 L7 9.5 L10.5 6" stroke="#00e8a2" strokeWidth="1.2"
        fill="none" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
    <span style={styles.secLabel}>SESSION SECURE</span>
  </div>
);

// ─── Main Screen ──────────────────────────────────────────────────────────────

export default function CarModeScreen() {
  const time = useClock();
  const [car, setCar] = useCarState();
  const [activeTab, setActiveTab] = useState("dash");

  const toggleMedia = () => setCar((p) => ({ ...p, mediaPlaying: !p.mediaPlaying }));

  return (
    <div style={styles.root}>
      {/* Scanline overlay */}
      <div style={styles.scanlines} />
      {/* Ambient glow */}
      <div style={styles.ambientGlow} />

      {/* Status bar */}
      <StatusBar
        time={time}
        signal={car.signal}
        battery={car.battery}
        connected={car.connected}
        castDevice={car.castDevice}
        temp={car.temp}
      />

      {/* Main content */}
      <div style={styles.content}>
        {/* Left: Gauge */}
        <div style={styles.leftPanel}>
          <SpeedGauge speed={car.speed} rpm={car.rpm} />
          <SecurityBadge />
        </div>

        {/* Center: Nav + Media */}
        <div style={styles.centerPanel}>
          <NavWidget
            instruction={car.navInstruction}
            distance={car.navDistance}
            eta={car.navETA}
          />
          <div style={styles.divider} />
          <MediaWidget
            title={car.mediaTitle}
            artist={car.mediaArtist}
            playing={car.mediaPlaying}
            onToggle={toggleMedia}
          />
        </div>

        {/* Right: Quick actions */}
        <div style={styles.rightPanel}>
          {[
            { icon: "📞", label: "Phone" },
            { icon: "🗺", label: "Maps" },
            { icon: "⚙️", label: "Settings" },
            { icon: "🏠", label: "Home" },
          ].map(({ icon, label }) => (
            <button key={label} style={styles.quickBtn}>
              <span style={styles.quickIcon}>{icon}</span>
              <span style={styles.quickLabel}>{label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Bottom nav */}
      <div style={styles.bottomBar}>
        {["dash", "media", "nav", "apps"].map((tab) => (
          <button
            key={tab}
            style={{ ...styles.tabBtn, ...(activeTab === tab ? styles.tabBtnActive : {}) }}
            onClick={() => setActiveTab(tab)}
          >
            {tab.toUpperCase()}
          </button>
        ))}
      </div>
    </div>
  );
}

// ─── Styles ───────────────────────────────────────────────────────────────────

const styles = {
  root: {
    width: "100%",
    height: "100vh",
    minHeight: 480,
    background: "#040d17",
    display: "flex",
    flexDirection: "column",
    fontFamily: "'Courier New', 'Lucida Console', monospace",
    color: "#c8d8e8",
    overflow: "hidden",
    position: "relative",
    userSelect: "none",
  },
  scanlines: {
    position: "absolute",
    inset: 0,
    background: "repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,232,162,0.015) 2px, rgba(0,232,162,0.015) 4px)",
    pointerEvents: "none",
    zIndex: 10,
  },
  ambientGlow: {
    position: "absolute",
    top: -80,
    left: "50%",
    transform: "translateX(-50%)",
    width: 600,
    height: 300,
    background: "radial-gradient(ellipse, rgba(0,200,255,0.06) 0%, transparent 70%)",
    pointerEvents: "none",
    zIndex: 0,
  },
  statusBar: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    padding: "6px 20px",
    borderBottom: "1px solid #0d1e30",
    background: "rgba(4,13,23,0.95)",
    zIndex: 5,
    minHeight: 36,
  },
  statusLeft: { display: "flex", alignItems: "center", gap: 8, flex: 1 },
  statusCenter: { display: "flex", alignItems: "baseline", gap: 4, flex: 1, justifyContent: "center" },
  statusRight: { display: "flex", alignItems: "center", gap: 12, flex: 1, justifyContent: "flex-end" },
  castBadge: { display: "flex", alignItems: "center", gap: 6, background: "#091520", padding: "2px 10px", borderRadius: 3, border: "1px solid #0d2030" },
  castDot: { width: 7, height: 7, borderRadius: "50%", display: "inline-block" },
  castLabel: { fontSize: 10, letterSpacing: 1, color: "#6a9090" },
  clockTime: { fontSize: 22, fontWeight: "bold", color: "#e8f0f8", letterSpacing: 2 },
  clockAMPM: { fontSize: 10, color: "#4a7080", letterSpacing: 2 },
  statusIcon: { fontSize: 11, color: "#4a7090", letterSpacing: 1 },
  batteryLabel: { fontSize: 11, color: "#4a7090" },
  content: {
    display: "flex",
    flex: 1,
    padding: "12px 16px",
    gap: 16,
    zIndex: 2,
    overflow: "hidden",
  },
  leftPanel: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    gap: 12,
    minWidth: 160,
  },
  gaugeWrap: {
    background: "radial-gradient(circle at 50% 50%, #0a1828 0%, #040d17 80%)",
    borderRadius: "50%",
    padding: 8,
    border: "1px solid #0d2030",
    boxShadow: "0 0 30px rgba(0,200,255,0.08), inset 0 0 20px rgba(0,0,0,0.4)",
  },
  secBadge: {
    display: "flex",
    alignItems: "center",
    gap: 5,
    background: "rgba(0,232,162,0.06)",
    border: "1px solid rgba(0,232,162,0.2)",
    borderRadius: 3,
    padding: "3px 8px",
    cursor: "default",
  },
  secLabel: { fontSize: 8, color: "#00e8a2", letterSpacing: 1.5, opacity: 0.8 },
  centerPanel: {
    flex: 1,
    display: "flex",
    flexDirection: "column",
    gap: 0,
    justifyContent: "center",
  },
  navWidget: {
    display: "flex",
    alignItems: "center",
    gap: 14,
    background: "linear-gradient(135deg, #081420 0%, #050e1a 100%)",
    border: "1px solid #0d2030",
    borderRadius: 6,
    padding: "14px 18px",
    marginBottom: 10,
  },
  navArrow: { flexShrink: 0 },
  navText: { display: "flex", flexDirection: "column", gap: 4 },
  navInstruction: { fontSize: 15, color: "#d0e8f0", letterSpacing: 0.5 },
  navMeta: { display: "flex", gap: 8, alignItems: "center" },
  navDistance: { fontSize: 12, color: "#00e8a2", fontWeight: "bold" },
  navDivider: { color: "#2a4050", fontSize: 12 },
  navETA: { fontSize: 12, color: "#4a8090" },
  divider: { height: 1, background: "#0d1e2e", margin: "0 0 10px" },
  mediaWidget: {
    display: "flex",
    alignItems: "center",
    gap: 14,
    background: "linear-gradient(135deg, #081420 0%, #050e1a 100%)",
    border: "1px solid #0d2030",
    borderRadius: 6,
    padding: "12px 18px",
  },
  mediaAlbumArt: { flexShrink: 0 },
  mediaInfo: { flex: 1, minWidth: 0 },
  mediaTitle: { fontSize: 13, color: "#c8e0f0", overflow: "hidden", whiteSpace: "nowrap", textOverflow: "ellipsis" },
  mediaArtist: { fontSize: 11, color: "#4a7090", marginTop: 3 },
  mediaControls: { display: "flex", gap: 8, alignItems: "center" },
  mediaBtn: {
    background: "#091520",
    border: "1px solid #1a3040",
    borderRadius: 4,
    color: "#7a9ab0",
    fontSize: 14,
    width: 32,
    height: 32,
    cursor: "pointer",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
  },
  mediaBtnPrimary: {
    background: "rgba(0,232,162,0.12)",
    border: "1px solid rgba(0,232,162,0.3)",
    color: "#00e8a2",
  },
  rightPanel: {
    display: "flex",
    flexDirection: "column",
    gap: 8,
    justifyContent: "center",
    minWidth: 80,
  },
  quickBtn: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    gap: 4,
    background: "#081420",
    border: "1px solid #0d2030",
    borderRadius: 6,
    padding: "10px 8px",
    cursor: "pointer",
    transition: "border-color 0.15s",
  },
  quickIcon: { fontSize: 20 },
  quickLabel: { fontSize: 9, color: "#4a7090", letterSpacing: 1 },
  bottomBar: {
    display: "flex",
    gap: 1,
    borderTop: "1px solid #0d1e30",
    background: "#040d17",
    zIndex: 5,
  },
  tabBtn: {
    flex: 1,
    background: "transparent",
    border: "none",
    borderTop: "2px solid transparent",
    color: "#2a4a60",
    fontSize: 10,
    letterSpacing: 2,
    padding: "10px 0",
    cursor: "pointer",
  },
  tabBtnActive: {
    color: "#00e8a2",
    borderTopColor: "#00e8a2",
    background: "rgba(0,232,162,0.04)",
  },
};
