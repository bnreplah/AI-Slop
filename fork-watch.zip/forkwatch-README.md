# 🔱 forkwatch — Fork Drift Monitor

[![Fork Status Check](../../actions/workflows/fork-check.yml/badge.svg)](../../actions/workflows/fork-check.yml)

**Report-only** monitoring for your GitHub forks. Every day (or on demand), forkwatch enumerates every fork you own, compares its default branch against the upstream's default branch, and tells you which forks are **behind**, **ahead**, **diverged**, or **up to date** — without ever touching your repositories.

> **Design guarantee:** there is no code path in this project that pushes, merges, syncs, or otherwise mutates a repository. The PAT it needs is read-only.

```
┌─────────────────────┬──────────────────────┬─────────────┬────────┬───────┬────────────────────────┐
│ Repository          │ Upstream             │ Status      │ Behind │ Ahead │ Action                 │
├─────────────────────┼──────────────────────┼─────────────┼────────┼───────┼────────────────────────┤
│ you/awesome-osint   │ jivoi/awesome-osint  │ ⬇️ Behind   │     12 │     0 │ Fetch upstream changes │
│ you/semgrep-rules   │ semgrep/semgrep-rules│ 🔀 Diverged │      4 │     2 │ Manual review          │
│ you/wazuh           │ wazuh/wazuh          │ ✅ Up to date│      0 │     0 │ None                   │
└─────────────────────┴──────────────────────┴─────────────┴────────┴───────┴────────────────────────┘
```

See [`examples/sample-report.md`](examples/sample-report.md) and [`examples/sample-report.json`](examples/sample-report.json) for full sample output.

---

## Contents

- [How it works](#how-it-works)
- [Quick start (GitHub Actions)](#quick-start-github-actions)
- [Token scopes (least privilege)](#token-scopes-least-privilege)
- [Local development / CLI](#local-development--cli)
- [Configuration](#configuration)
- [Notifications](#notifications)
- [Repository structure](#repository-structure)
- [Security model](#security-model)
- [Troubleshooting](#troubleshooting)
- [Extending](#extending)

---

## How it works

1. **Enumerate** — `GET /user/repos?affiliation=owner` (or `/users/{u}/repos`, `/orgs/{o}/repos`), keeping only `fork: true`. Private forks are included if the token allows.
2. **Resolve upstream** — list endpoints omit the `parent` field, so each fork is fetched individually (`GET /repos/{owner}/{repo}`). The `parent.full_name` returned here tracks **renamed upstreams** automatically; a fork flagged `fork: true` with no `parent` means the **upstream was deleted**.
3. **Compare** — `GET /repos/{upstream}/compare/{base}...{you}:{branch}`:
   - `behind_by` = commits upstream has that your fork lacks
   - `ahead_by` = commits your fork has that upstream lacks
4. **Classify** — `up_to_date` / `behind` / `ahead` / `diverged` / `upstream_missing` / `archived` / `error`.
5. **Report** — console table (rich), Markdown (job summary + optional issue), JSON artifact. Exit code `1` if anything needs attention (useful for alerting), `0` when clean, `2` on config/API failure.

No `git clone`/fetch is needed — the compare API does the work server-side, which keeps the runner fast and the attack surface small.

## Quick start (GitHub Actions)

1. **Create this repo** (private is fine) and push these files.
2. **Create a fine-grained PAT** (see scopes below).
3. Add it as a repository secret: **Settings → Secrets and variables → Actions → New repository secret** named `FORK_CHECK_PAT`.
4. The workflow runs **daily at 06:17 UTC** and via **Actions → Fork Status Check → Run workflow** (manual dispatch supports a `behind_threshold` and comma-separated `exclude` globs).
5. Results appear in:
   - the **job summary** (rendered Markdown table),
   - a downloadable **`fork-status-report` artifact** (JSON + Markdown, 30-day retention),
   - an auto-maintained **issue** titled "🔱 Fork status report" (only when action is needed).

> Without `FORK_CHECK_PAT`, the workflow falls back to the built-in `github.token`, which can only see **this repository** — so set the PAT to monitor your account's forks.

## Token scopes (least privilege)

Use a **fine-grained PAT**, not a classic token:

| Setting | Value |
| --- | --- |
| Resource owner | your user (or org) |
| Repository access | **All repositories** (needed to enumerate forks) |
| **Contents** | Read-only |
| **Metadata** | Read-only (auto-granted) |
| Everything else | No access |
| Expiration | ≤ 90 days; rotate on a calendar reminder |

That's it. No write scopes of any kind. If you only monitor public forks, the token can be restricted further (public repositories only).

The workflow's own `GITHUB_TOKEN` is scoped in the YAML to `contents: read` + `issues: write` (delete the issue step and the `issues: write` line if you don't want the rolling issue).

## Local development / CLI

```bash
git clone <this-repo> && cd <this-repo>
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

cp .env.example .env          # add your PAT — .env is gitignored
export $(grep -v '^#' .env | xargs)   # or use direnv / your shell of choice

python check_forks.py                          # forks of the token owner
python check_forks.py --user octocat           # someone else's public forks
python check_forks.py --org my-org             # an organization's forks
python check_forks.py --exclude 'archive-*' --exclude 'legacy/*'
python check_forks.py --behind-threshold 10    # only flag if behind > 10
python check_forks.py --json --markdown        # writes out/report.{json,md}
python check_forks.py --json custom/path.json  # explicit paths (must be under CWD)
python check_forks.py --include-archived -v    # verbose, include archived forks
```

Exit codes: `0` clean · `1` forks need attention · `2` configuration/API error.

Run the tests (no network needed — the GitHub client is stubbed):

```bash
pip install pytest && pytest -q
```

## Configuration

Optional `config.toml` in the repo root (copy from [`config.example.toml`](config.example.toml)); CLI flags always win:

```toml
exclude = ["archive-*", "legacy-*", "someorg/old-experiment"]
behind_threshold = 0
include_archived = false
```

Parsed with the stdlib `tomllib` — only an allowlisted set of keys is honored. **Tokens and webhook URLs never go in this file.**

## Notifications

Set either secret and notifications fire automatically when forks need attention:

| Secret | Purpose |
| --- | --- |
| `SLACK_WEBHOOK_URL` | Incoming webhook (host must be `hooks.slack.com`) |
| `DISCORD_WEBHOOK_URL` | Channel webhook (host must be `discord.com`/`discordapp.com`) |

Webhook URLs are validated in code: **HTTPS only, host allowlisted** — a tampered secret can't be used to exfiltrate the report to an arbitrary endpoint.

**Email**: rather than embedding SMTP credentials, subscribe to the rolling issue (Watch → Custom → Issues) — GitHub emails you on every update, zero extra secrets.

## Repository structure

```
.
├── check_forks.py              # CLI entry point
├── forkwatch/
│   ├── __init__.py
│   ├── client.py               # hardened REST client (validation, backoff, no token leakage)
│   ├── models.py               # dataclasses: ForkResult, RunReport, ForkStatus
│   ├── analyzer.py             # enumeration + classification (report-only)
│   ├── report.py               # rich table / escaped Markdown / JSON
│   └── notify.py               # Slack & Discord with URL allowlisting
├── .github/workflows/fork-check.yml
├── tests/test_forkwatch.py     # 37 tests, no network required
├── examples/sample-report.{md,json}
├── config.example.toml
├── .env.example
├── requirements.txt
├── .gitignore                  # blocks .env, keys, reports
└── LICENSE (MIT)
```

## Security model

- **Read-only by construction** — no write API is ever called; the recommended PAT has zero write scopes.
- **Input validation at the trust boundary** — every owner/repo/branch name is checked against strict regexes (anchored with `\Z`, not `$`, so trailing-newline tricks fail) before URL interpolation. CLI flags and workflow-dispatch inputs are validated twice (shell + Python).
- **Output sanitization** — repo/branch/error strings returned by the API are Markdown-escaped (`| ` `[]()` `<>` backticks, control chars stripped) before entering job summaries or issues, so a hostile repository name can't inject links or break tables. Repo links render only for `https://github.com/…` URLs.
- **No token leakage** — the token lives only in the session header; exceptions and `repr()` are sanitized; `urllib3` debug logging is suppressed.
- **Workflow hardening** — explicit least-privilege `permissions:`, `persist-credentials: false`, no third-party actions, dispatch inputs passed via `env:` (never `${{ }}` inside `run:`), concurrency guard, 30-minute timeout.
- **SSRF-resistant notifications** — webhook hosts pinned to official Slack/Discord domains, HTTPS enforced.
- **API host pinning** — the client refuses any request that resolves outside `api.github.com`.

## Troubleshooting

| Symptom | Cause / fix |
| --- | --- |
| `No GitHub token provided` | Export `GH_PAT` (or `GITHUB_TOKEN`); in CI, create the `FORK_CHECK_PAT` secret. |
| Empty table but you have forks | Fine-grained PAT not granted **All repositories**, or you used `--user` against a private account (use the token owner default instead). |
| `HTTP 404` / `upstream_missing` for a living upstream | Upstream went private and your token can't see it — same signal as deleted from the API's perspective. |
| `HTTP 403` loops / very slow runs | Rate limiting (5,000 req/hr authenticated; ~2 requests per fork). The client backs off automatically; for 1,000+ forks, raise the schedule interval or split by org. |
| Workflow can't create the issue | Repo setting **Actions → Workflow permissions** is read-only; either enable write or keep the YAML's `issues: write` (preferred — it's surgical). Org policies can still override. |
| `Invalid user/org name` | The name failed validation — check for typos, spaces, or copy-paste artifacts. |
| Forks behind by 1–2 constantly | Set `behind_threshold` (config or `--behind-threshold`) to cut the noise. |
| `tomllib` import error | Python < 3.11. Upgrade (CI uses 3.12), or delete `config.toml` and use flags. |

## Extending

- **Label stale forks**: add a step using `gh api -X POST /repos/{repo}/labels` driven by `out/report.json` — note this requires write scope, so keep it in a *separate* workflow with its own narrowly-scoped token.
- **Multi-account**: run the workflow as a matrix over `--user`/`--org` values; merge the JSON artifacts.
- **GraphQL**: swap `client.compare` for a batched GraphQL query if you monitor hundreds of forks and want fewer round-trips.
- **GitHub App auth**: replace the PAT with an App installation token minted in a pre-step (`actions/create-github-app-token`) for org-grade auditability and automatic expiry.

---

MIT © Cybopsec — report-only by design; your forks stay exactly as you left them.
