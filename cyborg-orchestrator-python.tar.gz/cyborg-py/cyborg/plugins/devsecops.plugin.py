"""
devsecops.plugin.py
~~~~~~~~~~~~~~~~~~~
Example CYBORG plugin demonstrating:
  - Pipeline definitions
  - Task aliases
  - State machines
  - Sensor subscriptions
  - Agent handler registration

Drop this file in ~/.cyborg/plugins/ and it loads automatically on daemon start.
Call setup() manually when loading via CLI.
"""
from __future__ import annotations

import asyncio
import logging

log = logging.getLogger("cyborg.plugin.devsecops")


def setup() -> None:
    """Plugin entry point — called by the daemon loader."""
    from cyborg.core.pipeline_engine import pipeline_define, task_register
    from cyborg.core.agent_registry  import register, set_handler
    from cyborg.core.sensor_bus      import subscribe, register_handler, emit
    import cyborg.core.state_machine  as sm_engine
    from cyborg.core.config           import AgentType

    log.info("Loading DevSecOps plugin v1.0.0")

    # ── Task aliases ──────────────────────────────────────────
    task_register("git-pull",     "git -C {0} pull --ff-only")
    task_register("docker-ps",    "docker ps --format 'table {{.Names}}\\t{{.Status}}'")
    task_register("netstat-open", "ss -tlnp 2>/dev/null || netstat -tlnp")
    task_register("disk-usage",   "df -h | grep -v tmpfs")
    task_register("proc-top",     "ps aux --sort=-%cpu | head -15")
    task_register("port-check",   "nc -zvw3 {0} {1} 2>&1")
    task_register("cert-check",
        "echo | openssl s_client -connect {0}:{1} 2>/dev/null | openssl x509 -noout -dates")

    # ── Pipeline definitions ──────────────────────────────────
    pipeline_define("security-baseline",
        "check-ports:ss -tlnp:10:0;"
        "check-suid:find / -perm /4000 -type f 2>/dev/null | head -20:30:0;"
        "check-world-writable:find /tmp /var -perm -o+w 2>/dev/null | head -20:20:0;"
        "check-auth-log:tail -50 /var/log/auth.log 2>/dev/null || journalctl -n 50 2>/dev/null:10:0"
    )

    pipeline_define("system-health",
        "cpu:top -bn1 | head -5:10:0:parallel_sys;"
        "mem:free -h:5:0:parallel_sys;"
        "disk:df -h:5:0:parallel_sys;"
        "net:ss -s 2>/dev/null:5:0:parallel_sys;"
        "load:uptime:3:0"
    )

    pipeline_define("incident-triage",
        "collect-procs:ps auxf 2>/dev/null | head -40:10:0;"
        "collect-conns:ss -antup 2>/dev/null:10:0;"
        "collect-logins:last -20 2>/dev/null:5:0;"
        "collect-syslog:journalctl -n 50 2>/dev/null || tail -50 /var/log/syslog 2>/dev/null:10:0"
    )

    pipeline_define("backup-state",
        "compress-state:tar -czf /tmp/cyborg-state-$(date +%Y%m%d).tar.gz "
        "-C $ORCH_ROOT state/ pipelines/ agents/ 2>/dev/null:30:1;"
        "verify:ls -lh /tmp/cyborg-state-*.tar.gz | tail -3:5:0"
    )

    # ── State machine: deploy lifecycle ──────────────────────
    try:
        sm_engine.sm_create(
            "deploy_lifecycle", "IDLE",
            ["IDLE", "BUILDING", "TESTING", "SCANNING", "DEPLOYING", "LIVE", "ROLLBACK", "FAILED"],
        )

        transitions = [
            ("IDLE",      "START",    "BUILDING",  None,                   "_deploy_on_build"),
            ("BUILDING",  "BUILT",    "TESTING",   None,                   None),
            ("TESTING",   "PASSED",   "SCANNING",  None,                   None),
            ("TESTING",   "FAILED",   "FAILED",    None,                   "_deploy_on_test_fail"),
            ("SCANNING",  "CLEAN",    "DEPLOYING", None,                   None),
            ("SCANNING",  "VULN",     "FAILED",    None,                   "_deploy_vuln_found"),
            ("DEPLOYING", "SUCCESS",  "LIVE",      None,                   "_deploy_on_live"),
            ("DEPLOYING", "FAIL",     "ROLLBACK",  None,                   "_deploy_on_rollback"),
            ("ROLLBACK",  "COMPLETE", "IDLE",      None,                   None),
            ("LIVE",      "RESET",    "IDLE",      None,                   None),
            ("FAILED",    "RESET",    "IDLE",      None,                   None),
        ]
        for from_s, event, to_s, guard, action in transitions:
            sm_engine.sm_add_transition("deploy_lifecycle", from_s, event, to_s, guard, action)

    except ValueError:
        pass  # Already exists (e.g. daemon restart)

    # Register SM action handlers
    def _deploy_on_build(sm_id, frm, to, data):
        log.info("Deploy SM: build phase started")
        emit("DEPLOY_BUILD_STARTED", {"sm_id": sm_id})

    def _deploy_on_test_fail(sm_id, frm, to, data):
        log.warning("Deploy SM: tests FAILED — deploy blocked")
        emit("DEPLOY_BLOCKED", {"reason": "test_failure"})

    def _deploy_vuln_found(sm_id, frm, to, data):
        log.warning("Deploy SM: vulnerability found — halted")
        emit("SECURITY_ALERT", {"source": "deploy_scan", "sm": sm_id})

    def _deploy_on_live(sm_id, frm, to, data):
        log.info("Deploy SM: service is LIVE")
        emit("DEPLOY_SUCCESS", {"sm_id": sm_id})

    def _deploy_on_rollback(sm_id, frm, to, data):
        log.warning("Deploy SM: initiating rollback")
        emit("DEPLOY_ROLLBACK", {"sm_id": sm_id})

    sm_engine.register_action("_deploy_on_build",    _deploy_on_build)
    sm_engine.register_action("_deploy_on_test_fail", _deploy_on_test_fail)
    sm_engine.register_action("_deploy_vuln_found",  _deploy_vuln_found)
    sm_engine.register_action("_deploy_on_live",     _deploy_on_live)
    sm_engine.register_action("_deploy_on_rollback", _deploy_on_rollback)

    # ── Sensor subscriptions ──────────────────────────────────
    async def on_high_load(event_type: str, data: dict) -> None:
        load = data.get("load", "?")
        log.warning(f"HIGH LOAD: {load} — triggering health check")

    async def on_deploy_success(event_type: str, data: dict) -> None:
        log.info(f"Deploy succeeded: {data}")

    async def on_security_alert(event_type: str, data: dict) -> None:
        log.warning(f"SECURITY ALERT: {data}")

    register_handler("on_high_load",       on_high_load)
    register_handler("on_deploy_success",  on_deploy_success)
    register_handler("on_security_alert",  on_security_alert)

    subscribe("SYSTEM_LOAD_HIGH", handler="on_high_load",      pipe_trigger="system-health")
    subscribe("DEPLOY_SUCCESS",   handler="on_deploy_success")
    subscribe("SECURITY_ALERT",   handler="on_security_alert", pipe_trigger="incident-triage")

    # ── Agent registration ────────────────────────────────────
    try:
        manifest = register(
            agent_id="devsecops-agent",
            name="DevSecOps Agent",
            agent_type=AgentType.LOCAL,
            capabilities=["security", "deploy", "scan", "triage"],
        )

        async def devsecops_handler(agent_id: str, task_id: str, payload: dict) -> str:
            action = payload.get("action", "")
            from cyborg.core.pipeline_engine import pipeline_run
            match action:
                case "scan":
                    await pipeline_run("security-baseline")
                    return "scan_launched"
                case "health":
                    await pipeline_run("system-health")
                    return "health_launched"
                case "triage":
                    await pipeline_run("incident-triage")
                    return "triage_launched"
                case "deploy":
                    from cyborg.core.state_machine import sm_transition
                    sm_transition("deploy_lifecycle", "START")
                    return "deploy_initiated"
                case _:
                    return f"unknown_action:{action}"

        set_handler("devsecops-agent", devsecops_handler)

    except Exception as exc:
        log.debug(f"Agent registration skipped: {exc}")

    log.info("DevSecOps plugin loaded: tasks=7, pipelines=4, agents=1, SMs=1")
