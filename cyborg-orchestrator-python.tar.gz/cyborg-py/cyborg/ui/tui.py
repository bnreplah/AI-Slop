"""
cyborg.ui.tui
~~~~~~~~~~~~~
Full-screen Textual TUI — 9 pages, live-refreshing, keyboard-driven.

Pages: Dashboard · Pipelines · Agents · State Machines · Sensors
       Scheduler · Tasks · Logs · Help
"""
from __future__ import annotations

import asyncio
import json
import os
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from rich.text import Text
from textual import on, work
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Container, Horizontal, Vertical, ScrollableContainer
from textual.reactive import reactive
from textual.screen import ModalScreen
from textual.widget import Widget
from textual.widgets import (
    Button, DataTable, Footer, Header, Input, Label,
    Log, Markdown, RichLog, Static, TabbedContent, TabPane,
)
from textual.widgets import ProgressBar

from cyborg.core.config import (
    ORCH_ROOT, VERSION, SOCKET_PATH, PID_FILE,
    PipelineStatus, AgentStatus, log,
)
import cyborg.core.pipeline_engine as pipeline_engine
import cyborg.core.agent_registry  as agent_registry
import cyborg.core.state_machine   as sm_engine
import cyborg.core.sensor_bus      as sensor_bus
import cyborg.core.scheduler       as scheduler


# ── CSS ───────────────────────────────────────────────────────
CSS = """
Screen {
    background: #0a0a0f;
}

/* ── Header ── */
#app-header {
    dock: top;
    height: 3;
    background: #0d0d1a;
    border-bottom: heavy #00ffff;
    padding: 0 2;
    layout: horizontal;
    align: left middle;
}
#header-title {
    color: #00ffff;
    text-style: bold;
    width: 1fr;
}
#header-status {
    color: #505060;
    width: auto;
}

/* ── Nav tabs ── */
TabbedContent {
    height: 1fr;
}
TabPane {
    padding: 1 2;
}

/* ── DataTable ── */
DataTable {
    height: 1fr;
    background: #0a0a0f;
    border: solid #1a1a2e;
}
DataTable > .datatable--header {
    background: #0d0d1a;
    color: #00ffff;
    text-style: bold;
}
DataTable > .datatable--cursor {
    background: #1a2a3a;
    color: #ffffff;
}
DataTable > .datatable--odd-row {
    background: #0c0c15;
}

/* ── Status badges ── */
.status-running  { color: #00ff82; text-style: bold; }
.status-success  { color: #00ccff; }
.status-failed   { color: #ff3355; text-style: bold; }
.status-aborted  { color: #ffaa00; }
.status-pending  { color: #808090; }
.status-online   { color: #00ff82; }
.status-offline  { color: #505060; }
.status-busy     { color: #ffaa00; text-style: bold; }
.status-error    { color: #ff3355; }

/* ── Panels ── */
.panel-title {
    color: #cc00ff;
    text-style: bold;
    padding: 0 1;
    background: #0d0d1a;
    border-bottom: solid #2a0040;
}
.panel {
    border: solid #1a1a2e;
    padding: 1;
    margin: 0 0 1 0;
}
.kv-label { color: #505070; }
.kv-value { color: #00ff82; text-style: bold; }

/* ── RichLog ── */
RichLog {
    background: #050508;
    border: solid #1a1a2e;
    height: 1fr;
}

/* ── Input prompt ── */
#prompt-input {
    border: heavy #00ffff;
    background: #050510;
    color: #ffffff;
}

/* ── Buttons ── */
Button {
    background: #0d1a2e;
    border: solid #00ffff;
    color: #00ffff;
    margin: 0 1;
}
Button:hover {
    background: #1a2a3a;
}
Button.-primary {
    background: #002244;
    border: solid #00ccff;
    color: #00ccff;
}

/* ── Dashboard stats ── */
.stat-box {
    border: solid #1a2a1a;
    background: #080810;
    padding: 1 2;
    margin: 0 1 1 0;
    min-width: 20;
}
.stat-number {
    color: #00ffff;
    text-style: bold;
}
.stat-label {
    color: #505060;
}

/* ── Help ── */
.help-key {
    color: #ffaa00;
    text-style: bold;
}
.help-desc {
    color: #a0a0b0;
}

/* ── Footer ── */
Footer {
    background: #0d0d1a;
    color: #505060;
}
"""


# ── Helper: coloured status ───────────────────────────────────
def _status_text(status: str) -> Text:
    colours = {
        "RUNNING": ("bright_green", "bold"),
        "SUCCESS": ("cyan", ""),
        "FAILED":  ("#ff3355", "bold"),
        "ABORTED": ("bright_yellow", ""),
        "PENDING": ("dim", ""),
        "ONLINE":  ("bright_green", ""),
        "IDLE":    ("bright_green", ""),
        "OFFLINE": ("dim", ""),
        "BUSY":    ("bright_yellow", "bold"),
        "ERROR":   ("bright_red", "bold"),
    }
    color, style = colours.get(status, ("white", ""))
    t = Text(status)
    t.stylize(f"{style} {color}".strip())
    return t


# ── Input prompt modal ────────────────────────────────────────
class PromptModal(ModalScreen):
    """Generic single-field input modal."""
    CSS = """
    PromptModal {
        align: center middle;
    }
    #prompt-box {
        width: 60;
        height: auto;
        padding: 2;
        background: #0d0d1a;
        border: heavy #00ffff;
    }
    #prompt-label { color: #00ffff; margin-bottom: 1; }
    """
    BINDINGS = [("escape", "dismiss(None)", "Cancel")]

    def __init__(self, title: str, placeholder: str = ""):
        super().__init__()
        self._title = title
        self._placeholder = placeholder

    def compose(self) -> ComposeResult:
        with Container(id="prompt-box"):
            yield Label(self._title, id="prompt-label")
            yield Input(placeholder=self._placeholder, id="prompt-input")
            with Horizontal():
                yield Button("OK",     variant="primary", id="ok-btn")
                yield Button("Cancel", id="cancel-btn")

    @on(Button.Pressed, "#ok-btn")
    def _ok(self) -> None:
        self.dismiss(self.query_one(Input).value)

    @on(Button.Pressed, "#cancel-btn")
    def _cancel(self) -> None:
        self.dismiss(None)

    @on(Input.Submitted)
    def _submitted(self, event: Input.Submitted) -> None:
        self.dismiss(event.value)


# ── Dashboard page ────────────────────────────────────────────
class DashboardPage(Widget):
    DEFAULT_CSS = "DashboardPage { height: 1fr; }"

    def compose(self) -> ComposeResult:
        with Horizontal():
            with Vertical(id="stats-col"):
                yield Static("◈ SYSTEM STATS", classes="panel-title")
                yield Static("", id="stat-pipes",   classes="stat-box")
                yield Static("", id="stat-agents",  classes="stat-box")
                yield Static("", id="stat-scheds",  classes="stat-box")
                yield Static("", id="stat-load",    classes="stat-box")
                yield Static("", id="stat-uptime",  classes="stat-box")
            with Vertical(id="events-col"):
                yield Static("◈ RECENT EVENTS", classes="panel-title")
                yield RichLog(id="events-log", highlight=True, markup=True)

    def on_mount(self) -> None:
        self.set_interval(2.0, self.refresh_stats)

    def refresh_stats(self) -> None:
        try:
            pipes = pipeline_engine.pipeline_count_active()
            agents = agent_registry.count()
            scheds = scheduler.count()

            load = "N/A"
            if Path("/proc/loadavg").exists():
                load = " ".join(Path("/proc/loadavg").read_text().split()[:3])

            uptime_s = int(time.time()) - _app_start
            uptime = f"{uptime_s // 3600}h {(uptime_s % 3600) // 60}m {uptime_s % 60}s"

            self.query_one("#stat-pipes",  Static).update(
                f"[dim]Pipelines Active[/]\n[bold cyan]{pipes}[/]")
            self.query_one("#stat-agents", Static).update(
                f"[dim]Agents Online[/]\n[bold cyan]{agents}[/]")
            self.query_one("#stat-scheds", Static).update(
                f"[dim]Schedules[/]\n[bold cyan]{scheds}[/]")
            self.query_one("#stat-load",   Static).update(
                f"[dim]Load Average[/]\n[bold green]{load}[/]")
            self.query_one("#stat-uptime", Static).update(
                f"[dim]TUI Uptime[/]\n[bold green]{uptime}[/]")

            # Event log
            elog = self.query_one("#events-log", RichLog)
            for evt in sensor_bus.recent_events(5):
                ts = evt.emitted_at.strftime("%H:%M:%S")
                elog.write(
                    f"[dim]{ts}[/]  [yellow]{evt.event_type:<28}[/]  "
                    f"[dim]{str(evt.data)[:60]}[/]"
                )
        except Exception:
            pass


# ── Pipelines page ────────────────────────────────────────────
class PipelinesPage(Widget):
    DEFAULT_CSS = "PipelinesPage { height: 1fr; }"

    def compose(self) -> ComposeResult:
        yield Static("◈ PIPELINE MANAGER", classes="panel-title")
        yield DataTable(id="pipes-table", cursor_type="row")
        with Horizontal():
            yield Button("▶ Run",    id="btn-run",  classes="-primary")
            yield Button("✕ Kill",   id="btn-kill")
            yield Button("📋 Logs",  id="btn-logs")
            yield Button("⟳ Refresh", id="btn-refresh")

    def on_mount(self) -> None:
        t = self.query_one(DataTable)
        t.add_columns("RUN ID", "STATUS", "NAME", "DURATION", "LOG (tail)")
        self.set_interval(3.0, self._refresh)

    def _refresh(self) -> None:
        t = self.query_one(DataTable)
        t.clear()
        for run in sorted(pipeline_engine.pipeline_list_all(),
                          key=lambda r: r.run_id, reverse=True)[:50]:
            dur = f"{run.duration:.1f}s" if run.duration else "-"
            tail = run.log_lines[-1][9:] if run.log_lines else "-"
            t.add_row(
                run.run_id[:36],
                _status_text(run.status.value),
                run.name[:24],
                dur,
                tail[:40],
                key=run.run_id,
            )

    @on(Button.Pressed, "#btn-run")
    async def _run(self) -> None:
        val = await self.app.push_screen_wait(
            PromptModal("Run Pipeline", placeholder="pipeline_name or inline:name:cmd:30")
        )
        if val:
            await pipeline_engine.pipeline_run(val)
            self.app.notify(f"Pipeline started: {val}", severity="information")
            self._refresh()

    @on(Button.Pressed, "#btn-kill")
    async def _kill(self) -> None:
        t = self.query_one(DataTable)
        if t.cursor_row is None:
            return
        row = t.get_row_at(t.cursor_row)
        run_id = str(row[0])
        pipeline_engine.pipeline_kill(run_id)
        self.app.notify(f"Killed: {run_id}", severity="warning")
        self._refresh()

    @on(Button.Pressed, "#btn-logs")
    async def _show_logs(self) -> None:
        t = self.query_one(DataTable)
        if t.cursor_row is None:
            return
        row = t.get_row_at(t.cursor_row)
        run = pipeline_engine.pipeline_get(str(row[0]))
        if run:
            await self.app.push_screen(
                _LogViewModal(run.run_id, "\n".join(run.log_lines))
            )

    @on(Button.Pressed, "#btn-refresh")
    def _do_refresh(self) -> None:
        self._refresh()


class _LogViewModal(ModalScreen):
    BINDINGS = [("escape", "dismiss", "Close"), ("q", "dismiss", "Close")]
    CSS = """
    _LogViewModal { align: center middle; }
    #log-box { width: 90%; height: 80%; background: #050508; border: heavy #00ffff; padding: 1; }
    """
    def __init__(self, title: str, content: str):
        super().__init__()
        self._title = title
        self._content = content

    def compose(self) -> ComposeResult:
        with ScrollableContainer(id="log-box"):
            yield Static(f"[bold cyan]{self._title}[/]")
            yield Static("[dim]─[/]" * 40)
            yield Static(self._content or "[dim]No output[/]")


# ── Agents page ───────────────────────────────────────────────
class AgentsPage(Widget):
    DEFAULT_CSS = "AgentsPage { height: 1fr; }"

    def compose(self) -> ComposeResult:
        yield Static("◈ AGENT REGISTRY", classes="panel-title")
        yield DataTable(id="agents-table", cursor_type="row")
        with Horizontal():
            yield Button("+ Register", id="btn-reg",     classes="-primary")
            yield Button("⊞ Spawn",    id="btn-spawn")
            yield Button("→ Delegate", id="btn-delegate")
            yield Button("⟳ Refresh",  id="btn-refresh")

    def on_mount(self) -> None:
        t = self.query_one(DataTable)
        t.add_columns("AGENT ID", "NAME", "TYPE", "STATUS", "SM STATE", "CAPABILITIES")
        self.set_interval(3.0, self._refresh)

    def _refresh(self) -> None:
        t = self.query_one(DataTable)
        t.clear()
        for m in agent_registry.get_all():
            sm_state = sm_engine.sm_get_state(f"agent_{m.agent_id}")
            t.add_row(
                m.agent_id[:20],
                m.name[:18],
                m.agent_type.value,
                _status_text(m.status.value),
                sm_state,
                ", ".join(m.capabilities)[:30],
                key=m.agent_id,
            )

    @on(Button.Pressed, "#btn-reg")
    async def _register(self) -> None:
        val = await self.app.push_screen_wait(
            PromptModal("Register Agent",
                        "agent_id|name|type|cap1,cap2")
        )
        if val:
            from cyborg.core.config import AgentType
            parts = [p.strip() for p in val.split("|")]
            if len(parts) >= 3:
                agent_registry.register(
                    parts[0], parts[1] if len(parts) > 1 else parts[0],
                    AgentType(parts[2]) if len(parts) > 2 else AgentType.LOCAL,
                    parts[3].split(",") if len(parts) > 3 else [],
                )
                self.app.notify(f"Agent registered: {parts[0]}")
                self._refresh()

    @on(Button.Pressed, "#btn-spawn")
    async def _spawn(self) -> None:
        val = await self.app.push_screen_wait(
            PromptModal("Spawn Nested Orchestrator", "nested_id")
        )
        if val:
            agent_registry.spawn_nested(val)
            self.app.notify(f"Nested orchestrator spawned: {val}")
            self._refresh()

    @on(Button.Pressed, "#btn-delegate")
    async def _delegate(self) -> None:
        t = self.query_one(DataTable)
        if t.cursor_row is None:
            return
        row = t.get_row_at(t.cursor_row)
        agent_id = str(row[0])
        val = await self.app.push_screen_wait(
            PromptModal("Delegate Task (JSON payload)", '{"action":"scan"}')
        )
        if val:
            try:
                payload = json.loads(val)
            except json.JSONDecodeError:
                payload = {"raw": val}
            task_id = await agent_registry.delegate(agent_id, payload)
            self.app.notify(f"Task {task_id} delegated to {agent_id}")

    @on(Button.Pressed, "#btn-refresh")
    def _do_refresh(self) -> None:
        self._refresh()


# ── State Machines page ───────────────────────────────────────
class StateMachinesPage(Widget):
    DEFAULT_CSS = "StateMachinesPage { height: 1fr; }"

    def compose(self) -> ComposeResult:
        yield Static("◈ STATE MACHINES", classes="panel-title")
        yield DataTable(id="sm-table", cursor_type="row")
        with Horizontal():
            yield Button("+ Create",    id="btn-create", classes="-primary")
            yield Button("→ Transition", id="btn-trans")
            yield Button("📋 Describe", id="btn-desc")
            yield Button("📜 History",  id="btn-hist")

    def on_mount(self) -> None:
        t = self.query_one(DataTable)
        t.add_columns("SM ID", "CURRENT STATE", "PARENT", "CHILDREN", "STATES")
        self.set_interval(3.0, self._refresh)

    def _refresh(self) -> None:
        t = self.query_one(DataTable)
        t.clear()
        for spec in sm_engine.sm_list():
            children = len(spec.children)
            t.add_row(
                spec.sm_id[:28],
                _status_text(spec.current_state),
                spec.parent_id or "-",
                str(children),
                ", ".join(spec.states)[:30],
                key=spec.sm_id,
            )

    @on(Button.Pressed, "#btn-trans")
    async def _transition(self) -> None:
        t = self.query_one(DataTable)
        if t.cursor_row is None:
            return
        row = t.get_row_at(t.cursor_row)
        sm_id = str(row[0])
        val = await self.app.push_screen_wait(
            PromptModal(f"Transition SM: {sm_id}", "EVENT_NAME")
        )
        if val:
            new_state = sm_engine.sm_transition(sm_id, val)
            if new_state:
                self.app.notify(f"SM {sm_id}: → {new_state}")
            else:
                self.app.notify(f"No transition for event '{val}'", severity="warning")
            self._refresh()

    @on(Button.Pressed, "#btn-desc")
    async def _describe(self) -> None:
        t = self.query_one(DataTable)
        if t.cursor_row is None:
            return
        row = t.get_row_at(t.cursor_row)
        sm_id = str(row[0])
        desc = sm_engine.sm_describe(sm_id)
        content = json.dumps(desc, indent=2)
        await self.app.push_screen(_LogViewModal(f"SM: {sm_id}", content))

    @on(Button.Pressed, "#btn-hist")
    async def _history(self) -> None:
        t = self.query_one(DataTable)
        if t.cursor_row is None:
            return
        row = t.get_row_at(t.cursor_row)
        sm_id = str(row[0])
        hist = sm_engine.sm_history(sm_id, 30)
        lines = [f"{h.get('ts','')} {h.get('from','?')} --[{h.get('event','?')}]--> {h.get('to','?')}"
                 for h in hist]
        await self.app.push_screen(_LogViewModal(f"History: {sm_id}", "\n".join(lines)))

    @on(Button.Pressed, "#btn-create")
    async def _create(self) -> None:
        val = await self.app.push_screen_wait(
            PromptModal("Create SM", "sm_id|initial_state|state1,state2")
        )
        if val:
            parts = val.split("|")
            sm_id = parts[0].strip()
            initial = parts[1].strip() if len(parts) > 1 else "IDLE"
            states = [s.strip() for s in parts[2].split(",")] if len(parts) > 2 else [initial]
            sm_engine.sm_create(sm_id, initial, [initial] + states)
            self.app.notify(f"SM created: {sm_id}")
            self._refresh()


# ── Sensors page ──────────────────────────────────────────────
class SensorsPage(Widget):
    DEFAULT_CSS = "SensorsPage { height: 1fr; layout: vertical; }"

    def compose(self) -> ComposeResult:
        with Vertical():
            yield Static("◈ SUBSCRIPTIONS", classes="panel-title")
            yield DataTable(id="subs-table")
            yield Static("◈ RECENT EVENTS", classes="panel-title")
            yield RichLog(id="sensor-log", highlight=True, markup=True, max_lines=100)
            with Horizontal():
                yield Button("+ Subscribe", id="btn-sub", classes="-primary")
                yield Button("⚡ Emit",     id="btn-emit")
                yield Button("👁 Watch File", id="btn-watch")

    def on_mount(self) -> None:
        t = self.query_one(DataTable)
        t.add_columns("SUB ID", "PATTERN", "HANDLER", "SM TRIGGER", "PIPE TRIGGER")
        self.set_interval(2.0, self._refresh)

    def _refresh(self) -> None:
        t = self.query_one(DataTable)
        t.clear()
        for sub in sensor_bus.list_subscriptions():
            t.add_row(sub.sub_id, sub.pattern, sub.handler or "-",
                      sub.sm_trigger or "-", sub.pipe_trigger or "-")
        log_w = self.query_one("#sensor-log", RichLog)
        for evt in sensor_bus.recent_events(20):
            ts = evt.emitted_at.strftime("%H:%M:%S")
            log_w.write(
                f"[dim]{ts}[/] [yellow]{evt.event_type:<28}[/] [dim]{str(evt.data)[:60]}[/]"
            )

    @on(Button.Pressed, "#btn-emit")
    async def _emit(self) -> None:
        val = await self.app.push_screen_wait(
            PromptModal("Emit Sensor Event", "EVENT_TYPE|{optional_json}")
        )
        if val:
            parts = val.split("|", 1)
            etype = parts[0].strip()
            data: dict = {}
            if len(parts) > 1:
                try:
                    data = json.loads(parts[1])
                except json.JSONDecodeError:
                    data = {"raw": parts[1]}
            sensor_bus.emit(etype, data)
            self.app.notify(f"Emitted: {etype}")

    @on(Button.Pressed, "#btn-sub")
    async def _subscribe(self) -> None:
        val = await self.app.push_screen_wait(
            PromptModal("Subscribe", "PATTERN|handler_name|sm_id:EVENT|pipeline_name")
        )
        if val:
            parts = [p.strip() for p in val.split("|")]
            sid = sensor_bus.subscribe(
                pattern=parts[0],
                handler=parts[1] if len(parts) > 1 and parts[1] else None,
                sm_trigger=parts[2] if len(parts) > 2 else "",
                pipe_trigger=parts[3] if len(parts) > 3 else "",
            )
            self.app.notify(f"Subscribed: {sid}")
            self._refresh()

    @on(Button.Pressed, "#btn-watch")
    async def _watch(self) -> None:
        val = await self.app.push_screen_wait(
            PromptModal("Watch File", "/path/to/file|EMIT_EVENT")
        )
        if val:
            parts = val.split("|", 1)
            path = parts[0].strip()
            event = parts[1].strip() if len(parts) > 1 else "FILE_CHANGED"
            await sensor_bus.watch_file(path, event)
            self.app.notify(f"Watching: {path} → {event}")


# ── Scheduler page ────────────────────────────────────────────
class SchedulerPage(Widget):
    DEFAULT_CSS = "SchedulerPage { height: 1fr; }"

    def compose(self) -> ComposeResult:
        yield Static("◈ TASK SCHEDULER", classes="panel-title")
        yield DataTable(id="sched-table", cursor_type="row")
        with Horizontal():
            yield Button("+ Cron",    id="btn-cron",     classes="-primary")
            yield Button("+ At",      id="btn-at")
            yield Button("+ In Nsec", id="btn-in")
            yield Button("✓ Enable",  id="btn-enable")
            yield Button("✗ Disable", id="btn-disable")
            yield Button("🗑 Remove",  id="btn-remove")

    def on_mount(self) -> None:
        t = self.query_one(DataTable)
        t.add_columns("ID", "TYPE", "SPEC / WHEN", "TARGET", "LAST RUN", "ENABLED")
        self.set_interval(5.0, self._refresh)

    def _refresh(self) -> None:
        t = self.query_one(DataTable)
        t.clear()
        for e in scheduler.list_all():
            spec = e.spec
            if e.sched_type.value == "at":
                try:
                    spec = datetime.fromtimestamp(int(e.spec)).strftime("%Y-%m-%d %H:%M")
                except Exception:
                    pass
            last = e.last_run.strftime("%H:%M:%S") if e.last_run else "-"
            en = Text("YES", style="green") if e.enabled else Text("no", style="dim")
            t.add_row(e.sched_id[:16], e.sched_type.value, spec[:22],
                      e.target[:20], last, en, key=e.sched_id)

    def _selected_id(self) -> Optional[str]:
        t = self.query_one(DataTable)
        if t.cursor_row is None:
            return None
        return str(t.get_row_at(t.cursor_row)[0])

    @on(Button.Pressed, "#btn-cron")
    async def _add_cron(self) -> None:
        val = await self.app.push_screen_wait(
            PromptModal("Add Cron Schedule", "*/5 * * * *|pipeline_name")
        )
        if val:
            parts = val.split("|", 1)
            sid = scheduler.add_cron(parts[0].strip(), parts[1].strip() if len(parts) > 1 else "")
            self.app.notify(f"Cron added: {sid}")
            self._refresh()

    @on(Button.Pressed, "#btn-at")
    async def _add_at(self) -> None:
        val = await self.app.push_screen_wait(
            PromptModal("At-time Schedule", "2025-12-01T14:00:00|pipeline_name")
        )
        if val:
            parts = val.split("|", 1)
            try:
                dt = datetime.fromisoformat(parts[0].strip())
                sid = scheduler.add_at(dt, parts[1].strip() if len(parts) > 1 else "")
                self.app.notify(f"At-schedule added: {sid}")
                self._refresh()
            except ValueError as exc:
                self.app.notify(f"Bad datetime: {exc}", severity="error")

    @on(Button.Pressed, "#btn-in")
    async def _add_in(self) -> None:
        val = await self.app.push_screen_wait(
            PromptModal("Run In N Seconds", "300|pipeline_name")
        )
        if val:
            parts = val.split("|", 1)
            sid = scheduler.add_countdown(
                int(parts[0].strip()),
                parts[1].strip() if len(parts) > 1 else "",
            )
            self.app.notify(f"Countdown added: {sid}")
            self._refresh()

    @on(Button.Pressed, "#btn-enable")
    def _enable(self) -> None:
        sid = self._selected_id()
        if sid:
            scheduler.enable(sid)
            self._refresh()

    @on(Button.Pressed, "#btn-disable")
    def _disable(self) -> None:
        sid = self._selected_id()
        if sid:
            scheduler.disable(sid)
            self._refresh()

    @on(Button.Pressed, "#btn-remove")
    def _remove(self) -> None:
        sid = self._selected_id()
        if sid:
            scheduler.remove(sid)
            self.app.notify(f"Removed: {sid}")
            self._refresh()


# ── Tasks page ────────────────────────────────────────────────
class TasksPage(Widget):
    DEFAULT_CSS = "TasksPage { height: 1fr; }"

    def compose(self) -> ComposeResult:
        yield Static("◈ TASK ALIASES", classes="panel-title")
        yield DataTable(id="tasks-table", cursor_type="row")
        with Horizontal():
            yield Button("+ Add",  id="btn-add",  classes="-primary")
            yield Button("▶ Run",  id="btn-run")

    def on_mount(self) -> None:
        t = self.query_one(DataTable)
        t.add_columns("TASK NAME", "COMMAND TEMPLATE")
        self._refresh()

    def _refresh(self) -> None:
        t = self.query_one(DataTable)
        t.clear()
        for name, cmd in pipeline_engine.task_list().items():
            t.add_row(name, cmd[:70], key=name)

    @on(Button.Pressed, "#btn-add")
    async def _add(self) -> None:
        val = await self.app.push_screen_wait(
            PromptModal("Register Task Alias", "task_name|command {0} {1}")
        )
        if val:
            parts = val.split("|", 1)
            if len(parts) == 2:
                pipeline_engine.task_register(parts[0].strip(), parts[1].strip())
                self.app.notify(f"Task registered: {parts[0].strip()}")
                self._refresh()

    @on(Button.Pressed, "#btn-run")
    async def _run(self) -> None:
        t = self.query_one(DataTable)
        if t.cursor_row is None:
            return
        name = str(t.get_row_at(t.cursor_row)[0])
        val = await self.app.push_screen_wait(
            PromptModal(f"Run task: {name}", "arg1 arg2 ...")
        )
        args = val.split() if val else []
        await pipeline_engine.task_run(name, args)
        self.app.notify(f"Task started: {name}")


# ── Logs page ─────────────────────────────────────────────────
class LogsPage(Widget):
    DEFAULT_CSS = "LogsPage { height: 1fr; }"

    def compose(self) -> ComposeResult:
        yield Static("◈ ORCHESTRATOR LOGS", classes="panel-title")
        yield RichLog(id="main-log", highlight=True, markup=True, max_lines=500)
        with Horizontal():
            yield Button("⟳ Refresh", id="btn-refresh")
            yield Button("🗑 Clear",   id="btn-clear")

    def on_mount(self) -> None:
        self._load()
        self.set_interval(3.0, self._load)

    def _load(self) -> None:
        from cyborg.core.config import LOG_FILE
        log_w = self.query_one(RichLog)
        if LOG_FILE.exists():
            lines = LOG_FILE.read_text().splitlines()[-80:]
            log_w.clear()
            for line in lines:
                color = "dim"
                if "[ERROR]" in line:    color = "bright_red"
                elif "[WARNING]" in line: color = "bright_yellow"
                elif "[INFO]" in line:    color = "cyan"
                log_w.write(f"[{color}]{line}[/]")

    @on(Button.Pressed, "#btn-refresh")
    def _refresh(self) -> None:
        self._load()

    @on(Button.Pressed, "#btn-clear")
    def _clear(self) -> None:
        from cyborg.core.config import LOG_FILE
        LOG_FILE.write_text("")
        self.query_one(RichLog).clear()
        self.app.notify("Logs cleared")


# ── Help page ─────────────────────────────────────────────────
class HelpPage(Widget):
    DEFAULT_CSS = "HelpPage { height: 1fr; overflow-y: auto; padding: 1 2; }"

    HELP_MD = """
# CYBORG Orchestrator — Help

## Navigation
| Key | Action |
|-----|--------|
| Tab / Shift+Tab | Next / previous page |
| Numbers 1–9 | Jump to page directly |
| q | Quit TUI (daemon continues) |
| Ctrl+C | Force quit |

## Pages
| Page | Description |
|------|-------------|
| **Dashboard** | Live system stats + event stream |
| **Pipelines** | Run, kill, inspect pipeline runs |
| **Agents** | Register, delegate, spawn nested orchestrators |
| **State Machines** | Create, transition, view SM history |
| **Sensors** | Subscribe to events, emit custom events, watch files |
| **Scheduler** | Cron/at/countdown schedules |
| **Tasks** | Register and run task aliases |
| **Logs** | Orchestrator log tail |

## IPC (CLI / Scripts)
```bash
cyborg pipeline run <name>
cyborg sm transition <sm_id> <event>
cyborg agent delegate <id> '{"action":"scan"}'
cyborg sensor emit MY_EVENT '{"key":"val"}'
cyborg schedule add "*/5 * * * *" my_pipeline
cyborg daemon status
```

## Pipeline Spec Format
```
step_name:command:timeout_sec:retry_count[:parallel_group]
```
Steps separated by `;`. Same parallel_group → concurrent execution.

## Plugin Format
Drop a `*.plugin.py` file in `~/.cyborg/plugins/` with a `setup()` function.

## Nested Orchestrators
Each agent can host a full child orchestrator with its own socket,
pipelines, SMs, and agents — fully independently operable.
    """

    def compose(self) -> ComposeResult:
        yield Markdown(self.HELP_MD)


# ── Main App ──────────────────────────────────────────────────
_app_start = int(time.time())


class CyborgApp(App):
    """CYBORG Orchestrator TUI."""
    CSS = CSS
    TITLE = f"CYBORG Orchestrator v{VERSION}"
    SUB_TITLE = "Distributed Agentic Terminal Orchestration Engine"
    BINDINGS = [
        Binding("q",          "quit",                   "Quit"),
        Binding("ctrl+c",     "quit",                   "Quit", show=False),
        Binding("r",          "run_pipeline",            "Run Pipeline"),
        Binding("e",          "emit_event",              "Emit Event"),
        Binding("d",          "daemon_status",           "Daemon Status"),
    ]

    def compose(self) -> ComposeResult:
        yield Header(show_clock=True)
        with TabbedContent(
            "Dashboard", "Pipelines", "Agents", "State Machines",
            "Sensors", "Scheduler", "Tasks", "Logs", "Help",
            id="main-tabs",
        ):
            yield TabPane("Dashboard",      DashboardPage(),      id="tab-dash")
            yield TabPane("Pipelines",      PipelinesPage(),      id="tab-pipes")
            yield TabPane("Agents",         AgentsPage(),         id="tab-agents")
            yield TabPane("State Machines", StateMachinesPage(),  id="tab-sm")
            yield TabPane("Sensors",        SensorsPage(),        id="tab-sensors")
            yield TabPane("Scheduler",      SchedulerPage(),      id="tab-sched")
            yield TabPane("Tasks",          TasksPage(),          id="tab-tasks")
            yield TabPane("Logs",           LogsPage(),           id="tab-logs")
            yield TabPane("Help",           HelpPage(),           id="tab-help")
        yield Footer()

    async def action_run_pipeline(self) -> None:
        val = await self.push_screen_wait(
            PromptModal("Run Pipeline", "pipeline_name")
        )
        if val:
            run = await pipeline_engine.pipeline_run(val)
            if run:
                self.notify(f"Pipeline started: {run.run_id}", severity="information")
            else:
                self.notify(f"Pipeline not found: {val}", severity="error")

    async def action_emit_event(self) -> None:
        val = await self.push_screen_wait(
            PromptModal("Emit Sensor Event", "EVENT_TYPE|{json}")
        )
        if val:
            parts = val.split("|", 1)
            data = {}
            if len(parts) > 1:
                try:
                    data = json.loads(parts[1])
                except Exception:
                    data = {"raw": parts[1]}
            sensor_bus.emit(parts[0].strip(), data)
            self.notify(f"Emitted: {parts[0].strip()}")

    async def action_daemon_status(self) -> None:
        from cyborg.ipc import send_command
        result = await send_command({"cmd": "STATUS"})
        if result:
            content = json.dumps(result.get("data", result), indent=2)
            await self.push_screen(_LogViewModal("Daemon Status", content))
        else:
            self.notify("Daemon not reachable", severity="warning")


def run_tui() -> None:
    """Launch the TUI (boots in-process engines if daemon not running)."""
    from cyborg.core.config import ensure_dirs
    ensure_dirs()

    # Boot engines in-process for standalone TUI mode
    from cyborg.core import pipeline_engine as pe, sensor_bus as sb
    pipeline_engine.pipeline_load_saved()
    scheduler.load_saved()
    agent_registry.init()

    app = CyborgApp()
    app.run()
