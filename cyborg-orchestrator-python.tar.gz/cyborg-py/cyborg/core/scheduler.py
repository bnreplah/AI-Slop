"""
cyborg.core.scheduler
~~~~~~~~~~~~~~~~~~~~~
Async cron-compatible scheduler supporting:
  - Cron expressions (5-field: min hour dom mon dow)
  - One-shot at-time execution
  - Countdown (run in N seconds)
  - Enable/disable per schedule
  - Persistence to config/schedules.conf
"""
from __future__ import annotations

import asyncio
import json
import time
import uuid
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from cyborg.core.config import (
    ORCH_ROOT, ScheduleEntry, ScheduleType, log, new_id, now_iso,
)

# ── Registry ──────────────────────────────────────────────────
_schedules:     dict[str, ScheduleEntry] = {}
_last_run_min:  dict[str, int] = {}  # sched_id -> last minute fired (epoch // 60)
_pipeline_run_fn = None   # set at boot


def set_pipeline_run_fn(fn) -> None:
    global _pipeline_run_fn
    _pipeline_run_fn = fn


# ── Persistence ───────────────────────────────────────────────
_cfg = ORCH_ROOT / "config" / "schedules.conf"


def _save_all() -> None:
    lines = []
    for entry in _schedules.values():
        d = asdict(entry)
        d["last_run"] = d["last_run"].isoformat() if d["last_run"] else ""
        lines.append(json.dumps(d))
    _cfg.write_text("\n".join(lines) + "\n" if lines else "")


def load_saved() -> None:
    if not _cfg.exists():
        return
    for line in _cfg.read_text().splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            raw = json.loads(line)
            raw["sched_type"] = ScheduleType(raw["sched_type"])
            raw["last_run"] = (datetime.fromisoformat(raw["last_run"])
                               if raw.get("last_run") else None)
            entry = ScheduleEntry(**raw)
            _schedules[entry.sched_id] = entry
            log.info(f"Restored schedule: {entry.sched_id} | {entry.spec} -> {entry.target}")
        except Exception as exc:
            log.warning(f"Could not restore schedule: {exc}")


# ── Public API ────────────────────────────────────────────────
def add_cron(cron_spec: str, target: str, args: str = "") -> str:
    """Add a cron-scheduled pipeline. Returns schedule ID."""
    sid = f"sched_{new_id()[:8]}"
    entry = ScheduleEntry(
        sched_id=sid,
        sched_type=ScheduleType.CRON,
        spec=cron_spec,
        target=target,
        args=args,
    )
    _schedules[sid] = entry
    _save_all()
    log.info(f"Schedule added: {sid} | {cron_spec} -> {target}")
    return sid


def add_at(run_at: datetime, target: str, args: str = "") -> str:
    """Run target once at a specific datetime."""
    sid = f"at_{new_id()[:8]}"
    entry = ScheduleEntry(
        sched_id=sid,
        sched_type=ScheduleType.AT,
        spec=str(int(run_at.timestamp())),
        target=target,
        args=args,
    )
    _schedules[sid] = entry
    _save_all()
    log.info(f"At-schedule added: {sid} at {run_at.isoformat()} -> {target}")
    return sid


def add_countdown(seconds: int, target: str, args: str = "") -> str:
    """Run target once after `seconds` seconds."""
    run_at = int(time.time()) + seconds
    sid = f"cd_{new_id()[:8]}"
    entry = ScheduleEntry(
        sched_id=sid,
        sched_type=ScheduleType.AT,
        spec=str(run_at),
        target=target,
        args=args,
    )
    _schedules[sid] = entry
    _save_all()
    log.info(f"Countdown schedule: {sid} in {seconds}s -> {target}")
    return sid


def remove(sched_id: str) -> bool:
    if sched_id not in _schedules:
        return False
    _schedules.pop(sched_id)
    _save_all()
    return True


def enable(sched_id: str) -> None:
    if sched_id in _schedules:
        _schedules[sched_id].enabled = True
        _save_all()


def disable(sched_id: str) -> None:
    if sched_id in _schedules:
        _schedules[sched_id].enabled = False
        _save_all()


def list_all() -> list[ScheduleEntry]:
    return list(_schedules.values())


def count() -> int:
    return len(_schedules)


# ── Cron evaluation ───────────────────────────────────────────
def _cron_matches(spec: str) -> bool:
    """Return True if the current time matches a 5-field cron expression."""
    fields = spec.strip().split()
    if len(fields) != 5:
        return False
    try:
        now = datetime.now()
        checks = [
            (fields[0], now.minute,   0,  59),
            (fields[1], now.hour,     0,  23),
            (fields[2], now.day,      1,  31),
            (fields[3], now.month,    1,  12),
            (fields[4], now.isoweekday() % 7, 0, 6),  # 0=Sun
        ]
        return all(_field_matches(f, v, lo, hi) for f, v, lo, hi in checks)
    except Exception:
        return False


def _field_matches(spec: str, val: int, lo: int, hi: int) -> bool:
    if spec == "*":
        return True
    for part in spec.split(","):
        # Step: */5 or 0-30/5
        if "/" in part:
            base, step_str = part.split("/", 1)
            step = int(step_str)
            if base == "*":
                if (val - lo) % step == 0:
                    return True
            elif "-" in base:
                start, end = (int(x) for x in base.split("-"))
                if start <= val <= end and (val - start) % step == 0:
                    return True
        # Range: 1-5
        elif "-" in part:
            start, end = (int(x) for x in part.split("-"))
            if start <= val <= end:
                return True
        # Exact
        elif int(part) == val:
            return True
    return False


# ── Async tick loop ───────────────────────────────────────────
async def tick_loop() -> None:
    """Run continuously, firing schedules as they come due."""
    log.info("Scheduler tick loop started")
    while True:
        now_epoch = int(time.time())
        now_minute = now_epoch // 60

        for sched_id, entry in list(_schedules.items()):
            if not entry.enabled:
                continue

            try:
                if entry.sched_type == ScheduleType.CRON:
                    last = _last_run_min.get(sched_id, 0)
                    if now_minute > last and _cron_matches(entry.spec):
                        _last_run_min[sched_id] = now_minute
                        log.info(f"Scheduler: firing {sched_id} | {entry.spec} -> {entry.target}")
                        await _fire(entry)

                elif entry.sched_type == ScheduleType.AT:
                    run_at = int(entry.spec)
                    if now_epoch >= run_at:
                        log.info(f"Scheduler: at-time firing {sched_id} -> {entry.target}")
                        entry.enabled = False  # one-shot
                        entry.last_run = datetime.now(timezone.utc)
                        _save_all()
                        await _fire(entry)

            except Exception as exc:
                log.error(f"Scheduler tick error for {sched_id}: {exc}")

        await asyncio.sleep(1)


async def _fire(entry: ScheduleEntry) -> None:
    entry.last_run = datetime.now(timezone.utc)
    if _pipeline_run_fn:
        extra_env = {}
        if entry.args:
            extra_env["SCHED_ARGS"] = entry.args
        await _pipeline_run_fn(entry.target, extra_env)
    else:
        log.warning(f"Scheduler: no pipeline_run_fn set; cannot fire {entry.target}")
