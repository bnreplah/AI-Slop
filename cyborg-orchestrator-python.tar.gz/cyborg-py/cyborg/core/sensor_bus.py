"""
cyborg.core.sensor_bus
~~~~~~~~~~~~~~~~~~~~~~~
Async event bus with:
  - Pub/sub subscriptions (fnmatch pattern matching)
  - File-system watchers (via watchdog)
  - Process up/down watchers
  - TCP port open/close watchers
  - System metric polling (load, disk)
  - Webhook receiver (asyncio HTTP)
  - SM transition and pipeline launch hooks on event
"""
from __future__ import annotations

import asyncio
import fnmatch
import json
import os
import time
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Optional

from cyborg.core.config import (
    ORCH_ROOT, SENSOR_LOAD_THRESHOLD, SENSOR_DISK_THRESHOLD,
    Subscription, SensorEvent, log, new_id, now_iso,
)


# ── Registry ──────────────────────────────────────────────────
_subscriptions: dict[str, Subscription] = {}
_handler_registry: dict[str, Callable] = {}   # name -> async callable
_event_history: list[SensorEvent] = []
_watcher_tasks: list[asyncio.Task] = []
_active = False

# Cross-engine references (set at startup to avoid circular imports)
_sm_transition_fn: Optional[Callable] = None
_pipeline_run_fn:  Optional[Callable] = None


def set_sm_transition_fn(fn: Callable) -> None:
    global _sm_transition_fn
    _sm_transition_fn = fn


def set_pipeline_run_fn(fn: Callable) -> None:
    global _pipeline_run_fn
    _pipeline_run_fn = fn


def register_handler(name: str, fn: Callable) -> None:
    """Register a named async event handler for subscriptions to reference."""
    _handler_registry[name] = fn


# ── Emit ──────────────────────────────────────────────────────
def emit(event_type: str, data: Optional[dict] = None) -> None:
    """
    Emit an event. Synchronous entry point — schedules async dispatch
    if an event loop is running, otherwise does a best-effort sync dispatch.
    """
    event = SensorEvent(
        event_id=new_id(),
        event_type=event_type,
        data=data or {},
        emitted_at=datetime.now(timezone.utc),
    )
    _event_history.append(event)
    if len(_event_history) > 500:
        _event_history.pop(0)

    log.debug(f"Sensor emit: {event_type} | {str(data)[:80]}")

    try:
        loop = asyncio.get_running_loop()
        loop.create_task(_dispatch(event))
    except RuntimeError:
        # No running loop — fire-and-forget in a new loop (CLI context)
        pass


async def emit_async(event_type: str, data: Optional[dict] = None) -> None:
    event = SensorEvent(
        event_id=new_id(),
        event_type=event_type,
        data=data or {},
        emitted_at=datetime.now(timezone.utc),
    )
    _event_history.append(event)
    if len(_event_history) > 500:
        _event_history.pop(0)
    await _dispatch(event)


async def _dispatch(event: SensorEvent) -> None:
    for sub in list(_subscriptions.values()):
        if not fnmatch.fnmatch(event.event_type, sub.pattern):
            continue

        # Optional key=val filter on event data
        if sub.filter_key:
            actual = event.data.get(sub.filter_key)
            if str(actual) != sub.filter_val:
                continue

        # Named handler
        if sub.handler and sub.handler in _handler_registry:
            fn = _handler_registry[sub.handler]
            try:
                if asyncio.iscoroutinefunction(fn):
                    asyncio.create_task(fn(event.event_type, event.data))
                else:
                    fn(event.event_type, event.data)
            except Exception as exc:
                log.warning(f"Sensor handler '{sub.handler}' error: {exc}")

        # SM state machine trigger
        if sub.sm_trigger and _sm_transition_fn:
            parts = sub.sm_trigger.split(":", 1)
            if len(parts) == 2:
                sm_id, sm_event = parts
                try:
                    _sm_transition_fn(sm_id, sm_event, event.data)
                except Exception as exc:
                    log.warning(f"Sensor SM trigger error: {exc}")

        # Pipeline trigger
        if sub.pipe_trigger and _pipeline_run_fn:
            try:
                asyncio.create_task(_pipeline_run_fn(
                    sub.pipe_trigger,
                    {"SENSOR_EVENT": event.event_type, "SENSOR_DATA": str(event.data)},
                ))
            except Exception as exc:
                log.warning(f"Sensor pipeline trigger error: {exc}")


# ── Subscription management ───────────────────────────────────
def subscribe(
    pattern: str,
    handler: Optional[str] = None,
    sm_trigger: str = "",
    pipe_trigger: str = "",
    filter_key: str = "",
    filter_val: str = "",
) -> str:
    sub_id = f"sub_{new_id()[:8]}"
    sub = Subscription(
        sub_id=sub_id,
        pattern=pattern,
        handler=handler,
        sm_trigger=sm_trigger,
        pipe_trigger=pipe_trigger,
        filter_key=filter_key,
        filter_val=filter_val,
    )
    _subscriptions[sub_id] = sub
    # Persist
    sub_dir = ORCH_ROOT / "sensors"
    sub_dir.mkdir(exist_ok=True)
    (sub_dir / sub_id).write_text(json.dumps(asdict(sub)))
    log.debug(f"Subscribed: {sub_id} pattern={pattern}")
    return sub_id


def unsubscribe(sub_id: str) -> None:
    _subscriptions.pop(sub_id, None)
    (ORCH_ROOT / "sensors" / sub_id).unlink(missing_ok=True)


def load_subscriptions() -> None:
    sub_dir = ORCH_ROOT / "sensors"
    if not sub_dir.exists():
        return
    for f in sub_dir.iterdir():
        if f.name.startswith("sub_"):
            try:
                data = json.loads(f.read_text())
                sub = Subscription(**data)
                _subscriptions[sub.sub_id] = sub
            except Exception:
                pass


def list_subscriptions() -> list[Subscription]:
    return list(_subscriptions.values())


def recent_events(n: int = 20) -> list[SensorEvent]:
    return list(reversed(_event_history[-n:]))


# ── System metric polling ─────────────────────────────────────
async def _poll_system_metrics() -> None:
    while _active:
        try:
            # Load average
            if Path("/proc/loadavg").exists():
                load = float(Path("/proc/loadavg").read_text().split()[0])
                if load > SENSOR_LOAD_THRESHOLD:
                    await emit_async("SYSTEM_LOAD_HIGH",
                                     {"load": load, "threshold": SENSOR_LOAD_THRESHOLD})

            # Disk usage via df
            proc = await asyncio.create_subprocess_shell(
                "df -h --output=pcent,target 2>/dev/null | tail -n+2",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.DEVNULL,
            )
            stdout, _ = await proc.communicate()
            for line in stdout.decode().splitlines():
                parts = line.strip().split()
                if len(parts) >= 2:
                    pct_str = parts[0].rstrip("%")
                    try:
                        pct = int(pct_str)
                        mp = parts[1]
                        if pct >= SENSOR_DISK_THRESHOLD:
                            await emit_async("DISK_USAGE_HIGH",
                                             {"mount": mp, "pct": pct})
                    except ValueError:
                        pass

        except Exception as exc:
            log.debug(f"Metric poll error: {exc}")

        await asyncio.sleep(10)


# ── Heartbeat loop ────────────────────────────────────────────
async def _heartbeat_loop() -> None:
    while _active:
        await asyncio.sleep(5)
        await emit_async("HEARTBEAT", {"ts": int(time.time())})


# ── File watcher ──────────────────────────────────────────────
async def watch_file(
    path: str,
    emit_event: str = "FILE_CHANGED",
    watch_on: str = "modify",
) -> asyncio.Task:
    """Watch a file for changes, emitting emit_event when it changes."""
    log.info(f"Watching file: {path} -> {emit_event}")

    async def _poll():
        last_mtime = 0.0
        p = Path(path)
        while _active:
            try:
                mtime = p.stat().st_mtime
                if mtime != last_mtime:
                    if last_mtime:  # skip initial trigger
                        await emit_async(emit_event, {"path": path})
                    last_mtime = mtime
            except FileNotFoundError:
                pass
            await asyncio.sleep(1)

    # Try watchdog for inotify-backed watching
    try:
        from watchdog.observers import Observer
        from watchdog.events import FileSystemEventHandler

        class _Handler(FileSystemEventHandler):
            def on_modified(self, event):
                if not event.is_directory and event.src_path == str(Path(path).resolve()):
                    emit(emit_event, {"path": event.src_path, "event": "modified"})

            def on_created(self, event):
                if not event.is_directory:
                    emit(emit_event, {"path": event.src_path, "event": "created"})

            def on_deleted(self, event):
                emit(emit_event, {"path": event.src_path, "event": "deleted"})

        observer = Observer()
        observer.schedule(_Handler(), str(Path(path).parent), recursive=False)
        observer.start()
        log.info(f"inotify watcher started for {path}")

        async def _keep_alive():
            while _active:
                await asyncio.sleep(5)
            observer.stop()
            observer.join()

        task = asyncio.create_task(_keep_alive())
        _watcher_tasks.append(task)
        return task

    except ImportError:
        task = asyncio.create_task(_poll())
        _watcher_tasks.append(task)
        return task


# ── Process watcher ───────────────────────────────────────────
async def watch_process(
    process_name: str,
    start_event: str = "PROC_STARTED",
    stop_event: str = "PROC_STOPPED",
) -> asyncio.Task:
    log.info(f"Watching process: {process_name}")

    async def _watch():
        was_running = False
        while _active:
            proc = await asyncio.create_subprocess_shell(
                f"pgrep -x {process_name}",
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.DEVNULL,
            )
            await proc.wait()
            running = proc.returncode == 0

            if running and not was_running:
                await emit_async(start_event, {"process": process_name})
            elif not running and was_running:
                await emit_async(stop_event, {"process": process_name})
            was_running = running
            await asyncio.sleep(3)

    task = asyncio.create_task(_watch())
    _watcher_tasks.append(task)
    return task


# ── Port watcher ──────────────────────────────────────────────
async def watch_port(
    port: int,
    open_event: str = "PORT_OPEN",
    close_event: str = "PORT_CLOSED",
    host: str = "127.0.0.1",
) -> asyncio.Task:
    log.info(f"Watching port: {host}:{port}")

    async def _watch():
        was_open = False
        while _active:
            try:
                _, writer = await asyncio.wait_for(
                    asyncio.open_connection(host, port), timeout=2.0
                )
                writer.close()
                await writer.wait_closed()
                is_open = True
            except (ConnectionRefusedError, asyncio.TimeoutError, OSError):
                is_open = False

            if is_open and not was_open:
                await emit_async(open_event, {"port": port, "host": host})
            elif not is_open and was_open:
                await emit_async(close_event, {"port": port, "host": host})
            was_open = is_open
            await asyncio.sleep(5)

    task = asyncio.create_task(_watch())
    _watcher_tasks.append(task)
    return task


# ── Webhook receiver ──────────────────────────────────────────
async def start_webhook_listener(
    port: int,
    emit_event: str = "WEBHOOK",
    host: str = "127.0.0.1",
) -> asyncio.Task:
    """Minimal async HTTP server that emits events for POST requests."""
    log.info(f"Webhook listener: {host}:{port} -> {emit_event}")

    async def _handle(reader: asyncio.StreamReader, writer: asyncio.StreamWriter):
        try:
            request = await asyncio.wait_for(reader.read(4096), timeout=5.0)
            text = request.decode(errors="replace")
            body = text.split("\r\n\r\n", 1)[1] if "\r\n\r\n" in text else ""
            try:
                data = json.loads(body) if body else {}
            except json.JSONDecodeError:
                data = {"raw": body}

            await emit_async(emit_event, data)

            writer.write(b"HTTP/1.1 200 OK\r\nContent-Length: 2\r\n\r\nOK")
            await writer.drain()
        except Exception:
            pass
        finally:
            writer.close()

    server = await asyncio.start_server(_handle, host, port)

    async def _serve():
        async with server:
            await server.serve_forever()

    task = asyncio.create_task(_serve())
    _watcher_tasks.append(task)
    return task


# ── Lifecycle ─────────────────────────────────────────────────
async def start() -> None:
    global _active
    _active = True
    load_subscriptions()
    asyncio.create_task(_heartbeat_loop())
    asyncio.create_task(_poll_system_metrics())
    log.info("Sensor bus started")


async def stop() -> None:
    global _active
    _active = False
    for task in _watcher_tasks:
        task.cancel()
    log.info("Sensor bus stopped")
