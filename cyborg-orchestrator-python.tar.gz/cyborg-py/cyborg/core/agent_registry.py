"""
cyborg.core.agent_registry
~~~~~~~~~~~~~~~~~~~~~~~~~~
Agent registry with SM-backed lifecycle, inbox/outbox delegation,
heartbeat tracking, and nested orchestrator spawning.
"""
from __future__ import annotations

import asyncio
import json
import shutil
import subprocess
import sys
import time
import uuid
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Optional

from cyborg.core.config import (
    ORCH_ROOT, AgentManifest, AgentStatus, AgentType,
    AGENT_HEARTBEAT_TIMEOUT, log, new_id, now_iso,
)
import cyborg.core.state_machine as sm_engine
import cyborg.core.sensor_bus as sensor_bus


# ── Registry ──────────────────────────────────────────────────
_agents:   dict[str, AgentManifest] = {}
_handlers: dict[str, Callable] = {}   # agent_id -> async handler fn
_inbox:    dict[str, list[dict]] = {}  # agent_id -> [task_json, ...]


# ── SM hooks ──────────────────────────────────────────────────
def _on_assign(sm_id: str, from_state: str, to_state: str, data: dict) -> None:
    agent_id = sm_id.removeprefix("agent_")
    if agent_id in _agents:
        _agents[agent_id].status = AgentStatus.BUSY
        _persist(agent_id)


def _on_complete(sm_id: str, from_state: str, to_state: str, data: dict) -> None:
    agent_id = sm_id.removeprefix("agent_")
    if agent_id in _agents:
        _agents[agent_id].status = AgentStatus.ONLINE
        _persist(agent_id)


def _on_error(sm_id: str, from_state: str, to_state: str, data: dict) -> None:
    agent_id = sm_id.removeprefix("agent_")
    if agent_id in _agents:
        _agents[agent_id].status = AgentStatus.ERROR
        _persist(agent_id)
    log.warning(f"Agent {agent_id} entered ERROR state")


def _on_offline(sm_id: str, from_state: str, to_state: str, data: dict) -> None:
    agent_id = sm_id.removeprefix("agent_")
    if agent_id in _agents:
        _agents[agent_id].status = AgentStatus.OFFLINE
        _persist(agent_id)


# Register SM actions at module load
sm_engine.register_action("agent_on_assign",   _on_assign)
sm_engine.register_action("agent_on_complete", _on_complete)
sm_engine.register_action("agent_on_error",    _on_error)
sm_engine.register_action("agent_on_offline",  _on_offline)


# ── Persistence ───────────────────────────────────────────────
def _agent_dir(agent_id: str) -> Path:
    return ORCH_ROOT / "agents" / agent_id


def _persist(agent_id: str) -> None:
    manifest = _agents.get(agent_id)
    if not manifest:
        return
    d = _agent_dir(agent_id)
    d.mkdir(parents=True, exist_ok=True)
    data = asdict(manifest)
    data["registered_at"] = data["registered_at"].isoformat()
    data["last_seen"] = data["last_seen"].isoformat()
    (d / "manifest.json").write_text(json.dumps(data, indent=2))


def _load_all() -> None:
    agents_dir = ORCH_ROOT / "agents"
    if not agents_dir.exists():
        return
    for d in agents_dir.iterdir():
        if not d.is_dir() or not (d / "manifest.json").exists():
            continue
        try:
            raw = json.loads((d / "manifest.json").read_text())
            raw["registered_at"] = datetime.fromisoformat(raw["registered_at"])
            raw["last_seen"] = datetime.fromisoformat(raw["last_seen"])
            raw["agent_type"] = AgentType(raw["agent_type"])
            raw["status"] = AgentStatus(raw["status"])
            manifest = AgentManifest(**raw)
            _agents[manifest.agent_id] = manifest
            _inbox.setdefault(manifest.agent_id, [])
        except Exception as exc:
            log.warning(f"Could not restore agent {d.name}: {exc}")


# ── Public API ────────────────────────────────────────────────
def register(
    agent_id: str,
    name: str,
    agent_type: AgentType,
    capabilities: list[str],
    endpoint: str = "local",
) -> AgentManifest:
    """Register an agent and create its backing state machine."""
    if agent_id in _agents:
        log.warning(f"Agent already registered: {agent_id}")
        return _agents[agent_id]

    sm_id = f"agent_{agent_id}"

    # Create SM for this agent
    try:
        sm_engine.sm_create(sm_id, "IDLE", ["IDLE", "BUSY", "WAITING", "ERROR", "OFFLINE"])
    except ValueError:
        pass  # already exists

    sm_engine.sm_add_transition(sm_id, "IDLE",    "ASSIGN",   "BUSY",    None, "agent_on_assign")
    sm_engine.sm_add_transition(sm_id, "BUSY",    "COMPLETE", "IDLE",    None, "agent_on_complete")
    sm_engine.sm_add_transition(sm_id, "BUSY",    "WAIT",     "WAITING")
    sm_engine.sm_add_transition(sm_id, "WAITING", "RESUME",   "BUSY")
    sm_engine.sm_add_transition(sm_id, "BUSY",    "ERROR",    "ERROR",   None, "agent_on_error")
    sm_engine.sm_add_transition(sm_id, "*",       "OFFLINE",  "OFFLINE", None, "agent_on_offline")
    sm_engine.sm_add_transition(sm_id, "OFFLINE", "ONLINE",   "IDLE")

    manifest = AgentManifest(
        agent_id=agent_id,
        name=name,
        agent_type=agent_type,
        capabilities=capabilities,
        endpoint=endpoint,
        sm_id=sm_id,
    )
    _agents[agent_id] = manifest
    _inbox[agent_id] = []

    d = _agent_dir(agent_id)
    d.mkdir(parents=True, exist_ok=True)
    (d / "inbox").touch()
    (d / "outbox").touch()
    _persist(agent_id)

    log.info(f"Agent registered: {agent_id} ({name}) type={agent_type.value}")
    return manifest


def unregister(agent_id: str) -> None:
    if agent_id not in _agents:
        return
    sm_engine.sm_destroy(f"agent_{agent_id}")
    _agents.pop(agent_id, None)
    _handlers.pop(agent_id, None)
    _inbox.pop(agent_id, None)
    shutil.rmtree(_agent_dir(agent_id), ignore_errors=True)
    log.info(f"Agent unregistered: {agent_id}")


def set_handler(agent_id: str, fn: Callable) -> None:
    """Register a local async handler function for an agent."""
    _handlers[agent_id] = fn


async def delegate(agent_id: str, payload: dict) -> Optional[str]:
    """Delegate a task dict to an agent. Returns task_id."""
    if agent_id not in _agents:
        log.error(f"Agent not found: {agent_id}")
        return None

    manifest = _agents[agent_id]
    if manifest.status in (AgentStatus.OFFLINE, AgentStatus.ERROR):
        log.warning(f"Cannot delegate to agent {agent_id}: status={manifest.status}")
        return None

    task_id = new_id("task_")
    task = {
        "task_id": task_id,
        "agent_id": agent_id,
        "submitted": now_iso(),
        "payload": payload,
    }
    _inbox[agent_id].append(task)

    # Append to inbox file
    d = _agent_dir(agent_id)
    with (d / "inbox").open("a") as f:
        f.write(json.dumps(task) + "\n")

    # Transition SM
    sm_engine.sm_transition(f"agent_{agent_id}", "ASSIGN", task)

    # Run local handler
    handler = _handlers.get(agent_id)
    if handler:
        asyncio.create_task(_run_handler(agent_id, task_id, payload, handler))

    manifest.last_seen = datetime.now(timezone.utc)
    _persist(agent_id)
    log.info(f"Task {task_id} delegated to agent {agent_id}")
    return task_id


async def _run_handler(
    agent_id: str,
    task_id: str,
    payload: dict,
    handler: Callable,
) -> None:
    try:
        if asyncio.iscoroutinefunction(handler):
            result = await handler(agent_id, task_id, payload)
        else:
            result = handler(agent_id, task_id, payload)

        # Write to outbox
        d = _agent_dir(agent_id)
        with (d / "outbox").open("a") as f:
            f.write(json.dumps({"task_id": task_id, "result": str(result)}) + "\n")

        sm_engine.sm_transition(f"agent_{agent_id}", "COMPLETE", {"task_id": task_id})
        sensor_bus.emit("AGENT_TASK_COMPLETE",
                        {"agent_id": agent_id, "task_id": task_id})

    except Exception as exc:
        log.error(f"Agent {agent_id} handler error: {exc}")
        sm_engine.sm_transition(f"agent_{agent_id}", "ERROR", {"error": str(exc)})
        sensor_bus.emit("AGENT_TASK_FAILED",
                        {"agent_id": agent_id, "task_id": task_id, "error": str(exc)})


def heartbeat(agent_id: str) -> None:
    if agent_id in _agents:
        _agents[agent_id].last_seen = datetime.now(timezone.utc)


def find_by_capability(capability: str) -> Optional[str]:
    for aid, m in _agents.items():
        if m.status in (AgentStatus.ONLINE, AgentStatus.IDLE) and capability in m.capabilities:
            return aid
    return None


def get_all() -> list[AgentManifest]:
    return list(_agents.values())


def count() -> int:
    return len(_agents)


# ── Nested orchestrator ───────────────────────────────────────
def spawn_nested(nested_id: str) -> Path:
    """
    Spawn a complete child orchestrator under agents/<nested_id>/orch/.
    The nested orch has its own socket, config, state, and agents.
    """
    nested_root = _agent_dir(nested_id) / "orch"
    nested_root.mkdir(parents=True, exist_ok=True)

    for sub in ("logs", "state", "pipelines", "sensors", "sockets",
                "agents", "plugins", "config"):
        (nested_root / sub).mkdir(exist_ok=True)

    # Write nested env config
    env_cfg = nested_root / "config" / "env.json"
    env_cfg.write_text(json.dumps({
        "ORCH_ROOT": str(nested_root),
        "ORCH_SOCKET": str(nested_root / "sockets" / "cyborg.sock"),
        "ORCH_WORKERS": "4",
        "NESTED_PARENT": str(ORCH_ROOT / "sockets" / "cyborg.sock"),
        "NESTED_ID": nested_id,
    }, indent=2))

    # Register nested orch as a nested-type agent in the parent
    if nested_id not in _agents:
        register(
            nested_id,
            f"Nested Orchestrator [{nested_id}]",
            AgentType.NESTED,
            ["orchestrate", "delegate", "pipeline"],
            str(nested_root / "sockets" / "cyborg.sock"),
        )

    log.info(f"Nested orchestrator spawned: {nested_id} root={nested_root}")
    return nested_root


async def start_nested(nested_id: str) -> Optional[asyncio.subprocess.Process]:
    """Launch the nested orchestrator daemon process."""
    nested_root = _agent_dir(nested_id) / "orch"
    if not nested_root.exists():
        spawn_nested(nested_id)

    env = {
        **{k: str(v) for k, v in __import__("os").environ.items()},
        "ORCH_ROOT": str(nested_root),
        "ORCH_SOCKET": str(nested_root / "sockets" / "cyborg.sock"),
    }

    proc = await asyncio.create_subprocess_exec(
        sys.executable, "-m", "cyborg.daemon",
        env=env,
        stdout=asyncio.subprocess.DEVNULL,
        stderr=asyncio.subprocess.DEVNULL,
    )
    log.info(f"Nested orchestrator started: {nested_id} pid={proc.pid}")
    return proc


# ── Heartbeat monitor ─────────────────────────────────────────
async def monitor_heartbeats() -> None:
    while True:
        await asyncio.sleep(10)
        now = datetime.now(timezone.utc)
        for agent_id, manifest in list(_agents.items()):
            if manifest.status == AgentStatus.OFFLINE:
                continue
            age = (now - manifest.last_seen).total_seconds()
            if age > AGENT_HEARTBEAT_TIMEOUT:
                log.warning(f"Agent {agent_id}: heartbeat timeout ({age:.0f}s)")
                manifest.status = AgentStatus.OFFLINE
                sm_engine.sm_transition(f"agent_{agent_id}", "OFFLINE")
                sensor_bus.emit("AGENT_OFFLINE", {"agent_id": agent_id})
                _persist(agent_id)


def init() -> None:
    """Load persisted agents on startup."""
    _load_all()
    log.info(f"Agent registry initialised | {len(_agents)} agents restored")
