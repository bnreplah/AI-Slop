"""
cyborg.core.pipeline_engine
~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Async DAG pipeline runner.

Pipelines are semicolon-separated step specs:
    name:command:timeout:retry_count[:parallel_group]

Steps in the same parallel_group run concurrently via asyncio.gather().
Output of each step is passed as PIPE_OUTPUT env var to subsequent steps.
"""
from __future__ import annotations

import asyncio
import json
import os
import shlex
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Optional

from cyborg.core.config import (
    ORCH_ROOT, PIPELINE_GC_AGE, StepSpec, PipelineRun,
    PipelineStatus, log, new_id, now_iso, epoch,
)


# ── In-memory registries ──────────────────────────────────────
_pipeline_defs: dict[str, str] = {}          # name -> raw spec string
_pipeline_runs: dict[str, PipelineRun] = {}  # run_id -> PipelineRun
_task_aliases:  dict[str, str] = {}          # task_name -> command template
_run_tasks:     dict[str, asyncio.Task] = {} # run_id -> asyncio.Task

# Event emitter hook (set by sensor_bus at boot)
_event_emitter: Optional[Callable] = None


def set_event_emitter(fn: Callable) -> None:
    global _event_emitter
    _event_emitter = fn


def _emit(event_type: str, data: dict) -> None:
    if _event_emitter:
        try:
            _event_emitter(event_type, data)
        except Exception:
            pass


# ── Pipeline definition ───────────────────────────────────────
def pipeline_define(name: str, spec: str) -> None:
    """Register a named pipeline spec."""
    _pipeline_defs[name] = spec
    # Persist to config
    cfg = ORCH_ROOT / "config" / "pipelines.conf"
    lines = cfg.read_text().splitlines() if cfg.exists() else []
    lines = [l for l in lines if not l.startswith(f"{name}|")]
    lines.append(f"{name}|{spec}")
    cfg.write_text("\n".join(lines) + "\n")
    log.debug(f"Pipeline defined: {name}")


def pipeline_load_saved() -> None:
    """Reload pipeline definitions from config file."""
    cfg = ORCH_ROOT / "config" / "pipelines.conf"
    if not cfg.exists():
        return
    for line in cfg.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split("|", 1)
        if len(parts) == 2:
            _pipeline_defs[parts[0]] = parts[1]
            log.info(f"Restored pipeline: {parts[0]}")


def _resolve_spec(target: str) -> Optional[str]:
    if target.startswith("inline:"):
        return target[7:]
    if target in _pipeline_defs:
        return _pipeline_defs[target]
    # Config fallback
    cfg = ORCH_ROOT / "config" / "pipelines.conf"
    if cfg.exists():
        for line in cfg.read_text().splitlines():
            if line.startswith(f"{target}|"):
                return line.split("|", 1)[1]
    return None


def _parse_steps(spec: str) -> list[StepSpec]:
    return [StepSpec.parse(s.strip()) for s in spec.split(";") if s.strip()]


# ── Async pipeline runner ─────────────────────────────────────
async def pipeline_run(
    target: str,
    env_extras: Optional[dict[str, str]] = None,
) -> Optional[PipelineRun]:
    """Launch a pipeline asynchronously. Returns the PipelineRun object."""
    spec = _resolve_spec(target)
    if spec is None:
        log.error(f"Pipeline not found: {target}")
        return None

    run_id = f"{target}_{int(time.time() * 1000)}"
    run = PipelineRun(run_id=run_id, name=target)
    _pipeline_runs[run_id] = run

    # Persist run directory
    run_dir = ORCH_ROOT / "pipelines" / run_id
    run_dir.mkdir(parents=True, exist_ok=True)
    (run_dir / "name").write_text(target)
    (run_dir / "status").write_text(PipelineStatus.PENDING.value)

    steps = _parse_steps(spec)
    task = asyncio.create_task(_run_pipeline(run, steps, env_extras or {}))
    _run_tasks[run_id] = task
    log.info(f"Pipeline launched: {run_id}")
    return run


async def _run_pipeline(
    run: PipelineRun,
    steps: list[StepSpec],
    env_extras: dict[str, str],
) -> None:
    run_dir = ORCH_ROOT / "pipelines" / run.run_id
    run.status = PipelineStatus.RUNNING
    run.started_at = datetime.now(timezone.utc)
    (run_dir / "status").write_text(run.status.value)
    run.log(f"Pipeline started: {run.run_id}")

    env = {**os.environ, **env_extras, "PIPE_ID": run.run_id}
    pipe_output = ""

    try:
        # Group steps by parallel_group
        i = 0
        while i < len(steps):
            step = steps[i]

            if step.parallel_group:
                # Collect all steps in this group
                group = [step]
                while i + 1 < len(steps) and steps[i + 1].parallel_group == step.parallel_group:
                    i += 1
                    group.append(steps[i])
                i += 1

                run.log(f"Parallel group [{step.parallel_group}]: {[s.name for s in group]}")
                results = await asyncio.gather(
                    *[_run_step(run, s, {**env, "PIPE_OUTPUT": pipe_output}) for s in group],
                    return_exceptions=True,
                )
                for s, r in zip(group, results):
                    if isinstance(r, Exception):
                        run.log(f"Step [{s.name}] parallel FAILED: {r}")
                        raise RuntimeError(f"Parallel step {s.name} failed")
                    else:
                        pipe_output = r or pipe_output
            else:
                env["PIPE_OUTPUT"] = pipe_output
                pipe_output = await _run_step(run, step, env)
                i += 1

        run.status = PipelineStatus.SUCCESS
        run.output = pipe_output
        run.log(f"Pipeline SUCCEEDED in {run.duration:.1f}s" if run.duration else "Pipeline SUCCEEDED")
        _emit("PIPELINE_SUCCESS", {"run_id": run.run_id, "name": run.name})

    except asyncio.CancelledError:
        run.status = PipelineStatus.ABORTED
        run.log("Pipeline ABORTED")
        _emit("PIPELINE_ABORTED", {"run_id": run.run_id})

    except Exception as exc:
        run.status = PipelineStatus.FAILED
        run.log(f"Pipeline FAILED: {exc}")
        _emit("PIPELINE_FAILED", {"run_id": run.run_id, "error": str(exc)})

    finally:
        run.finished_at = datetime.now(timezone.utc)
        run_dir = ORCH_ROOT / "pipelines" / run.run_id
        (run_dir / "status").write_text(run.status.value)
        (run_dir / "output").write_text(run.output)
        (run_dir / "log").write_text("\n".join(run.log_lines))


async def _run_step(
    run: PipelineRun,
    step: StepSpec,
    env: dict[str, str],
) -> str:
    """Run a single step with retries. Returns captured stdout."""
    attempt = 0
    max_attempts = step.retry_count + 1

    while attempt < max_attempts:
        attempt += 1
        run.log(f"  Step [{step.name}] attempt {attempt}/{max_attempts}: {step.command[:80]}")

        try:
            proc = await asyncio.create_subprocess_shell(
                step.command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,
                env=env,
            )
            try:
                stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=step.timeout)
            except asyncio.TimeoutError:
                proc.kill()
                raise RuntimeError(f"Step [{step.name}] timed out after {step.timeout}s")

            output = stdout.decode(errors="replace").strip()
            if proc.returncode == 0:
                run.log(f"  Step [{step.name}] OK | rc=0 | out={output[:120]}")
                env[f"STEP_{step.name.upper()}_OUTPUT"] = output
                _emit("STEP_SUCCESS", {"run_id": run.run_id, "step": step.name})
                return output
            else:
                run.log(f"  Step [{step.name}] FAILED rc={proc.returncode} | {output[:120]}")
                if attempt < max_attempts:
                    await asyncio.sleep(attempt * 2)

        except RuntimeError:
            raise
        except Exception as exc:
            run.log(f"  Step [{step.name}] exception: {exc}")
            if attempt >= max_attempts:
                raise

    _emit("STEP_FAILED", {"run_id": run.run_id, "step": step.name})
    raise RuntimeError(f"Step [{step.name}] exhausted {max_attempts} attempts")


# ── Control ───────────────────────────────────────────────────
def pipeline_kill(run_id: str) -> bool:
    task = _run_tasks.get(run_id)
    if task and not task.done():
        task.cancel()
        run = _pipeline_runs.get(run_id)
        if run:
            run.status = PipelineStatus.ABORTED
        log.info(f"Pipeline aborted: {run_id}")
        return True
    return False


def pipeline_count_active() -> int:
    return sum(1 for r in _pipeline_runs.values()
               if r.status == PipelineStatus.RUNNING)


def pipeline_list_all() -> list[PipelineRun]:
    return list(_pipeline_runs.values())


def pipeline_get(run_id: str) -> Optional[PipelineRun]:
    return _pipeline_runs.get(run_id)


def pipeline_gc() -> int:
    """Remove completed runs older than PIPELINE_GC_AGE seconds."""
    cutoff = epoch() - PIPELINE_GC_AGE
    removed = 0
    stale = [
        rid for rid, r in _pipeline_runs.items()
        if r.status not in (PipelineStatus.RUNNING, PipelineStatus.PENDING)
        and r.finished_at
        and r.finished_at.timestamp() < cutoff
    ]
    for rid in stale:
        _pipeline_runs.pop(rid, None)
        _run_tasks.pop(rid, None)
        import shutil
        shutil.rmtree(ORCH_ROOT / "pipelines" / rid, ignore_errors=True)
        removed += 1
    return removed


# ── Task aliases ──────────────────────────────────────────────
def task_register(name: str, command_template: str) -> None:
    _task_aliases[name] = command_template
    cfg = ORCH_ROOT / "config" / "tasks.conf"
    lines = cfg.read_text().splitlines() if cfg.exists() else []
    lines = [l for l in lines if not l.startswith(f"task:{name}:")]
    lines.append(f"task:{name}:{command_template}")
    cfg.write_text("\n".join(lines) + "\n")


def task_list() -> dict[str, str]:
    result = dict(_task_aliases)
    cfg = ORCH_ROOT / "config" / "tasks.conf"
    if cfg.exists():
        for line in cfg.read_text().splitlines():
            if line.startswith("task:"):
                parts = line.split(":", 2)
                if len(parts) == 3:
                    result.setdefault(parts[1], parts[2])
    return result


async def task_run(name: str, args: list[str] = None) -> Optional[PipelineRun]:
    args = args or []
    cmd = _task_aliases.get(name)
    if not cmd:
        cfg = ORCH_ROOT / "config" / "tasks.conf"
        if cfg.exists():
            for line in cfg.read_text().splitlines():
                if line.startswith(f"task:{name}:"):
                    cmd = line.split(":", 2)[2]
                    break
    if not cmd:
        log.error(f"Task not found: {name}")
        return None
    for i, arg in enumerate(args):
        cmd = cmd.replace(f"{{{i}}}", arg)
    return await pipeline_run(f"inline:{name}:{cmd}:60:0")
