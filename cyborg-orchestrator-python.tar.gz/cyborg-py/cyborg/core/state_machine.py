"""
cyborg.core.state_machine
~~~~~~~~~~~~~~~~~~~~~~~~~
Hierarchical finite state machine engine.

Each SM is stored under ORCH_ROOT/state/<sm_id>/ as JSON files.
Parent→child relationships allow nested SM trees.
Transition guards, entry/exit hooks, and history are all supported.
"""
from __future__ import annotations

import asyncio
import fnmatch
import json
import threading
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Optional

from cyborg.core.config import ORCH_ROOT, log, now_iso


# ── Dataclasses ───────────────────────────────────────────────
@dataclass
class Transition:
    from_state: str          # "*" means any
    event: str
    to_state: str
    guard: Optional[str] = None   # name of guard callable
    action: Optional[str] = None  # name of action callable


@dataclass
class StateMachineSpec:
    sm_id: str
    states: list[str]
    transitions: list[Transition]
    initial_state: str
    current_state: str
    parent_id: str = ""
    children: list[str] = field(default_factory=list)
    history: list[dict] = field(default_factory=list)
    meta: dict = field(default_factory=dict)
    created_at: str = field(default_factory=now_iso)


# ── Registry singletons ───────────────────────────────────────
_guards:        dict[str, Callable] = {}
_actions:       dict[str, Callable] = {}
_entry_hooks:   dict[str, Callable] = {}   # key: "sm_id:state"
_exit_hooks:    dict[str, Callable] = {}   # key: "sm_id:state"
_sm_cache:      dict[str, StateMachineSpec] = {}
_lock = threading.RLock()

# Transition listeners (for sensor bus integration)
_transition_listeners: list[Callable] = []


def on_transition(fn: Callable) -> None:
    """Register a coroutine that's called after every transition."""
    _transition_listeners.append(fn)


def register_guard(name: str, fn: Callable) -> None:
    _guards[name] = fn


def register_action(name: str, fn: Callable) -> None:
    _actions[name] = fn


def register_entry_hook(sm_id: str, state: str, fn: Callable) -> None:
    _entry_hooks[f"{sm_id}:{state}"] = fn


def register_exit_hook(sm_id: str, state: str, fn: Callable) -> None:
    _exit_hooks[f"{sm_id}:{state}"] = fn


# ── Persistence helpers ───────────────────────────────────────
def _sm_dir(sm_id: str) -> Path:
    return ORCH_ROOT / "state" / sm_id


def _save(spec: StateMachineSpec) -> None:
    d = _sm_dir(spec.sm_id)
    d.mkdir(parents=True, exist_ok=True)
    data = {
        "sm_id": spec.sm_id,
        "states": spec.states,
        "transitions": [asdict(t) for t in spec.transitions],
        "initial_state": spec.initial_state,
        "current_state": spec.current_state,
        "parent_id": spec.parent_id,
        "children": spec.children,
        "history": spec.history[-500:],   # cap history
        "meta": spec.meta,
        "created_at": spec.created_at,
    }
    (d / "spec.json").write_text(json.dumps(data, indent=2))


def _load(sm_id: str) -> Optional[StateMachineSpec]:
    p = _sm_dir(sm_id) / "spec.json"
    if not p.exists():
        return None
    raw = json.loads(p.read_text())
    raw["transitions"] = [Transition(**t) for t in raw["transitions"]]
    return StateMachineSpec(**raw)


def _get(sm_id: str) -> Optional[StateMachineSpec]:
    with _lock:
        if sm_id not in _sm_cache:
            spec = _load(sm_id)
            if spec:
                _sm_cache[sm_id] = spec
        return _sm_cache.get(sm_id)


# ── Public API ────────────────────────────────────────────────
def sm_create(
    sm_id: str,
    initial_state: str,
    states: Optional[list[str]] = None,
    parent_id: str = "",
) -> StateMachineSpec:
    """Create a new state machine."""
    with _lock:
        if _get(sm_id):
            raise ValueError(f"SM already exists: {sm_id}")

        spec = StateMachineSpec(
            sm_id=sm_id,
            states=states or [initial_state],
            transitions=[],
            initial_state=initial_state,
            current_state=initial_state,
            parent_id=parent_id,
            history=[{"ts": now_iso(), "event": "CREATED", "to": initial_state}],
        )
        if initial_state not in spec.states:
            spec.states.insert(0, initial_state)

        # Register as child of parent
        if parent_id:
            parent = _get(parent_id)
            if parent and sm_id not in parent.children:
                parent.children.append(sm_id)
                _save(parent)

        _sm_cache[sm_id] = spec
        _save(spec)
        log.info(f"SM created: {sm_id} | initial={initial_state}")
        return spec


def sm_add_state(sm_id: str, state: str) -> None:
    with _lock:
        spec = _get(sm_id)
        if not spec:
            raise KeyError(sm_id)
        if state not in spec.states:
            spec.states.append(state)
            _save(spec)


def sm_add_transition(
    sm_id: str,
    from_state: str,
    event: str,
    to_state: str,
    guard: Optional[str] = None,
    action: Optional[str] = None,
) -> None:
    with _lock:
        spec = _get(sm_id)
        if not spec:
            raise KeyError(sm_id)
        t = Transition(from_state=from_state, event=event,
                       to_state=to_state, guard=guard, action=action)
        spec.transitions.append(t)
        _save(spec)


def sm_get_state(sm_id: str) -> str:
    spec = _get(sm_id)
    return spec.current_state if spec else "UNKNOWN"


def sm_transition(
    sm_id: str,
    event: str,
    data: Optional[dict] = None,
) -> Optional[str]:
    """
    Fire a transition event.  Returns the new state, or None if no match / guard blocked.
    This is synchronous — async wrapper below handles loop integration.
    """
    data = data or {}
    with _lock:
        spec = _get(sm_id)
        if not spec:
            log.error(f"SM not found: {sm_id}")
            return None

        current = spec.current_state
        match: Optional[Transition] = None
        for t in spec.transitions:
            if (t.from_state == current or t.from_state == "*") and t.event == event:
                match = t
                break

        if not match:
            log.warning(f"SM {sm_id}: no transition from '{current}' on '{event}'")
            return None

        # Guard
        if match.guard and match.guard in _guards:
            try:
                if not _guards[match.guard](sm_id, current, match.to_state, data):
                    log.warning(f"SM {sm_id}: guard '{match.guard}' blocked transition")
                    return None
            except Exception as exc:
                log.error(f"SM {sm_id}: guard error: {exc}")
                return None

        # Exit hook
        exit_key = f"{sm_id}:{current}"
        if exit_key in _exit_hooks:
            try:
                _exit_hooks[exit_key](sm_id, current, data)
            except Exception as exc:
                log.warning(f"SM {sm_id}: exit hook error: {exc}")

        # Commit
        spec.current_state = match.to_state
        spec.history.append({
            "ts": now_iso(),
            "from": current,
            "event": event,
            "to": match.to_state,
            "data": str(data)[:200],
        })
        _save(spec)

        # Transition action
        if match.action and match.action in _actions:
            try:
                _actions[match.action](sm_id, current, match.to_state, data)
            except Exception as exc:
                log.warning(f"SM {sm_id}: action error: {exc}")

        # Entry hook
        entry_key = f"{sm_id}:{match.to_state}"
        if entry_key in _entry_hooks:
            try:
                _entry_hooks[entry_key](sm_id, match.to_state, data)
            except Exception as exc:
                log.warning(f"SM {sm_id}: entry hook error: {exc}")

        log.info(f"SM {sm_id}: {current} --[{event}]--> {match.to_state}")

        # Notify listeners (non-blocking)
        for listener in _transition_listeners:
            try:
                if asyncio.iscoroutinefunction(listener):
                    try:
                        loop = asyncio.get_running_loop()
                        loop.create_task(listener(sm_id, current, match.to_state, event, data))
                    except RuntimeError:
                        pass
                else:
                    listener(sm_id, current, match.to_state, event, data)
            except Exception:
                pass

        return match.to_state


def sm_destroy(sm_id: str) -> None:
    with _lock:
        spec = _get(sm_id)
        if not spec:
            return
        # Recursively destroy children
        for child in list(spec.children):
            sm_destroy(child)
        _sm_cache.pop(sm_id, None)
        import shutil
        shutil.rmtree(_sm_dir(sm_id), ignore_errors=True)
        log.info(f"SM destroyed: {sm_id}")


def sm_list() -> list[StateMachineSpec]:
    state_dir = ORCH_ROOT / "state"
    result = []
    if not state_dir.exists():
        return result
    for d in sorted(state_dir.iterdir()):
        if d.is_dir() and (d / "spec.json").exists():
            spec = _get(d.name)
            if spec:
                result.append(spec)
    return result


def sm_describe(sm_id: str) -> dict:
    spec = _get(sm_id)
    if not spec:
        return {}
    return {
        "sm_id": spec.sm_id,
        "current": spec.current_state,
        "states": spec.states,
        "transitions": [asdict(t) for t in spec.transitions],
        "children": spec.children,
        "parent": spec.parent_id,
        "history_tail": spec.history[-10:],
    }


def sm_history(sm_id: str, limit: int = 20) -> list[dict]:
    spec = _get(sm_id)
    if not spec:
        return []
    return spec.history[-limit:]


def sm_snapshot() -> None:
    """Persist all cached SMs to disk."""
    with _lock:
        for spec in _sm_cache.values():
            _save(spec)
    log.info("SM snapshot complete")
