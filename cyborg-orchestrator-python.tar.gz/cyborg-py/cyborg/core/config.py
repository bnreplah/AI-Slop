"""
cyborg.core.config
~~~~~~~~~~~~~~~~~~
Centralised configuration, path resolution, shared enums and dataclasses.
Everything in the engine imports from here — never the other way around.
"""
from __future__ import annotations

import hashlib
import logging
import os
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum, auto
from pathlib import Path
from typing import Any, Optional


# ── Root resolution ───────────────────────────────────────────
def _resolve_root() -> Path:
    env = os.environ.get("ORCH_ROOT")
    if env:
        return Path(env).expanduser().resolve()
    return Path.home() / ".cyborg"


ORCH_ROOT: Path = _resolve_root()
SOCKET_PATH: Path = Path(os.environ.get("ORCH_SOCKET", str(ORCH_ROOT / "sockets" / "cyborg.sock")))
PID_FILE: Path = ORCH_ROOT / "sockets" / "cyborg.pid"
LOG_FILE: Path = ORCH_ROOT / "logs" / "orchestrator.log"
LOG_LEVEL: str = os.environ.get("ORCH_LOG_LEVEL", "INFO")
MAX_WORKERS: int = int(os.environ.get("ORCH_WORKERS", "8"))
HEARTBEAT_INTERVAL: int = int(os.environ.get("ORCH_HEARTBEAT", "5"))
AGENT_HEARTBEAT_TIMEOUT: int = int(os.environ.get("AGENT_HEARTBEAT_TIMEOUT", "30"))
SENSOR_LOAD_THRESHOLD: float = float(os.environ.get("SENSOR_LOAD_THRESHOLD", "4.0"))
SENSOR_DISK_THRESHOLD: int = int(os.environ.get("SENSOR_DISK_THRESHOLD", "90"))
PIPELINE_GC_AGE: int = int(os.environ.get("PIPELINE_GC_AGE", "3600"))
VERSION: str = "1.0.0"


# ── Ensure directories exist ──────────────────────────────────
def ensure_dirs() -> None:
    for sub in ("core", "logs", "state", "pipelines", "sensors",
                "sockets", "agents", "plugins", "config"):
        (ORCH_ROOT / sub).mkdir(parents=True, exist_ok=True)
    LOG_FILE.touch(exist_ok=True)
    (ORCH_ROOT / "config" / "pipelines.conf").touch(exist_ok=True)
    (ORCH_ROOT / "config" / "schedules.conf").touch(exist_ok=True)
    (ORCH_ROOT / "config" / "tasks.conf").touch(exist_ok=True)


# ── Enumerations ──────────────────────────────────────────────
class PipelineStatus(str, Enum):
    PENDING  = "PENDING"
    RUNNING  = "RUNNING"
    SUCCESS  = "SUCCESS"
    FAILED   = "FAILED"
    ABORTED  = "ABORTED"


class AgentStatus(str, Enum):
    ONLINE  = "ONLINE"
    OFFLINE = "OFFLINE"
    BUSY    = "BUSY"
    ERROR   = "ERROR"
    IDLE    = "IDLE"


class AgentType(str, Enum):
    LOCAL   = "local"
    REMOTE  = "remote"
    NESTED  = "nested"
    LLM     = "llm"
    SENSOR  = "sensor"


class ScheduleType(str, Enum):
    CRON      = "cron"
    AT        = "at"
    COUNTDOWN = "countdown"


# ── Dataclasses ───────────────────────────────────────────────
@dataclass
class StepSpec:
    """A single step within a pipeline definition."""
    name: str
    command: str
    timeout: int = 60
    retry_count: int = 0
    parallel_group: str = ""

    @classmethod
    def parse(cls, raw: str) -> "StepSpec":
        """Parse 'name:cmd:timeout:retry:pgroup' string."""
        parts = [p.strip() for p in raw.split(":")]
        return cls(
            name=parts[0] if len(parts) > 0 else "step",
            command=parts[1] if len(parts) > 1 else "true",
            timeout=int(parts[2]) if len(parts) > 2 and parts[2] else 60,
            retry_count=int(parts[3]) if len(parts) > 3 and parts[3] else 0,
            parallel_group=parts[4] if len(parts) > 4 else "",
        )


@dataclass
class PipelineRun:
    """Live record of a pipeline execution."""
    run_id: str
    name: str
    status: PipelineStatus = PipelineStatus.PENDING
    started_at: Optional[datetime] = None
    finished_at: Optional[datetime] = None
    log_lines: list[str] = field(default_factory=list)
    output: str = ""
    pid: Optional[int] = None

    @property
    def duration(self) -> Optional[float]:
        if self.started_at and self.finished_at:
            return (self.finished_at - self.started_at).total_seconds()
        return None

    def log(self, msg: str) -> None:
        ts = datetime.now(timezone.utc).strftime("%H:%M:%S")
        self.log_lines.append(f"[{ts}] {msg}")


@dataclass
class AgentManifest:
    """Static description of a registered agent."""
    agent_id: str
    name: str
    agent_type: AgentType
    capabilities: list[str]
    endpoint: str = "local"
    registered_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    status: AgentStatus = AgentStatus.ONLINE
    last_seen: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    sm_id: str = ""


@dataclass
class ScheduleEntry:
    """A single scheduled job."""
    sched_id: str
    sched_type: ScheduleType
    spec: str                 # cron string OR epoch timestamp string
    target: str               # pipeline/task name
    args: str = ""
    enabled: bool = True
    last_run: Optional[datetime] = None


@dataclass
class SensorEvent:
    """An event emitted on the sensor bus."""
    event_id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    event_type: str = ""
    data: dict[str, Any] = field(default_factory=dict)
    emitted_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


@dataclass
class Subscription:
    """A sensor bus subscription."""
    sub_id: str
    pattern: str               # fnmatch glob
    handler: Optional[str] = None   # callable name in plugin registry
    sm_trigger: str = ""            # "sm_id:event"
    pipe_trigger: str = ""          # pipeline name to launch
    filter_key: str = ""
    filter_val: str = ""


# ── Utilities ─────────────────────────────────────────────────
def new_id(prefix: str = "") -> str:
    return f"{prefix}{uuid.uuid4().hex[:12]}"


def sha256(data: str) -> str:
    return hashlib.sha256(data.encode()).hexdigest()


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def epoch() -> int:
    return int(datetime.now(timezone.utc).timestamp())


# ── Logging setup ─────────────────────────────────────────────
def setup_logging() -> logging.Logger:
    ensure_dirs()
    logger = logging.getLogger("cyborg")
    logger.setLevel(getattr(logging, LOG_LEVEL.upper(), logging.INFO))

    if not logger.handlers:
        fh = logging.FileHandler(LOG_FILE)
        fh.setFormatter(logging.Formatter(
            "[%(levelname)s] %(asctime)s %(name)s | %(message)s",
            datefmt="%Y-%m-%dT%H:%M:%S"
        ))
        logger.addHandler(fh)
    return logger


log = setup_logging()
