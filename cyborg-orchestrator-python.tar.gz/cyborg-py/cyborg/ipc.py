"""
cyborg.ipc
~~~~~~~~~~
Async and sync IPC client for communicating with the daemon via Unix socket.
All CLI commands that need live daemon data go through here.
"""
from __future__ import annotations

import asyncio
import json
from pathlib import Path
from typing import Any, Optional

from cyborg.core.config import SOCKET_PATH, log


async def send_command(
    msg: dict,
    timeout: float = 10.0,
    socket_path: Optional[Path] = None,
) -> Optional[dict]:
    """Send a command dict to the daemon. Returns the parsed response or None."""
    sock = socket_path or SOCKET_PATH
    if not sock.exists():
        return None
    try:
        reader, writer = await asyncio.wait_for(
            asyncio.open_unix_connection(str(sock)), timeout=timeout
        )
        writer.write(json.dumps(msg).encode() + b"\n")
        await writer.drain()
        line = await asyncio.wait_for(reader.readline(), timeout=timeout)
        writer.close()
        await writer.wait_closed()
        return json.loads(line.decode().strip())
    except (asyncio.TimeoutError, ConnectionRefusedError, FileNotFoundError, json.JSONDecodeError):
        return None
    except Exception as exc:
        log.debug(f"IPC error: {exc}")
        return None


def send_sync(msg: dict, timeout: float = 10.0) -> Optional[dict]:
    """Synchronous wrapper for CLI contexts without a running event loop."""
    try:
        return asyncio.run(send_command(msg, timeout))
    except Exception:
        return None


def daemon_is_running() -> bool:
    from cyborg.core.config import PID_FILE
    if not PID_FILE.exists():
        return False
    try:
        pid = int(PID_FILE.read_text().strip())
        import os
        os.kill(pid, 0)  # signal 0 = just check if process exists
        return True
    except (ProcessLookupError, PermissionError, ValueError):
        return False
