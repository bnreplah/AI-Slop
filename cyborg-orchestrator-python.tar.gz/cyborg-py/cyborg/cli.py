"""
cyborg.cli
~~~~~~~~~~
Click-based CLI entrypoint. All subcommands send JSON over the Unix socket
to the daemon; if the daemon isn't running, most read-commands work in-process.
"""
from __future__ import annotations

import asyncio
import json
import os
import signal
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Optional

import click
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich import box

from cyborg.core.config import (
    ORCH_ROOT, SOCKET_PATH, PID_FILE, LOG_FILE, VERSION,
    ensure_dirs,
)
from cyborg.ipc import send_sync, daemon_is_running

console = Console()


# ── Banner ────────────────────────────────────────────────────
BANNER = r"""
  ██████╗██╗   ██╗██████╗  ██████╗ ██████╗  ██████╗
 ██╔════╝╚██╗ ██╔╝██╔══██╗██╔═══██╗██╔══██╗██╔════╝
 ██║      ╚████╔╝ ██████╔╝██║   ██║██████╔╝██║  ███╗
 ██║       ╚██╔╝  ██╔══██╗██║   ██║██╔══██╗██║   ██║
 ╚██████╗   ██║   ██████╔╝╚██████╔╝██║  ██║╚██████╔╝
  ╚═════╝   ╚═╝   ╚═════╝  ╚═════╝ ╚═╝  ╚═╝ ╚═════╝
"""


def _ok_resp(result: Optional[dict], key: str = "data") -> Optional[dict]:
    if result and result.get("ok"):
        return result.get(key)
    if result:
        console.print(f"[red]Error:[/] {result.get('error', 'Unknown error')}")
    else:
        console.print("[red]Daemon not reachable.[/] Is it running? Try: cyborg daemon start")
    return None


def _status_color(s: str) -> str:
    return {
        "RUNNING": "green", "SUCCESS": "cyan", "FAILED": "red",
        "ABORTED": "yellow", "PENDING": "dim",
        "ONLINE": "green", "IDLE": "green", "OFFLINE": "dim",
        "BUSY": "yellow", "ERROR": "red",
    }.get(s, "white")


# ── Main group ────────────────────────────────────────────────
@click.group(invoke_without_command=True, context_settings={"help_option_names": ["-h", "--help"]})
@click.pass_context
def main(ctx: click.Context) -> None:
    """CYBORG Orchestrator — Distributed Agentic Terminal Engine"""
    if ctx.invoked_subcommand is None:
        console.print(BANNER, style="cyan bold")
        console.print(f"  [dim]v{VERSION} | Cybopsec | ORCH_ROOT={ORCH_ROOT}[/]")
        console.print("\n  Run [bold cyan]cyborg --help[/] for commands\n")


# ── Daemon commands ───────────────────────────────────────────
@main.group()
def daemon() -> None:
    """Daemon lifecycle management."""


@daemon.command("start")
@click.option("--foreground", "-f", is_flag=True, help="Run in foreground")
def daemon_start(foreground: bool) -> None:
    """Start the orchestrator daemon."""
    ensure_dirs()
    if daemon_is_running():
        console.print("[yellow]Daemon already running.[/]")
        return

    if foreground:
        console.print(f"[cyan]Starting CYBORG daemon v{VERSION} (foreground)...[/]")
        from cyborg.daemon import main as daemon_main
        daemon_main()
    else:
        proc = subprocess.Popen(
            [sys.executable, "-m", "cyborg.daemon"],
            stdout=open(LOG_FILE, "a"),
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )
        time.sleep(1.0)
        if daemon_is_running():
            console.print(f"[green]✓[/] Daemon started (PID {proc.pid})")
            console.print(f"  Socket: [dim]{SOCKET_PATH}[/]")
            console.print(f"  Logs:   [dim]{LOG_FILE}[/]")
        else:
            console.print("[red]Daemon failed to start. Check logs:[/]")
            console.print(f"  tail -f {LOG_FILE}")


@daemon.command("stop")
def daemon_stop() -> None:
    """Stop the daemon."""
    if not daemon_is_running():
        console.print("[yellow]Daemon not running.[/]")
        return
    result = send_sync({"cmd": "SHUTDOWN"})
    if result:
        console.print("[green]✓[/] Daemon shutdown requested.")
    else:
        # Try SIGTERM via PID
        try:
            pid = int(PID_FILE.read_text().strip())
            os.kill(pid, signal.SIGTERM)
            console.print(f"[green]✓[/] Sent SIGTERM to PID {pid}")
        except Exception as exc:
            console.print(f"[red]Error:[/] {exc}")


@daemon.command("status")
def daemon_status() -> None:
    """Show daemon status."""
    result = send_sync({"cmd": "STATUS"})
    if result and result.get("ok"):
        data = result["data"]
        t = Table(box=box.MINIMAL, show_header=False, padding=(0, 1))
        t.add_column(style="dim", width=24)
        t.add_column(style="cyan bold")
        for k, v in data.items():
            t.add_row(k, str(v))
        console.print(Panel(t, title="[cyan]Daemon Status[/]", border_style="cyan"))
    else:
        console.print("[red]Daemon not reachable[/]")


@daemon.command("logs")
@click.argument("lines", default=50, type=int)
def daemon_logs(lines: int) -> None:
    """Tail orchestrator logs."""
    if LOG_FILE.exists():
        for line in LOG_FILE.read_text().splitlines()[-lines:]:
            color = "dim"
            if "[ERROR]" in line:    color = "red"
            elif "[WARNING]" in line: color = "yellow"
            elif "[INFO]" in line:   color = "cyan"
            console.print(f"[{color}]{line}[/]")
    else:
        console.print("[dim]No log file found.[/]")


# ── TUI ───────────────────────────────────────────────────────
@main.command("tui")
def tui_cmd() -> None:
    """Launch the full-screen TUI."""
    ensure_dirs()
    from cyborg.ui.tui import run_tui
    run_tui()


# ── Pipeline commands ─────────────────────────────────────────
@main.group("pipeline", aliases=["pipe", "p"])
def pipeline_grp() -> None:
    """Pipeline management."""


@pipeline_grp.command("run")
@click.argument("name")
@click.option("--env", "-e", multiple=True, help="KEY=VALUE env pairs")
def pipeline_run(name: str, env: tuple) -> None:
    """Run a named pipeline."""
    env_dict = {}
    for e in env:
        k, _, v = e.partition("=")
        env_dict[k] = v
    result = send_sync({"cmd": "PIPELINE_RUN", "args": {"name": name, "env": env_dict}})
    data = _ok_resp(result)
    if data:
        console.print(f"[green]✓[/] Pipeline started: [cyan]{data.get('run_id')}[/]")


@pipeline_grp.command("list")
def pipeline_list() -> None:
    """List all pipeline runs."""
    result = send_sync({"cmd": "PIPELINE_LIST"})
    runs = _ok_resp(result)
    if runs is None:
        return
    t = Table("RUN ID", "STATUS", "NAME", box=box.SIMPLE, show_lines=False)
    for r in runs:
        sc = _status_color(r["status"])
        t.add_row(r["run_id"][:36], Text(r["status"], style=sc), r["name"])
    console.print(t)


@pipeline_grp.command("kill")
@click.argument("run_id")
def pipeline_kill(run_id: str) -> None:
    """Kill a running pipeline."""
    result = send_sync({"cmd": "PIPELINE_KILL", "args": {"run_id": run_id}})
    if result and result.get("ok"):
        console.print(f"[yellow]✓[/] Killed: {run_id}")
    else:
        console.print(f"[red]Could not kill {run_id}[/]")


@pipeline_grp.command("log")
@click.argument("run_id")
def pipeline_log(run_id: str) -> None:
    """Show pipeline execution log."""
    result = send_sync({"cmd": "PIPELINE_LOG", "args": {"run_id": run_id}})
    data = _ok_resp(result)
    if data:
        for line in data.get("lines", []):
            console.print(f"[dim]{line}[/]")


# ── Task commands ─────────────────────────────────────────────
@main.group("task", aliases=["t"])
def task_grp() -> None:
    """Task alias management."""


@task_grp.command("run")
@click.argument("name")
@click.argument("args", nargs=-1)
def task_run(name: str, args: tuple) -> None:
    """Run a task alias."""
    result = send_sync({"cmd": "TASK_RUN", "args": {"name": name, "args": list(args)}})
    if result and result.get("ok"):
        console.print(f"[green]✓[/] Task started: {name}")
    else:
        _ok_resp(result)


@task_grp.command("list")
def task_list() -> None:
    """List task aliases."""
    result = send_sync({"cmd": "TASK_LIST"})
    data = _ok_resp(result)
    if data:
        t = Table("TASK NAME", "COMMAND", box=box.SIMPLE)
        for name, cmd in data.items():
            t.add_row(f"[cyan]{name}[/]", cmd[:70])
        console.print(t)


@task_grp.command("add")
@click.argument("name")
@click.argument("command")
def task_add(name: str, command: str) -> None:
    """Register a task alias."""
    ensure_dirs()
    from cyborg.core.pipeline_engine import task_register, pipeline_load_saved
    pipeline_load_saved()
    task_register(name, command)
    console.print(f"[green]✓[/] Task registered: [cyan]{name}[/]")


# ── Scheduler commands ────────────────────────────────────────
@main.group("schedule", aliases=["sched"])
def schedule_grp() -> None:
    """Schedule management."""


@schedule_grp.command("add")
@click.argument("cron_spec")
@click.argument("target")
def schedule_add(cron_spec: str, target: str) -> None:
    """Add a cron schedule. Example: '*/5 * * * *' my_pipeline"""
    result = send_sync({
        "cmd": "SCHEDULE_ADD",
        "args": {"spec": cron_spec, "target": target},
    })
    data = _ok_resp(result)
    if data:
        console.print(f"[green]✓[/] Schedule added: [cyan]{data['sched_id']}[/]")


@schedule_grp.command("list")
def schedule_list() -> None:
    """List all schedules."""
    result = send_sync({"cmd": "SCHEDULE_LIST"})
    entries = _ok_resp(result)
    if entries is None:
        return
    t = Table("ID", "TYPE", "SPEC", "TARGET", "ENABLED", box=box.SIMPLE)
    for e in entries:
        spec = e["spec"]
        if e["type"] == "at":
            try:
                spec = datetime.fromtimestamp(int(spec)).strftime("%Y-%m-%d %H:%M")
            except Exception:
                pass
        en = Text("YES", style="green") if e["enabled"] else Text("no", style="dim")
        t.add_row(e["sched_id"][:16], e["type"], spec[:22], e["target"][:20], en)
    console.print(t)


@schedule_grp.command("remove")
@click.argument("sched_id")
def schedule_remove(sched_id: str) -> None:
    result = send_sync({"cmd": "SCHEDULE_REMOVE", "args": {"sched_id": sched_id}})
    if result and result.get("ok"):
        console.print(f"[green]✓[/] Removed: {sched_id}")


@schedule_grp.command("enable")
@click.argument("sched_id")
def schedule_enable(sched_id: str) -> None:
    send_sync({"cmd": "SCHEDULE_ENABLE", "args": {"sched_id": sched_id}})
    console.print(f"[green]✓[/] Enabled: {sched_id}")


@schedule_grp.command("disable")
@click.argument("sched_id")
def schedule_disable(sched_id: str) -> None:
    send_sync({"cmd": "SCHEDULE_DISABLE", "args": {"sched_id": sched_id}})
    console.print(f"[yellow]✓[/] Disabled: {sched_id}")


# ── Agent commands ────────────────────────────────────────────
@main.group("agent", aliases=["a"])
def agent_grp() -> None:
    """Agent management."""


@agent_grp.command("list")
def agent_list() -> None:
    """List registered agents."""
    result = send_sync({"cmd": "AGENT_LIST"})
    agents = _ok_resp(result)
    if agents is None:
        return
    t = Table("AGENT ID", "NAME", "TYPE", "STATUS", "CAPABILITIES", box=box.SIMPLE)
    for a in agents:
        sc = _status_color(a["status"])
        t.add_row(
            a["agent_id"][:20], a["name"][:18], a["type"],
            Text(a["status"], style=sc),
            ", ".join(a["capabilities"])[:30],
        )
    console.print(t)


@agent_grp.command("register")
@click.argument("agent_id")
@click.argument("name")
@click.option("--type", "-t", "atype", default="local",
              type=click.Choice(["local", "remote", "nested", "llm", "sensor"]))
@click.option("--capabilities", "-c", default="", help="Comma-separated capabilities")
def agent_register(agent_id: str, name: str, atype: str, capabilities: str) -> None:
    """Register an agent."""
    result = send_sync({
        "cmd": "AGENT_REGISTER",
        "args": {
            "agent_id": agent_id, "name": name, "type": atype,
            "capabilities": [c.strip() for c in capabilities.split(",") if c.strip()],
        },
    })
    data = _ok_resp(result)
    if data:
        console.print(f"[green]✓[/] Agent registered: [cyan]{data['agent_id']}[/]")


@agent_grp.command("delegate")
@click.argument("agent_id")
@click.argument("payload_json")
def agent_delegate(agent_id: str, payload_json: str) -> None:
    """Delegate a task to an agent."""
    try:
        payload = json.loads(payload_json)
    except json.JSONDecodeError:
        payload = {"raw": payload_json}
    result = send_sync({
        "cmd": "AGENT_DELEGATE",
        "args": {"agent_id": agent_id, "payload": payload},
    })
    data = _ok_resp(result)
    if data:
        console.print(f"[green]✓[/] Task delegated: [cyan]{data.get('task_id')}[/]")


@agent_grp.command("spawn")
@click.argument("nested_id")
def agent_spawn(nested_id: str) -> None:
    """Spawn a nested orchestrator."""
    result = send_sync({"cmd": "AGENT_SPAWN", "args": {"nested_id": nested_id}})
    data = _ok_resp(result)
    if data:
        console.print(f"[green]✓[/] Nested orchestrator spawned: [cyan]{nested_id}[/]")
        console.print(f"  Root: [dim]{data.get('root')}[/]")


# ── State machine commands ────────────────────────────────────
@main.group("sm", aliases=["state"])
def sm_grp() -> None:
    """State machine management."""


@sm_grp.command("list")
def sm_list() -> None:
    """List all state machines."""
    result = send_sync({"cmd": "SM_LIST"})
    sms = _ok_resp(result)
    if sms is None:
        return
    t = Table("SM ID", "STATE", "PARENT", "CHILDREN", box=box.SIMPLE)
    for s in sms:
        t.add_row(s["sm_id"][:28], f"[cyan]{s['state']}[/]",
                  s["parent"] or "-", str(len(s["children"])))
    console.print(t)


@sm_grp.command("state")
@click.argument("sm_id")
def sm_state(sm_id: str) -> None:
    """Get current state of a SM."""
    result = send_sync({"cmd": "SM_STATE", "args": {"sm_id": sm_id}})
    data = _ok_resp(result)
    if data:
        console.print(f"[cyan]{sm_id}[/] → [bold green]{data['state']}[/]")


@sm_grp.command("transition")
@click.argument("sm_id")
@click.argument("event")
def sm_transition(sm_id: str, event: str) -> None:
    """Fire a transition event on a SM."""
    result = send_sync({
        "cmd": "SM_TRANSITION",
        "args": {"sm_id": sm_id, "event": event, "data": {}},
    })
    data = _ok_resp(result)
    if data:
        console.print(f"[green]✓[/] {sm_id}: → [bold cyan]{data.get('new_state')}[/]")


@sm_grp.command("history")
@click.argument("sm_id")
@click.argument("limit", default=20, type=int)
def sm_history(sm_id: str, limit: int) -> None:
    """Show transition history for a SM."""
    result = send_sync({"cmd": "SM_HISTORY", "args": {"sm_id": sm_id, "limit": limit}})
    hist = _ok_resp(result)
    if hist:
        for h in hist:
            console.print(
                f"[dim]{h.get('ts','')}[/]  "
                f"[cyan]{h.get('from','?')}[/] "
                f"--[[yellow]{h.get('event','?')}[/]]--> "
                f"[green]{h.get('to','?')}[/]"
            )


@sm_grp.command("describe")
@click.argument("sm_id")
def sm_describe(sm_id: str) -> None:
    """Describe a SM structure."""
    result = send_sync({"cmd": "SM_DESCRIBE", "args": {"sm_id": sm_id}})
    data = _ok_resp(result)
    if data:
        console.print_json(json.dumps(data, indent=2))


# ── Sensor commands ───────────────────────────────────────────
@main.group("sensor")
def sensor_grp() -> None:
    """Sensor bus management."""


@sensor_grp.command("emit")
@click.argument("event_type")
@click.argument("data_json", default="{}")
def sensor_emit(event_type: str, data_json: str) -> None:
    """Emit a sensor event."""
    try:
        data = json.loads(data_json)
    except json.JSONDecodeError:
        data = {"raw": data_json}
    result = send_sync({
        "cmd": "SENSOR_EMIT",
        "args": {"event_type": event_type, "data": data},
    })
    if result and result.get("ok"):
        console.print(f"[green]✓[/] Emitted: [yellow]{event_type}[/]")


@sensor_grp.command("list")
def sensor_list() -> None:
    """List sensor subscriptions."""
    result = send_sync({"cmd": "SENSOR_LIST"})
    subs = _ok_resp(result)
    if subs is None:
        return
    t = Table("SUB ID", "PATTERN", "HANDLER", box=box.SIMPLE)
    for s in subs:
        t.add_row(s["sub_id"], f"[yellow]{s['pattern']}[/]", s.get("handler") or "-")
    console.print(t)


# ── Direct send ───────────────────────────────────────────────
@main.command("send")
@click.argument("cmd")
@click.argument("args_json", default="{}")
def send_cmd(cmd: str, args_json: str) -> None:
    """Send a raw JSON command to the daemon."""
    try:
        args = json.loads(args_json)
    except json.JSONDecodeError:
        args = {}
    result = send_sync({"cmd": cmd.upper(), "args": args})
    if result:
        console.print_json(json.dumps(result, indent=2))
    else:
        console.print("[red]No response from daemon[/]")


# ── Version ───────────────────────────────────────────────────
@main.command("version")
def version_cmd() -> None:
    console.print(f"[cyan]cyborg[/] {VERSION}")


if __name__ == "__main__":
    main()
