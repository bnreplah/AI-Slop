"""
cyborg.daemon
~~~~~~~~~~~~~
The orchestrator daemon.

Starts the Unix socket server, wires up all subsystems,
and runs the async event loop until SIGTERM/SIGINT.

IPC protocol: newline-delimited JSON over Unix socket.
Request:  {"cmd": "PIPELINE_RUN", "args": {...}}
Response: {"ok": true, "data": {...}} or {"ok": false, "error": "..."}
"""
from __future__ import annotations

import asyncio
import json
import os
import signal
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

from cyborg.core.config import (
    ORCH_ROOT, SOCKET_PATH, PID_FILE, LOG_FILE,
    VERSION, log, ensure_dirs, epoch,
)
import cyborg.core.state_machine   as sm_engine
import cyborg.core.pipeline_engine as pipeline_engine
import cyborg.core.sensor_bus      as sensor_bus
import cyborg.core.agent_registry  as agent_registry
import cyborg.core.scheduler       as scheduler


_start_time: int = 0


# ── IPC message handlers ──────────────────────────────────────
async def _handle_message(raw: str) -> dict:
    try:
        msg = json.loads(raw)
    except json.JSONDecodeError:
        return {"ok": False, "error": "Invalid JSON"}

    cmd = msg.get("cmd", "").upper()
    args = msg.get("args", {})

    try:
        match cmd:
            # ── Pipelines ───────────────────────────────────
            case "PIPELINE_RUN":
                run = await pipeline_engine.pipeline_run(
                    args.get("name", ""),
                    args.get("env", {}),
                )
                return {"ok": bool(run), "data": {"run_id": run.run_id if run else None}}

            case "PIPELINE_KILL":
                ok = pipeline_engine.pipeline_kill(args.get("run_id", ""))
                return {"ok": ok}

            case "PIPELINE_LIST":
                runs = pipeline_engine.pipeline_list_all()
                return {"ok": True, "data": [
                    {"run_id": r.run_id, "name": r.name, "status": r.status.value}
                    for r in runs
                ]}

            case "PIPELINE_LOG":
                run = pipeline_engine.pipeline_get(args.get("run_id", ""))
                return {"ok": bool(run), "data": {"lines": run.log_lines if run else []}}

            # ── Tasks ────────────────────────────────────────
            case "TASK_RUN":
                run = await pipeline_engine.task_run(
                    args.get("name", ""), args.get("args", [])
                )
                return {"ok": bool(run)}

            case "TASK_LIST":
                return {"ok": True, "data": pipeline_engine.task_list()}

            # ── State machines ───────────────────────────────
            case "SM_LIST":
                specs = sm_engine.sm_list()
                return {"ok": True, "data": [
                    {"sm_id": s.sm_id, "state": s.current_state,
                     "parent": s.parent_id, "children": s.children}
                    for s in specs
                ]}

            case "SM_STATE":
                state = sm_engine.sm_get_state(args.get("sm_id", ""))
                return {"ok": True, "data": {"state": state}}

            case "SM_TRANSITION":
                new_state = sm_engine.sm_transition(
                    args.get("sm_id", ""),
                    args.get("event", ""),
                    args.get("data", {}),
                )
                return {"ok": new_state is not None, "data": {"new_state": new_state}}

            case "SM_HISTORY":
                hist = sm_engine.sm_history(args.get("sm_id", ""),
                                            int(args.get("limit", 20)))
                return {"ok": True, "data": hist}

            case "SM_DESCRIBE":
                desc = sm_engine.sm_describe(args.get("sm_id", ""))
                return {"ok": bool(desc), "data": desc}

            # ── Agents ───────────────────────────────────────
            case "AGENT_LIST":
                agents = agent_registry.get_all()
                return {"ok": True, "data": [
                    {"agent_id": a.agent_id, "name": a.name,
                     "type": a.agent_type.value, "status": a.status.value,
                     "capabilities": a.capabilities}
                    for a in agents
                ]}

            case "AGENT_REGISTER":
                from cyborg.core.config import AgentType
                m = agent_registry.register(
                    agent_id=args["agent_id"],
                    name=args.get("name", args["agent_id"]),
                    agent_type=AgentType(args.get("type", "local")),
                    capabilities=args.get("capabilities", []),
                    endpoint=args.get("endpoint", "local"),
                )
                return {"ok": True, "data": {"agent_id": m.agent_id}}

            case "AGENT_DELEGATE":
                task_id = await agent_registry.delegate(
                    args.get("agent_id", ""),
                    args.get("payload", {}),
                )
                return {"ok": task_id is not None, "data": {"task_id": task_id}}

            case "AGENT_SPAWN":
                nested_root = agent_registry.spawn_nested(args.get("nested_id", ""))
                return {"ok": True, "data": {"root": str(nested_root)}}

            # ── Scheduler ────────────────────────────────────
            case "SCHEDULE_ADD":
                sid = scheduler.add_cron(
                    args.get("spec", "* * * * *"),
                    args.get("target", ""),
                    args.get("args", ""),
                )
                return {"ok": True, "data": {"sched_id": sid}}

            case "SCHEDULE_AT":
                dt = datetime.fromisoformat(args.get("at", ""))
                sid = scheduler.add_at(dt, args.get("target", ""))
                return {"ok": True, "data": {"sched_id": sid}}

            case "SCHEDULE_LIST":
                entries = scheduler.list_all()
                return {"ok": True, "data": [
                    {"sched_id": e.sched_id, "type": e.sched_type.value,
                     "spec": e.spec, "target": e.target, "enabled": e.enabled}
                    for e in entries
                ]}

            case "SCHEDULE_REMOVE":
                ok = scheduler.remove(args.get("sched_id", ""))
                return {"ok": ok}

            case "SCHEDULE_ENABLE":
                scheduler.enable(args.get("sched_id", ""))
                return {"ok": True}

            case "SCHEDULE_DISABLE":
                scheduler.disable(args.get("sched_id", ""))
                return {"ok": True}

            # ── Sensors ──────────────────────────────────────
            case "SENSOR_EMIT":
                sensor_bus.emit(args.get("event_type", "CUSTOM"), args.get("data", {}))
                return {"ok": True}

            case "SENSOR_LIST":
                subs = sensor_bus.list_subscriptions()
                return {"ok": True, "data": [
                    {"sub_id": s.sub_id, "pattern": s.pattern, "handler": s.handler}
                    for s in subs
                ]}

            # ── Status ───────────────────────────────────────
            case "STATUS":
                return {"ok": True, "data": {
                    "version": VERSION,
                    "pid": os.getpid(),
                    "uptime": epoch() - _start_time,
                    "pipelines_active": pipeline_engine.pipeline_count_active(),
                    "agents": agent_registry.count(),
                    "schedules": scheduler.count(),
                    "socket": str(SOCKET_PATH),
                }}

            case "SHUTDOWN":
                asyncio.get_event_loop().call_soon(_shutdown)
                return {"ok": True, "data": {"message": "Shutting down"}}

            case _:
                return {"ok": False, "error": f"Unknown command: {cmd}"}

    except Exception as exc:
        log.exception(f"IPC handler error for cmd={cmd}: {exc}")
        return {"ok": False, "error": str(exc)}


# ── Socket client handler ─────────────────────────────────────
async def _client_handler(
    reader: asyncio.StreamReader,
    writer: asyncio.StreamWriter,
) -> None:
    try:
        data = await asyncio.wait_for(reader.readline(), timeout=10.0)
        if data:
            response = await _handle_message(data.decode().strip())
            writer.write(json.dumps(response).encode() + b"\n")
            await writer.drain()
    except asyncio.TimeoutError:
        pass
    except Exception as exc:
        log.debug(f"Client handler error: {exc}")
    finally:
        writer.close()
        try:
            await writer.wait_closed()
        except Exception:
            pass


# ── Boot sequence ─────────────────────────────────────────────
async def _boot() -> None:
    global _start_time
    _start_time = epoch()
    ensure_dirs()

    log.info(f"CYBORG Orchestrator v{VERSION} booting...")

    # Wire up cross-module references
    pipeline_engine.set_event_emitter(sensor_bus.emit)
    sensor_bus.set_sm_transition_fn(sm_engine.sm_transition)
    sensor_bus.set_pipeline_run_fn(pipeline_engine.pipeline_run)
    scheduler.set_pipeline_run_fn(pipeline_engine.pipeline_run)

    # Start subsystems
    await sensor_bus.start()
    agent_registry.init()
    pipeline_engine.pipeline_load_saved()
    scheduler.load_saved()

    # Background loops
    asyncio.create_task(scheduler.tick_loop())
    asyncio.create_task(agent_registry.monitor_heartbeats())
    asyncio.create_task(_gc_loop())

    # Load plugins
    _load_plugins()

    log.info("All subsystems online.")


async def _gc_loop() -> None:
    while True:
        await asyncio.sleep(300)
        removed = pipeline_engine.pipeline_gc()
        if removed:
            log.debug(f"GC: removed {removed} completed pipeline records")


def _load_plugins() -> None:
    plugin_dir = ORCH_ROOT / "plugins"
    if not plugin_dir.exists():
        return
    import importlib.util, sys
    for py_file in sorted(plugin_dir.glob("*.plugin.py")):
        try:
            spec = importlib.util.spec_from_file_location(
                f"cyborg_plugin_{py_file.stem}", py_file
            )
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            if hasattr(module, "setup"):
                module.setup()
            log.info(f"Plugin loaded: {py_file.name}")
        except Exception as exc:
            log.warning(f"Plugin failed to load {py_file.name}: {exc}")


# ── Shutdown ──────────────────────────────────────────────────
def _shutdown() -> None:
    log.info("Shutting down...")
    sm_engine.sm_snapshot()
    if SOCKET_PATH.exists():
        SOCKET_PATH.unlink()
    if PID_FILE.exists():
        PID_FILE.unlink()
    sys.exit(0)


# ── Main ──────────────────────────────────────────────────────
async def _main() -> None:
    # Write PID
    PID_FILE.parent.mkdir(parents=True, exist_ok=True)
    PID_FILE.write_text(str(os.getpid()))

    # Remove stale socket
    if SOCKET_PATH.exists():
        SOCKET_PATH.unlink()

    await _boot()

    server = await asyncio.start_unix_server(_client_handler, path=str(SOCKET_PATH))
    log.info(f"Socket server listening: {SOCKET_PATH}")

    loop = asyncio.get_running_loop()
    for sig in (signal.SIGTERM, signal.SIGINT):
        loop.add_signal_handler(sig, _shutdown)

    async with server:
        await server.serve_forever()


def main() -> None:
    """Entry point for 'cyborg daemon start'."""
    try:
        asyncio.run(_main())
    except SystemExit:
        pass
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
