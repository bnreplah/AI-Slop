# CYBORG Orchestrator — Python Edition

> **Distributed Agentic Terminal Orchestration Engine**  
> Cybopsec | v1.0.0 | Python 3.11+ | asyncio-native | Textual TUI

```
  ██████╗██╗   ██╗██████╗  ██████╗ ██████╗  ██████╗
 ██╔════╝╚██╗ ██╔╝██╔══██╗██╔═══██╗██╔══██╗██╔════╝
 ██║      ╚████╔╝ ██████╔╝██║   ██║██████╔╝██║  ███╗
 ██║       ╚██╔╝  ██╔══██╗██║   ██║██╔══██╗██║   ██║
 ╚██████╗   ██║   ██████╔╝╚██████╔╝██║  ██║╚██████╔╝
  ╚═════╝   ╚═╝   ╚═════╝  ╚═════╝ ╚═╝  ╚═╝ ╚═════╝
```

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                     CYBORG ORCHESTRATOR (Python)                     │
├──────────────┬──────────────┬──────────────┬────────────────────────┤
│  Textual TUI │  Click CLI   │  Unix Socket │   Plugin Loader        │
│  (ui/tui.py) │  (cli.py)    │  IPC (ipc.py)│  (*.plugin.py)        │
├──────────────┴──────────────┴──────────────┴────────────────────────┤
│                         daemon.py (asyncio)                          │
│  ┌───────────────┐  ┌──────────────┐  ┌──────────────────────────┐  │
│  │ Pipeline      │  │ Scheduler    │  │ Sensor Bus               │  │
│  │ Engine        │  │ (cron/at)    │  │ (file/proc/port/metrics) │  │
│  │ (async DAG)   │  │              │  │                          │  │
│  └───────┬───────┘  └──────┬───────┘  └───────────┬──────────────┘  │
│          │                 │                       │                 │
│  ┌───────▼─────────────────▼───────────────────────▼──────────────┐  │
│  │                  State Machine Engine                           │  │
│  │  sm_create / sm_transition / guards / entry-exit hooks         │  │
│  │  Hierarchical: parent → child → nested, JSON-persisted         │  │
│  └──────────────────────────┬────────────────────────────────────┘   │
│                             │                                        │
│  ┌──────────────────────────▼────────────────────────────────────┐   │
│  │                   Agent Registry                               │   │
│  │  local / remote / nested / llm / sensor agents                │   │
│  │  Each agent: own SM + inbox + outbox + async handler          │   │
│  │  Nested orchestrators: full child orch tree in agents/        │   │
│  └────────────────────────────────────────────────────────────────┘  │
├─────────────────────────────────────────────────────────────────────┤
│          Persistence Layer  (~/.cyborg/)                             │
│  state/<sm_id>/spec.json  pipelines/<id>/  agents/<id>/manifest.json│
│  config/schedules.conf  config/pipelines.conf  config/tasks.conf    │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Quick Start

```bash
# Install
pip install rich textual click watchdog aiofiles
pip install -e .

# Start daemon
cyborg daemon start

# Open TUI
cyborg tui

# CLI
cyborg pipeline run security-baseline
cyborg sm list
cyborg agent list
cyborg schedule add "*/5 * * * *" system-health
cyborg daemon status
```

---

## File Structure

```
cyborg-py/
├── pyproject.toml
├── cyborg/
│   ├── __init__.py
│   ├── cli.py              ← Click CLI (all subcommands)
│   ├── daemon.py           ← Async daemon: socket server + boot
│   ├── ipc.py              ← Unix socket client (sync + async)
│   ├── core/
│   │   ├── config.py       ← Paths, enums, dataclasses, logging
│   │   ├── state_machine.py← Hierarchical SM engine (JSON-persisted)
│   │   ├── pipeline_engine.py ← Async DAG runner + task aliases
│   │   ├── sensor_bus.py   ← Async event bus + file/proc/port watchers
│   │   ├── agent_registry.py  ← Agent lifecycle + nested orch spawning
│   │   └── scheduler.py    ← Async cron + at + countdown
│   ├── ui/
│   │   └── tui.py          ← Textual TUI (9 pages, live-refresh)
│   └── plugins/
│       └── devsecops.plugin.py ← Example plugin
```

---

## TUI Pages

| Page | Description |
|------|-------------|
| **Dashboard** | Live stats: pipelines, agents, schedules, load, events |
| **Pipelines** | Run/kill/log pipeline runs with DataTable |
| **Agents** | Register, delegate tasks, spawn nested orchestrators |
| **State Machines** | Create SMs, fire transitions, view history |
| **Sensors** | Subscribe to events, emit, watch files |
| **Scheduler** | Cron/at/countdown schedules |
| **Tasks** | Register and run task aliases |
| **Logs** | Live orchestrator log tail |
| **Help** | All keybindings and IPC reference |

---

## IPC Protocol

The daemon exposes a Unix socket at `~/.cyborg/sockets/cyborg.sock`.  
Every request/response is newline-terminated JSON:

```json
→ {"cmd": "PIPELINE_RUN", "args": {"name": "my-pipeline", "env": {"K": "V"}}}
← {"ok": true, "data": {"run_id": "my-pipeline_1234567890"}}
```

```bash
# Direct socket send
echo '{"cmd":"STATUS"}' | socat - UNIX-CONNECT:~/.cyborg/sockets/cyborg.sock

# Via CLI
cyborg send STATUS
cyborg send PIPELINE_RUN '{"name":"system-health"}'
cyborg send SM_TRANSITION '{"sm_id":"deploy_lifecycle","event":"START"}'
```

---

## Pipeline Spec Format

```
step_name:command:timeout_sec:retry_count[:parallel_group]
```

Steps separated by `;`. Steps sharing a `parallel_group` value run concurrently via `asyncio.gather()`.

```python
pipeline_define("deploy", (
    "test:pytest tests/ -x:120:2;"
    "build:docker build -t app .:300:0;"
    "scan:trivy image app:60:0;"
    "push:docker push app:registry:60:1;"
    "notify-slack:curl -X POST $SLACK_URL -d ...:10:0:notify;"
    "notify-email:./send_email.sh:10:0:notify"
))
```

---

## Plugin API

Create `~/.cyborg/plugins/myplugin.plugin.py` with a `setup()` function:

```python
def setup():
    from cyborg.core.pipeline_engine import pipeline_define, task_register
    from cyborg.core.agent_registry import register, set_handler
    from cyborg.core.sensor_bus import subscribe, register_handler
    import cyborg.core.state_machine as sm
    from cyborg.core.config import AgentType

    # Register tasks
    task_register("my-task", "echo {0}")

    # Define pipelines
    pipeline_define("my-pipeline", "step1:echo start:5:0;step2:./run.sh:60:1")

    # Create state machine
    sm.sm_create("my_sm", "IDLE", ["IDLE", "RUNNING", "DONE"])
    sm.sm_add_transition("my_sm", "IDLE", "START", "RUNNING")

    def on_start(sm_id, frm, to, data):
        print(f"SM {sm_id} started!")
    sm.register_action("my_start", on_start)

    # Subscribe to events
    async def on_event(etype, data):
        print(f"Got event: {etype}")
    register_handler("my_handler", on_event)
    subscribe("MY_EVENT_*", handler="my_handler")

    # Register an agent
    register("my-agent", "My Agent", AgentType.LOCAL, ["compute"])

    async def my_handler(agent_id, task_id, payload):
        return f"processed: {payload}"
    set_handler("my-agent", my_handler)
```

---

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `ORCH_ROOT` | `~/.cyborg` | Root data directory |
| `ORCH_SOCKET` | `$ORCH_ROOT/sockets/cyborg.sock` | Unix socket path |
| `ORCH_LOG_LEVEL` | `INFO` | DEBUG / INFO / WARNING / ERROR |
| `ORCH_WORKERS` | `8` | Async pipeline concurrency hint |
| `ORCH_HEARTBEAT` | `5` | Daemon heartbeat interval (seconds) |
| `AGENT_HEARTBEAT_TIMEOUT` | `30` | Seconds before agent marked OFFLINE |
| `SENSOR_LOAD_THRESHOLD` | `4.0` | Load avg → SYSTEM_LOAD_HIGH event |
| `SENSOR_DISK_THRESHOLD` | `90` | Disk % → DISK_USAGE_HIGH event |
| `PIPELINE_GC_AGE` | `3600` | Seconds before completed pipelines GC'd |

---

## Nested Orchestrators

Each agent can host a full child orchestrator:

```bash
cyborg agent spawn worker-1
# Starts a second CYBORG daemon rooted at ~/.cyborg/agents/worker-1/orch/
# with its own socket, pipelines, SMs, and agents
```

```python
from cyborg.core.agent_registry import spawn_nested, start_nested
spawn_nested("worker-1")
await start_nested("worker-1")
```

---

## Dependencies

| Package | Required | Purpose |
|---------|----------|---------|
| `python>=3.11` | **Required** | match statements, asyncio improvements |
| `rich>=13` | **Required** | CLI output formatting |
| `textual>=0.80` | **Required** | TUI framework |
| `click>=8` | **Required** | CLI framework |
| `watchdog>=4` | Optional | inotify-backed file watching |
| `aiofiles` | Optional | Async file I/O |

All core engine functionality works with only `rich`, `textual`, and `click`.

---

*CYBORG Orchestrator Python Edition — Built by Cybopsec*  
*Aligned with DARM-ANN v6.0 architectural principles*
