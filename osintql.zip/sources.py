"""
OSINT Connectors — HIBP, VirusTotal, WHOIS, Hunter.io, CRT.sh
Cybopsec / OmniOSINT Framework

Env vars:
  OMNI_HIBP_API_KEY       — HaveIBeenPwned v3 API key
  OMNI_VIRUSTOTAL_API_KEY — VirusTotal API key
  OMNI_HUNTER_API_KEY     — Hunter.io API key
"""

import os
import asyncio
import aiohttp
from typing import List, Optional
from .base_connector import (
    BaseConnector, EntityType, QueryParams, OSINTResult,
    RateLimit, ResultType,
)


# ==========================================================================
# HaveIBeenPwned
# ==========================================================================

class HIBPConnector(BaseConnector):
    """
    HaveIBeenPwned v3 — email breach lookup + password hash check.
    Supports EMAIL entity type.
    """
    BASE_URL = "https://haveibeenpwned.com/api/v3"
    PWNED_URL = "https://api.pwnedpasswords.com"

    def __init__(self, api_key: Optional[str] = None):
        self._api_key = api_key or os.environ.get("OMNI_HIBP_API_KEY", "")
        self._rl = RateLimit(requests_per_minute=10, requests_per_day=1000)

    @property
    def name(self) -> str:
        return "hibp"

    @property
    def supported_entities(self) -> List[EntityType]:
        return [EntityType.EMAIL, EntityType.HASH]

    @property
    def rate_limit(self) -> RateLimit:
        return self._rl

    async def health_check(self) -> bool:
        return bool(self._api_key)

    async def _search(
        self, entity_type: EntityType, query: str, params: QueryParams
    ) -> List[OSINTResult]:
        if entity_type == EntityType.EMAIL:
            return await self._check_email(query)
        elif entity_type == EntityType.HASH:
            return await self._check_hash(query)
        return []

    async def _check_email(self, email: str) -> List[OSINTResult]:
        results = []
        url = f"{self.BASE_URL}/breachedaccount/{email}"
        headers = {
            "hibp-api-key": self._api_key,
            "user-agent": "OmniOSINT/1.0 (github.com/cybopsec/omni-osint)",
        }
        try:
            async with aiohttp.ClientSession() as s:
                async with s.get(url, headers=headers,
                                 params={"truncateResponse": "false"},
                                 timeout=aiohttp.ClientTimeout(total=15)) as resp:
                    if resp.status == 404:
                        return []   # no breaches found
                    resp.raise_for_status()
                    breaches = await resp.json()
        except aiohttp.ClientResponseError as e:
            if e.status == 404:
                return []
            raise

        for breach in breaches:
            results.append(self._make_result(
                result_type=ResultType.BREACH,
                entity_type=EntityType.EMAIL,
                value=email,
                raw=breach,
                confidence=0.99,
                tags=["breach", breach.get("Name", "").lower()],
                timestamp=breach.get("BreachDate"),
                metadata={
                    "breach_name":   breach.get("Name"),
                    "domain":        breach.get("Domain"),
                    "data_classes":  breach.get("DataClasses", []),
                    "pwn_count":     breach.get("PwnCount"),
                    "is_verified":   breach.get("IsVerified"),
                    "is_sensitive":  breach.get("IsSensitive"),
                },
            ))
        return results

    async def _check_hash(self, sha1_prefix: str) -> List[OSINTResult]:
        """k-Anonymity model: send first 5 chars of SHA-1, compare suffixes."""
        prefix = sha1_prefix[:5].upper()
        url = f"{self.PWNED_URL}/range/{prefix}"
        async with aiohttp.ClientSession() as s:
            async with s.get(url, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                resp.raise_for_status()
                text = await resp.text()

        results = []
        for line in text.strip().splitlines():
            suffix, count = line.split(":")
            full_hash = (prefix + suffix).lower()
            results.append(self._make_result(
                result_type=ResultType.BREACH,
                entity_type=EntityType.HASH,
                value=full_hash,
                raw={"hash": full_hash, "count": int(count)},
                confidence=0.99,
                tags=["pwned-password"],
                metadata={"occurrences": int(count)},
            ))
        return results


# ==========================================================================
# VirusTotal
# ==========================================================================

class VirusTotalConnector(BaseConnector):
    """
    VirusTotal v3 — malware/domain/IP/hash threat intelligence.
    Supports DOMAIN, IP, HASH, URL entity types.
    """
    BASE_URL = "https://www.virustotal.com/api/v3"

    def __init__(self, api_key: Optional[str] = None):
        self._api_key = api_key or os.environ.get("OMNI_VIRUSTOTAL_API_KEY", "")
        self._rl = RateLimit(requests_per_minute=4, requests_per_day=500)

    @property
    def name(self) -> str:
        return "virustotal"

    @property
    def supported_entities(self) -> List[EntityType]:
        return [EntityType.DOMAIN, EntityType.IP, EntityType.HASH, EntityType.URL]

    @property
    def rate_limit(self) -> RateLimit:
        return self._rl

    async def health_check(self) -> bool:
        return bool(self._api_key)

    async def _search(
        self, entity_type: EntityType, query: str, params: QueryParams
    ) -> List[OSINTResult]:
        endpoint_map = {
            EntityType.DOMAIN: f"/domains/{query}",
            EntityType.IP:     f"/ip_addresses/{query}",
            EntityType.HASH:   f"/files/{query}",
            EntityType.URL:    f"/urls/{self._url_id(query)}",
        }
        ep = endpoint_map.get(entity_type)
        if not ep:
            return []

        data = await self._get(ep)
        attrs = data.get("data", {}).get("attributes", {})
        stats = attrs.get("last_analysis_stats", {})
        malicious = stats.get("malicious", 0)
        total = sum(stats.values()) if stats else 0

        confidence = min(malicious / max(total, 1), 1.0) if malicious > 0 else 0.05
        tags = ["malicious"] if malicious > 0 else ["clean"]

        return [self._make_result(
            result_type=ResultType.THREAT_INTEL,
            entity_type=entity_type,
            value=query,
            raw=data,
            confidence=confidence,
            tags=tags,
            timestamp=str(attrs.get("last_analysis_date", "")),
            metadata={
                "malicious_engines": malicious,
                "total_engines":     total,
                "reputation":        attrs.get("reputation"),
                "categories":        attrs.get("categories", {}),
            },
        )]

    async def _get(self, path: str) -> dict:
        url = self.BASE_URL + path
        headers = {"x-apikey": self._api_key}
        async with aiohttp.ClientSession() as s:
            async with s.get(url, headers=headers,
                             timeout=aiohttp.ClientTimeout(total=20)) as resp:
                resp.raise_for_status()
                return await resp.json()

    @staticmethod
    def _url_id(url: str) -> str:
        """VT URL IDs are base64url-encoded without padding."""
        import base64
        return base64.urlsafe_b64encode(url.encode()).decode().rstrip("=")


# ==========================================================================
# WHOIS
# ==========================================================================

class WHOISConnector(BaseConnector):
    """
    WHOIS via whoisjson.com (no API key required for basic queries).
    Supports DOMAIN, IP entity types.
    """
    BASE_URL = "https://whoisjson.com/api/v1/whois"

    def __init__(self):
        self._rl = RateLimit(requests_per_minute=5, requests_per_day=500)

    @property
    def name(self) -> str:
        return "whois"

    @property
    def supported_entities(self) -> List[EntityType]:
        return [EntityType.DOMAIN, EntityType.IP, EntityType.ORG]

    @property
    def rate_limit(self) -> RateLimit:
        return self._rl

    @property
    def requires_auth(self) -> bool:
        return False

    async def health_check(self) -> bool:
        return True

    async def _search(
        self, entity_type: EntityType, query: str, params: QueryParams
    ) -> List[OSINTResult]:
        async with aiohttp.ClientSession() as s:
            async with s.get(
                self.BASE_URL,
                params={"domain": query},
                timeout=aiohttp.ClientTimeout(total=15)
            ) as resp:
                resp.raise_for_status()
                data = await resp.json()

        registrant = data.get("registrant", {})
        registrar = data.get("registrar", {})

        return [self._make_result(
            result_type=ResultType.WHOIS,
            entity_type=entity_type,
            value=query,
            raw=data,
            confidence=0.9,
            tags=["whois", "registration"],
            timestamp=data.get("creation_date"),
            metadata={
                "registrar":       registrar.get("name"),
                "registrant_org":  registrant.get("organization"),
                "registrant_country": registrant.get("country"),
                "creation_date":   data.get("creation_date"),
                "expiration_date": data.get("expiration_date"),
                "name_servers":    data.get("name_servers", []),
                "status":          data.get("status", []),
                "dnssec":          data.get("dnssec"),
            },
        )]


# ==========================================================================
# Hunter.io
# ==========================================================================

class HunterConnector(BaseConnector):
    """
    Hunter.io — email finder, email verifier, domain search.
    Supports EMAIL, DOMAIN, ORG entity types.
    """
    BASE_URL = "https://api.hunter.io/v2"

    def __init__(self, api_key: Optional[str] = None):
        self._api_key = api_key or os.environ.get("OMNI_HUNTER_API_KEY", "")
        self._rl = RateLimit(requests_per_minute=5, requests_per_day=250)

    @property
    def name(self) -> str:
        return "hunter"

    @property
    def supported_entities(self) -> List[EntityType]:
        return [EntityType.EMAIL, EntityType.DOMAIN, EntityType.ORG]

    @property
    def rate_limit(self) -> RateLimit:
        return self._rl

    async def health_check(self) -> bool:
        return bool(self._api_key)

    async def _search(
        self, entity_type: EntityType, query: str, params: QueryParams
    ) -> List[OSINTResult]:
        if entity_type == EntityType.EMAIL:
            return await self._verify_email(query)
        elif entity_type in (EntityType.DOMAIN, EntityType.ORG):
            return await self._domain_search(query, params.limit)
        return []

    async def _verify_email(self, email: str) -> List[OSINTResult]:
        data = await self._get("/email-verifier", params={"email": email})
        d = data.get("data", {})
        status = d.get("status", "unknown")
        confidence = {"deliverable": 0.95, "risky": 0.5, "undeliverable": 0.1}.get(status, 0.3)

        return [self._make_result(
            result_type=ResultType.MATCH,
            entity_type=EntityType.EMAIL,
            value=email,
            raw=data,
            confidence=confidence,
            tags=[f"status:{status}", "hunter-verified"],
            metadata={
                "status":        status,
                "score":         d.get("score"),
                "regexp":        d.get("regexp"),
                "gibberish":     d.get("gibberish"),
                "disposable":    d.get("disposable"),
                "webmail":       d.get("webmail"),
                "mx_records":    d.get("mx_records"),
                "smtp_server":   d.get("smtp_server"),
                "smtp_check":    d.get("smtp_check"),
                "accept_all":    d.get("accept_all"),
                "block":         d.get("block"),
            },
        )]

    async def _domain_search(self, domain: str, limit: int) -> List[OSINTResult]:
        data = await self._get("/domain-search",
                               params={"domain": domain, "limit": min(limit, 100)})
        d = data.get("data", {})
        results = []

        for email_info in d.get("emails", []):
            addr = email_info.get("value", "")
            if not addr:
                continue
            results.append(self._make_result(
                result_type=ResultType.MATCH,
                entity_type=EntityType.EMAIL,
                value=addr,
                raw=email_info,
                confidence=email_info.get("confidence", 50) / 100.0,
                tags=["hunter-discovery", f"type:{email_info.get('type','?')}"],
                timestamp=email_info.get("last_seen_on"),
                metadata={
                    "first_name": email_info.get("first_name"),
                    "last_name":  email_info.get("last_name"),
                    "position":   email_info.get("position"),
                    "department": email_info.get("department"),
                    "linkedin":   email_info.get("linkedin"),
                    "twitter":    email_info.get("twitter"),
                    "sources":    email_info.get("sources", []),
                },
            ))
        return results

    async def _get(self, path: str, params: Optional[dict] = None) -> dict:
        p = params or {}
        p["api_key"] = self._api_key
        async with aiohttp.ClientSession() as s:
            async with s.get(
                self.BASE_URL + path, params=p,
                timeout=aiohttp.ClientTimeout(total=15)
            ) as resp:
                resp.raise_for_status()
                return await resp.json()


# ==========================================================================
# CRT.sh (Certificate Transparency)
# ==========================================================================

class CRTSHConnector(BaseConnector):
    """
    crt.sh — Certificate Transparency log search.
    Supports DOMAIN, CERT, ORG entity types.
    No API key required.
    """
    BASE_URL = "https://crt.sh"

    def __init__(self):
        self._rl = RateLimit(requests_per_minute=10, requests_per_day=1000)

    @property
    def name(self) -> str:
        return "crtsh"

    @property
    def supported_entities(self) -> List[EntityType]:
        return [EntityType.DOMAIN, EntityType.CERT, EntityType.ORG, EntityType.EMAIL]

    @property
    def rate_limit(self) -> RateLimit:
        return self._rl

    @property
    def requires_auth(self) -> bool:
        return False

    async def health_check(self) -> bool:
        return True

    async def _search(
        self, entity_type: EntityType, query: str, params: QueryParams
    ) -> List[OSINTResult]:
        search_q = query
        if entity_type == EntityType.DOMAIN:
            search_q = f"%.{query}"

        async with aiohttp.ClientSession() as s:
            async with s.get(
                self.BASE_URL,
                params={"q": search_q, "output": "json"},
                timeout=aiohttp.ClientTimeout(total=30)
            ) as resp:
                if resp.status != 200:
                    return []
                certs = await resp.json()

        results = []
        seen_names = set()

        for cert in (certs or [])[:params.limit]:
            name = cert.get("name_value", "")
            # Handle SANs (multi-line name_value)
            for san in name.split("\n"):
                san = san.strip()
                if san and san not in seen_names:
                    seen_names.add(san)
                    results.append(self._make_result(
                        result_type=ResultType.CERTIFICATE,
                        entity_type=EntityType.DOMAIN,
                        value=san,
                        raw=cert,
                        confidence=0.95,
                        tags=["certificate-transparency", "san"],
                        timestamp=cert.get("entry_timestamp"),
                        metadata={
                            "issuer":       cert.get("issuer_name"),
                            "serial":       cert.get("serial_number"),
                            "not_before":   cert.get("not_before"),
                            "not_after":    cert.get("not_after"),
                            "cert_id":      cert.get("id"),
                            "logged_at":    cert.get("entry_timestamp"),
                        },
                    ))
        return results
