"""
omniod — OmniOSINT Background Daemon
Cybopsec / OmniOSINT Framework

Provides:
  - Unix domain socket IPC for low-latency local queries
  - HTTP REST API (localhost:7743) for programmatic access
  - Job queue with priority scheduling
  - Async worker pool
  - Structured JSON-Lines logging

Socket protocol (newline-delimited JSON):
  Request:  {"id": "<uuid>", "type": "query|health|status", "payload": "...OQL..."}
  Response: {"id": "<uuid>", "status": "ok|error", "results": [...], "errors": [...]}

Usage:
  python -m omni_osint.daemon.daemon start
  python -m omni_osint.daemon.daemon stop
  python -m omni_osint.daemon.daemon status
"""

import asyncio
import json
import logging
import os
import signal
import sys
import uuid
from dataclasses import dataclass, field, asdict
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

DEFAULT_SOCKET_PATH = "/tmp/omniod.sock"
DEFAULT_HTTP_HOST   = "127.0.0.1"
DEFAULT_HTTP_PORT   = 7743
DEFAULT_MAX_WORKERS = 8
DAEMON_PID_FILE     = "/tmp/omniod.pid"

log = logging.getLogger("omniod")


# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------

@dataclass
class DaemonRequest:
    id:      str
    type:    str        # "query" | "health" | "status" | "cancel"
    payload: str = ""   # OQL source or empty
    priority: int = 5   # 1 (high) – 10 (low)
    timeout:  int = 60  # seconds

    @classmethod
    def from_json(cls, raw: str) -> "DaemonRequest":
        d = json.loads(raw)
        return cls(
            id=d.get("id", str(uuid.uuid4())),
            type=d.get("type", "query"),
            payload=d.get("payload", ""),
            priority=d.get("priority", 5),
            timeout=d.get("timeout", 60),
        )


@dataclass
class DaemonResponse:
    id:      str
    status:  str         # "ok" | "error" | "partial"
    results: List[Dict[str, Any]] = field(default_factory=list)
    errors:  List[Dict[str, Any]] = field(default_factory=list)
    meta:    Dict[str, Any]       = field(default_factory=dict)
    elapsed_ms: float = 0.0

    def to_json(self) -> str:
        return json.dumps(asdict(self), default=str)


# ---------------------------------------------------------------------------
# Job Queue
# ---------------------------------------------------------------------------

@dataclass(order=True)
class Job:
    priority: int
    request:  DaemonRequest = field(compare=False)
    submitted_at: datetime  = field(default_factory=datetime.utcnow, compare=False)
    future: Optional[asyncio.Future] = field(default=None, compare=False)


class JobQueue:
    def __init__(self, maxsize: int = 1000):
        self._q: asyncio.PriorityQueue = asyncio.PriorityQueue(maxsize=maxsize)
        self._active: Dict[str, Job] = {}
        self._done:   Dict[str, DaemonResponse] = {}

    async def submit(self, request: DaemonRequest) -> asyncio.Future:
        loop = asyncio.get_event_loop()
        future = loop.create_future()
        job = Job(priority=request.priority, request=request, future=future)
        self._active[request.id] = job
        await self._q.put(job)
        return future

    async def get(self) -> Job:
        job = await self._q.get()
        return job

    def complete(self, job_id: str, response: DaemonResponse):
        job = self._active.pop(job_id, None)
        self._done[job_id] = response
        if job and job.future and not job.future.done():
            job.future.set_result(response)

    def fail(self, job_id: str, error: str):
        job = self._active.pop(job_id, None)
        resp = DaemonResponse(id=job_id, status="error",
                              errors=[{"code": "JOB_FAILED", "message": error}])
        self._done[job_id] = resp
        if job and job.future and not job.future.done():
            job.future.set_result(resp)

    def status(self) -> Dict:
        return {
            "queued": self._q.qsize(),
            "active": len(self._active),
            "completed": len(self._done),
        }


# ---------------------------------------------------------------------------
# Daemon Core
# ---------------------------------------------------------------------------

class OmniDaemon:
    """
    Async daemon that accepts OQL requests, executes them via QueryExecutor,
    and returns structured results.
    """

    def __init__(
        self,
        socket_path: str = DEFAULT_SOCKET_PATH,
        http_host:   str = DEFAULT_HTTP_HOST,
        http_port:   int = DEFAULT_HTTP_PORT,
        max_workers: int = DEFAULT_MAX_WORKERS,
    ):
        self.socket_path = socket_path
        self.http_host   = http_host
        self.http_port   = http_port
        self.max_workers = max_workers
        self._queue      = JobQueue()
        self._executor   = None
        self._registry   = None
        self._running    = False
        self._start_time = datetime.utcnow()

    async def start(self):
        """Initialize connectors and start all server coroutines."""
        self._setup_logging()
        log.info("omniod starting — socket=%s http=%s:%d",
                 self.socket_path, self.http_host, self.http_port)

        # Import here to avoid circular deps at module level
        from ..connectors.registry import build_default_registry
        from ..executor import QueryExecutor
        self._registry = build_default_registry()
        self._executor = QueryExecutor(self._registry)

        self._running = True

        # Write PID
        Path(DAEMON_PID_FILE).write_text(str(os.getpid()))

        # Start worker pool
        workers = [asyncio.create_task(self._worker(i))
                   for i in range(self.max_workers)]

        # Start socket server
        sock_server = await asyncio.start_unix_server(
            self._handle_socket_client, path=self.socket_path
        )

        # Start HTTP server
        http_server = await self._start_http_server()

        log.info("omniod ready — %d connectors registered, %d workers",
                 len(self._registry), self.max_workers)

        try:
            async with sock_server:
                await asyncio.gather(sock_server.serve_forever(), http_server)
        finally:
            for w in workers:
                w.cancel()
            self._running = False
            log.info("omniod stopped")

    # ------------------------------------------------------------------
    # Worker pool
    # ------------------------------------------------------------------

    async def _worker(self, worker_id: int):
        log.debug("worker-%d started", worker_id)
        while self._running:
            try:
                job = await asyncio.wait_for(self._queue.get(), timeout=1.0)
            except asyncio.TimeoutError:
                continue

            log.info("worker-%d processing job %s", worker_id, job.request.id)
            start = asyncio.get_event_loop().time()

            try:
                response = await asyncio.wait_for(
                    self._process_request(job.request),
                    timeout=job.request.timeout
                )
                response.elapsed_ms = (asyncio.get_event_loop().time() - start) * 1000
                self._queue.complete(job.request.id, response)
            except asyncio.TimeoutError:
                self._queue.fail(job.request.id, f"Job timed out after {job.request.timeout}s")
            except Exception as exc:
                log.error("worker-%d job %s failed: %s", worker_id, job.request.id, exc, exc_info=True)
                self._queue.fail(job.request.id, str(exc))

    # ------------------------------------------------------------------
    # Request processing
    # ------------------------------------------------------------------

    async def _process_request(self, req: DaemonRequest) -> DaemonResponse:
        if req.type == "health":
            health = await self._registry.health_report()
            return DaemonResponse(id=req.id, status="ok",
                                  meta={"health": health,
                                        "connectors": list(health.keys())})

        if req.type == "status":
            return DaemonResponse(id=req.id, status="ok",
                                  meta={"queue": self._queue.status(),
                                        "uptime_s": (datetime.utcnow() - self._start_time).total_seconds()})

        if req.type == "query":
            from ..oql.parser import parse
            program = parse(req.payload)
            exec_results = await self._executor.execute(program)

            all_results, all_errors = [], []
            for er in exec_results:
                all_results.extend([r.to_dict() for r in er.results])
                all_errors.extend([{"source": e.source, "code": e.code,
                                    "message": e.message} for e in er.errors])

            return DaemonResponse(
                id=req.id,
                status="ok" if not all_errors else "partial",
                results=all_results,
                errors=all_errors,
                meta={"result_count": len(all_results), "error_count": len(all_errors)},
            )

        return DaemonResponse(id=req.id, status="error",
                              errors=[{"code": "UNKNOWN_TYPE",
                                       "message": f"Unknown request type: {req.type}"}])

    # ------------------------------------------------------------------
    # Socket IPC handler
    # ------------------------------------------------------------------

    async def _handle_socket_client(
        self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter
    ):
        peer = writer.get_extra_info("peername", "unix")
        log.debug("socket connection from %s", peer)
        try:
            while True:
                raw = await reader.readline()
                if not raw:
                    break
                try:
                    request = DaemonRequest.from_json(raw.decode().strip())
                except Exception as e:
                    resp = DaemonResponse(
                        id="?", status="error",
                        errors=[{"code": "PARSE_ERROR", "message": str(e)}]
                    )
                    writer.write((resp.to_json() + "\n").encode())
                    await writer.drain()
                    continue

                future = await self._queue.submit(request)
                response = await future
                writer.write((response.to_json() + "\n").encode())
                await writer.drain()
        except asyncio.IncompleteReadError:
            pass
        finally:
            writer.close()

    # ------------------------------------------------------------------
    # HTTP server (aiohttp)
    # ------------------------------------------------------------------

    async def _start_http_server(self):
        try:
            from aiohttp import web
        except ImportError:
            log.warning("aiohttp not installed; HTTP server disabled")
            return asyncio.sleep(float("inf"))

        app = web.Application()
        app.router.add_post("/query",  self._http_query)
        app.router.add_get("/health",  self._http_health)
        app.router.add_get("/status",  self._http_status)
        app.router.add_get("/sources", self._http_sources)

        runner = web.AppRunner(app)
        await runner.setup()
        site = web.TCPSite(runner, self.http_host, self.http_port)
        await site.start()
        log.info("HTTP API listening on http://%s:%d", self.http_host, self.http_port)
        return asyncio.sleep(float("inf"))  # keep alive

    async def _http_query(self, request):
        from aiohttp import web
        try:
            body = await request.json()
        except Exception:
            return web.json_response({"error": "Invalid JSON"}, status=400)

        req = DaemonRequest(
            id=str(uuid.uuid4()),
            type="query",
            payload=body.get("query", ""),
            priority=body.get("priority", 5),
            timeout=body.get("timeout", 60),
        )
        future = await self._queue.submit(req)
        resp = await asyncio.wait_for(future, timeout=req.timeout + 5)
        return web.json_response(json.loads(resp.to_json()))

    async def _http_health(self, request):
        from aiohttp import web
        req = DaemonRequest(id=str(uuid.uuid4()), type="health")
        future = await self._queue.submit(req)
        resp = await asyncio.wait_for(future, timeout=15)
        return web.json_response(json.loads(resp.to_json()))

    async def _http_status(self, request):
        from aiohttp import web
        return web.json_response({
            "queue": self._queue.status(),
            "uptime_s": (datetime.utcnow() - self._start_time).total_seconds(),
            "connectors": [c.name for c in self._registry.all()],
        })

    async def _http_sources(self, request):
        from aiohttp import web
        sources = []
        for c in self._registry.all():
            sources.append({
                "name":             c.name,
                "supported_entities": [e.value for e in c.supported_entities],
                "requires_auth":    c.requires_auth,
                "rate_limit": {
                    "per_minute": c.rate_limit.requests_per_minute,
                    "per_day":    c.rate_limit.requests_per_day,
                },
            })
        return web.json_response({"sources": sources})

    # ------------------------------------------------------------------
    # Utilities
    # ------------------------------------------------------------------

    @staticmethod
    def _setup_logging():
        logging.basicConfig(
            level=logging.INFO,
            format='{"time":"%(asctime)s","level":"%(levelname)s","name":"%(name)s","msg":%(message)s}',
            handlers=[logging.StreamHandler(sys.stdout)],
        )


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

def main():
    import argparse
    p = argparse.ArgumentParser(prog="omniod", description="OmniOSINT Daemon")
    sub = p.add_subparsers(dest="cmd")

    start_p = sub.add_parser("start")
    start_p.add_argument("--socket", default=DEFAULT_SOCKET_PATH)
    start_p.add_argument("--host",   default=DEFAULT_HTTP_HOST)
    start_p.add_argument("--port",   type=int, default=DEFAULT_HTTP_PORT)
    start_p.add_argument("--workers",type=int, default=DEFAULT_MAX_WORKERS)

    sub.add_parser("stop")
    sub.add_parser("status")

    args = p.parse_args()

    if args.cmd == "start":
        daemon = OmniDaemon(
            socket_path=args.socket,
            http_host=args.host,
            http_port=args.port,
            max_workers=args.workers,
        )

        def _handle_signal(sig, _):
            log.info("Received signal %s — shutting down", sig)
            sys.exit(0)

        signal.signal(signal.SIGINT,  _handle_signal)
        signal.signal(signal.SIGTERM, _handle_signal)

        asyncio.run(daemon.start())

    elif args.cmd == "stop":
        try:
            pid = int(Path(DAEMON_PID_FILE).read_text())
            os.kill(pid, signal.SIGTERM)
            print(f"Sent SIGTERM to omniod (pid {pid})")
        except FileNotFoundError:
            print("omniod is not running (no PID file)")
        except ProcessLookupError:
            print("omniod process not found")

    elif args.cmd == "status":
        import socket
        sock_path = DEFAULT_SOCKET_PATH
        try:
            s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            s.connect(sock_path)
            req = json.dumps({"id": str(uuid.uuid4()), "type": "status"}) + "\n"
            s.sendall(req.encode())
            data = b""
            while b"\n" not in data:
                chunk = s.recv(4096)
                if not chunk:
                    break
                data += chunk
            s.close()
            resp = json.loads(data.decode().strip())
            print(json.dumps(resp, indent=2))
        except Exception as e:
            print(f"Could not connect to omniod at {sock_path}: {e}")

    else:
        p.print_help()


if __name__ == "__main__":
    main()
