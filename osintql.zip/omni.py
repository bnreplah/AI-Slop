#!/usr/bin/env python3
"""
omni — OmniOSINT CLI
Cybopsec / OmniOSINT Framework

Commands:
  omni query  <oql>           Run an OQL query
  omni search <type> <query>  Quick search shorthand
  omni health                 Check connector health
  omni status                 Daemon status
  omni sources                List available sources
  omni repl                   Interactive OQL REPL
  omni run    <file.oql>      Execute an OQL script file

Options:
  --socket PATH       Unix socket path (default: /tmp/omniod.sock)
  --http URL          HTTP base URL (e.g. http://localhost:7743)
  --format json|table Output format (default: table)
  --confidence FLOAT  Minimum confidence filter
  --limit INT         Result limit
  --no-daemon         Run query in-process (no daemon required)
"""

import argparse
import asyncio
import json
import os
import sys
from pathlib import Path
from typing import List, Optional


# ANSI color helpers
def _c(code: str, text: str) -> str:
    if not sys.stdout.isatty():
        return text
    return f"\033[{code}m{text}\033[0m"

RED     = lambda t: _c("31", t)
GREEN   = lambda t: _c("32", t)
YELLOW  = lambda t: _c("33", t)
CYAN    = lambda t: _c("36", t)
BOLD    = lambda t: _c("1",  t)
DIM     = lambda t: _c("2",  t)
MAGENTA = lambda t: _c("35", t)


BANNER = f"""{CYAN(BOLD("╔═══════════════════════════════════════╗"))}
{CYAN(BOLD("║"))}  {BOLD("OmniOSINT")} — Mass OSINT Query Framework  {CYAN(BOLD("║"))}
{CYAN(BOLD("║"))}  {DIM("Cybopsec  |  Type 'help' for commands")}  {CYAN(BOLD("║"))}
{CYAN(BOLD("╚═══════════════════════════════════════╝"))}"""


def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="omni",
        description="OmniOSINT — OSINT Query Language CLI",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    p.add_argument("--socket",  default="/tmp/omniod.sock")
    p.add_argument("--http",    default=None,
                   help="HTTP base URL instead of Unix socket")
    p.add_argument("--format",  choices=["table", "json", "csv"], default="table")
    p.add_argument("--confidence", type=float, default=0.0)
    p.add_argument("--limit",   type=int, default=100)
    p.add_argument("--no-daemon", action="store_true",
                   help="Execute in-process without daemon")

    sub = p.add_subparsers(dest="command")

    # query
    qp = sub.add_parser("query", help="Execute OQL query string")
    qp.add_argument("oql", nargs="+", help="OQL query (quoted or multi-arg)")

    # search
    sp = sub.add_parser("search", help="Quick entity search")
    sp.add_argument("type",  help="Entity type: DOMAIN, IP, EMAIL, etc.")
    sp.add_argument("query", help="Search value")
    sp.add_argument("--via", nargs="+", help="Specific sources to use")

    # health
    sub.add_parser("health", help="Check connector health")

    # status
    sub.add_parser("status", help="Daemon status")

    # sources
    sub.add_parser("sources", help="List available connectors")

    # run
    rp = sub.add_parser("run", help="Execute an .oql script file")
    rp.add_argument("file", help="Path to .oql file")

    # repl
    sub.add_parser("repl", help="Interactive OQL REPL")

    return p


# ===========================================================================
# Output rendering
# ===========================================================================

def _print_table(results, confidence_min: float = 0.0):
    if not results:
        print(DIM("  (no results)"))
        return

    filtered = [r for r in results if r.confidence >= confidence_min]
    if not filtered:
        print(DIM(f"  (all results below confidence {confidence_min})"))
        return

    # Column widths
    cols = ["SOURCE", "TYPE", "VALUE", "CONF", "TAGS"]
    rows = [
        [r.source, r.entity_type, r.value[:60],
         f"{r.confidence:.2f}", ", ".join(r.tags[:3])]
        for r in filtered
    ]
    widths = [max(len(c), max((len(row[i]) for row in rows), default=0))
              for i, c in enumerate(cols)]

    def _row(cells, bold=False):
        parts = [cell.ljust(widths[i]) for i, cell in enumerate(cells)]
        line = "  " + "  ".join(parts)
        return BOLD(line) if bold else line

    print()
    print(_row(cols, bold=True))
    print("  " + "  ".join("─" * w for w in widths))
    for row in rows:
        conf_val = float(row[3])
        if conf_val >= 0.9:
            row[3] = GREEN(row[3])
        elif conf_val >= 0.5:
            row[3] = YELLOW(row[3])
        else:
            row[3] = RED(row[3])
        print(_row(row))
    print()
    print(DIM(f"  {len(filtered)} result(s)"))


def _print_json(results):
    data = []
    for r in results:
        data.append({
            "source": r.source, "type": r.entity_type, "value": r.value,
            "confidence": r.confidence, "tags": r.tags,
            "timestamp": r.timestamp, "metadata": r.metadata,
        })
    print(json.dumps(data, indent=2, default=str))


def _print_errors(errors):
    if errors:
        print()
        for e in errors:
            src = e.get("source", "?")
            msg = e.get("message", "?")
            print(f"  {RED('⚠')}  [{src}] {msg}")


def _render(results, errors, fmt, confidence_min):
    if fmt == "json":
        _print_json(results)
    elif fmt == "csv":
        import csv, io
        out = io.StringIO()
        if results:
            w = csv.DictWriter(out, fieldnames=["source","type","value","confidence","tags","timestamp"])
            w.writeheader()
            for r in results:
                w.writerow({"source": r.source, "type": r.entity_type,
                             "value": r.value, "confidence": r.confidence,
                             "tags": ",".join(r.tags), "timestamp": r.timestamp or ""})
        print(out.getvalue(), end="")
    else:
        _print_table(results, confidence_min)
    _print_errors(errors)


# ===========================================================================
# In-process execution (no daemon)
# ===========================================================================

async def _run_inline(oql: str) -> "ResultSet":
    from ..connectors.registry import build_default_registry
    from ..executor import QueryExecutor
    from ..oql.parser import parse
    from ..sdk.client import ResultSet, Result

    registry = build_default_registry()
    executor = QueryExecutor(registry)
    program  = parse(oql)
    exec_results = await executor.execute(program)

    all_results, all_errors = [], []
    for er in exec_results:
        all_results.extend([Result.from_dict(r.to_dict()) for r in er.results])
        all_errors.extend([{"source": e.source, "code": e.code, "message": e.message}
                            for e in er.errors])
    return ResultSet(all_results, all_errors)


# ===========================================================================
# REPL
# ===========================================================================

async def _repl(args):
    from ..sdk.client import OmniClient
    print(BANNER)
    print(f"\n{DIM('Connected to')} {args.socket}")
    print(f"{DIM('Type OQL queries, or: help | exit | clear')}\n")

    history = []
    prompt = f"{CYAN('oql')} {BOLD('>')} "

    try:
        import readline
        readline.set_history_length(200)
    except ImportError:
        pass

    async with OmniClient(
        socket_path=None if args.http else args.socket,
        http_base=args.http
    ) as client:
        while True:
            try:
                line = input(prompt).strip()
            except (EOFError, KeyboardInterrupt):
                print("\nBye.")
                break

            if not line:
                continue
            if line.lower() in ("exit", "quit", "\\q"):
                print("Bye.")
                break
            if line.lower() == "clear":
                print("\033[2J\033[H", end="")
                continue
            if line.lower() == "help":
                _repl_help()
                continue
            if line.lower() == "history":
                for i, h in enumerate(history, 1):
                    print(f"  {DIM(str(i))}  {h}")
                continue

            history.append(line)

            # Multi-line support: continue if line ends with |>
            while line.rstrip().endswith("|>") or line.rstrip().endswith("\\"):
                try:
                    cont = input(f"{DIM('...')} ").strip()
                    line = line.rstrip("\\").rstrip() + "\n" + cont
                except (EOFError, KeyboardInterrupt):
                    break

            try:
                print(DIM("  executing…"))
                rs = await client.query(line)
                _render(list(rs), rs.errors, args.format, args.confidence)
                summary = rs.summary()
                print(DIM(f"  sources: {list(summary['by_source'].keys())}"))
            except Exception as e:
                print(f"  {RED('Error:')} {e}")


def _repl_help():
    print(f"""
{BOLD('OQL Quick Reference')}

  {CYAN('SEARCH')} <type> <"value">      — Search for an entity
  {CYAN('PIVOT')}  <type>                — Pivot to related entity type
  {CYAN('ENRICH')} [source1, source2]    — Enrich results with extra data
  {CYAN('CORRELATE')} <type>             — Find correlated entities
  {CYAN('TRACE')} <type>:<depth>         — Multi-hop relationship trace
  {CYAN('MONITOR')} <type> <"value">:<n> — Watch for changes every n seconds

  Clauses (append to any command):
    WHERE <field> <op> <value>    Filter results
    VIA [src1, src2]              Use specific sources
    LIMIT <n>                     Max results
    SINCE "<datetime>"            Time filter
    CONFIDENCE >= <0.0–1.0>       Minimum confidence
    EXCLUDE [src1]                Skip sources

  Pipeline operator: {BOLD('|>')}

  Output: {BOLD('AS')} JSON|TABLE|CSV|GRAPH ({BOLD('TO')} "file.json")

  {DIM('Examples:')}
    SEARCH DOMAIN "example.com"
    SEARCH EMAIL "user@corp.com" |> ENRICH [hibp, hunter] AS TABLE
    SEARCH IP "1.2.3.4" WHERE confidence >= 0.8 VIA [shodan, virustotal]
""")


# ===========================================================================
# Main
# ===========================================================================

async def _async_main(args):
    from ..sdk.client import OmniClient

    # ---- query ----
    if args.command == "query":
        oql = " ".join(args.oql)
        if args.no_daemon:
            rs = await _run_inline(oql)
        else:
            async with OmniClient(
                socket_path=None if args.http else args.socket,
                http_base=args.http,
                timeout=120,
            ) as c:
                rs = await c.query(oql)
        _render(list(rs), rs.errors, args.format, args.confidence)

    # ---- search ----
    elif args.command == "search":
        oql = f'SEARCH {args.type.upper()} "{args.query}"'
        if args.via:
            oql += f"\n  VIA [{', '.join(args.via)}]"
        oql += f"\n  LIMIT {args.limit}"
        if args.confidence:
            oql += f"\n  CONFIDENCE >= {args.confidence}"
        if args.no_daemon:
            rs = await _run_inline(oql)
        else:
            async with OmniClient(
                socket_path=None if args.http else args.socket,
                http_base=args.http,
            ) as c:
                rs = await c.query(oql)
        _render(list(rs), rs.errors, args.format, args.confidence)

    # ---- health ----
    elif args.command == "health":
        async with OmniClient(socket_path=args.socket, http_base=args.http) as c:
            h = await c.health()
        health_data = h.get("health", {})
        print(f"\n{BOLD('Connector Health')}\n")
        for name, ok in health_data.items():
            icon = GREEN("✔") if ok else RED("✘")
            print(f"  {icon}  {name}")
        print()

    # ---- status ----
    elif args.command == "status":
        async with OmniClient(socket_path=args.socket, http_base=args.http) as c:
            s = await c.status()
        print(json.dumps(s, indent=2))

    # ---- sources ----
    elif args.command == "sources":
        if args.no_daemon:
            from ..connectors.registry import build_default_registry
            reg = build_default_registry()
            print(f"\n{BOLD('Available Connectors')}\n")
            for c in reg.all():
                auth = DIM("(key required)") if c.requires_auth else GREEN("(free)")
                ents = ", ".join(e.value for e in c.supported_entities)
                print(f"  {CYAN(c.name.ljust(14))}  {auth}  [{ents}]")
            print()
        else:
            try:
                import aiohttp
                async with aiohttp.ClientSession() as s:
                    async with s.get(f"http://{args.socket.replace('/tmp/omniod.sock','127.0.0.1:7743')}/sources") as r:
                        data = await r.json()
                print(json.dumps(data, indent=2))
            except Exception:
                print(DIM("Could not reach daemon; use --no-daemon to list local connectors"))

    # ---- run ----
    elif args.command == "run":
        path = Path(args.file)
        if not path.exists():
            print(RED(f"File not found: {path}"))
            sys.exit(1)
        oql = path.read_text()
        if args.no_daemon:
            rs = await _run_inline(oql)
        else:
            async with OmniClient(socket_path=args.socket, http_base=args.http) as c:
                rs = await c.query(oql)
        _render(list(rs), rs.errors, args.format, args.confidence)

    # ---- repl ----
    elif args.command == "repl":
        await _repl(args)

    else:
        _build_parser().print_help()


def main():
    parser = _build_parser()
    args   = parser.parse_args()
    try:
        asyncio.run(_async_main(args))
    except KeyboardInterrupt:
        print("\nInterrupted.")
    except Exception as e:
        print(f"{RED('Error:')} {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
