"""
Shodan Connector — IP/Domain/Cert/Port intelligence
Cybopsec / OmniOSINT Framework

Env vars:
  OMNI_SHODAN_API_KEY — Shodan API key
"""

import os
import aiohttp
from typing import List, Optional
from .base_connector import (
    BaseConnector, EntityType, QueryParams, OSINTResult,
    RateLimit, ResultType,
)


class ShodanConnector(BaseConnector):

    BASE_URL = "https://api.shodan.io"

    def __init__(self, api_key: Optional[str] = None):
        self._api_key = api_key or os.environ.get("OMNI_SHODAN_API_KEY", "")
        self._rl = RateLimit(requests_per_minute=1, requests_per_day=100)

    @property
    def name(self) -> str:
        return "shodan"

    @property
    def supported_entities(self) -> List[EntityType]:
        return [EntityType.IP, EntityType.DOMAIN, EntityType.CERT, EntityType.VULN]

    @property
    def rate_limit(self) -> RateLimit:
        return self._rl

    @property
    def requires_auth(self) -> bool:
        return True

    async def health_check(self) -> bool:
        if not self._api_key:
            return False
        url = f"{self.BASE_URL}/api-info?key={self._api_key}"
        try:
            async with aiohttp.ClientSession() as s:
                async with s.get(url, timeout=aiohttp.ClientTimeout(total=10)) as r:
                    return r.status == 200
        except Exception:
            return False

    async def _search(
        self, entity_type: EntityType, query: str, params: QueryParams
    ) -> List[OSINTResult]:
        if not self._api_key:
            raise RuntimeError("OMNI_SHODAN_API_KEY not set")

        results: List[OSINTResult] = []

        if entity_type == EntityType.IP:
            data = await self._get(f"/shodan/host/{query}")
            results += self._parse_host(data)

        elif entity_type == EntityType.DOMAIN:
            data = await self._get(f"/dns/domain/{query}")
            results += self._parse_domain_dns(data)
            # Also search for hosts serving the domain
            search_data = await self._get(
                "/shodan/host/search",
                params={"query": f"hostname:{query}", "key": self._api_key,
                        "page": 1}
            )
            results += self._parse_search(search_data)

        elif entity_type == EntityType.VULN:
            data = await self._get("/shodan/host/search",
                                   params={"query": f"vuln:{query}", "key": self._api_key})
            results += self._parse_search(data)

        elif entity_type == EntityType.CERT:
            data = await self._get("/shodan/host/search",
                                   params={"query": f"ssl.cert.subject.cn:{query}",
                                           "key": self._api_key})
            results += self._parse_search(data)

        return results[:params.limit]

    # ------------------------------------------------------------------
    # HTTP helpers
    # ------------------------------------------------------------------

    async def _get(self, path: str, params: Optional[dict] = None) -> dict:
        p = params or {}
        p.setdefault("key", self._api_key)
        url = self.BASE_URL + path
        async with aiohttp.ClientSession() as session:
            async with session.get(
                url, params=p,
                timeout=aiohttp.ClientTimeout(total=30)
            ) as resp:
                resp.raise_for_status()
                return await resp.json()

    # ------------------------------------------------------------------
    # Parsers
    # ------------------------------------------------------------------

    def _parse_host(self, data: dict) -> List[OSINTResult]:
        results = []
        ip = data.get("ip_str", "")
        tags = data.get("tags", [])
        org = data.get("org", "")
        country = data.get("country_name", "")
        vulns = list(data.get("vulns", {}).keys())

        # Base IP result
        results.append(self._make_result(
            result_type=ResultType.MATCH,
            entity_type=EntityType.IP,
            value=ip,
            raw=data,
            confidence=0.99,
            tags=tags,
            metadata={"org": org, "country": country, "vulns": vulns},
        ))

        # Port/service results
        for port_data in data.get("data", []):
            port = port_data.get("port")
            transport = port_data.get("transport", "tcp")
            product = port_data.get("product", "")
            banner = port_data.get("data", "")[:512]  # truncate banners
            results.append(self._make_result(
                result_type=ResultType.PORT_SERVICE,
                entity_type=EntityType.IP,
                value=f"{ip}:{port}/{transport}",
                raw=port_data,
                confidence=0.99,
                tags=[f"port:{port}", f"proto:{transport}"],
                metadata={"product": product, "banner": banner},
            ))

        # Vulnerability results
        for cve, vuln_info in data.get("vulns", {}).items():
            results.append(self._make_result(
                result_type=ResultType.THREAT_INTEL,
                entity_type=EntityType.VULN,
                value=cve,
                raw=vuln_info,
                confidence=0.95,
                tags=["cve", "shodan-verified"],
                metadata={"affected_ip": ip, "cvss": vuln_info.get("cvss")},
            ))

        return results

    def _parse_domain_dns(self, data: dict) -> List[OSINTResult]:
        results = []
        domain = data.get("domain", "")
        for sub in data.get("subdomains", []):
            fqdn = f"{sub}.{domain}"
            results.append(self._make_result(
                result_type=ResultType.DNS_RECORD,
                entity_type=EntityType.DOMAIN,
                value=fqdn,
                raw={"subdomain": sub, "parent": domain},
                confidence=0.9,
                tags=["subdomain", "shodan-dns"],
            ))
        for record in data.get("data", []):
            results.append(self._make_result(
                result_type=ResultType.DNS_RECORD,
                entity_type=EntityType.DOMAIN,
                value=record.get("value", ""),
                raw=record,
                confidence=0.9,
                tags=[f"dns:{record.get('type','?')}"],
                timestamp=record.get("last_seen"),
            ))
        return results

    def _parse_search(self, data: dict) -> List[OSINTResult]:
        results = []
        for match in data.get("matches", []):
            ip = match.get("ip_str", "")
            port = match.get("port", 0)
            results.append(self._make_result(
                result_type=ResultType.PORT_SERVICE,
                entity_type=EntityType.IP,
                value=f"{ip}:{port}",
                raw=match,
                confidence=0.85,
                tags=match.get("tags", []),
                timestamp=match.get("timestamp"),
            ))
        return results
