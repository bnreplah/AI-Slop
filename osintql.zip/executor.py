"""
OQL Query Executor — Walks the AST and orchestrates connector calls
Cybopsec / OmniOSINT Framework

Architecture:
  - Each AST Pipeline stage is executed sequentially
  - Within a stage, applicable connectors run concurrently (asyncio.gather)
  - Results flow through the pipeline, each stage consuming/transforming the prior output
  - Rate limiting, error isolation, and dedup happen here
"""

import asyncio
import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from .oql.ast_nodes import (
    Program, Pipeline, EntityType, OutputFormat,
    SearchCmd, PivotCmd, EnrichCmd, CorrelateCmd,
    TraceCmd, MonitorCmd, ExportCmd,
    WhereClause, SinceClause, UntilClause, LimitClause,
    ExcludeClause, ConfidenceClause, ViaClause,
    CompareExpr, BinaryExpr, UnaryExpr,
    StringLiteral, IntegerLiteral, FloatLiteral, BoolLiteral,
    DatetimeLiteral, Identifier, ListLiteral,
    CompareOp, OutputClause,
)
from .connectors.base_connector import (
    BaseConnector, EntityType as CEntityType,
    QueryParams, OSINTResult, ConnectorError,
)
from .connectors.registry import ConnectorRegistry

log = logging.getLogger(__name__)


@dataclass
class ExecutionContext:
    """Mutable state passed through pipeline stages."""
    results:      List[OSINTResult] = field(default_factory=list)
    errors:       List[ConnectorError] = field(default_factory=list)
    meta:         Dict[str, Any] = field(default_factory=dict)
    current_entity_type: Optional[CEntityType] = None
    current_query: str = ""


@dataclass
class ExecutionResult:
    results:  List[OSINTResult]
    errors:   List[ConnectorError]
    output:   Optional[OutputClause]
    pipeline_index: int


class QueryExecutor:
    """
    Executes a parsed OQL Program against a ConnectorRegistry.

    Usage:
        executor = QueryExecutor(registry)
        results = await executor.execute(program)
    """

    def __init__(self, registry: ConnectorRegistry):
        self.registry = registry

    async def execute(self, program: Program) -> List[ExecutionResult]:
        tasks = [self._execute_pipeline(i, p)
                 for i, p in enumerate(program.pipelines)]
        return await asyncio.gather(*tasks)

    # ------------------------------------------------------------------
    # Pipeline execution
    # ------------------------------------------------------------------

    async def _execute_pipeline(self, idx: int, pipeline: Pipeline) -> ExecutionResult:
        ctx = ExecutionContext()

        for stage in pipeline.stages:
            await self._execute_stage(stage, ctx)

        return ExecutionResult(
            results=ctx.results,
            errors=ctx.errors,
            output=pipeline.output,
            pipeline_index=idx,
        )

    async def _execute_stage(self, node, ctx: ExecutionContext):
        dispatch = {
            SearchCmd:    self._exec_search,
            PivotCmd:     self._exec_pivot,
            EnrichCmd:    self._exec_enrich,
            CorrelateCmd: self._exec_correlate,
            TraceCmd:     self._exec_trace,
            MonitorCmd:   self._exec_monitor,
            ExportCmd:    self._exec_export,
        }
        handler = dispatch.get(type(node))
        if handler:
            await handler(node, ctx)
        else:
            log.warning("No executor for node type: %s", type(node).__name__)

    # ------------------------------------------------------------------
    # SEARCH
    # ------------------------------------------------------------------

    async def _exec_search(self, cmd: SearchCmd, ctx: ExecutionContext):
        query = self._eval_literal(cmd.query)
        entity_type = CEntityType(cmd.entity_type.value)
        params = self._build_params(cmd.clauses)
        sources = self._get_sources(cmd.clauses)
        excluded = self._get_excluded(cmd.clauses)

        connectors = [
            c for c in self.registry.for_entity(entity_type)
            if c.name not in excluded
        ]
        if sources and "all" not in sources:
            connectors = [c for c in connectors if c.name in sources]

        ctx.current_entity_type = entity_type
        ctx.current_query = query

        raw_results = await asyncio.gather(*[
            c.search(entity_type, query, params) for c in connectors
        ], return_exceptions=True)

        new_results = []
        for res in raw_results:
            if isinstance(res, Exception):
                ctx.errors.append(ConnectorError("unknown", "EXCEPTION", str(res)))
            elif isinstance(res, ConnectorError):
                ctx.errors.append(res)
            elif isinstance(res, list):
                new_results.extend(res)

        ctx.results = self._dedup(new_results)
        ctx.results = self._apply_where(ctx.results, cmd.clauses)

        log.info("SEARCH %s %r → %d results from %d connectors",
                 entity_type, query, len(ctx.results), len(connectors))

    # ------------------------------------------------------------------
    # PIVOT
    # ------------------------------------------------------------------

    async def _exec_pivot(self, cmd: PivotCmd, ctx: ExecutionContext):
        """Re-query with each result value as input for a new entity type."""
        target_type = CEntityType(cmd.target_type.value)
        params = self._build_params(cmd.clauses)
        excluded = self._get_excluded(cmd.clauses)

        connectors = [
            c for c in self.registry.for_entity(target_type)
            if c.name not in excluded
        ]

        pivot_queries = {r.value for r in ctx.results}
        all_new: List[OSINTResult] = []

        for pivot_val in pivot_queries:
            raw = await asyncio.gather(*[
                c.search(target_type, pivot_val, params) for c in connectors
            ], return_exceptions=True)
            for res in raw:
                if isinstance(res, list):
                    all_new.extend(res)
                elif isinstance(res, ConnectorError):
                    ctx.errors.append(res)

        ctx.results = self._dedup(ctx.results + all_new)
        log.info("PIVOT → %s: %d new results", target_type, len(all_new))

    # ------------------------------------------------------------------
    # ENRICH
    # ------------------------------------------------------------------

    async def _exec_enrich(self, cmd: EnrichCmd, ctx: ExecutionContext):
        sources = cmd.sources or []
        connectors = self.registry.for_sources(sources)

        enriched = []
        for result in ctx.results:
            applicable = [
                c for c in connectors
                if result.entity_type in [e.value for e in c.supported_entities]
            ]
            enrich_tasks = [c.enrich(result) for c in applicable]
            enrich_results = await asyncio.gather(*enrich_tasks, return_exceptions=True)
            merged = result
            for er in enrich_results:
                if isinstance(er, OSINTResult):
                    # Merge metadata from enrichment into original result
                    merged.metadata.update(er.metadata)
                    merged.tags = list(set(merged.tags + er.tags))
            enriched.append(merged)

        ctx.results = enriched
        log.info("ENRICH: enriched %d results", len(enriched))

    # ------------------------------------------------------------------
    # CORRELATE
    # ------------------------------------------------------------------

    async def _exec_correlate(self, cmd: CorrelateCmd, ctx: ExecutionContext):
        """Find results that share values — build a correlation map."""
        target_type = CEntityType(cmd.target_type.value)
        value_map: Dict[str, List[OSINTResult]] = {}

        for r in ctx.results:
            key = r.value
            value_map.setdefault(key, []).append(r)

        # Results that appear in multiple sources are higher confidence
        correlated = []
        for val, matches in value_map.items():
            if len(matches) > 1:
                for m in matches:
                    m.confidence = min(m.confidence * 1.1, 1.0)
                    m.tags = list(set(m.tags + ["correlated", f"seen_in:{len(matches)}_sources"]))
                correlated.extend(matches)

        ctx.results = correlated if correlated else ctx.results
        log.info("CORRELATE → %s: %d correlated results", target_type, len(correlated))

    # ------------------------------------------------------------------
    # TRACE
    # ------------------------------------------------------------------

    async def _exec_trace(self, cmd: TraceCmd, ctx: ExecutionContext):
        """Multi-hop trace: iteratively pivot through entity relationships."""
        target_type = CEntityType(cmd.target_type.value)
        depth = cmd.depth
        params = self._build_params(cmd.clauses)
        connectors = self.registry.for_entity(target_type)

        frontier = {r.value for r in ctx.results}
        all_results = list(ctx.results)
        visited = set(frontier)

        for hop in range(depth):
            next_frontier = set()
            raw = await asyncio.gather(*[
                c.search(target_type, q, params)
                for c in connectors for q in frontier
            ], return_exceptions=True)
            for res in raw:
                if isinstance(res, list):
                    for r in res:
                        if r.value not in visited:
                            next_frontier.add(r.value)
                            all_results.append(r)
                            visited.add(r.value)

            log.info("TRACE hop %d/%d: %d new nodes", hop + 1, depth, len(next_frontier))
            frontier = next_frontier
            if not frontier:
                break

        ctx.results = self._dedup(all_results)

    # ------------------------------------------------------------------
    # MONITOR (registers a watch job — non-blocking)
    # ------------------------------------------------------------------

    async def _exec_monitor(self, cmd: MonitorCmd, ctx: ExecutionContext):
        entity_type = CEntityType(cmd.entity_type.value)
        query = self._eval_literal(cmd.query)
        log.info("MONITOR registered: %s %r every %ds",
                 entity_type, query, cmd.interval_seconds)
        ctx.meta["monitor"] = {
            "entity_type": entity_type.value,
            "query": query,
            "interval_seconds": cmd.interval_seconds,
        }

    # ------------------------------------------------------------------
    # EXPORT
    # ------------------------------------------------------------------

    async def _exec_export(self, cmd: ExportCmd, ctx: ExecutionContext):
        import json
        data = [r.to_dict() for r in ctx.results]
        if cmd.format == OutputFormat.JSON:
            with open(cmd.filepath, "w") as f:
                json.dump(data, f, indent=2, default=str)
        elif cmd.format == OutputFormat.CSV:
            import csv
            if data:
                with open(cmd.filepath, "w", newline="") as f:
                    w = csv.DictWriter(f, fieldnames=data[0].keys())
                    w.writeheader()
                    w.writerows(data)
        log.info("EXPORT %s → %s (%d records)", cmd.format, cmd.filepath, len(data))

    # ------------------------------------------------------------------
    # Clause extraction helpers
    # ------------------------------------------------------------------

    def _build_params(self, clauses) -> QueryParams:
        p = QueryParams()
        for c in clauses:
            if isinstance(c, SinceClause):
                p.since = self._eval_literal(c.value)
            elif isinstance(c, UntilClause):
                p.until = self._eval_literal(c.value)
            elif isinstance(c, LimitClause):
                p.limit = c.count
            elif isinstance(c, ConfidenceClause):
                p.confidence_min = c.min_score
        return p

    def _get_sources(self, clauses) -> List[str]:
        for c in clauses:
            if isinstance(c, ViaClause):
                return c.sources
        return []

    def _get_excluded(self, clauses) -> List[str]:
        for c in clauses:
            if isinstance(c, ExcludeClause):
                return c.sources
        return []

    def _apply_where(self, results: List[OSINTResult], clauses) -> List[OSINTResult]:
        where = next((c for c in clauses if isinstance(c, WhereClause)), None)
        if where is None:
            return results
        return [r for r in results if self._eval_condition(where.condition, r)]

    def _eval_condition(self, node, result: OSINTResult) -> bool:
        if isinstance(node, BinaryExpr):
            left = self._eval_condition(node.left, result)
            if node.op == "AND":
                return left and self._eval_condition(node.right, result)
            else:  # OR
                return left or self._eval_condition(node.right, result)
        if isinstance(node, UnaryExpr) and node.op == "NOT":
            return not self._eval_condition(node.operand, result)
        if isinstance(node, CompareExpr):
            field_val = self._get_field(result, node.field)
            compare_val = self._eval_literal(node.value)
            return self._compare(field_val, node.op, compare_val)
        return True

    @staticmethod
    def _get_field(result: OSINTResult, field: str):
        attr_map = {
            "source":     result.source,
            "value":      result.value,
            "confidence": result.confidence,
            "type":       result.result_type.value,
        }
        return attr_map.get(field, result.metadata.get(field, ""))

    @staticmethod
    def _compare(left, op: CompareOp, right) -> bool:
        try:
            if op == CompareOp.EQ:       return str(left).lower() == str(right).lower()
            if op == CompareOp.NEQ:      return str(left).lower() != str(right).lower()
            if op == CompareOp.GT:       return float(left) > float(right)
            if op == CompareOp.LT:       return float(left) < float(right)
            if op == CompareOp.GTE:      return float(left) >= float(right)
            if op == CompareOp.LTE:      return float(left) <= float(right)
            if op == CompareOp.CONTAINS: return str(right).lower() in str(left).lower()
            if op == CompareOp.MATCHES:
                import re
                return bool(re.search(str(right), str(left)))
        except (ValueError, TypeError):
            return False
        return False

    @staticmethod
    def _eval_literal(node) -> Any:
        if isinstance(node, StringLiteral):   return node.value
        if isinstance(node, IntegerLiteral):  return node.value
        if isinstance(node, FloatLiteral):    return node.value
        if isinstance(node, BoolLiteral):     return node.value
        if isinstance(node, DatetimeLiteral): return node.value
        if isinstance(node, Identifier):      return node.name
        return str(node)

    @staticmethod
    def _dedup(results: List[OSINTResult]) -> List[OSINTResult]:
        seen = {}
        for r in results:
            fp = r.fingerprint
            if fp not in seen or r.confidence > seen[fp].confidence:
                seen[fp] = r
        return list(seen.values())
