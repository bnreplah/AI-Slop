"""
OQL Parser — Converts OQL token stream to an AST
Cybopsec / OmniOSINT Framework

Grammar (simplified EBNF):
  program     := pipeline (NEWLINE* pipeline)* EOF
  pipeline    := command (PIPE command)* (AS output_fmt (TO STRING))?
  command     := search_cmd | pivot_cmd | enrich_cmd | correlate_cmd
               | trace_cmd | monitor_cmd | export_cmd
  search_cmd  := SEARCH entity_type literal clause*
  pivot_cmd   := PIVOT entity_type clause*
  enrich_cmd  := ENRICH entity_type? (LBRACKET source_list RBRACKET)? clause*
  correlate   := CORRELATE entity_type clause*
  trace_cmd   := TRACE entity_type (COLON INTEGER)? clause*
  monitor_cmd := MONITOR entity_type literal (COLON INTEGER)? clause*
  export_cmd  := EXPORT output_fmt TO STRING
  clause      := where_clause | since_clause | until_clause | limit_clause
               | exclude_clause | confidence_clause | via_clause
  where_clause:= WHERE condition
  condition   := and_expr (OR and_expr)*
  and_expr    := not_expr (AND not_expr)*
  not_expr    := NOT? compare_expr | LPAREN condition RPAREN
  compare_expr:= IDENT op literal
"""

from typing import List, Optional

from .lexer import Lexer, Token, TokenType
from .ast_nodes import (
    ASTNode, Program, Pipeline, OutputClause, OutputFormat, EntityType,
    CompareOp, StringLiteral, IntegerLiteral, FloatLiteral, BoolLiteral,
    DatetimeLiteral, RegexLiteral, ListLiteral, Identifier,
    BinaryExpr, UnaryExpr, CompareExpr,
    WhereClause, SinceClause, UntilClause, LimitClause,
    ExcludeClause, ConfidenceClause, ViaClause,
    SearchCmd, PivotCmd, EnrichCmd, CorrelateCmd,
    TraceCmd, MonitorCmd, ExportCmd,
)

# Map output keyword token types → OutputFormat
OUTPUT_FORMAT_MAP = {
    TokenType.GRAPH:    OutputFormat.GRAPH,
    TokenType.JSON:     OutputFormat.JSON,
    TokenType.TABLE:    OutputFormat.TABLE,
    TokenType.TIMELINE: OutputFormat.TIMELINE,
    TokenType.REPORT:   OutputFormat.REPORT,
    TokenType.CSV:      OutputFormat.CSV,
}

ENTITY_TYPE_MAP = {
    TokenType.PERSON:   EntityType.PERSON,
    TokenType.DOMAIN:   EntityType.DOMAIN,
    TokenType.IP:       EntityType.IP,
    TokenType.EMAIL:    EntityType.EMAIL,
    TokenType.PHONE:    EntityType.PHONE,
    TokenType.ORG:      EntityType.ORG,
    TokenType.HASH:     EntityType.HASH,
    TokenType.USERNAME: EntityType.USERNAME,
    TokenType.CERT:     EntityType.CERT,
    TokenType.VULN:     EntityType.VULN,
    TokenType.URL:      EntityType.URL,
    TokenType.CRYPTO:   EntityType.CRYPTO,
}

SOURCE_TOKENS = {
    TokenType.SHODAN, TokenType.CENSYS, TokenType.HIBP,
    TokenType.VIRUSTOTAL, TokenType.WHOIS, TokenType.HUNTER,
    TokenType.FULLHUNT, TokenType.LEAKIX, TokenType.INTELX,
    TokenType.CRTSH, TokenType.ALL, TokenType.IDENT,
}

CLAUSE_STARTERS = {
    TokenType.WHERE, TokenType.SINCE, TokenType.UNTIL,
    TokenType.LIMIT, TokenType.EXCLUDE, TokenType.CONFIDENCE,
    TokenType.VIA,
}

COMPARE_OP_MAP = {
    TokenType.EQ:       CompareOp.EQ,
    TokenType.NEQ:      CompareOp.NEQ,
    TokenType.GT:       CompareOp.GT,
    TokenType.LT:       CompareOp.LT,
    TokenType.GTE:      CompareOp.GTE,
    TokenType.LTE:      CompareOp.LTE,
    TokenType.CONTAINS: CompareOp.CONTAINS,
    TokenType.MATCHES:  CompareOp.MATCHES,
}


class ParseError(Exception):
    def __init__(self, msg: str, token: Token):
        super().__init__(f"[ParseError L{token.line}:C{token.col}] {msg} (got {token.type.name} {token.value!r})")
        self.token = token


class Parser:
    """
    Recursive-descent parser for OQL.
    Returns a Program AST node.
    """

    def __init__(self, source: str):
        self._tokens: List[Token] = Lexer(source).tokenize()
        self._pos = 0

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _peek(self, offset: int = 0) -> Token:
        idx = self._pos + offset
        if idx < len(self._tokens):
            return self._tokens[idx]
        return self._tokens[-1]  # EOF

    def _advance(self) -> Token:
        tok = self._tokens[self._pos]
        if tok.type != TokenType.EOF:
            self._pos += 1
        return tok

    def _check(self, *types: TokenType) -> bool:
        return self._peek().type in types

    def _match(self, *types: TokenType) -> Optional[Token]:
        if self._check(*types):
            return self._advance()
        return None

    def _expect(self, *types: TokenType) -> Token:
        tok = self._advance()
        if tok.type not in types:
            raise ParseError(
                f"Expected {'/'.join(t.name for t in types)}",
                tok
            )
        return tok

    def _skip_newlines(self):
        while self._check(TokenType.NEWLINE, TokenType.SEMICOLON):
            self._advance()

    # ------------------------------------------------------------------
    # Entry
    # ------------------------------------------------------------------

    def parse(self) -> Program:
        prog = Program(line=1, col=1)
        self._skip_newlines()
        while not self._check(TokenType.EOF):
            pipeline = self._parse_pipeline()
            prog.pipelines.append(pipeline)
            self._skip_newlines()
        return prog

    # ------------------------------------------------------------------
    # Pipeline
    # ------------------------------------------------------------------

    def _parse_pipeline(self) -> Pipeline:
        tok = self._peek()
        pipe = Pipeline(line=tok.line, col=tok.col)

        # First command
        pipe.stages.append(self._parse_command())

        # Additional |> stages — skip newlines/whitespace before checking for pipe
        while True:
            self._skip_newlines()
            if not self._check(TokenType.PIPE):
                break
            self._advance()  # consume |>
            self._skip_newlines()
            pipe.stages.append(self._parse_command())

        # Optional: AS <format> (TO <file>)?
        self._skip_newlines()
        if self._check(TokenType.AS):
            self._advance()
            fmt_tok = self._peek()
            if fmt_tok.type not in OUTPUT_FORMAT_MAP:
                raise ParseError("Expected output format after AS", fmt_tok)
            fmt = OUTPUT_FORMAT_MAP[self._advance().type]
            filepath = None
            if self._match(TokenType.TO):
                filepath = self._strip_quotes(self._expect(TokenType.STRING).value)
            pipe.output = OutputClause(format=fmt, filepath=filepath,
                                       line=fmt_tok.line, col=fmt_tok.col)

        return pipe

    # ------------------------------------------------------------------
    # Commands
    # ------------------------------------------------------------------

    def _parse_command(self) -> ASTNode:
        tok = self._peek()
        dispatch = {
            TokenType.SEARCH:    self._parse_search,
            TokenType.PIVOT:     self._parse_pivot,
            TokenType.ENRICH:    self._parse_enrich,
            TokenType.CORRELATE: self._parse_correlate,
            TokenType.TRACE:     self._parse_trace,
            TokenType.MONITOR:   self._parse_monitor,
            TokenType.EXPORT:    self._parse_export,
        }
        fn = dispatch.get(tok.type)
        if fn is None:
            raise ParseError("Expected a command keyword", tok)
        return fn()

    def _parse_search(self) -> SearchCmd:
        tok = self._expect(TokenType.SEARCH)
        entity = self._parse_entity_type()
        query = self._parse_literal()
        clauses = self._parse_clauses()
        return SearchCmd(entity_type=entity, query=query, clauses=clauses,
                         line=tok.line, col=tok.col)

    def _parse_pivot(self) -> PivotCmd:
        tok = self._expect(TokenType.PIVOT)
        entity = self._parse_entity_type()
        clauses = self._parse_clauses()
        return PivotCmd(target_type=entity, clauses=clauses,
                        line=tok.line, col=tok.col)

    def _parse_enrich(self) -> EnrichCmd:
        tok = self._expect(TokenType.ENRICH)
        entity: Optional[EntityType] = None
        if self._peek().type in ENTITY_TYPE_MAP:
            entity = self._parse_entity_type()
        sources: List[str] = []
        if self._check(TokenType.LBRACKET):
            sources = self._parse_source_list()
        clauses = self._parse_clauses()
        return EnrichCmd(target_type=entity, sources=sources, clauses=clauses,
                         line=tok.line, col=tok.col)

    def _parse_correlate(self) -> CorrelateCmd:
        tok = self._expect(TokenType.CORRELATE)
        entity = self._parse_entity_type()
        clauses = self._parse_clauses()
        return CorrelateCmd(target_type=entity, clauses=clauses,
                            line=tok.line, col=tok.col)

    def _parse_trace(self) -> TraceCmd:
        tok = self._expect(TokenType.TRACE)
        entity = self._parse_entity_type()
        depth = 3
        if self._check(TokenType.COLON):
            self._advance()
            depth = int(self._expect(TokenType.INTEGER).value)
        clauses = self._parse_clauses()
        return TraceCmd(target_type=entity, depth=depth, clauses=clauses,
                        line=tok.line, col=tok.col)

    def _parse_monitor(self) -> MonitorCmd:
        tok = self._expect(TokenType.MONITOR)
        entity = self._parse_entity_type()
        query = self._parse_literal()
        interval = 3600
        if self._check(TokenType.COLON):
            self._advance()
            interval = int(self._expect(TokenType.INTEGER).value)
        clauses = self._parse_clauses()
        return MonitorCmd(entity_type=entity, query=query,
                          interval_seconds=interval, clauses=clauses,
                          line=tok.line, col=tok.col)

    def _parse_export(self) -> ExportCmd:
        tok = self._expect(TokenType.EXPORT)
        fmt_tok = self._peek()
        if fmt_tok.type not in OUTPUT_FORMAT_MAP:
            raise ParseError("Expected output format after EXPORT", fmt_tok)
        fmt = OUTPUT_FORMAT_MAP[self._advance().type]
        self._expect(TokenType.TO)
        filepath = self._strip_quotes(self._expect(TokenType.STRING).value)
        return ExportCmd(format=fmt, filepath=filepath,
                         line=tok.line, col=tok.col)

    # ------------------------------------------------------------------
    # Clauses
    # ------------------------------------------------------------------

    def _parse_clauses(self) -> List[ASTNode]:
        clauses = []
        while True:
            self._skip_newlines()
            if not self._check(*CLAUSE_STARTERS):
                break
            tok = self._peek()
            t = tok.type
            if t == TokenType.WHERE:
                clauses.append(self._parse_where())
            elif t == TokenType.SINCE:
                clauses.append(self._parse_since())
            elif t == TokenType.UNTIL:
                clauses.append(self._parse_until())
            elif t == TokenType.LIMIT:
                clauses.append(self._parse_limit())
            elif t == TokenType.EXCLUDE:
                clauses.append(self._parse_exclude())
            elif t == TokenType.CONFIDENCE:
                clauses.append(self._parse_confidence())
            elif t == TokenType.VIA:
                clauses.append(self._parse_via())
        return clauses

    def _parse_where(self) -> WhereClause:
        tok = self._expect(TokenType.WHERE)
        cond = self._parse_condition()
        return WhereClause(condition=cond, line=tok.line, col=tok.col)

    def _parse_since(self) -> SinceClause:
        tok = self._expect(TokenType.SINCE)
        val = self._parse_literal()
        return SinceClause(value=val, line=tok.line, col=tok.col)

    def _parse_until(self) -> UntilClause:
        tok = self._expect(TokenType.UNTIL)
        val = self._parse_literal()
        return UntilClause(value=val, line=tok.line, col=tok.col)

    def _parse_limit(self) -> LimitClause:
        tok = self._expect(TokenType.LIMIT)
        n = int(self._expect(TokenType.INTEGER).value)
        return LimitClause(count=n, line=tok.line, col=tok.col)

    def _parse_exclude(self) -> ExcludeClause:
        tok = self._expect(TokenType.EXCLUDE)
        sources = self._parse_source_list()
        return ExcludeClause(sources=sources, line=tok.line, col=tok.col)

    def _parse_confidence(self) -> ConfidenceClause:
        tok = self._expect(TokenType.CONFIDENCE)
        self._expect(TokenType.GTE)
        score_tok = self._peek()
        if score_tok.type == TokenType.FLOAT:
            score = float(self._advance().value)
        elif score_tok.type == TokenType.INTEGER:
            score = float(self._advance().value)
        else:
            raise ParseError("Expected float after CONFIDENCE >=", score_tok)
        return ConfidenceClause(min_score=score, line=tok.line, col=tok.col)

    def _parse_via(self) -> ViaClause:
        tok = self._expect(TokenType.VIA)
        sources = self._parse_source_list()
        return ViaClause(sources=sources, line=tok.line, col=tok.col)

    # ------------------------------------------------------------------
    # Conditions (WHERE body)
    # ------------------------------------------------------------------

    def _parse_condition(self) -> ASTNode:
        """condition := and_expr (OR and_expr)*"""
        left = self._parse_and_expr()
        while self._check(TokenType.OR):
            op_tok = self._advance()
            right = self._parse_and_expr()
            left = BinaryExpr(left=left, op="OR", right=right,
                              line=op_tok.line, col=op_tok.col)
        return left

    def _parse_and_expr(self) -> ASTNode:
        """and_expr := not_expr (AND not_expr)*"""
        left = self._parse_not_expr()
        while self._check(TokenType.AND):
            op_tok = self._advance()
            right = self._parse_not_expr()
            left = BinaryExpr(left=left, op="AND", right=right,
                              line=op_tok.line, col=op_tok.col)
        return left

    def _parse_not_expr(self) -> ASTNode:
        if self._check(TokenType.NOT):
            op_tok = self._advance()
            operand = self._parse_compare_expr()
            return UnaryExpr(op="NOT", operand=operand,
                             line=op_tok.line, col=op_tok.col)
        if self._check(TokenType.LPAREN):
            self._advance()
            expr = self._parse_condition()
            self._expect(TokenType.RPAREN)
            return expr
        return self._parse_compare_expr()

    def _parse_compare_expr(self) -> CompareExpr:
        field_tok = self._peek()
        field_name = self._advance().value
        op_tok = self._peek()
        if op_tok.type not in COMPARE_OP_MAP:
            raise ParseError("Expected comparison operator", op_tok)
        op = COMPARE_OP_MAP[self._advance().type]
        value = self._parse_literal()
        return CompareExpr(field=field_name, op=op, value=value,
                           line=field_tok.line, col=field_tok.col)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _parse_entity_type(self) -> EntityType:
        tok = self._peek()
        et = ENTITY_TYPE_MAP.get(tok.type)
        if et is None:
            raise ParseError("Expected entity type", tok)
        self._advance()
        return et

    def _parse_literal(self) -> ASTNode:
        tok = self._peek()
        if tok.type == TokenType.STRING:
            self._advance()
            return StringLiteral(value=self._strip_quotes(tok.value),
                                 line=tok.line, col=tok.col)
        if tok.type == TokenType.INTEGER:
            self._advance()
            return IntegerLiteral(value=int(tok.value),
                                  line=tok.line, col=tok.col)
        if tok.type == TokenType.FLOAT:
            self._advance()
            return FloatLiteral(value=float(tok.value),
                                line=tok.line, col=tok.col)
        if tok.type == TokenType.DATETIME:
            self._advance()
            return DatetimeLiteral(value=tok.value,
                                   line=tok.line, col=tok.col)
        if tok.type == TokenType.REGEX:
            self._advance()
            return RegexLiteral(pattern=tok.value,
                                line=tok.line, col=tok.col)
        if tok.type == TokenType.BOOLEAN:
            self._advance()
            return BoolLiteral(value=tok.value.lower() == "true",
                               line=tok.line, col=tok.col)
        if tok.type == TokenType.IDENT:
            self._advance()
            return Identifier(name=tok.value, line=tok.line, col=tok.col)
        raise ParseError("Expected a literal value", tok)

    def _parse_source_list(self) -> List[str]:
        """Parse [source1, source2, ...]"""
        sources = []
        if self._check(TokenType.LBRACKET):
            self._advance()
            while not self._check(TokenType.RBRACKET, TokenType.EOF):
                tok = self._peek()
                if tok.type in SOURCE_TOKENS:
                    sources.append(self._advance().value.lower())
                else:
                    raise ParseError("Expected source name", tok)
                if not self._check(TokenType.RBRACKET):
                    self._expect(TokenType.COMMA)
            self._expect(TokenType.RBRACKET)
        elif self._peek().type in SOURCE_TOKENS:
            # Bare single source without brackets
            sources.append(self._advance().value.lower())
        return sources

    @staticmethod
    def _strip_quotes(s: str) -> str:
        if len(s) >= 2 and s[0] in ('"', "'") and s[-1] == s[0]:
            return s[1:-1]
        return s


def parse(source: str) -> Program:
    """Convenience function: parse OQL source → AST Program."""
    return Parser(source).parse()
