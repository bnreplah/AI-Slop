import { useState, useEffect, useRef, useCallback } from "react";

// ─── Color palette & theme ────────────────────────────────────────────────
const C = {
  bg:       "#080c10",
  surface:  "#0d1117",
  panel:    "#111820",
  border:   "#1a2535",
  accent:   "#00d4aa",
  accent2:  "#0096ff",
  warn:     "#ffb700",
  danger:   "#ff3b5c",
  success:  "#00e676",
  text:     "#c9d6e3",
  textDim:  "#4a6080",
  textBold: "#e8f4ff",
};

// ─── Mock data for demo ──────────────────────────────────────────────────
const MOCK_RESULTS = [
  { fingerprint:"a1b2c3d4", source:"shodan",     result_type:"PORT_SERVICE", entity_type:"IP",     value:"104.21.33.12:443", confidence:0.99, tags:["https","cloudflare"], timestamp:"2026-05-14" },
  { fingerprint:"b2c3d4e5", source:"crtsh",      result_type:"CERTIFICATE",  entity_type:"DOMAIN", value:"api.example.com",  confidence:0.95, tags:["san","certificate-transparency"], timestamp:"2026-04-01" },
  { fingerprint:"c3d4e5f6", source:"hibp",       result_type:"BREACH",       entity_type:"EMAIL",  value:"user@example.com", confidence:0.99, tags:["breach","linkedin"], timestamp:"2021-06-11" },
  { fingerprint:"d4e5f6g7", source:"virustotal", result_type:"THREAT_INTEL", entity_type:"DOMAIN", value:"example.com",      confidence:0.12, tags:["clean"], timestamp:"2026-05-10" },
  { fingerprint:"e5f6g7h8", source:"shodan",     result_type:"PORT_SERVICE", entity_type:"IP",     value:"104.21.33.12:80",  confidence:0.99, tags:["http"], timestamp:"2026-05-14" },
  { fingerprint:"f6g7h8i9", source:"hunter",     result_type:"MATCH",        entity_type:"EMAIL",  value:"admin@example.com",confidence:0.82, tags:["status:deliverable","hunter-verified"], timestamp:"2026-03-15" },
  { fingerprint:"g7h8i9j0", source:"whois",      result_type:"WHOIS",        entity_type:"DOMAIN", value:"example.com",     confidence:0.90, tags:["whois","registration"], timestamp:"1995-08-14" },
  { fingerprint:"h8i9j0k1", source:"shodan",     result_type:"THREAT_INTEL", entity_type:"VULN",   value:"CVE-2024-1234",   confidence:0.95, tags:["cve","critical"], timestamp:"2024-09-01" },
];

const SAMPLE_QUERIES = [
  `SEARCH DOMAIN "example.com"\n  |> ENRICH [shodan, crtsh]\n  |> PIVOT IP\n  AS TABLE`,
  `SEARCH EMAIL "user@corp.com"\n  WHERE confidence >= 0.8\n  |> ENRICH [hibp, hunter]\n  LIMIT 50`,
  `SEARCH IP "192.168.1.1"\n  VIA [shodan, virustotal]\n  |> CORRELATE DOMAIN\n  AS JSON TO "output.json"`,
  `SEARCH DOMAIN "target.org"\n  |> TRACE IP:3\n  SINCE "2025-01-01"\n  CONFIDENCE >= 0.7`,
];

// ─── Syntax highlighter ──────────────────────────────────────────────────
function highlightOQL(code) {
  const rules = [
    { re: /(#[^\n]*)/g,                        cls: "cmt"  },
    { re: /\b(SEARCH|PIVOT|ENRICH|CORRELATE|TRACE|MONITOR|EXPORT|DIFF)\b/g, cls: "cmd"  },
    { re: /\b(PERSON|DOMAIN|IP|EMAIL|PHONE|ORG|HASH|USERNAME|CERT|VULN|URL|CRYPTO)\b/g, cls: "ent"  },
    { re: /\b(WHERE|SINCE|UNTIL|LIMIT|EXCLUDE|CONFIDENCE|AS|TO|FROM|VIA|AND|OR|NOT)\b/g, cls: "kw"   },
    { re: /\b(shodan|censys|hibp|virustotal|whois|hunter|crtsh|fullhunt|leakix|all)\b/gi, cls: "src"  },
    { re: /\b(JSON|TABLE|GRAPH|TIMELINE|REPORT|CSV)\b/g,                     cls: "fmt"  },
    { re: /(\|>)/g,                             cls: "pipe" },
    { re: /("(?:[^"\\]|\\.)*")/g,              cls: "str"  },
    { re: /\b(\d+\.?\d*)\b/g,                  cls: "num"  },
  ];

  // Escape HTML first
  let result = code
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");

  // Apply highlight classes
  const colorMap = {
    cmd:  C.accent,
    ent:  C.accent2,
    kw:   "#b08dff",
    src:  C.warn,
    fmt:  "#ff9a8b",
    pipe: C.success,
    str:  "#a8d8a8",
    num:  "#ffd580",
    cmt:  C.textDim,
  };

  for (const { re, cls } of rules) {
    result = result.replace(re, (m) =>
      `<span style="color:${colorMap[cls]};font-weight:${cls==="cmd"||cls==="pipe"?"600":"400"}">${m}</span>`
    );
  }
  return result;
}

// ─── Confidence badge ────────────────────────────────────────────────────
function ConfBadge({ value }) {
  const color = value >= 0.9 ? C.success : value >= 0.5 ? C.warn : C.danger;
  return (
    <span style={{
      display: "inline-block", padding: "1px 6px", borderRadius: 3,
      fontSize: 11, fontWeight: 700, color: C.bg,
      background: color, fontFamily: "monospace",
    }}>
      {(value * 100).toFixed(0)}%
    </span>
  );
}

// ─── Source chip ─────────────────────────────────────────────────────────
function SourceChip({ name }) {
  const palettes = {
    shodan: "#ff6b35", crtsh: "#00d4aa", hibp: "#ff3b5c",
    virustotal: "#1565c0", whois: "#7c3aed", hunter: "#0f9d58",
  };
  const bg = palettes[name] || C.accent2;
  return (
    <span style={{
      display: "inline-block", padding: "1px 7px", borderRadius: 10,
      fontSize: 10, fontWeight: 700, color: "#fff",
      background: bg, letterSpacing: "0.04em", textTransform: "uppercase",
    }}>
      {name}
    </span>
  );
}

// ─── Tag pill ────────────────────────────────────────────────────────────
function Tag({ text }) {
  return (
    <span style={{
      display: "inline-block", padding: "1px 6px", marginRight: 3,
      borderRadius: 3, fontSize: 10, color: C.textDim,
      border: `1px solid ${C.border}`, background: C.surface,
    }}>
      {text}
    </span>
  );
}

// ─── Results table ───────────────────────────────────────────────────────
function ResultsTable({ results, filter }) {
  const filtered = results.filter(r => {
    if (!filter) return true;
    const q = filter.toLowerCase();
    return r.value.toLowerCase().includes(q)
      || r.source.toLowerCase().includes(q)
      || r.entity_type.toLowerCase().includes(q)
      || r.tags.some(t => t.toLowerCase().includes(q));
  });

  if (!filtered.length) {
    return (
      <div style={{ textAlign: "center", padding: "40px 0", color: C.textDim, fontSize: 13 }}>
        No results match your filter
      </div>
    );
  }

  const headers = ["SOURCE", "TYPE", "VALUE", "CONF", "TAGS", "TIMESTAMP"];

  return (
    <div style={{ overflowX: "auto" }}>
      <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12 }}>
        <thead>
          <tr>
            {headers.map(h => (
              <th key={h} style={{
                padding: "8px 12px", textAlign: "left", color: C.textDim,
                borderBottom: `1px solid ${C.border}`, fontWeight: 600,
                fontSize: 10, letterSpacing: "0.08em",
              }}>
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {filtered.map((r, i) => (
            <tr key={r.fingerprint} style={{
              background: i % 2 === 0 ? C.surface : C.panel,
              borderBottom: `1px solid ${C.border}`,
            }}>
              <td style={{ padding: "8px 12px" }}><SourceChip name={r.source} /></td>
              <td style={{ padding: "8px 12px", color: C.accent2, fontSize: 11, fontFamily: "monospace" }}>
                {r.entity_type}
              </td>
              <td style={{ padding: "8px 12px", color: C.textBold, fontFamily: "monospace", fontSize: 12 }}>
                {r.value}
              </td>
              <td style={{ padding: "8px 12px" }}><ConfBadge value={r.confidence} /></td>
              <td style={{ padding: "8px 12px" }}>
                {r.tags.slice(0, 3).map(t => <Tag key={t} text={t} />)}
              </td>
              <td style={{ padding: "8px 12px", color: C.textDim, fontSize: 11 }}>
                {r.timestamp || "—"}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <div style={{ padding: "8px 12px", color: C.textDim, fontSize: 11, borderTop: `1px solid ${C.border}` }}>
        {filtered.length} result{filtered.length !== 1 ? "s" : ""}
        {filter && ` matching "${filter}"`}
      </div>
    </div>
  );
}

// ─── Stat card ───────────────────────────────────────────────────────────
function StatCard({ label, value, color }) {
  return (
    <div style={{
      background: C.panel, border: `1px solid ${C.border}`,
      borderRadius: 8, padding: "14px 18px", minWidth: 120,
    }}>
      <div style={{ fontSize: 22, fontWeight: 700, color: color || C.accent, fontFamily: "monospace" }}>
        {value}
      </div>
      <div style={{ fontSize: 11, color: C.textDim, marginTop: 4, letterSpacing: "0.06em" }}>
        {label}
      </div>
    </div>
  );
}

// ─── Source breakdown bar ────────────────────────────────────────────────
function SourceBar({ results }) {
  const counts = {};
  results.forEach(r => { counts[r.source] = (counts[r.source] || 0) + 1; });
  const total = results.length || 1;
  const sorted = Object.entries(counts).sort((a, b) => b[1] - a[1]);
  const pal = ["#00d4aa","#0096ff","#ff6b35","#ff3b5c","#b08dff","#ffd580"];

  return (
    <div>
      <div style={{ display: "flex", height: 6, borderRadius: 3, overflow: "hidden", marginBottom: 10 }}>
        {sorted.map(([name, count], i) => (
          <div key={name} style={{
            width: `${(count / total) * 100}%`,
            background: pal[i % pal.length],
          }} />
        ))}
      </div>
      <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
        {sorted.map(([name, count], i) => (
          <div key={name} style={{ display: "flex", alignItems: "center", gap: 5, fontSize: 11 }}>
            <div style={{ width: 8, height: 8, borderRadius: 2, background: pal[i % pal.length] }} />
            <span style={{ color: C.textDim }}>{name}</span>
            <span style={{ color: C.text, fontWeight: 600 }}>{count}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Main App ────────────────────────────────────────────────────────────
export default function App() {
  const [oql, setOql]           = useState(SAMPLE_QUERIES[0]);
  const [results, setResults]   = useState([]);
  const [errors, setErrors]     = useState([]);
  const [running, setRunning]   = useState(false);
  const [filter, setFilter]     = useState("");
  const [tab, setTab]           = useState("results");
  const [elapsed, setElapsed]   = useState(null);
  const [log, setLog]           = useState([]);
  const editorRef               = useRef(null);

  const addLog = (msg, level = "info") => {
    const ts = new Date().toISOString().slice(11, 23);
    setLog(prev => [...prev.slice(-99), { ts, msg, level }]);
  };

  const runQuery = useCallback(async () => {
    if (running || !oql.trim()) return;
    setRunning(true);
    setResults([]);
    setErrors([]);
    setElapsed(null);
    addLog(`Executing OQL query (${oql.length} chars)`, "info");

    const t0 = Date.now();
    try {
      // In production: POST to omniod HTTP API
      // const resp = await fetch("http://localhost:7743/query", {
      //   method: "POST",
      //   headers: { "Content-Type": "application/json" },
      //   body: JSON.stringify({ query: oql, timeout: 60 }),
      // });
      // const data = await resp.json();

      // Demo: simulate async with mock data
      await new Promise(r => setTimeout(r, 900 + Math.random() * 600));
      const data = { results: MOCK_RESULTS, errors: [] };

      setResults(data.results);
      setErrors(data.errors || []);
      const ms = Date.now() - t0;
      setElapsed(ms);
      addLog(`Query completed in ${ms}ms — ${data.results.length} results`, "success");
      setTab("results");
    } catch (e) {
      setErrors([{ source: "client", code: "NETWORK_ERROR", message: e.message }]);
      addLog(`Query failed: ${e.message}`, "error");
    } finally {
      setRunning(false);
    }
  }, [oql, running]);

  // Ctrl+Enter to run
  useEffect(() => {
    const handler = (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key === "Enter") runQuery();
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [runQuery]);

  const summary = {
    total: results.length,
    breaches: results.filter(r => r.result_type === "BREACH").length,
    threats: results.filter(r => r.result_type === "THREAT_INTEL").length,
    avgConf: results.length
      ? (results.reduce((s, r) => s + r.confidence, 0) / results.length).toFixed(2)
      : "—",
  };

  return (
    <div style={{
      minHeight: "100vh", background: C.bg, color: C.text,
      fontFamily: "'JetBrains Mono', 'Fira Code', 'Cascadia Code', monospace",
      display: "flex", flexDirection: "column",
    }}>

      {/* ── Header ── */}
      <header style={{
        background: C.surface, borderBottom: `1px solid ${C.border}`,
        padding: "0 24px", height: 52, display: "flex", alignItems: "center",
        justifyContent: "space-between", flexShrink: 0,
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{
            width: 28, height: 28, borderRadius: 6,
            background: `linear-gradient(135deg, ${C.accent}, ${C.accent2})`,
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 14, fontWeight: 900, color: C.bg,
          }}>⬡</div>
          <span style={{ fontWeight: 700, fontSize: 15, color: C.textBold, letterSpacing: "0.04em" }}>
            OMNI<span style={{ color: C.accent }}>OSINT</span>
          </span>
          <span style={{
            fontSize: 10, color: C.textDim, border: `1px solid ${C.border}`,
            padding: "1px 6px", borderRadius: 3, letterSpacing: "0.06em",
          }}>v1.0.0</span>
        </div>
        <div style={{ display: "flex", gap: 16, alignItems: "center" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 5, fontSize: 11 }}>
            <div style={{ width: 7, height: 7, borderRadius: "50%", background: C.success }} />
            <span style={{ color: C.textDim }}>daemon online</span>
          </div>
          <div style={{ fontSize: 11, color: C.textDim }}>
            {new Date().toUTCString().slice(0, 25)}
          </div>
        </div>
      </header>

      {/* ── Main layout ── */}
      <div style={{ display: "flex", flex: 1, overflow: "hidden" }}>

        {/* ── Left: Query Panel ── */}
        <div style={{
          width: 420, flexShrink: 0, background: C.surface,
          borderRight: `1px solid ${C.border}`,
          display: "flex", flexDirection: "column",
        }}>

          {/* Editor header */}
          <div style={{
            padding: "10px 16px", borderBottom: `1px solid ${C.border}`,
            display: "flex", alignItems: "center", justifyContent: "space-between",
          }}>
            <span style={{ fontSize: 11, color: C.textDim, letterSpacing: "0.08em" }}>
              OQL EDITOR
            </span>
            <span style={{ fontSize: 10, color: C.textDim }}>Ctrl+Enter to run</span>
          </div>

          {/* Code editor */}
          <div style={{ position: "relative", flex: 1, overflow: "hidden" }}>
            <textarea
              ref={editorRef}
              value={oql}
              onChange={e => setOql(e.target.value)}
              spellCheck={false}
              style={{
                position: "absolute", inset: 0, width: "100%", height: "100%",
                background: "transparent", color: "transparent",
                caretColor: C.accent, border: "none", outline: "none",
                resize: "none", padding: "14px 16px",
                fontFamily: "inherit", fontSize: 13, lineHeight: 1.7,
                zIndex: 2,
              }}
            />
            <pre
              aria-hidden
              dangerouslySetInnerHTML={{ __html: highlightOQL(oql) + "\n" }}
              style={{
                position: "absolute", inset: 0, overflow: "hidden",
                margin: 0, padding: "14px 16px",
                fontFamily: "inherit", fontSize: 13, lineHeight: 1.7,
                color: C.text, pointerEvents: "none", zIndex: 1,
                whiteSpace: "pre-wrap", wordBreak: "break-word",
              }}
            />
          </div>

          {/* Sample queries */}
          <div style={{ padding: "8px 12px", borderTop: `1px solid ${C.border}` }}>
            <div style={{ fontSize: 10, color: C.textDim, marginBottom: 6, letterSpacing: "0.06em" }}>
              EXAMPLES
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
              {SAMPLE_QUERIES.map((q, i) => (
                <button key={i} onClick={() => setOql(q)} style={{
                  background: "none", border: `1px solid ${C.border}`,
                  borderRadius: 4, padding: "4px 8px", cursor: "pointer",
                  color: C.textDim, fontSize: 10, textAlign: "left",
                  fontFamily: "inherit",
                  transition: "color 0.15s, border-color 0.15s",
                }}
                  onMouseEnter={e => { e.target.style.color = C.accent; e.target.style.borderColor = C.accent; }}
                  onMouseLeave={e => { e.target.style.color = C.textDim; e.target.style.borderColor = C.border; }}
                >
                  {q.split("\n")[0].slice(0, 48)}…
                </button>
              ))}
            </div>
          </div>

          {/* Run button */}
          <div style={{ padding: "12px 16px", borderTop: `1px solid ${C.border}` }}>
            <button
              onClick={runQuery}
              disabled={running}
              style={{
                width: "100%", padding: "10px 0",
                background: running
                  ? C.border
                  : `linear-gradient(135deg, ${C.accent}, ${C.accent2})`,
                border: "none", borderRadius: 6, cursor: running ? "not-allowed" : "pointer",
                color: C.bg, fontWeight: 700, fontSize: 13,
                fontFamily: "inherit", letterSpacing: "0.06em",
                transition: "opacity 0.2s",
                opacity: running ? 0.6 : 1,
              }}
            >
              {running ? "⟳  EXECUTING…" : "▶  RUN QUERY"}
            </button>
          </div>
        </div>

        {/* ── Right: Results Panel ── */}
        <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>

          {/* Stats row */}
          {results.length > 0 && (
            <div style={{
              padding: "12px 20px", borderBottom: `1px solid ${C.border}`,
              display: "flex", gap: 12, flexWrap: "wrap", alignItems: "center",
            }}>
              <StatCard label="TOTAL RESULTS" value={summary.total} color={C.accent} />
              <StatCard label="BREACHES" value={summary.breaches} color={summary.breaches > 0 ? C.danger : C.textDim} />
              <StatCard label="THREATS" value={summary.threats} color={summary.threats > 0 ? C.warn : C.textDim} />
              <StatCard label="AVG CONF" value={summary.avgConf} color={C.accent2} />
              {elapsed && (
                <StatCard label="ELAPSED" value={`${elapsed}ms`} color={C.textDim} />
              )}
              <div style={{ flex: 1, minWidth: 200 }}>
                <div style={{ fontSize: 10, color: C.textDim, marginBottom: 6, letterSpacing: "0.06em" }}>
                  BY SOURCE
                </div>
                <SourceBar results={results} />
              </div>
            </div>
          )}

          {/* Tab bar */}
          <div style={{
            display: "flex", borderBottom: `1px solid ${C.border}`,
            background: C.surface, padding: "0 16px", gap: 0,
            flexShrink: 0,
          }}>
            {["results", "raw json", "errors", "log"].map(t => (
              <button key={t} onClick={() => setTab(t)} style={{
                background: "none", border: "none", cursor: "pointer",
                padding: "10px 16px", fontSize: 11, fontFamily: "inherit",
                letterSpacing: "0.06em",
                color: tab === t ? C.accent : C.textDim,
                borderBottom: tab === t ? `2px solid ${C.accent}` : "2px solid transparent",
                transition: "color 0.15s",
              }}>
                {t.toUpperCase()}
                {t === "errors" && errors.length > 0 && (
                  <span style={{
                    marginLeft: 5, background: C.danger, color: C.bg,
                    borderRadius: 8, padding: "1px 5px", fontSize: 9, fontWeight: 700,
                  }}>{errors.length}</span>
                )}
              </button>
            ))}

            {results.length > 0 && (
              <div style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: 8 }}>
                <input
                  value={filter}
                  onChange={e => setFilter(e.target.value)}
                  placeholder="Filter results…"
                  style={{
                    background: C.panel, border: `1px solid ${C.border}`,
                    borderRadius: 4, padding: "4px 10px", color: C.text,
                    fontSize: 11, fontFamily: "inherit", outline: "none",
                    width: 180,
                  }}
                />
              </div>
            )}
          </div>

          {/* Tab content */}
          <div style={{ flex: 1, overflow: "auto", padding: 0 }}>
            {/* ── Results tab ── */}
            {tab === "results" && (
              results.length === 0 && !running
                ? (
                  <div style={{
                    display: "flex", flexDirection: "column",
                    alignItems: "center", justifyContent: "center",
                    height: "100%", color: C.textDim, gap: 12,
                  }}>
                    <div style={{ fontSize: 48 }}>⬡</div>
                    <div style={{ fontSize: 14, fontWeight: 600, color: C.textDim }}>
                      Run a query to see results
                    </div>
                    <div style={{ fontSize: 11 }}>Ctrl+Enter to execute</div>
                  </div>
                )
                : running
                  ? (
                    <div style={{
                      display: "flex", flexDirection: "column",
                      alignItems: "center", justifyContent: "center",
                      height: "100%", color: C.textDim, gap: 12,
                    }}>
                      <div style={{
                        width: 36, height: 36, border: `3px solid ${C.border}`,
                        borderTop: `3px solid ${C.accent}`, borderRadius: "50%",
                        animation: "spin 0.8s linear infinite",
                      }} />
                      <div style={{ fontSize: 13 }}>Querying OSINT sources…</div>
                      <style>{`@keyframes spin { to { transform: rotate(360deg) } }`}</style>
                    </div>
                  )
                  : <ResultsTable results={results} filter={filter} />
            )}

            {/* ── Raw JSON tab ── */}
            {tab === "raw json" && (
              <pre style={{
                margin: 0, padding: "16px 20px",
                color: C.text, fontSize: 11, lineHeight: 1.7,
                background: C.bg,
              }}>
                {JSON.stringify(results, null, 2)}
              </pre>
            )}

            {/* ── Errors tab ── */}
            {tab === "errors" && (
              <div style={{ padding: "16px 20px" }}>
                {errors.length === 0
                  ? <div style={{ color: C.textDim, fontSize: 12 }}>No errors</div>
                  : errors.map((e, i) => (
                    <div key={i} style={{
                      background: C.panel, border: `1px solid ${C.danger}33`,
                      borderRadius: 6, padding: "10px 14px", marginBottom: 8,
                    }}>
                      <div style={{ color: C.danger, fontSize: 11, fontWeight: 700 }}>
                        [{e.source}] {e.code}
                      </div>
                      <div style={{ color: C.text, fontSize: 12, marginTop: 4 }}>
                        {e.message}
                      </div>
                    </div>
                  ))
                }
              </div>
            )}

            {/* ── Log tab ── */}
            {tab === "log" && (
              <div style={{ padding: "12px 16px", fontFamily: "monospace" }}>
                {log.length === 0
                  ? <div style={{ color: C.textDim, fontSize: 11 }}>No log entries</div>
                  : [...log].reverse().map((entry, i) => {
                    const col = { info: C.textDim, success: C.success, error: C.danger }[entry.level] || C.textDim;
                    return (
                      <div key={i} style={{ fontSize: 11, lineHeight: 1.8, color: col }}>
                        <span style={{ color: C.textDim }}>{entry.ts}</span>
                        {"  "}{entry.msg}
                      </div>
                    );
                  })
                }
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
