"""
Base Connector — Abstract interface all OSINT source adapters must implement
Cybopsec / OmniOSINT Framework

Security principles:
  - All API keys handled via environment variables or secrets manager
  - Rate limits enforced at the connector level (not just daemon)
  - All results are typed and validated before returning
  - Errors are structured and never expose raw exceptions upstream
"""

import time
import asyncio
import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional
import hashlib
import json

log = logging.getLogger(__name__)


class EntityType(str, Enum):
    PERSON   = "PERSON"
    DOMAIN   = "DOMAIN"
    IP       = "IP"
    EMAIL    = "EMAIL"
    PHONE    = "PHONE"
    ORG      = "ORG"
    HASH     = "HASH"
    USERNAME = "USERNAME"
    CERT     = "CERT"
    VULN     = "VULN"
    URL      = "URL"
    CRYPTO   = "CRYPTO"


class ResultType(str, Enum):
    MATCH        = "MATCH"
    RELATED      = "RELATED"
    ENRICHMENT   = "ENRICHMENT"
    BREACH       = "BREACH"
    EXPOSURE     = "EXPOSURE"
    CERTIFICATE  = "CERTIFICATE"
    DNS_RECORD   = "DNS_RECORD"
    PORT_SERVICE = "PORT_SERVICE"
    WHOIS        = "WHOIS"
    SOCIAL       = "SOCIAL"
    THREAT_INTEL = "THREAT_INTEL"


@dataclass
class RateLimit:
    requests_per_minute: int
    requests_per_day: int
    burst_size: int = 5

    def __post_init__(self):
        self._minute_window: List[float] = []
        self._day_window: List[float] = []

    def check_and_consume(self) -> bool:
        """Returns True if request is allowed, False if rate limited."""
        now = time.monotonic()
        # Clean stale entries
        self._minute_window = [t for t in self._minute_window if now - t < 60]
        self._day_window    = [t for t in self._day_window    if now - t < 86400]

        if len(self._minute_window) >= self.requests_per_minute:
            return False
        if len(self._day_window) >= self.requests_per_day:
            return False

        self._minute_window.append(now)
        self._day_window.append(now)
        return True

    async def wait_for_slot(self):
        """Async-friendly: block until a request slot is available."""
        while not self.check_and_consume():
            await asyncio.sleep(1)


@dataclass
class QueryParams:
    since: Optional[str]   = None   # ISO 8601
    until: Optional[str]   = None
    limit: int             = 100
    confidence_min: float  = 0.0
    extra: Dict[str, Any]  = field(default_factory=dict)


@dataclass
class OSINTResult:
    source:        str
    result_type:   ResultType
    entity_type:   EntityType
    value:         str
    raw:           Dict[str, Any]
    confidence:    float = 1.0
    tags:          List[str] = field(default_factory=list)
    relationships: List["OSINTResult"] = field(default_factory=list)
    timestamp:     Optional[str] = None
    metadata:      Dict[str, Any] = field(default_factory=dict)

    @property
    def fingerprint(self) -> str:
        """Deterministic ID for deduplication."""
        key = f"{self.source}:{self.entity_type}:{self.value}"
        return hashlib.sha256(key.encode()).hexdigest()[:16]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "fingerprint":   self.fingerprint,
            "source":        self.source,
            "result_type":   self.result_type.value,
            "entity_type":   self.entity_type.value,
            "value":         self.value,
            "confidence":    self.confidence,
            "tags":          self.tags,
            "timestamp":     self.timestamp,
            "metadata":      self.metadata,
            "relationships": [r.to_dict() for r in self.relationships],
        }


@dataclass
class ConnectorError:
    source:    str
    code:      str
    message:   str
    retryable: bool = False


class BaseConnector(ABC):
    """
    Abstract base for all OSINT source connectors.

    Subclasses must implement:
      - name (str property)
      - supported_entities (list property)
      - rate_limit (RateLimit property)
      - _search(entity_type, query, params) → list[OSINTResult]
      - health_check() → bool

    And optionally:
      - _enrich(result, params) → OSINTResult
    """

    @property
    @abstractmethod
    def name(self) -> str: ...

    @property
    @abstractmethod
    def supported_entities(self) -> List[EntityType]: ...

    @property
    @abstractmethod
    def rate_limit(self) -> RateLimit: ...

    @property
    def requires_auth(self) -> bool:
        return True

    # ------------------------------------------------------------------
    # Public API (called by daemon/orchestrator)
    # ------------------------------------------------------------------

    async def search(
        self,
        entity_type: EntityType,
        query: str,
        params: Optional[QueryParams] = None,
    ) -> List[OSINTResult] | ConnectorError:
        """Rate-limited search with error normalization."""
        if entity_type not in self.supported_entities:
            return ConnectorError(
                source=self.name,
                code="UNSUPPORTED_ENTITY",
                message=f"{self.name} does not support entity type {entity_type}",
                retryable=False,
            )
        await self.rate_limit.wait_for_slot()
        try:
            results = await self._search(entity_type, query, params or QueryParams())
            return [r for r in results if r.confidence >= (params.confidence_min if params else 0.0)]
        except Exception as exc:
            log.warning("[%s] search error: %s", self.name, exc, exc_info=True)
            return ConnectorError(
                source=self.name,
                code="SEARCH_ERROR",
                message=str(exc),
                retryable=True,
            )

    async def enrich(
        self,
        result: OSINTResult,
        params: Optional[QueryParams] = None,
    ) -> OSINTResult | ConnectorError:
        """Enrich an existing result with additional data from this source."""
        await self.rate_limit.wait_for_slot()
        try:
            return await self._enrich(result, params or QueryParams())
        except Exception as exc:
            log.warning("[%s] enrich error: %s", self.name, exc, exc_info=True)
            return ConnectorError(
                source=self.name,
                code="ENRICH_ERROR",
                message=str(exc),
                retryable=True,
            )

    # ------------------------------------------------------------------
    # Abstract internals
    # ------------------------------------------------------------------

    @abstractmethod
    async def _search(
        self,
        entity_type: EntityType,
        query: str,
        params: QueryParams,
    ) -> List[OSINTResult]: ...

    async def _enrich(
        self,
        result: OSINTResult,
        params: QueryParams,
    ) -> OSINTResult:
        """Default: return unchanged. Override for source-specific enrichment."""
        return result

    @abstractmethod
    async def health_check(self) -> bool: ...

    # ------------------------------------------------------------------
    # Utility
    # ------------------------------------------------------------------

    def _make_result(
        self,
        result_type: ResultType,
        entity_type: EntityType,
        value: str,
        raw: Dict[str, Any],
        confidence: float = 1.0,
        tags: Optional[List[str]] = None,
        timestamp: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> OSINTResult:
        return OSINTResult(
            source=self.name,
            result_type=result_type,
            entity_type=entity_type,
            value=value,
            raw=raw,
            confidence=confidence,
            tags=tags or [],
            timestamp=timestamp,
            metadata=metadata or {},
        )
