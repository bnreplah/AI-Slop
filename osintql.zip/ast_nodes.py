"""
OQL AST Nodes — Abstract Syntax Tree for OSINT Query Language
Cybopsec / OmniOSINT Framework
"""

from dataclasses import dataclass, field
from typing import Any, List, Optional, Union
from enum import Enum


class EntityType(str, Enum):
    PERSON   = "PERSON"
    DOMAIN   = "DOMAIN"
    IP       = "IP"
    EMAIL    = "EMAIL"
    PHONE    = "PHONE"
    ORG      = "ORG"
    HASH     = "HASH"
    USERNAME = "USERNAME"
    CERT     = "CERT"
    VULN     = "VULN"
    URL      = "URL"
    CRYPTO   = "CRYPTO"


class OutputFormat(str, Enum):
    GRAPH    = "GRAPH"
    JSON     = "JSON"
    TABLE    = "TABLE"
    TIMELINE = "TIMELINE"
    REPORT   = "REPORT"
    CSV      = "CSV"


class CompareOp(str, Enum):
    EQ       = "="
    NEQ      = "!="
    GT       = ">"
    LT       = "<"
    GTE      = ">="
    LTE      = "<="
    CONTAINS = "CONTAINS"
    MATCHES  = "MATCHES"


# ---------------------------------------------------------------------------
# Base
# ---------------------------------------------------------------------------

@dataclass
class ASTNode:
    """Base class for all AST nodes."""
    line: int = field(default=0, kw_only=True)
    col:  int = field(default=0, kw_only=True)

    def accept(self, visitor):
        method = f"visit_{type(self).__name__}"
        return getattr(visitor, method, visitor.generic_visit)(self)


# ---------------------------------------------------------------------------
# Literals
# ---------------------------------------------------------------------------

@dataclass
class StringLiteral(ASTNode):
    value: str

@dataclass
class IntegerLiteral(ASTNode):
    value: int

@dataclass
class FloatLiteral(ASTNode):
    value: float

@dataclass
class BoolLiteral(ASTNode):
    value: bool

@dataclass
class DatetimeLiteral(ASTNode):
    value: str  # ISO 8601

@dataclass
class RegexLiteral(ASTNode):
    pattern: str
    flags: str = ""

@dataclass
class ListLiteral(ASTNode):
    items: List[ASTNode] = field(default_factory=list)

@dataclass
class Identifier(ASTNode):
    name: str


# ---------------------------------------------------------------------------
# Expressions
# ---------------------------------------------------------------------------

@dataclass
class BinaryExpr(ASTNode):
    left: ASTNode
    op: str          # AND, OR
    right: ASTNode

@dataclass
class UnaryExpr(ASTNode):
    op: str          # NOT
    operand: ASTNode

@dataclass
class CompareExpr(ASTNode):
    field: str
    op: CompareOp
    value: ASTNode


# ---------------------------------------------------------------------------
# Clauses
# ---------------------------------------------------------------------------

@dataclass
class WhereClause(ASTNode):
    condition: ASTNode

@dataclass
class SinceClause(ASTNode):
    value: ASTNode          # DatetimeLiteral or relative string "30d"

@dataclass
class UntilClause(ASTNode):
    value: ASTNode

@dataclass
class LimitClause(ASTNode):
    count: int

@dataclass
class ExcludeClause(ASTNode):
    sources: List[str] = field(default_factory=list)

@dataclass
class ConfidenceClause(ASTNode):
    min_score: float        # 0.0–1.0

@dataclass
class ViaClause(ASTNode):
    sources: List[str] = field(default_factory=list)

@dataclass
class OutputClause(ASTNode):
    format: OutputFormat
    filepath: Optional[str] = None


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------

@dataclass
class SearchCmd(ASTNode):
    entity_type: EntityType
    query: ASTNode                           # StringLiteral or expression
    clauses: List[ASTNode] = field(default_factory=list)

@dataclass
class PivotCmd(ASTNode):
    target_type: EntityType
    clauses: List[ASTNode] = field(default_factory=list)

@dataclass
class EnrichCmd(ASTNode):
    target_type: Optional[EntityType]        # None = enrich all fields
    sources: List[str] = field(default_factory=list)  # [] = all sources
    clauses: List[ASTNode] = field(default_factory=list)

@dataclass
class CorrelateCmd(ASTNode):
    target_type: EntityType
    clauses: List[ASTNode] = field(default_factory=list)

@dataclass
class TraceCmd(ASTNode):
    target_type: EntityType
    depth: int = 3
    clauses: List[ASTNode] = field(default_factory=list)

@dataclass
class DiffCmd(ASTNode):
    """Compare two SEARCH results."""
    left_query: "Pipeline"
    right_query: "Pipeline"
    clauses: List[ASTNode] = field(default_factory=list)

@dataclass
class MonitorCmd(ASTNode):
    entity_type: EntityType
    query: ASTNode
    interval_seconds: int = 3600
    clauses: List[ASTNode] = field(default_factory=list)

@dataclass
class ExportCmd(ASTNode):
    format: OutputFormat
    filepath: str


# ---------------------------------------------------------------------------
# Pipeline
# ---------------------------------------------------------------------------

@dataclass
class Pipeline(ASTNode):
    """A |>-chained sequence of commands."""
    stages: List[ASTNode] = field(default_factory=list)
    output: Optional[OutputClause] = None


# ---------------------------------------------------------------------------
# Program (root node)
# ---------------------------------------------------------------------------

@dataclass
class Program(ASTNode):
    pipelines: List[Pipeline] = field(default_factory=list)
