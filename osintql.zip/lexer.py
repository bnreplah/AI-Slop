"""
OQL Lexer — OSINT Query Language Tokenizer
Cybopsec / OmniOSINT Framework
"""

import re
from dataclasses import dataclass
from enum import Enum, auto
from typing import Iterator, List


class TokenType(Enum):
    # --- Commands ---
    SEARCH    = auto()
    PIVOT     = auto()
    ENRICH    = auto()
    CORRELATE = auto()
    TRACE     = auto()
    DIFF      = auto()
    MONITOR   = auto()
    EXPORT    = auto()

    # --- Entity types ---
    PERSON    = auto()
    DOMAIN    = auto()
    IP        = auto()
    EMAIL     = auto()
    PHONE     = auto()
    ORG       = auto()
    HASH      = auto()
    USERNAME  = auto()
    CERT      = auto()
    VULN      = auto()
    URL       = auto()
    CRYPTO    = auto()

    # --- Clauses ---
    WHERE     = auto()
    SINCE     = auto()
    UNTIL     = auto()
    LIMIT     = auto()
    EXCLUDE   = auto()
    CONFIDENCE= auto()
    AS        = auto()
    TO        = auto()
    FROM      = auto()
    VIA       = auto()

    # --- Output formats ---
    GRAPH     = auto()
    JSON      = auto()
    TABLE     = auto()
    TIMELINE  = auto()
    REPORT    = auto()
    CSV       = auto()

    # --- Sources ---
    SHODAN    = auto()
    CENSYS    = auto()
    HIBP      = auto()
    VIRUSTOTAL= auto()
    WHOIS     = auto()
    HUNTER    = auto()
    FULLHUNT  = auto()
    LEAKIX    = auto()
    INTELX    = auto()
    CRTSH     = auto()
    ALL       = auto()

    # --- Operators ---
    PIPE      = auto()   # |>
    AND       = auto()
    OR        = auto()
    NOT       = auto()
    EQ        = auto()   # =
    NEQ       = auto()   # !=
    GT        = auto()   # >
    LT        = auto()   # <
    GTE       = auto()   # >=
    LTE       = auto()   # <=
    CONTAINS  = auto()
    MATCHES   = auto()   # regex match

    # --- Literals ---
    STRING    = auto()
    INTEGER   = auto()
    FLOAT     = auto()
    DATETIME  = auto()
    REGEX     = auto()
    BOOLEAN   = auto()

    # --- Structure ---
    LBRACKET  = auto()   # [
    RBRACKET  = auto()   # ]
    LPAREN    = auto()   # (
    RPAREN    = auto()   # )
    COMMA     = auto()
    COLON     = auto()
    DOT       = auto()
    NEWLINE   = auto()
    SEMICOLON = auto()

    # --- Meta ---
    COMMENT   = auto()
    IDENT     = auto()
    EOF       = auto()
    UNKNOWN   = auto()


@dataclass
class Token:
    type: TokenType
    value: str
    line: int
    col: int

    def __repr__(self):
        return f"Token({self.type.name}, {self.value!r}, L{self.line}:C{self.col})"


# Keyword map: lowercased token string → TokenType
KEYWORDS: dict[str, TokenType] = {
    # Commands
    "search":     TokenType.SEARCH,
    "pivot":      TokenType.PIVOT,
    "enrich":     TokenType.ENRICH,
    "correlate":  TokenType.CORRELATE,
    "trace":      TokenType.TRACE,
    "diff":       TokenType.DIFF,
    "monitor":    TokenType.MONITOR,
    "export":     TokenType.EXPORT,
    # Entity types
    "person":     TokenType.PERSON,
    "domain":     TokenType.DOMAIN,
    "ip":         TokenType.IP,
    "email":      TokenType.EMAIL,
    "phone":      TokenType.PHONE,
    "org":        TokenType.ORG,
    "hash":       TokenType.HASH,
    "username":   TokenType.USERNAME,
    "cert":       TokenType.CERT,
    "vuln":       TokenType.VULN,
    "url":        TokenType.URL,
    "crypto":     TokenType.CRYPTO,
    # Clauses
    "where":      TokenType.WHERE,
    "since":      TokenType.SINCE,
    "until":      TokenType.UNTIL,
    "limit":      TokenType.LIMIT,
    "exclude":    TokenType.EXCLUDE,
    "confidence": TokenType.CONFIDENCE,
    "as":         TokenType.AS,
    "to":         TokenType.TO,
    "from":       TokenType.FROM,
    "via":        TokenType.VIA,
    # Output formats
    "graph":      TokenType.GRAPH,
    "json":       TokenType.JSON,
    "table":      TokenType.TABLE,
    "timeline":   TokenType.TIMELINE,
    "report":     TokenType.REPORT,
    "csv":        TokenType.CSV,
    # Sources
    "shodan":     TokenType.SHODAN,
    "censys":     TokenType.CENSYS,
    "hibp":       TokenType.HIBP,
    "virustotal": TokenType.VIRUSTOTAL,
    "whois":      TokenType.WHOIS,
    "hunter":     TokenType.HUNTER,
    "fullhunt":   TokenType.FULLHUNT,
    "leakix":     TokenType.LEAKIX,
    "intelx":     TokenType.INTELX,
    "crtsh":      TokenType.CRTSH,
    "all":        TokenType.ALL,
    # Boolean ops
    "and":        TokenType.AND,
    "or":         TokenType.OR,
    "not":        TokenType.NOT,
    "contains":   TokenType.CONTAINS,
    "matches":    TokenType.MATCHES,
    "true":       TokenType.BOOLEAN,
    "false":      TokenType.BOOLEAN,
}

# Token patterns ordered by priority
TOKEN_PATTERNS = [
    (TokenType.COMMENT,   r'#[^\n]*'),
    (TokenType.PIPE,      r'\|>'),
    (TokenType.GTE,       r'>='),
    (TokenType.LTE,       r'<='),
    (TokenType.NEQ,       r'!='),
    (TokenType.EQ,        r'='),
    (TokenType.GT,        r'>'),
    (TokenType.LT,        r'<'),
    (TokenType.LBRACKET,  r'\['),
    (TokenType.RBRACKET,  r'\]'),
    (TokenType.LPAREN,    r'\('),
    (TokenType.RPAREN,    r'\)'),
    (TokenType.COMMA,     r','),
    (TokenType.COLON,     r':'),
    (TokenType.DOT,       r'\.'),
    (TokenType.SEMICOLON, r';'),
    (TokenType.NEWLINE,   r'\n'),
    (TokenType.DATETIME,  r'\d{4}-\d{2}-\d{2}(?:T\d{2}:\d{2}:\d{2})?'),
    (TokenType.FLOAT,     r'\d+\.\d+'),
    (TokenType.INTEGER,   r'\d+'),
    (TokenType.STRING,    r'"(?:[^"\\]|\\.)*"|\'(?:[^\'\\]|\\.)*\''),
    (TokenType.REGEX,     r'/(?:[^/\\]|\\.)+/[gimsuy]*'),
    (TokenType.IDENT,     r'[A-Za-z_][A-Za-z0-9_\-]*'),
]

_MASTER_PATTERN = re.compile(
    r'[ \t]+|' +  # whitespace (skip)
    '|'.join(f'(?P<T{i}_{tt.name}>{pat})' for i, (tt, pat) in enumerate(TOKEN_PATTERNS)),
    re.IGNORECASE
)


class LexerError(Exception):
    def __init__(self, msg: str, line: int, col: int):
        super().__init__(f"[LexerError L{line}:C{col}] {msg}")
        self.line = line
        self.col = col


class Lexer:
    """
    Tokenizes an OQL query string into a list of Token objects.

    Usage:
        lexer = Lexer(source)
        tokens = lexer.tokenize()
    """

    def __init__(self, source: str):
        self.source = source
        self.line = 1
        self.col = 1
        self._tokens: List[Token] = []

    def tokenize(self) -> List[Token]:
        pos = 0
        src = self.source
        length = len(src)

        while pos < length:
            m = _MASTER_PATTERN.match(src, pos)
            if not m:
                raise LexerError(
                    f"Unexpected character {src[pos]!r}",
                    self.line, self.col
                )

            matched_text = m.group(0)

            # Skip pure whitespace
            if matched_text.strip(' \t') == '' and '\n' not in matched_text:
                self.col += len(matched_text)
                pos = m.end()
                continue

            # Identify which group matched
            tok_type = None
            tok_val = matched_text

            for i, (tt, _) in enumerate(TOKEN_PATTERNS):
                group_name = f'T{i}_{tt.name}'
                if m.group(group_name) is not None:
                    tok_type = tt
                    tok_val = m.group(group_name)
                    break

            if tok_type is None:
                pos = m.end()
                continue

            # Resolve IDENT → keyword or leave as IDENT
            if tok_type == TokenType.IDENT:
                kw = KEYWORDS.get(tok_val.lower())
                if kw is not None:
                    tok_type = kw

            # Skip comments
            if tok_type != TokenType.COMMENT:
                self._tokens.append(Token(tok_type, tok_val, self.line, self.col))

            # Update line/col tracking
            if tok_type == TokenType.NEWLINE:
                self.line += 1
                self.col = 1
            else:
                self.col += len(tok_val)

            pos = m.end()

        self._tokens.append(Token(TokenType.EOF, '', self.line, self.col))
        return self._tokens

    def token_stream(self) -> Iterator[Token]:
        yield from self.tokenize()
