"""
Connector Registry — Auto-discovery and lifecycle management
Cybopsec / OmniOSINT Framework
"""

import importlib
import inspect
import logging
import os
from typing import Dict, List, Optional, Type

from .base_connector import BaseConnector, EntityType, QueryParams, OSINTResult

log = logging.getLogger(__name__)


class ConnectorRegistry:
    """
    Central registry for all OSINT connectors.

    Connectors are registered by name and looked up by name or supported entity type.
    Auto-discovery scans the connectors/ package for BaseConnector subclasses.
    """

    def __init__(self):
        self._connectors: Dict[str, BaseConnector] = {}

    def register(self, connector: BaseConnector):
        """Register a connector instance."""
        name = connector.name
        if name in self._connectors:
            log.warning("Overwriting existing connector: %s", name)
        self._connectors[name] = connector
        log.info("Registered connector: %s (entities: %s)", name,
                 [e.value for e in connector.supported_entities])

    def get(self, name: str) -> Optional[BaseConnector]:
        return self._connectors.get(name)

    def all(self) -> List[BaseConnector]:
        return list(self._connectors.values())

    def for_entity(self, entity_type: EntityType) -> List[BaseConnector]:
        """Return all connectors that support a given entity type."""
        return [c for c in self._connectors.values()
                if entity_type in c.supported_entities]

    def for_sources(self, sources: List[str]) -> List[BaseConnector]:
        """Return connectors matching a list of source names. 'all' returns everything."""
        if not sources or "all" in sources:
            return self.all()
        result = []
        for name in sources:
            c = self._connectors.get(name)
            if c:
                result.append(c)
            else:
                log.warning("Unknown source requested: %s", name)
        return result

    async def health_report(self) -> Dict[str, bool]:
        """Run health checks on all registered connectors."""
        import asyncio
        tasks = {name: c.health_check() for name, c in self._connectors.items()}
        results = await asyncio.gather(*tasks.values(), return_exceptions=True)
        return {
            name: (r if isinstance(r, bool) else False)
            for name, r in zip(tasks.keys(), results)
        }

    def __len__(self):
        return len(self._connectors)

    def __repr__(self):
        return f"<ConnectorRegistry [{', '.join(self._connectors.keys())}]>"


def build_default_registry() -> ConnectorRegistry:
    """
    Build a registry with all built-in connectors, configured via environment vars.
    Connectors whose auth check fails are registered but will return errors at query time.
    """
    from .shodan import ShodanConnector
    from .sources import (
        HIBPConnector, VirusTotalConnector, WHOISConnector,
        HunterConnector, CRTSHConnector,
    )

    reg = ConnectorRegistry()

    # Built-in connectors
    connectors = [
        ShodanConnector(),
        HIBPConnector(),
        VirusTotalConnector(),
        WHOISConnector(),
        HunterConnector(),
        CRTSHConnector(),
    ]

    for c in connectors:
        reg.register(c)

    # Auto-discover user plugins from OMNI_PLUGINS_DIR
    plugins_dir = os.environ.get("OMNI_PLUGINS_DIR")
    if plugins_dir and os.path.isdir(plugins_dir):
        _autodiscover(reg, plugins_dir)

    return reg


def _autodiscover(reg: ConnectorRegistry, plugins_dir: str):
    """
    Scan a directory for Python files and register any BaseConnector subclasses found.
    This is the plugin system — drop a .py file in OMNI_PLUGINS_DIR to add a connector.
    """
    import sys
    sys.path.insert(0, plugins_dir)

    for fname in os.listdir(plugins_dir):
        if not fname.endswith(".py") or fname.startswith("_"):
            continue
        module_name = fname[:-3]
        try:
            mod = importlib.import_module(module_name)
            for _, obj in inspect.getmembers(mod, inspect.isclass):
                if (issubclass(obj, BaseConnector)
                        and obj is not BaseConnector
                        and not inspect.isabstract(obj)):
                    try:
                        instance = obj()
                        reg.register(instance)
                    except Exception as e:
                        log.warning("Could not instantiate plugin %s.%s: %s",
                                    module_name, obj.__name__, e)
        except Exception as e:
            log.warning("Could not load plugin module %s: %s", module_name, e)
