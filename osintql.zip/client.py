"""
OmniOSINT Python SDK
Cybopsec / OmniOSINT Framework

Provides:
  - OmniClient: high-level async/sync API for running OQL queries
  - QueryBuilder: fluent Python DSL that generates OQL source
  - ResultSet: structured, filterable query result container

Usage (async):
    from omni_osint import OmniClient

    async with OmniClient() as client:
        results = await client.search("DOMAIN", "example.com")
        # or full OQL:
        results = await client.query('''
            SEARCH DOMAIN "example.com"
              |> ENRICH [shodan, crtsh]
              |> PIVOT IP
              AS JSON TO "out.json"
        ''')

Usage (sync):
    client = OmniClient.sync()
    results = client.search_sync("EMAIL", "user@example.com")

Usage (QueryBuilder):
    from omni_osint import QueryBuilder

    q = (QueryBuilder()
         .search("DOMAIN", "example.com")
         .via(["shodan", "crtsh"])
         .enrich()
         .pivot("IP")
         .limit(50)
         .as_json("output.json"))
    async with OmniClient() as c:
        results = await c.query(q.build())
"""

import asyncio
import json
import socket
import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, Iterator, List, Optional, Union

DEFAULT_SOCKET_PATH = "/tmp/omniod.sock"
DEFAULT_HTTP_BASE   = "http://127.0.0.1:7743"


# ===========================================================================
# Result models
# ===========================================================================

@dataclass
class Result:
    fingerprint:   str
    source:        str
    result_type:   str
    entity_type:   str
    value:         str
    confidence:    float
    tags:          List[str]
    timestamp:     Optional[str]
    metadata:      Dict[str, Any]
    relationships: List["Result"] = field(default_factory=list)

    @classmethod
    def from_dict(cls, d: Dict) -> "Result":
        return cls(
            fingerprint=d.get("fingerprint", ""),
            source=d.get("source", ""),
            result_type=d.get("result_type", ""),
            entity_type=d.get("entity_type", ""),
            value=d.get("value", ""),
            confidence=d.get("confidence", 0.0),
            tags=d.get("tags", []),
            timestamp=d.get("timestamp"),
            metadata=d.get("metadata", {}),
            relationships=[Result.from_dict(r) for r in d.get("relationships", [])],
        )

    def __repr__(self):
        return f"<Result {self.entity_type}:{self.value!r} from={self.source} conf={self.confidence:.2f}>"


class ResultSet:
    """Filterable, iterable collection of OSINT results."""

    def __init__(self, results: List[Result], errors: List[Dict] = None,
                 meta: Dict = None):
        self._results = results
        self.errors   = errors or []
        self.meta     = meta or {}

    def __len__(self):
        return len(self._results)

    def __iter__(self) -> Iterator[Result]:
        return iter(self._results)

    def __getitem__(self, idx):
        return self._results[idx]

    # --- Filtering ---

    def by_source(self, source: str) -> "ResultSet":
        return ResultSet([r for r in self._results if r.source == source])

    def by_type(self, entity_type: str) -> "ResultSet":
        return ResultSet([r for r in self._results
                          if r.entity_type.upper() == entity_type.upper()])

    def above_confidence(self, threshold: float) -> "ResultSet":
        return ResultSet([r for r in self._results if r.confidence >= threshold])

    def with_tag(self, tag: str) -> "ResultSet":
        return ResultSet([r for r in self._results if tag in r.tags])

    def breaches_only(self) -> "ResultSet":
        return ResultSet([r for r in self._results if r.result_type == "BREACH"])

    def threats_only(self) -> "ResultSet":
        return ResultSet([r for r in self._results if r.result_type == "THREAT_INTEL"])

    # --- Export ---

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(
            [{"fingerprint": r.fingerprint, "source": r.source,
              "result_type": r.result_type, "entity_type": r.entity_type,
              "value": r.value, "confidence": r.confidence,
              "tags": r.tags, "timestamp": r.timestamp,
              "metadata": r.metadata} for r in self._results],
            indent=indent, default=str
        )

    def to_csv_rows(self) -> List[Dict]:
        return [
            {"source": r.source, "type": r.entity_type, "value": r.value,
             "confidence": r.confidence, "tags": ",".join(r.tags),
             "timestamp": r.timestamp or ""}
            for r in self._results
        ]

    def summary(self) -> Dict:
        by_src  = {}
        by_type = {}
        for r in self._results:
            by_src[r.source]        = by_src.get(r.source, 0) + 1
            by_type[r.entity_type]  = by_type.get(r.entity_type, 0) + 1
        return {
            "total":      len(self._results),
            "errors":     len(self.errors),
            "by_source":  by_src,
            "by_type":    by_type,
            "avg_confidence": (sum(r.confidence for r in self._results) /
                               len(self._results)) if self._results else 0.0,
        }

    def __repr__(self):
        return f"<ResultSet n={len(self._results)} errors={len(self.errors)}>"


# ===========================================================================
# Client
# ===========================================================================

class OmniClient:
    """
    Async client for the omniod daemon.

    Connects via Unix socket (default) or HTTP REST.
    """

    def __init__(
        self,
        socket_path: Optional[str] = DEFAULT_SOCKET_PATH,
        http_base:   Optional[str] = None,
        timeout:     int = 60,
    ):
        self._socket_path = socket_path
        self._http_base   = http_base
        self._timeout     = timeout
        self._reader: Optional[asyncio.StreamReader]  = None
        self._writer: Optional[asyncio.StreamWriter]  = None

    async def __aenter__(self):
        await self.connect()
        return self

    async def __aexit__(self, *_):
        await self.close()

    async def connect(self):
        if self._http_base:
            return  # HTTP is stateless
        self._reader, self._writer = await asyncio.open_unix_connection(
            self._socket_path
        )

    async def close(self):
        if self._writer:
            self._writer.close()
            try:
                await self._writer.wait_closed()
            except Exception:
                pass

    # --- High-level API ---

    async def query(self, oql: str, priority: int = 5) -> ResultSet:
        """Execute raw OQL and return a ResultSet."""
        resp = await self._send_request({
            "id": str(uuid.uuid4()),
            "type": "query",
            "payload": oql,
            "priority": priority,
            "timeout": self._timeout,
        })
        results = [Result.from_dict(r) for r in resp.get("results", [])]
        return ResultSet(results, resp.get("errors", []), resp.get("meta", {}))

    async def search(
        self, entity_type: str, query: str,
        sources: Optional[List[str]] = None,
        limit: int = 100,
        confidence: float = 0.0,
    ) -> ResultSet:
        """Convenience: build and run a SEARCH query."""
        oql = f'SEARCH {entity_type.upper()} "{query}"'
        if sources:
            oql += f"\n  VIA [{', '.join(sources)}]"
        if limit != 100:
            oql += f"\n  LIMIT {limit}"
        if confidence > 0:
            oql += f"\n  CONFIDENCE >= {confidence}"
        return await self.query(oql)

    async def health(self) -> Dict:
        resp = await self._send_request({"id": str(uuid.uuid4()), "type": "health"})
        return resp.get("meta", {})

    async def status(self) -> Dict:
        resp = await self._send_request({"id": str(uuid.uuid4()), "type": "status"})
        return resp.get("meta", {})

    # --- Transport ---

    async def _send_request(self, payload: Dict) -> Dict:
        if self._http_base:
            return await self._http_request(payload)
        return await self._socket_request(payload)

    async def _socket_request(self, payload: Dict) -> Dict:
        if not self._writer:
            await self.connect()
        line = json.dumps(payload) + "\n"
        self._writer.write(line.encode())
        await self._writer.drain()
        raw = await asyncio.wait_for(self._reader.readline(), timeout=self._timeout)
        return json.loads(raw.decode().strip())

    async def _http_request(self, payload: Dict) -> Dict:
        try:
            import aiohttp
        except ImportError:
            raise RuntimeError("aiohttp required for HTTP transport: pip install aiohttp")

        req_type = payload.get("type", "query")
        url_map = {
            "query":  f"{self._http_base}/query",
            "health": f"{self._http_base}/health",
            "status": f"{self._http_base}/status",
        }
        url = url_map.get(req_type, f"{self._http_base}/query")

        async with aiohttp.ClientSession() as s:
            if req_type == "query":
                async with s.post(url, json={"query": payload.get("payload", ""),
                                             "timeout": payload.get("timeout", 60)},
                                  timeout=aiohttp.ClientTimeout(total=self._timeout + 5)) as resp:
                    return await resp.json()
            else:
                async with s.get(url, timeout=aiohttp.ClientTimeout(total=15)) as resp:
                    return await resp.json()

    # --- Sync convenience wrapper ---

    @classmethod
    def sync(cls, **kwargs) -> "SyncOmniClient":
        return SyncOmniClient(**kwargs)


class SyncOmniClient:
    """Synchronous wrapper around OmniClient using a dedicated event loop."""

    def __init__(self, **kwargs):
        self._kwargs = kwargs
        self._loop   = asyncio.new_event_loop()

    def _run(self, coro):
        return self._loop.run_until_complete(coro)

    def query(self, oql: str, **kwargs) -> ResultSet:
        async def _q():
            async with OmniClient(**self._kwargs) as c:
                return await c.query(oql, **kwargs)
        return self._run(_q())

    def search(self, entity_type: str, query: str, **kwargs) -> ResultSet:
        async def _s():
            async with OmniClient(**self._kwargs) as c:
                return await c.search(entity_type, query, **kwargs)
        return self._run(_s())

    def health(self) -> Dict:
        async def _h():
            async with OmniClient(**self._kwargs) as c:
                return await c.health()
        return self._run(_h())

    def close(self):
        self._loop.close()

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()


# ===========================================================================
# QueryBuilder — Fluent DSL
# ===========================================================================

class QueryBuilder:
    """
    Fluent Python API that generates OQL source strings.

    Example:
        oql = (QueryBuilder()
               .search("DOMAIN", "example.com")
               .via(["shodan", "crtsh"])
               .where("confidence >= 0.7")
               .enrich()
               .pivot("IP")
               .limit(50)
               .as_json("results.json")
               .build())
    """

    def __init__(self):
        self._stages: List[str] = []
        self._current_clauses: List[str] = []
        self._output: Optional[str] = None

    def _flush_stage(self, cmd: str):
        """Finalize current stage with its clauses."""
        if self._current_clauses:
            cmd += "\n  " + "\n  ".join(self._current_clauses)
            self._current_clauses = []
        self._stages.append(cmd)
        return self

    def search(self, entity_type: str, query: str) -> "QueryBuilder":
        if self._stages:
            self._flush_stage(self._stages[-1]) if self._current_clauses else None
        self._current_entity = entity_type.upper()
        self._current_cmd = f'SEARCH {entity_type.upper()} "{query}"'
        return self

    def pivot(self, entity_type: str) -> "QueryBuilder":
        self._flush_stage(self._current_cmd)
        self._current_cmd = f"PIVOT {entity_type.upper()}"
        return self

    def enrich(self, sources: Optional[List[str]] = None) -> "QueryBuilder":
        self._flush_stage(self._current_cmd)
        if sources:
            self._current_cmd = f"ENRICH [{', '.join(sources)}]"
        else:
            self._current_cmd = "ENRICH"
        return self

    def correlate(self, entity_type: str) -> "QueryBuilder":
        self._flush_stage(self._current_cmd)
        self._current_cmd = f"CORRELATE {entity_type.upper()}"
        return self

    def trace(self, entity_type: str, depth: int = 3) -> "QueryBuilder":
        self._flush_stage(self._current_cmd)
        self._current_cmd = f"TRACE {entity_type.upper()}:{depth}"
        return self

    # --- Clauses (apply to current stage) ---

    def where(self, condition: str) -> "QueryBuilder":
        self._current_clauses.append(f"WHERE {condition}")
        return self

    def via(self, sources: List[str]) -> "QueryBuilder":
        self._current_clauses.append(f"VIA [{', '.join(sources)}]")
        return self

    def limit(self, n: int) -> "QueryBuilder":
        self._current_clauses.append(f"LIMIT {n}")
        return self

    def since(self, dt: str) -> "QueryBuilder":
        self._current_clauses.append(f'SINCE "{dt}"')
        return self

    def confidence(self, min_score: float) -> "QueryBuilder":
        self._current_clauses.append(f"CONFIDENCE >= {min_score}")
        return self

    def exclude(self, sources: List[str]) -> "QueryBuilder":
        self._current_clauses.append(f"EXCLUDE [{', '.join(sources)}]")
        return self

    # --- Output ---

    def as_json(self, filepath: Optional[str] = None) -> "QueryBuilder":
        self._output = f'AS JSON' + (f' TO "{filepath}"' if filepath else '')
        return self

    def as_table(self) -> "QueryBuilder":
        self._output = "AS TABLE"
        return self

    def as_graph(self, filepath: Optional[str] = None) -> "QueryBuilder":
        self._output = f'AS GRAPH' + (f' TO "{filepath}"' if filepath else '')
        return self

    def as_csv(self, filepath: str) -> "QueryBuilder":
        self._output = f'AS CSV TO "{filepath}"'
        return self

    # --- Build ---

    def build(self) -> str:
        """Generate the final OQL string."""
        if hasattr(self, "_current_cmd"):
            self._flush_stage(self._current_cmd)
            del self._current_cmd

        pipeline = "\n  |> ".join(self._stages)
        if self._output:
            pipeline += f"\n{self._output}"
        return pipeline

    def __str__(self):
        return self.build()
