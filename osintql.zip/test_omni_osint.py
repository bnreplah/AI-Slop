"""
OmniOSINT Test Suite
Tests: OQL lexer, parser, AST nodes, connector base, dedup, query builder
"""

import asyncio
import pytest
from unittest.mock import AsyncMock, MagicMock, patch

import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from omni_osint.oql.lexer import Lexer, TokenType, LexerError
from omni_osint.oql.parser import Parser, ParseError, parse
from omni_osint.oql.ast_nodes import (
    Program, Pipeline, SearchCmd, PivotCmd, EnrichCmd,
    CorrelateCmd, TraceCmd, EntityType, OutputFormat,
    WhereClause, LimitClause, ViaClause, ConfidenceClause,
    CompareExpr, BinaryExpr, CompareOp,
    StringLiteral, IntegerLiteral, FloatLiteral,
)
from omni_osint.connectors.base_connector import (
    BaseConnector, EntityType as CET, QueryParams,
    OSINTResult, ResultType, RateLimit, ConnectorError,
)
from omni_osint.sdk.client import QueryBuilder, ResultSet, Result


# ═══════════════════════════════════════════════════════════════════════════
# Lexer Tests
# ═══════════════════════════════════════════════════════════════════════════

class TestLexer:

    def _tokens(self, src):
        return [(t.type, t.value) for t in Lexer(src).tokenize()
                if t.type != TokenType.EOF]

    def test_basic_search_tokens(self):
        toks = self._tokens('SEARCH DOMAIN "example.com"')
        types = [t for t, _ in toks]
        assert TokenType.SEARCH in types
        assert TokenType.DOMAIN in types
        assert TokenType.STRING in types

    def test_keyword_case_insensitive(self):
        toks1 = self._tokens("search DOMAIN")
        toks2 = self._tokens("SEARCH domain")
        types1 = {t for t, _ in toks1}
        types2 = {t for t, _ in toks2}
        assert types1 == types2

    def test_pipe_operator(self):
        toks = self._tokens("SEARCH IP |> PIVOT DOMAIN")
        pipe = [(t, v) for t, v in toks if t == TokenType.PIPE]
        assert len(pipe) == 1
        assert pipe[0][1] == "|>"

    def test_string_with_escapes(self):
        toks = self._tokens(r'"hello \"world\""')
        strings = [(t, v) for t, v in toks if t == TokenType.STRING]
        assert len(strings) == 1

    def test_integer_and_float(self):
        toks = self._tokens("100 3.14")
        types = [t for t, _ in toks]
        assert TokenType.INTEGER in types
        assert TokenType.FLOAT in types

    def test_comment_skipped(self):
        toks = self._tokens("# this is a comment\nSEARCH DOMAIN")
        types = [t for t, _ in toks]
        assert TokenType.COMMENT not in types
        assert TokenType.SEARCH in types

    def test_source_tokens(self):
        toks = self._tokens("[shodan, censys, hibp]")
        types = [t for t, _ in toks]
        assert TokenType.SHODAN in types
        assert TokenType.CENSYS in types
        assert TokenType.HIBP in types

    def test_comparison_operators(self):
        src = ">= <= != = > <"
        toks = self._tokens(src)
        types = {t for t, _ in toks}
        assert {TokenType.GTE, TokenType.LTE, TokenType.NEQ,
                TokenType.EQ, TokenType.GT, TokenType.LT} == types

    def test_datetime_token(self):
        toks = self._tokens("2025-01-15")
        assert any(t == TokenType.DATETIME for t, _ in toks)

    def test_regex_token(self):
        toks = self._tokens("/^admin.*/i")
        assert any(t == TokenType.REGEX for t, _ in toks)

    def test_unknown_char_raises(self):
        with pytest.raises(LexerError):
            Lexer("@@@").tokenize()


# ═══════════════════════════════════════════════════════════════════════════
# Parser Tests
# ═══════════════════════════════════════════════════════════════════════════

class TestParser:

    def test_simple_search(self):
        prog = parse('SEARCH DOMAIN "example.com"')
        assert len(prog.pipelines) == 1
        stage = prog.pipelines[0].stages[0]
        assert isinstance(stage, SearchCmd)
        assert stage.entity_type == EntityType.DOMAIN
        assert isinstance(stage.query, StringLiteral)
        assert stage.query.value == "example.com"

    def test_all_entity_types(self):
        entities = ["PERSON", "DOMAIN", "IP", "EMAIL", "PHONE",
                    "ORG", "HASH", "USERNAME", "CERT", "VULN", "URL", "CRYPTO"]
        for ent in entities:
            prog = parse(f'SEARCH {ent} "test"')
            assert prog.pipelines[0].stages[0].entity_type == EntityType(ent)

    def test_pipeline_stages(self):
        prog = parse('SEARCH DOMAIN "example.com"\n  |> PIVOT IP\n  |> ENRICH')
        pipe = prog.pipelines[0]
        assert len(pipe.stages) == 3
        assert isinstance(pipe.stages[0], SearchCmd)
        assert isinstance(pipe.stages[1], PivotCmd)
        assert isinstance(pipe.stages[2], EnrichCmd)

    def test_where_clause(self):
        prog = parse('SEARCH IP "1.2.3.4" WHERE confidence >= 0.9')
        cmd = prog.pipelines[0].stages[0]
        where = next(c for c in cmd.clauses if isinstance(c, WhereClause))
        assert where is not None
        cmp = where.condition
        assert isinstance(cmp, CompareExpr)
        assert cmp.op == CompareOp.GTE

    def test_where_and_condition(self):
        prog = parse('SEARCH EMAIL "x" WHERE source = "shodan" AND confidence > 0.5')
        cmd = prog.pipelines[0].stages[0]
        where = next(c for c in cmd.clauses if isinstance(c, WhereClause))
        assert isinstance(where.condition, BinaryExpr)
        assert where.condition.op == "AND"

    def test_limit_clause(self):
        prog = parse('SEARCH IP "x" LIMIT 50')
        cmd = prog.pipelines[0].stages[0]
        limit = next(c for c in cmd.clauses if isinstance(c, LimitClause))
        assert limit.count == 50

    def test_via_clause(self):
        prog = parse('SEARCH DOMAIN "x" VIA [shodan, crtsh]')
        cmd = prog.pipelines[0].stages[0]
        via = next(c for c in cmd.clauses if isinstance(c, ViaClause))
        assert "shodan" in via.sources
        assert "crtsh" in via.sources

    def test_confidence_clause(self):
        prog = parse('SEARCH EMAIL "x" CONFIDENCE >= 0.75')
        cmd = prog.pipelines[0].stages[0]
        conf = next(c for c in cmd.clauses if isinstance(c, ConfidenceClause))
        assert conf.min_score == 0.75

    def test_output_clause_as_json(self):
        prog = parse('SEARCH IP "x" AS JSON TO "out.json"')
        pipe = prog.pipelines[0]
        assert pipe.output is not None
        assert pipe.output.format == OutputFormat.JSON
        assert pipe.output.filepath == "out.json"

    def test_output_clause_as_table(self):
        prog = parse('SEARCH IP "x" AS TABLE')
        pipe = prog.pipelines[0]
        assert pipe.output.format == OutputFormat.TABLE
        assert pipe.output.filepath is None

    def test_trace_with_depth(self):
        prog = parse('TRACE DOMAIN:5')
        cmd = prog.pipelines[0].stages[0]
        assert isinstance(cmd, TraceCmd)
        assert cmd.depth == 5

    def test_enrich_with_sources(self):
        prog = parse('SEARCH DOMAIN "x" |> ENRICH [shodan, hibp]')
        enrich = prog.pipelines[0].stages[1]
        assert isinstance(enrich, EnrichCmd)
        assert "shodan" in enrich.sources
        assert "hibp" in enrich.sources

    def test_multi_pipeline(self):
        prog = parse('SEARCH DOMAIN "x"\nSEARCH IP "y"')
        assert len(prog.pipelines) == 2

    def test_parse_error_bad_entity(self):
        with pytest.raises(ParseError):
            parse('SEARCH NOTANENTITY "x"')

    def test_full_complex_query(self):
        oql = """
        SEARCH DOMAIN "example.com"
          WHERE confidence >= 0.7
          VIA [shodan, crtsh]
          LIMIT 100
          |> ENRICH [hibp, virustotal]
          |> PIVOT IP
          |> CORRELATE DOMAIN
          AS JSON TO "results.json"
        """
        prog = parse(oql)
        assert len(prog.pipelines) == 1
        pipe = prog.pipelines[0]
        assert len(pipe.stages) == 4
        assert pipe.output.format == OutputFormat.JSON


# ═══════════════════════════════════════════════════════════════════════════
# Connector Base Tests
# ═══════════════════════════════════════════════════════════════════════════

class TestRateLimit:

    def test_allows_within_limit(self):
        rl = RateLimit(requests_per_minute=10, requests_per_day=1000)
        for _ in range(10):
            assert rl.check_and_consume() is True

    def test_blocks_over_minute_limit(self):
        rl = RateLimit(requests_per_minute=3, requests_per_day=1000)
        for _ in range(3):
            rl.check_and_consume()
        assert rl.check_and_consume() is False

    def test_blocks_over_day_limit(self):
        rl = RateLimit(requests_per_minute=1000, requests_per_day=3)
        for _ in range(3):
            rl.check_and_consume()
        assert rl.check_and_consume() is False


class MockConnector(BaseConnector):
    @property
    def name(self): return "mock"
    @property
    def supported_entities(self): return [CET.DOMAIN, CET.IP]
    @property
    def rate_limit(self): return RateLimit(100, 10000)

    async def _search(self, entity_type, query, params):
        return [self._make_result(
            ResultType.MATCH, entity_type, query, {"mock": True}, 0.9
        )]

    async def health_check(self): return True


class TestBaseConnector:

    @pytest.mark.asyncio
    async def test_search_supported_entity(self):
        c = MockConnector()
        results = await c.search(CET.DOMAIN, "example.com")
        assert isinstance(results, list)
        assert len(results) == 1
        assert results[0].value == "example.com"

    @pytest.mark.asyncio
    async def test_search_unsupported_entity_returns_error(self):
        c = MockConnector()
        result = await c.search(CET.EMAIL, "user@example.com")
        assert isinstance(result, ConnectorError)
        assert result.code == "UNSUPPORTED_ENTITY"

    @pytest.mark.asyncio
    async def test_health_check(self):
        c = MockConnector()
        assert await c.health_check() is True

    def test_fingerprint_deterministic(self):
        c = MockConnector()
        r1 = c._make_result(ResultType.MATCH, CET.DOMAIN, "example.com", {})
        r2 = c._make_result(ResultType.MATCH, CET.DOMAIN, "example.com", {})
        assert r1.fingerprint == r2.fingerprint

    def test_fingerprint_unique(self):
        c = MockConnector()
        r1 = c._make_result(ResultType.MATCH, CET.DOMAIN, "example.com", {})
        r2 = c._make_result(ResultType.MATCH, CET.DOMAIN, "other.com", {})
        assert r1.fingerprint != r2.fingerprint


# ═══════════════════════════════════════════════════════════════════════════
# SDK QueryBuilder Tests
# ═══════════════════════════════════════════════════════════════════════════

class TestQueryBuilder:

    def test_simple_search(self):
        oql = QueryBuilder().search("DOMAIN", "example.com").build()
        assert "SEARCH DOMAIN" in oql
        assert '"example.com"' in oql

    def test_pipeline(self):
        oql = (QueryBuilder()
               .search("DOMAIN", "example.com")
               .pivot("IP")
               .build())
        assert "|>" in oql
        assert "PIVOT IP" in oql

    def test_via_clause(self):
        oql = QueryBuilder().search("IP", "1.2.3.4").via(["shodan", "censys"]).build()
        assert "VIA" in oql
        assert "shodan" in oql
        assert "censys" in oql

    def test_limit_clause(self):
        oql = QueryBuilder().search("EMAIL", "x@x.com").limit(25).build()
        assert "LIMIT 25" in oql

    def test_confidence_clause(self):
        oql = QueryBuilder().search("DOMAIN", "x").confidence(0.8).build()
        assert "CONFIDENCE" in oql
        assert "0.8" in oql

    def test_as_json_output(self):
        oql = QueryBuilder().search("DOMAIN", "x").as_json("out.json").build()
        assert "AS JSON" in oql
        assert "out.json" in oql

    def test_as_table_no_file(self):
        oql = QueryBuilder().search("DOMAIN", "x").as_table().build()
        assert "AS TABLE" in oql
        assert "TO" not in oql

    def test_full_chain(self):
        oql = (QueryBuilder()
               .search("DOMAIN", "target.com")
               .via(["shodan", "crtsh"])
               .where("confidence >= 0.8")
               .limit(50)
               .enrich(["hibp"])
               .pivot("IP")
               .as_json("results.json")
               .build())
        # Should be valid OQL parseable by the parser
        prog = parse(oql)
        assert len(prog.pipelines) >= 1

    def test_str_repr(self):
        q = QueryBuilder().search("IP", "1.1.1.1")
        assert "SEARCH IP" in str(q)


# ═══════════════════════════════════════════════════════════════════════════
# ResultSet Tests
# ═══════════════════════════════════════════════════════════════════════════

class TestResultSet:

    def _make_results(self):
        return [
            Result("fp1", "shodan",     "PORT_SERVICE", "IP",    "1.1.1.1", 0.99, ["port:443"], None, {}),
            Result("fp2", "hibp",       "BREACH",       "EMAIL", "user@x.com", 0.99, ["breach"], "2021-01-01", {}),
            Result("fp3", "virustotal", "THREAT_INTEL",  "DOMAIN","evil.com", 0.1, ["malicious"], None, {}),
            Result("fp4", "shodan",     "PORT_SERVICE", "IP",    "2.2.2.2", 0.55, ["port:80"], None, {}),
        ]

    def test_len(self):
        rs = ResultSet(self._make_results())
        assert len(rs) == 4

    def test_iter(self):
        rs = ResultSet(self._make_results())
        assert sum(1 for _ in rs) == 4

    def test_by_source(self):
        rs = ResultSet(self._make_results())
        shodan = rs.by_source("shodan")
        assert len(shodan) == 2

    def test_by_type(self):
        rs = ResultSet(self._make_results())
        ips = rs.by_type("IP")
        assert len(ips) == 2

    def test_above_confidence(self):
        rs = ResultSet(self._make_results())
        high = rs.above_confidence(0.9)
        assert len(high) == 2

    def test_breaches_only(self):
        rs = ResultSet(self._make_results())
        breaches = rs.breaches_only()
        assert len(breaches) == 1
        assert breaches[0].result_type == "BREACH"

    def test_threats_only(self):
        rs = ResultSet(self._make_results())
        threats = rs.threats_only()
        assert len(threats) == 1

    def test_summary(self):
        rs = ResultSet(self._make_results())
        s = rs.summary()
        assert s["total"] == 4
        assert "shodan" in s["by_source"]
        assert s["by_source"]["shodan"] == 2

    def test_to_json(self):
        import json
        rs = ResultSet(self._make_results())
        data = json.loads(rs.to_json())
        assert len(data) == 4

    def test_to_csv_rows(self):
        rs = ResultSet(self._make_results())
        rows = rs.to_csv_rows()
        assert len(rows) == 4
        assert "source" in rows[0]
        assert "value" in rows[0]
