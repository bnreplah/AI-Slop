# OmniOSINT

**Mass OSINT Query Framework** — A custom query language (OQL) and async daemon for orchestrating queries across every major OSINT database simultaneously.

By [Cybopsec](https://cybopsec.dev) · MIT License

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        OQL Query Language                       │
│   SEARCH DOMAIN "example.com" |> ENRICH [shodan] |> PIVOT IP   │
└───────────────────────────┬─────────────────────────────────────┘
                            │
┌───────────────────────────▼─────────────────────────────────────┐
│                     OQL Lexer → Parser → AST                    │
└───────────────────────────┬─────────────────────────────────────┘
                            │
┌───────────────────────────▼─────────────────────────────────────┐
│                    Query Executor (async)                        │
│   Walks AST, dispatches to connectors concurrently              │
└───────────────────────────┬─────────────────────────────────────┘
                            │
┌───────────────────────────▼─────────────────────────────────────┐
│                    Connector Registry                           │
│  shodan  censys  hibp  virustotal  whois  hunter  crtsh  ...   │
└─────────────────────────────────────────────────────────────────┘
```

### Components

| Component | Path | Description |
|-----------|------|-------------|
| **OQL Lexer** | `oql/lexer.py` | Tokenizes OQL source |
| **OQL Parser** | `oql/parser.py` | Recursive-descent parser → AST |
| **AST Nodes** | `oql/ast_nodes.py` | All AST node dataclasses |
| **Executor** | `executor.py` | AST walker + async connector dispatch |
| **Daemon** | `daemon/daemon.py` | `omniod` — Unix socket + HTTP server |
| **Connectors** | `connectors/` | Pluggable OSINT source adapters |
| **SDK** | `sdk/client.py` | Python async/sync client + QueryBuilder |
| **CLI** | `cli/omni.py` | `omni` command-line tool |
| **Dashboard** | `ui/dashboard.jsx` | React SPA for visual querying |

---

## OQL — OSINT Query Language

### Entity Types

| Type | Description |
|------|-------------|
| `PERSON` | Individual person |
| `DOMAIN` | Domain name |
| `IP` | IPv4/v6 address |
| `EMAIL` | Email address |
| `PHONE` | Phone number |
| `ORG` | Organization |
| `HASH` | File/password hash (MD5, SHA1, SHA256) |
| `USERNAME` | Social / platform username |
| `CERT` | TLS/SSL certificate CN |
| `VULN` | CVE ID |
| `URL` | Full URL |
| `CRYPTO` | Crypto wallet address |

### Commands

| Command | Description |
|---------|-------------|
| `SEARCH <type> <"value">` | Initial search across sources |
| `PIVOT <type>` | Re-query using current results as input |
| `ENRICH [sources]` | Augment results with additional data |
| `CORRELATE <type>` | Find cross-source correlations |
| `TRACE <type>:<depth>` | Multi-hop relationship traversal |
| `MONITOR <type> <"value">:<interval>` | Watch for changes |
| `EXPORT <format> TO <"file">` | Write current results |

### Clauses

| Clause | Example |
|--------|---------|
| `WHERE` | `WHERE confidence >= 0.8` |
| `VIA` | `VIA [shodan, crtsh]` |
| `LIMIT` | `LIMIT 100` |
| `SINCE` | `SINCE "2025-01-01"` |
| `UNTIL` | `UNTIL "2026-01-01"` |
| `CONFIDENCE` | `CONFIDENCE >= 0.7` |
| `EXCLUDE` | `EXCLUDE [whois]` |

### Pipeline Operator

`|>` chains commands. Output of each stage feeds the next:

```oql
SEARCH DOMAIN "example.com"
  VIA [shodan, crtsh]
  |> ENRICH [hibp, virustotal]
  |> PIVOT IP
  |> CORRELATE DOMAIN
  AS JSON TO "results.json"
```

### Output Formats

`AS JSON | TABLE | CSV | GRAPH | TIMELINE | REPORT`

Optional: `TO "filepath"` to write to disk.

### Example Queries

```oql
# Domain recon
SEARCH DOMAIN "target.org"
  SINCE "2024-01-01"
  VIA [shodan, crtsh, whois]
  LIMIT 500
  |> ENRICH [virustotal]
  WHERE confidence >= 0.7
  |> PIVOT IP
  AS TABLE

# Email breach check
SEARCH EMAIL "user@company.com"
  |> ENRICH [hibp, hunter]
  CONFIDENCE >= 0.5
  AS JSON TO "breach_report.json"

# Multi-hop IP trace
SEARCH IP "192.0.2.1"
  VIA [shodan, censys]
  |> TRACE DOMAIN:3
  WHERE confidence > 0.6
  AS GRAPH TO "trace.json"

# CVE exposure scan
SEARCH VULN "CVE-2024-1234"
  VIA [shodan]
  LIMIT 1000
  AS CSV TO "exposed_hosts.csv"
```

---

## Installation

```bash
pip install omni-osint
# or from source:
git clone https://github.com/cybopsec/omni-osint
cd omni-osint
pip install -e ".[dev]"
```

### Configure API Keys

```bash
export OMNI_SHODAN_API_KEY="your_key"
export OMNI_HIBP_API_KEY="your_key"
export OMNI_VIRUSTOTAL_API_KEY="your_key"
export OMNI_HUNTER_API_KEY="your_key"
# WHOIS and CRT.sh require no key
```

---

## Usage

### CLI

```bash
# Start daemon
omniod start

# Quick search
omni search DOMAIN example.com
omni search EMAIL user@corp.com --via hibp hunter

# Full OQL
omni query 'SEARCH DOMAIN "example.com" |> PIVOT IP AS TABLE'

# Run OQL script file
omni run recon.oql

# Interactive REPL
omni repl

# Health check
omni health

# List sources
omni sources --no-daemon

# No daemon (in-process)
omni search IP 1.2.3.4 --no-daemon --format json
```

### Python SDK

```python
import asyncio
from omni_osint import OmniClient, QueryBuilder

# Async
async def main():
    async with OmniClient() as client:
        # High-level search
        results = await client.search("DOMAIN", "example.com",
                                      sources=["shodan", "crtsh"])
        print(results.summary())
        for r in results.above_confidence(0.8):
            print(r)

        # Raw OQL
        results = await client.query("""
            SEARCH EMAIL "admin@corp.com"
              |> ENRICH [hibp, hunter]
              CONFIDENCE >= 0.6
        """)
        print(results.breaches_only())

asyncio.run(main())

# Sync
from omni_osint import OmniClient
with OmniClient.sync() as client:
    results = client.search("IP", "1.2.3.4")
    print(results.summary())
```

### QueryBuilder DSL

```python
from omni_osint import QueryBuilder, OmniClient
import asyncio

oql = (QueryBuilder()
       .search("DOMAIN", "target.com")
       .via(["shodan", "crtsh"])
       .where("confidence >= 0.7")
       .limit(200)
       .enrich(["hibp", "virustotal"])
       .pivot("IP")
       .correlate("DOMAIN")
       .as_json("target_recon.json")
       .build())

print(oql)
# SEARCH DOMAIN "target.com"
#   VIA [shodan, crtsh]
#   WHERE confidence >= 0.7
#   LIMIT 200
#   |> ENRICH [hibp, virustotal]
#   |> PIVOT IP
#   |> CORRELATE DOMAIN
# AS JSON TO "target_recon.json"
```

---

## Adding a Custom Connector

Create `my_source.py` in `$OMNI_PLUGINS_DIR`:

```python
import aiohttp
from omni_osint.connectors.base_connector import (
    BaseConnector, EntityType, QueryParams, OSINTResult,
    RateLimit, ResultType,
)

class MySourceConnector(BaseConnector):
    @property
    def name(self) -> str:
        return "mysource"

    @property
    def supported_entities(self):
        return [EntityType.DOMAIN, EntityType.IP]

    @property
    def rate_limit(self):
        return RateLimit(requests_per_minute=10, requests_per_day=500)

    async def _search(self, entity_type, query, params):
        # Your API call here
        async with aiohttp.ClientSession() as s:
            async with s.get(f"https://api.mysource.io/search?q={query}") as r:
                data = await r.json()
        return [
            self._make_result(
                ResultType.MATCH, entity_type,
                item["value"], item,
                confidence=item.get("score", 0.5),
            )
            for item in data.get("results", [])
        ]

    async def health_check(self) -> bool:
        return True
```

Set `OMNI_PLUGINS_DIR=/path/to/plugins` and restart `omniod`. The connector is auto-discovered.

---

## Daemon

The `omniod` daemon provides:

- **Unix socket IPC** (`/tmp/omniod.sock`) — low latency, zero auth, local only
- **HTTP REST** (`http://127.0.0.1:7743`) — for web UI and remote clients
- **Priority job queue** — 8 async workers by default
- **Rate limit enforcement** per connector
- **JSON-Lines structured logging**

```
POST /query     { "query": "SEARCH ...", "timeout": 60 }
GET  /health    Connector health report
GET  /status    Queue stats + uptime
GET  /sources   Registered connectors
```

---

## Security Notes

- All API keys are read from environment variables — never hardcoded
- Rate limits enforced at connector level (belt + suspenders with daemon queue)
- Result deduplication by SHA-256 fingerprint of `source:entity_type:value`
- HTTP API binds to `127.0.0.1` only by default
- Socket file created at `/tmp/omniod.sock` — ensure proper file permissions (`chmod 600`)
- All connector errors are isolated — one failing source doesn't abort the pipeline

---

## Running Tests

```bash
pytest tests/ -v --cov=omni_osint --cov-report=term-missing
```

---

## Supported Sources

| Source | Free | Entities |
|--------|------|---------|
| Shodan | API key | IP, DOMAIN, CERT, VULN |
| CRT.sh | ✓ | DOMAIN, CERT |
| WHOIS | ✓ | DOMAIN, IP |
| HaveIBeenPwned | API key | EMAIL, HASH |
| VirusTotal | API key | DOMAIN, IP, HASH, URL |
| Hunter.io | API key | EMAIL, DOMAIN, ORG |

Planned: Censys, LeakIX, FullHunt, IntelX, PassiveDNS, Maltego, Recon-ng

---

## License

MIT © Cybopsec — See LICENSE for details.
