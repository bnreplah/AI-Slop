/**
 * DataViz3D v2.0 — 3D Data Visualization Library
 * 
 * A zero-dependency, pure JavaScript 3D rendering engine for data art and visualization.
 * Works in browsers, Node.js (with canvas library), and bundlers (webpack, esbuild, vite).
 * 
 * @module DataViz3D
 * @author Cybopsec
 * @license MIT
 * 
 * Usage:
 *   import DataViz3D from './dataviz3d-library.js';
 *   
 *   const viz = new DataViz3D(canvasElement, {
 *     vizType: 'scatter3d',
 *     width: 800,
 *     height: 600,
 *   });
 *   
 *   viz.setData([
 *     {x: 1, y: 2, z: 3, v: 0.5},
 *     {x: -1, y: 1, z: 2, v: 0.8},
 *   ]);
 *   
 *   viz.setPalette('Cyber');
 *   viz.start();
 */

class DataViz3D {
  /**
   * @typedef {Object} Point3D
   * @property {number} x - X coordinate
   * @property {number} y - Y coordinate
   * @property {number} z - Z coordinate
   * @property {number} [v=0.5] - Value for coloring (0-1)
   * @property {number} [vx] - X velocity (for particle sim)
   * @property {number} [vy] - Y velocity
   * @property {number} [vz] - Z velocity
   */

  /**
   * @typedef {Object} Palette
   * @property {string} name - Palette name
   * @property {string[]} colors - Array of 6 hex colors
   */

  /**
   * @typedef {Object} Config
   * @property {string} [vizType='scatter3d'] - Viz type: scatter3d, bars3d, surface, helix, network, particles, spiral, terrain, constellation, voxels
   * @property {number} [width] - Canvas width (defaults to container)
   * @property {number} [height] - Canvas height (defaults to container)
   * @property {number} [pointSize=4] - Point/marker size (1-20)
   * @property {number} [count=300] - Data point count for generated data
   * @property {number} [spread=5] - 3D space spread/scale (1-20)
   * @property {number} [speed=1.0] - Animation speed (0-50)
   * @property {string} [colorMode='palette'] - palette, depth, velocity, index, rainbow, mono
   * @property {string} [projection='perspective'] - perspective, orthographic, isometric
   * @property {string} [background='dark'] - dark, void, nebula, grid_bg, gradient
   * @property {boolean} [autoplay=true] - Start render loop on init
   * @property {number} [fpsTarget=60] - Target FPS cap
   */

  /**
   * @typedef {Object} FX - Post-processing effects state
   * @property {boolean} bloom - Glow bloom effect
   * @property {boolean} trails - Motion trails (persistent frame buffer)
   * @property {boolean} grid - Floor grid
   * @property {boolean} axes - XYZ axes
   * @property {boolean} scanlines - CRT scanlines + vignette
   * @property {boolean} connect - Line connections between nearby points
   * @property {boolean} labels - Data point labels
   * @property {boolean} fog - Depth fog
   * @property {boolean} pulse - Pulsing animation
   * @property {boolean} wireframe - Wireframe-only rendering
   */

  static PALETTES = [
    { name: 'Cyber',      colors: ['#00f5d4','#7209b7','#f72585','#3a86ff','#ffbe0b','#06d6a0'] },
    { name: 'Inferno',    colors: ['#ff006e','#fb5607','#ffbe0b','#8338ec','#ff006e','#3a86ff'] },
    { name: 'Ocean',      colors: ['#03045e','#0077b6','#00b4d8','#90e0ef','#caf0f8','#48cae4'] },
    { name: 'Forest',     colors: ['#081c15','#1b4332','#2d6a4f','#52b788','#95d5b2','#d8f3dc'] },
    { name: 'Lava',       colors: ['#370617','#6a040f','#d00000','#e85d04','#f48c06','#faa307'] },
    { name: 'Neon',       colors: ['#ff00ff','#00ffff','#ff9900','#00ff00','#ff0044','#9b00ff'] },
    { name: 'Pastel',     colors: ['#ffadad','#ffd6a5','#fdffb6','#caffbf','#9bf6ff','#bdb2ff'] },
    { name: 'Monochrome', colors: ['#ffffff','#cccccc','#999999','#666666','#333333','#111111'] },
    { name: 'Gold',       colors: ['#bf9b30','#d4af37','#f5e663','#a67c00','#ffdc5e','#c8960c'] },
    { name: 'Blood',      colors: ['#200010','#6b0018','#a30030','#cc0044','#ff1166','#ff6699'] },
  ];

  static VIZ_TYPES = [
    'scatter3d', 'bars3d', 'surface', 'helix', 'network',
    'particles', 'spiral', 'terrain', 'constellation', 'voxels'
  ];

  /**
   * Initialize DataViz3D instance
   * @param {HTMLCanvasElement} canvas - Canvas element to render to
   * @param {Config} [config={}] - Configuration object
   */
  constructor(canvas, config = {}) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d', { alpha: false });
    if (!this.ctx) throw new Error('Canvas 2D context unavailable');

    // Config defaults
    this.config = {
      vizType: 'scatter3d',
      pointSize: 4,
      count: 300,
      spread: 5,
      speed: 1.0,
      colorMode: 'palette',
      projection: 'perspective',
      background: 'dark',
      autoplay: true,
      fpsTarget: 60,
      ...config,
    };

    // Validation
    if (!DataViz3D.VIZ_TYPES.includes(this.config.vizType)) {
      throw new Error(`Invalid vizType: ${this.config.vizType}`);
    }

    // State
    this.points = [];
    this.rotation = { x: 0.4, y: 0.3, z: 0 };
    this.pan = { x: 0, y: 0 };
    this.zoom = 1;
    this.autoRotate = false;
    this.autoRotateSpeed = 0.005;

    this.frame = 0;
    this.fps = 0;
    this.fpsHistory = [];
    this.lastFrameTime = 0;

    this.activePaletteIdx = 0;
    this.animationFrameId = null;
    this.isRunning = false;

    /** @type {FX} */
    this.fx = {
      bloom: true,
      trails: false,
      grid: true,
      axes: true,
      scanlines: false,
      connect: false,
      labels: false,
      fog: true,
      pulse: true,
      wireframe: false,
    };

    // Internal
    this.W = 0;
    this.H = 0;
    this.CX = 0;
    this.CY = 0;
    this.tau = Math.PI * 2;

    // Input handling
    this._setupInteraction();
    this._resize();
    window.addEventListener('resize', () => this._resize());

    if (this.config.autoplay) {
      this.start();
    }
  }

  // ─────────────────────────────────────────────────────────────────────────
  // PUBLIC API
  // ─────────────────────────────────────────────────────────────────────────

  /**
   * Start the render loop
   */
  start() {
    if (this.isRunning) return;
    this.isRunning = true;
    this.lastFrameTime = performance.now();
    this._render();
  }

  /**
   * Stop the render loop
   */
  stop() {
    this.isRunning = false;
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
      this.animationFrameId = null;
    }
  }

  /**
   * Set visualization type
   * @param {string} type - One of DataViz3D.VIZ_TYPES
   */
  setVizType(type) {
    if (!DataViz3D.VIZ_TYPES.includes(type)) {
      throw new Error(`Invalid vizType: ${type}`);
    }
    this.config.vizType = type;
  }

  /**
   * Set data points from array
   * @param {Point3D[]} points - Array of 3D points
   */
  setData(points) {
    if (!Array.isArray(points)) {
      throw new Error('Data must be an array of points');
    }
    this.points = points.map((p, i) => {
      const pt = {
        x: +p.x || 0,
        y: +p.y || 0,
        z: +p.z || 0,
        v: +p.v ?? 0.5,
        i,
        animOffset: Math.random() * this.tau,
        animSpeed: 0.5 + Math.random() * 1.5,
      };
      // Preserve particle velocity if present
      if (p.vx !== undefined) pt.vx = +p.vx;
      if (p.vy !== undefined) pt.vy = +p.vy;
      if (p.vz !== undefined) pt.vz = +p.vz;
      return pt;
    });
  }

  /**
   * Generate random data for active visualization type
   * @param {number} [count] - Override config.count
   * @param {number} [spread] - Override config.spread
   */
  generateData(count, spread) {
    const c = count ?? this.config.count;
    const s = spread ?? this.config.spread;
    this.setData(this._generatePoints(this.config.vizType, c, s));
  }

  /**
   * Set color palette by name
   * @param {string} name - Palette name (see DataViz3D.PALETTES)
   */
  setPalette(name) {
    const idx = DataViz3D.PALETTES.findIndex(p => p.name === name);
    if (idx === -1) {
      throw new Error(`Unknown palette: ${name}`);
    }
    this.activePaletteIdx = idx;
  }

  /**
   * Get available palettes
   * @returns {Palette[]}
   */
  static getPalettes() {
    return DataViz3D.PALETTES;
  }

  /**
   * Enable/disable post-effect
   * @param {string} effect - FX key
   * @param {boolean} enabled
   */
  setFX(effect, enabled) {
    if (!(effect in this.fx)) {
      throw new Error(`Unknown effect: ${effect}`);
    }
    this.fx[effect] = !!enabled;
  }

  /**
   * Set animation parameter
   * @param {string} param - 'pointSize', 'spread', 'speed', 'colorMode', 'projection', 'background'
   * @param {*} value
   */
  setParam(param, value) {
    const valid = ['pointSize', 'spread', 'speed', 'colorMode', 'projection', 'background'];
    if (!valid.includes(param)) {
      throw new Error(`Invalid param: ${param}`);
    }
    this.config[param] = value;
  }

  /**
   * Get current config
   * @returns {Config}
   */
  getConfig() {
    return { ...this.config };
  }

  /**
   * Get current FX state
   * @returns {FX}
   */
  getFX() {
    return { ...this.fx };
  }

  /**
   * Set rotation (radians)
   * @param {number} x - Rotation around X axis
   * @param {number} y - Rotation around Y axis
   * @param {number} [z] - Rotation around Z axis
   */
  setRotation(x, y, z) {
    this.rotation = { x: +x || 0, y: +y || 0, z: +z || 0 };
  }

  /**
   * Get current rotation
   * @returns {{x: number, y: number, z: number}}
   */
  getRotation() {
    return { ...this.rotation };
  }

  /**
   * Set zoom level
   * @param {number} z - Zoom (0.1-10)
   */
  setZoom(z) {
    this.zoom = Math.max(0.1, Math.min(10, +z || 1));
  }

  /**
   * Get current zoom
   * @returns {number}
   */
  getZoom() {
    return this.zoom;
  }

  /**
   * Set pan offset (screen pixels)
   * @param {number} x
   * @param {number} y
   */
  setPan(x, y) {
    this.pan = { x: +x || 0, y: +y || 0 };
  }

  /**
   * Get current pan
   * @returns {{x: number, y: number}}
   */
  getPan() {
    return { ...this.pan };
  }

  /**
   * Enable/disable auto-rotation
   * @param {boolean} enabled
   */
  setAutoRotate(enabled) {
    this.autoRotate = !!enabled;
  }

  /**
   * Export current frame as PNG
   * @returns {string} Data URL
   */
  exportPNG() {
    return this.canvas.toDataURL('image/png');
  }

  /**
   * Export current frame as SVG
   * @returns {string} SVG markup
   */
  exportSVG() {
    const pal = DataViz3D.PALETTES[this.activePaletteIdx];
    const parts = [`<svg xmlns="http://www.w3.org/2000/svg" width="${this.W}" height="${this.H}" style="background:#050509">`];

    this.points.forEach((p, i) => {
      const p3 = this._transform([p.x, p.y, p.z]);
      const proj = this._project(p3);
      if (!proj) return;
      const col = this._getColor(p, i, this.points.length, pal, this.config.colorMode, 0);
      const r = Math.max(0.5, this.config.pointSize * proj.scale * 0.5);
      parts.push(`<circle cx="${proj.x.toFixed(1)}" cy="${proj.y.toFixed(1)}" r="${r.toFixed(1)}" fill="rgb(${col[0]},${col[1]},${col[2]})" opacity="0.85"/>`);
    });

    parts.push('</svg>');
    return parts.join('\n');
  }

  /**
   * Export data as JSON
   * @returns {string} JSON string
   */
  exportJSON() {
    return JSON.stringify(this.points.map(p => ({
      x: p.x, y: p.y, z: p.z, v: p.v
    })), null, 2);
  }

  /**
   * Parse data from CSV, JSON, or plain text
   * @param {string} raw - Raw input string
   * @returns {Point3D[]}
   */
  static parseData(raw) {
    const lines = raw.trim().split(/\n+/);
    const pts = [];

    try {
      const json = JSON.parse(raw.trim());
      if (Array.isArray(json)) {
        json.forEach((item, i) => {
          if (Array.isArray(item)) {
            pts.push({ x: +item[0]||0, y: +item[1]||0, z: +item[2]||0, v: +item[3]||(i/json.length), i });
          } else if (typeof item === 'object' && item !== null) {
            pts.push({ x: +item.x||0, y: +item.y||0, z: +item.z||0, v: +item.v||(i/json.length), i });
          } else if (typeof item === 'number') {
            const maxVal = json.reduce((m, v) => Math.max(m, Math.abs(+v || 0)), 0.001);
            pts.push({ x: i, y: item, z: 0, v: Math.abs(item) / maxVal, i });
          }
        });
        return pts;
      }
    } catch (e) {}

    // CSV / plain numbers
    lines.forEach((line, i) => {
      const parts = line.split(/[,\s\t]+/).map(p => parseFloat(p)).filter(n => !isNaN(n));
      if (parts.length === 0) return;
      if (parts.length === 1) pts.push({ x: i, y: parts[0], z: 0, v: 0.5, i });
      else if (parts.length === 2) pts.push({ x: parts[0], y: parts[1], z: 0, v: 0.5, i });
      else pts.push({ x: parts[0], y: parts[1], z: parts[2], v: parts[3] ?? 0.5, i });
    });

    return pts;
  }

  // ─────────────────────────────────────────────────────────────────────────
  // PRIVATE / INTERNAL
  // ─────────────────────────────────────────────────────────────────────────

  _resize() {
    this.W = this.canvas.width = this.canvas.offsetWidth;
    this.H = this.canvas.height = this.canvas.offsetHeight - 24; // subtract status bar if embedded
    this._updateProjectionCenter();
  }

  _updateProjectionCenter() {
    this.CX = this.W / 2 + this.pan.x;
    this.CY = this.H / 2 + this.pan.y;
  }

  _setupInteraction() {
    const c = this.canvas;
    let mouseDown = false;
    let lastMouse = { x: 0, y: 0 };

    c.addEventListener('mousedown', e => {
      mouseDown = true;
      lastMouse = { x: e.clientX, y: e.clientY };
    });

    window.addEventListener('mouseup', () => {
      mouseDown = false;
    });

    window.addEventListener('mousemove', e => {
      if (!mouseDown) return;
      const dx = e.clientX - lastMouse.x;
      const dy = e.clientY - lastMouse.y;
      if (e.shiftKey) {
        this.pan.x += dx;
        this.pan.y += dy;
        this._updateProjectionCenter();
      } else {
        this.rotation.y += dx * 0.008;
        this.rotation.x += dy * 0.008;
      }
      lastMouse = { x: e.clientX, y: e.clientY };
    });

    c.addEventListener('wheel', e => {
      e.preventDefault();
      this.zoom *= e.deltaY < 0 ? 1.08 : 0.93;
      this.zoom = Math.max(0.1, Math.min(10, this.zoom));
    }, { passive: false });

    // Touch
    let touches = {};
    c.addEventListener('touchstart', e => {
      e.preventDefault();
      [...e.touches].forEach(t => {
        touches[t.identifier] = { x: t.clientX, y: t.clientY };
      });
    }, { passive: false });

    c.addEventListener('touchmove', e => {
      e.preventDefault();
      if (e.touches.length === 1) {
        const t = e.touches[0];
        const prev = touches[t.identifier];
        if (prev) {
          this.rotation.y += (t.clientX - prev.x) * 0.01;
          this.rotation.x += (t.clientY - prev.y) * 0.01;
        }
        touches[t.identifier] = { x: t.clientX, y: t.clientY };
      } else if (e.touches.length === 2) {
        const [a, b] = [...e.touches];
        const dist = Math.hypot(a.clientX - b.clientX, a.clientY - b.clientY);
        const prevA = touches[a.identifier];
        const prevB = touches[b.identifier];
        if (prevA && prevB) {
          const prevDist = Math.hypot(prevA.x - prevB.x, prevA.y - prevB.y);
          this.zoom *= dist / Math.max(1, prevDist);
          this.zoom = Math.max(0.1, Math.min(10, this.zoom));
        }
        touches[a.identifier] = { x: a.clientX, y: a.clientY };
        touches[b.identifier] = { x: b.clientX, y: b.clientY };
      }
    }, { passive: false });
  }

  _render() {
    if (!this.isRunning) return;
    this.animationFrameId = requestAnimationFrame(t => this._render());

    const now = performance.now();
    const dt = now - this.lastFrameTime;
    if (dt < 1000 / this.config.fpsTarget) return;

    this.lastFrameTime = now;
    const timeSeconds = now * 0.001;

    // FPS
    this.fpsHistory.push(1000 / Math.max(1, dt));
    if (this.fpsHistory.length > 30) this.fpsHistory.shift();
    this.fps = Math.round(this.fpsHistory.reduce((a, b) => a + b, 0) / this.fpsHistory.length);

    // Auto rotate
    if (this.autoRotate) {
      this.rotation.y += this.autoRotateSpeed * this.config.speed;
    }

    this._updateProjectionCenter();

    // Background / trails
    if (this.fx.trails) {
      this.ctx.fillStyle = 'rgba(5,5,9,0.25)';
      this.ctx.fillRect(0, 0, this.W, this.H);
    } else {
      this._drawBackground(this.config.background);
    }

    this.ctx.save();

    // Grid & axes
    if (this.fx.grid) this._drawGrid();
    if (this.fx.axes) this._drawAxes();

    // Main visualization
    const vizFn = this._getDrawer(this.config.vizType);
    const pal = DataViz3D.PALETTES[this.activePaletteIdx];
    if (vizFn && this.points.length > 0) {
      vizFn(this.points, pal, timeSeconds);
    }

    // Post-process
    if (this.fx.scanlines) this._drawScanlines();

    this.ctx.restore();

    this.frame++;
  }

  _getDrawer(type) {
    const drawers = {
      scatter3d: (pts, pal, t) => this._drawScatter3D(pts, pal, t),
      bars3d: (pts, pal, t) => this._drawBars3D(pts, pal, t),
      surface: (pts, pal, t) => this._drawSurface(pts, pal, t),
      helix: (pts, pal, t) => this._drawHelix(pts, pal, t),
      network: (pts, pal, t) => this._drawNetwork(pts, pal, t),
      particles: (pts, pal, t) => this._drawParticles(pts, pal, t),
      spiral: (pts, pal, t) => this._drawSpiral(pts, pal, t),
      terrain: (pts, pal, t) => this._drawTerrain(pts, pal, t),
      constellation: (pts, pal, t) => this._drawConstellation(pts, pal, t),
      voxels: (pts, pal, t) => this._drawVoxels(pts, pal, t),
    };
    return drawers[type];
  }

  _transform(p3) {
    let p = [...p3];
    const c = Math.cos, s = Math.sin;
    const rx = this.rotation.x, ry = this.rotation.y, rz = this.rotation.z;

    // Rotate X
    let tmp = p[1] * c(rx) - p[2] * s(rx);
    p[2] = p[1] * s(rx) + p[2] * c(rx);
    p[1] = tmp;

    // Rotate Y
    tmp = p[0] * c(ry) + p[2] * s(ry);
    p[2] = -p[0] * s(ry) + p[2] * c(ry);
    p[0] = tmp;

    // Rotate Z
    tmp = p[0] * c(rz) - p[1] * s(rz);
    p[1] = p[0] * s(rz) + p[1] * c(rz);
    p[0] = tmp;

    return p;
  }

  _project(p3) {
    let [x, y, z] = p3;
    const fov = 500 * this.zoom;
    const proj = this.config.projection;

    if (proj === 'perspective') {
      const d = fov + z * 80;
      if (d <= 0) return null;
      const scale = fov / d;
      return { x: this.CX + x * scale * 60, y: this.CY - y * scale * 60, z, scale };
    } else if (proj === 'orthographic') {
      const s = this.zoom * 55;
      return { x: this.CX + x * s, y: this.CY - y * s, z, scale: this.zoom };
    } else { // isometric
      const s = this.zoom * 45;
      const ix = (x - z) * Math.cos(Math.PI / 6) * s;
      const iy = (x + z) * Math.sin(Math.PI / 6) * s - y * s;
      return { x: this.CX + ix, y: this.CY + iy, z, scale: this.zoom };
    }
  }

  _hexToRGB(hex) {
    const r = parseInt(hex.slice(1, 3), 16);
    const g = parseInt(hex.slice(3, 5), 16);
    const b = parseInt(hex.slice(5, 7), 16);
    return [r, g, b];
  }

  _lerpColor(c1, c2, t) {
    return [
      Math.round(c1[0] + (c2[0] - c1[0]) * t),
      Math.round(c1[1] + (c2[1] - c1[1]) * t),
      Math.round(c1[2] + (c2[2] - c1[2]) * t),
    ];
  }

  _samplePalette(t, palette) {
    const colors = palette.colors.map(h => this._hexToRGB(h));
    const seg = t * (colors.length - 1);
    const i = Math.floor(seg);
    const f = seg - i;
    return this._lerpColor(colors[Math.min(i, colors.length - 2)], colors[Math.min(i + 1, colors.length - 1)], f);
  }

  _getColor(point, idx, total, palette, mode, t) {
    let val;
    if (mode === 'palette') val = point.v ?? (idx / total);
    else if (mode === 'depth') val = (point.z + 10) / 20;
    else if (mode === 'velocity') val = Math.sqrt((point.vx || 0) ** 2 + (point.vy || 0) ** 2 + (point.vz || 0) ** 2) * 50;
    else if (mode === 'index') val = idx / total;
    else if (mode === 'rainbow') val = ((idx / total) + t * 0.1) % 1;
    else if (mode === 'mono') val = 0.8;
    else val = point.v ?? 0.5;
    val = Math.max(0, Math.min(1, val));
    return this._samplePalette(val, palette);
  }

  _drawBackground(bg) {
    this.ctx.save();
    if (bg === 'void') {
      this.ctx.fillStyle = '#000000';
      this.ctx.fillRect(0, 0, this.W, this.H);
    } else if (bg === 'dark') {
      this.ctx.fillStyle = '#050509';
      this.ctx.fillRect(0, 0, this.W, this.H);
      // Subtle star field
      this.ctx.fillStyle = 'rgba(255,255,255,0.3)';
      for (let i = 0; i < 120; i++) {
        const sx = (((i * 9301 + 49297) % 233280) / 233280) * this.W;
        const sy = (((i * 7351 + 31337) % 233280) / 233280) * this.H;
        this.ctx.fillRect(sx, sy, 0.8, 0.8);
      }
    } else if (bg === 'nebula') {
      const grd = this.ctx.createRadialGradient(this.W * 0.3, this.H * 0.4, 0, this.W * 0.5, this.H * 0.5, this.W * 0.8);
      grd.addColorStop(0, '#0d0030');
      grd.addColorStop(0.3, '#050028');
      grd.addColorStop(0.7, '#02001a');
      grd.addColorStop(1, '#000010');
      this.ctx.fillStyle = grd;
      this.ctx.fillRect(0, 0, this.W, this.H);
    } else if (bg === 'grid_bg') {
      this.ctx.fillStyle = '#030308';
      this.ctx.fillRect(0, 0, this.W, this.H);
      this.ctx.strokeStyle = '#0d0d20';
      this.ctx.lineWidth = 0.5;
      const gs = 40;
      for (let x = 0; x < this.W; x += gs) {
        this.ctx.beginPath();
        this.ctx.moveTo(x, 0);
        this.ctx.lineTo(x, this.H);
        this.ctx.stroke();
      }
      for (let y = 0; y < this.H; y += gs) {
        this.ctx.beginPath();
        this.ctx.moveTo(0, y);
        this.ctx.lineTo(this.W, y);
        this.ctx.stroke();
      }
    } else if (bg === 'gradient') {
      const grd = this.ctx.createLinearGradient(0, 0, this.W, this.H);
      grd.addColorStop(0, '#070018');
      grd.addColorStop(0.5, '#001020');
      grd.addColorStop(1, '#100008');
      this.ctx.fillStyle = grd;
      this.ctx.fillRect(0, 0, this.W, this.H);
    }
    this.ctx.restore();
  }

  _drawGrid() {
    const size = 6;
    const steps = 12;
    const pal = DataViz3D.PALETTES[this.activePaletteIdx];
    const gc = this._hexToRGB(pal.colors[0]);

    for (let i = -steps; i <= steps; i++) {
      const lineColor = `rgba(${gc[0]},${gc[1]},${gc[2]},${i === 0 ? 0.25 : 0.07})`;
      // Along X
      const a3 = this._transform([i * (size / steps), -size * 0.5, -size]);
      const b3 = this._transform([i * (size / steps), -size * 0.5, size]);
      const ap = this._project(a3);
      const bp = this._project(b3);
      if (ap && bp) {
        this.ctx.beginPath();
        this.ctx.moveTo(ap.x, ap.y);
        this.ctx.lineTo(bp.x, bp.y);
        this.ctx.strokeStyle = lineColor;
        this.ctx.lineWidth = i === 0 ? 1 : 0.5;
        this.ctx.stroke();
      }
      // Along Z
      const c3 = this._transform([-size, -size * 0.5, i * (size / steps)]);
      const d3 = this._transform([size, -size * 0.5, i * (size / steps)]);
      const cp = this._project(c3);
      const dp = this._project(d3);
      if (cp && dp) {
        this.ctx.beginPath();
        this.ctx.moveTo(cp.x, cp.y);
        this.ctx.lineTo(dp.x, dp.y);
        this.ctx.strokeStyle = lineColor;
        this.ctx.lineWidth = i === 0 ? 1 : 0.5;
        this.ctx.stroke();
      }
    }
  }

  _drawAxes() {
    const L = 6;
    const axes = [
      { end: [L, 0, 0], color: '#ff4444', label: 'X' },
      { end: [0, L, 0], color: '#44ff44', label: 'Y' },
      { end: [0, 0, L], color: '#4488ff', label: 'Z' },
    ];
    axes.forEach(ax => {
      const op = this._project(this._transform([0, 0, 0]));
      const ep = this._project(this._transform(ax.end));
      if (!op || !ep) return;
      this.ctx.beginPath();
      this.ctx.moveTo(op.x, op.y);
      this.ctx.lineTo(ep.x, ep.y);
      this.ctx.strokeStyle = ax.color + '88';
      this.ctx.lineWidth = 1;
      this.ctx.stroke();
      this.ctx.fillStyle = ax.color + 'bb';
      this.ctx.font = '10px monospace';
      this.ctx.fillText(ax.label, ep.x + 4, ep.y + 4);
    });
  }

  _drawGlowPoint(x, y, r, color, alpha) {
    if (r <= 0) return;
    const [cr, cg, cb] = color;
    const layers = [[r * 4, 0.04], [r * 2.5, 0.08], [r * 1.5, 0.14]];
    layers.forEach(([lr, la]) => {
      if (lr <= 0) return;
      try {
        const g = this.ctx.createRadialGradient(x, y, 0, x, y, lr);
        g.addColorStop(0, `rgba(${cr},${cg},${cb},${la * alpha})`);
        g.addColorStop(1, `rgba(${cr},${cg},${cb},0)`);
        this.ctx.beginPath();
        this.ctx.arc(x, y, lr, 0, Math.PI * 2);
        this.ctx.fillStyle = g;
        this.ctx.fill();
      } catch (e) {}
    });
  }

  _drawScanlines() {
    for (let y = 0; y < this.H; y += 4) {
      this.ctx.fillStyle = 'rgba(0,0,0,0.12)';
      this.ctx.fillRect(0, y, this.W, 1.5);
    }
    const vgrd = this.ctx.createRadialGradient(this.CX, this.CY, this.H * 0.3, this.CX, this.CY, this.H * 0.85);
    vgrd.addColorStop(0, 'transparent');
    vgrd.addColorStop(1, 'rgba(0,0,0,0.45)');
    this.ctx.fillStyle = vgrd;
    this.ctx.fillRect(0, 0, this.W, this.H);
  }

  // ── Visualization drawers ──

  _drawScatter3D(pts, palette, t) {
    const sorted = pts.map((p, i) => {
      const p3 = this._transform([p.x, p.y, p.z]);
      const proj = this._project(p3);
      return { p, i, p3, proj };
    })
      .filter(d => d.proj)
      .sort((a, b) => a.p3[2] - b.p3[2]);

    // Connect lines
    if (this.fx.connect) {
      const MAX_DIST = this.config.spread * 0.4;
      for (let i = 0; i < sorted.length; i++) {
        for (let j = i + 1; j < Math.min(sorted.length, i + 8); j++) {
          const dx = sorted[i].p.x - sorted[j].p.x;
          const dy = sorted[i].p.y - sorted[j].p.y;
          const dz = sorted[i].p.z - sorted[j].p.z;
          const d = Math.sqrt(dx * dx + dy * dy + dz * dz);
          if (d < MAX_DIST) {
            const [cr, cg, cb] = this._getColor(sorted[i].p, sorted[i].i, pts.length, palette, this.config.colorMode, t);
            this.ctx.beginPath();
            this.ctx.moveTo(sorted[i].proj.x, sorted[i].proj.y);
            this.ctx.lineTo(sorted[j].proj.x, sorted[j].proj.y);
            this.ctx.strokeStyle = `rgba(${cr},${cg},${cb},${0.08 * (1 - d / MAX_DIST)})`;
            this.ctx.lineWidth = 0.5;
            this.ctx.stroke();
          }
        }
      }
    }

    sorted.forEach(({ p, i, p3, proj }) => {
      const fogA = this.fx.fog ? Math.max(0.1, 1 - Math.abs(p3[2]) / (this.config.spread * 2)) : 1;
      const pulA = this.fx.pulse ? (0.7 + 0.3 * Math.sin(t * p.animSpeed + p.animOffset)) : 1;
      const col = this._getColor(p, i, pts.length, palette, this.config.colorMode, t);
      const sz = this.config.pointSize * proj.scale * pulA * 0.5;

      if (this.fx.bloom) this._drawGlowPoint(proj.x, proj.y, sz, col, fogA * 0.5);

      this.ctx.beginPath();
      this.ctx.arc(proj.x, proj.y, Math.max(0.5, sz), 0, Math.PI * 2);
      this.ctx.fillStyle = `rgba(${col[0]},${col[1]},${col[2]},${fogA})`;
      this.ctx.fill();

      if (this.fx.labels && i < 30) {
        this.ctx.fillStyle = `rgba(${col[0]},${col[1]},${col[2]},0.6)`;
        this.ctx.font = '8px monospace';
        this.ctx.fillText(`${i}`, proj.x + sz + 2, proj.y + 3);
      }
    });
  }

  _drawBars3D(pts, palette, t) {
    const sp = this.config.spread;
    const sorted = pts.map((p, i) => {
      const barH = p.h * sp * 1.5;
      const pulse = this.fx.pulse ? (0.9 + 0.1 * Math.sin(t * 1.5 + p.animOffset)) : 1;
      const t3top = this._transform([p.x, barH * pulse, p.z]);
      const t3bot = this._transform([p.x, -sp * 0.1, p.z]);
      return { p, i, t3bot, ptop: this._project(t3top), pbot: this._project(t3bot) };
    })
      .filter(d => d.ptop && d.pbot)
      .sort((a, b) => a.t3bot[2] - b.t3bot[2]);

    sorted.forEach(({ p, i, ptop, pbot }) => {
      const col = this._getColor(p, i, pts.length, palette, this.config.colorMode, t);
      const w = Math.max(2, this.config.pointSize * ptop.scale * 1.5);
      const fogA = this.fx.fog ? Math.max(0.15, 1 - Math.abs(p.z) / (sp * 2)) : 1;

      if (this.fx.wireframe) {
        this.ctx.strokeStyle = `rgba(${col[0]},${col[1]},${col[2]},${fogA})`;
        this.ctx.lineWidth = 0.5;
        this.ctx.strokeRect(ptop.x - w / 2, ptop.y, w, Math.max(1, pbot.y - ptop.y));
      } else {
        const barH = Math.max(1, pbot.y - ptop.y);
        let fillStyle;
        try {
          const grad = this.ctx.createLinearGradient(ptop.x, ptop.y, ptop.x, ptop.y + barH);
          grad.addColorStop(0, `rgba(${col[0]},${col[1]},${col[2]},${fogA})`);
          grad.addColorStop(1, `rgba(${Math.round(col[0] * 0.3)},${Math.round(col[1] * 0.3)},${Math.round(col[2] * 0.3)},${fogA * 0.4})`);
          fillStyle = grad;
        } catch (e) {
          fillStyle = `rgba(${col[0]},${col[1]},${col[2]},${fogA})`;
        }
        this.ctx.fillStyle = fillStyle;
        this.ctx.fillRect(ptop.x - w / 2, ptop.y, w, barH);
      }

      if (this.fx.bloom) this._drawGlowPoint(ptop.x, ptop.y, w, col, fogA * 0.4);
    });
  }

  _drawSurface(pts, palette, t) {
    const res = Math.ceil(Math.sqrt(pts.length));
    for (let r = 0; r < res - 1; r++) {
      for (let c = 0; c < res - 1; c++) {
        const idx = r * res + c;
        if (idx + res + 1 >= pts.length) continue;
        const a = pts[idx], b = pts[idx + 1];
        const d = pts[idx + res], e = pts[idx + res + 1];

        const ap = this._project(this._transform([a.x, a.y, a.z]));
        const bp = this._project(this._transform([b.x, b.y, b.z]));
        const dp = this._project(this._transform([d.x, d.y, d.z]));
        const ep = this._project(this._transform([e.x, e.y, e.z]));
        if (!ap || !bp || !dp || !ep) continue;

        const avgV = (a.v + b.v + d.v + e.v) / 4;
        const col = this._samplePalette(avgV, palette);

        if (this.fx.wireframe) {
          this.ctx.beginPath();
          this.ctx.moveTo(ap.x, ap.y);
          this.ctx.lineTo(bp.x, bp.y);
          this.ctx.lineTo(ep.x, ep.y);
          this.ctx.lineTo(dp.x, dp.y);
          this.ctx.closePath();
          this.ctx.strokeStyle = `rgba(${col[0]},${col[1]},${col[2]},0.5)`;
          this.ctx.lineWidth = 0.5;
          this.ctx.stroke();
        } else {
          this.ctx.beginPath();
          this.ctx.moveTo(ap.x, ap.y);
          this.ctx.lineTo(bp.x, bp.y);
          this.ctx.lineTo(ep.x, ep.y);
          this.ctx.lineTo(dp.x, dp.y);
          this.ctx.closePath();
          this.ctx.fillStyle = `rgba(${col[0]},${col[1]},${col[2]},0.7)`;
          this.ctx.fill();
          this.ctx.strokeStyle = `rgba(${col[0]},${col[1]},${col[2]},0.1)`;
          this.ctx.lineWidth = 0.3;
          this.ctx.stroke();
        }
      }
    }
  }

  _drawHelix(pts, palette, t) {
    const strand0 = pts.filter(p => p.strand === 0).sort((a, b) => a.i - b.i);
    const strand1 = pts.filter(p => p.strand === 1).sort((a, b) => a.i - b.i);

    [strand0, strand1].forEach(strand => {
      for (let i = 1; i < strand.length; i++) {
        const pp = this._project(this._transform([strand[i - 1].x, strand[i - 1].y, strand[i - 1].z]));
        const cp = this._project(this._transform([strand[i].x, strand[i].y, strand[i].z]));
        if (!pp || !cp) continue;
        const col = this._samplePalette(strand[i].v, palette);
        this.ctx.beginPath();
        this.ctx.moveTo(pp.x, pp.y);
        this.ctx.lineTo(cp.x, cp.y);
        this.ctx.strokeStyle = `rgba(${col[0]},${col[1]},${col[2]},0.6)`;
        this.ctx.lineWidth = 1.5;
        this.ctx.stroke();
      }
    });

    const minLen = Math.min(strand0.length, strand1.length);
    for (let i = 0; i < minLen; i += 3) {
      const ap = this._project(this._transform([strand0[i].x, strand0[i].y, strand0[i].z]));
      const bp = this._project(this._transform([strand1[i].x, strand1[i].y, strand1[i].z]));
      if (!ap || !bp) continue;
      const col = this._samplePalette(strand0[i].v, palette);
      this.ctx.beginPath();
      this.ctx.moveTo(ap.x, ap.y);
      this.ctx.lineTo(bp.x, bp.y);
      this.ctx.strokeStyle = `rgba(${col[0]},${col[1]},${col[2]},0.25)`;
      this.ctx.lineWidth = 0.8;
      this.ctx.stroke();
    }

    pts.forEach((p, i) => {
      const pp = this._project(this._transform([p.x, p.y, p.z]));
      if (!pp) return;
      const col = this._getColor(p, i, pts.length, palette, this.config.colorMode, t);
      const sz = this.config.pointSize * pp.scale * 0.5;
      if (this.fx.bloom) this._drawGlowPoint(pp.x, pp.y, sz, col, 0.7);
      this.ctx.beginPath();
      this.ctx.arc(pp.x, pp.y, Math.max(0.5, sz), 0, Math.PI * 2);
      this.ctx.fillStyle = `rgba(${col[0]},${col[1]},${col[2]},0.9)`;
      this.ctx.fill();
    });
  }

  _drawNetwork(pts, palette, t) {
    const MAX_DIST = this.config.spread * 0.8;
    for (let i = 0; i < pts.length; i++) {
      for (let j = i + 1; j < pts.length; j++) {
        const dx = pts[i].x - pts[j].x;
        const dy = pts[i].y - pts[j].y;
        const dz = pts[i].z - pts[j].z;
        const d = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (d < MAX_DIST) {
          const ap = this._project(this._transform([pts[i].x, pts[i].y, pts[i].z]));
          const bp = this._project(this._transform([pts[j].x, pts[j].y, pts[j].z]));
          if (!ap || !bp) continue;
          const col = this._samplePalette(pts[i].v, palette);
          this.ctx.beginPath();
          this.ctx.moveTo(ap.x, ap.y);
          this.ctx.lineTo(bp.x, bp.y);
          this.ctx.strokeStyle = `rgba(${col[0]},${col[1]},${col[2]},${0.12 * (1 - d / MAX_DIST)})`;
          this.ctx.lineWidth = 0.7;
          this.ctx.stroke();
        }
      }
    }

    pts.forEach((p, i) => {
      const pp = this._project(this._transform([p.x, p.y, p.z]));
      if (!pp) return;
      const col = this._getColor(p, i, pts.length, palette, this.config.colorMode, t);
      const sz = (this.config.pointSize + (p.connections || 1) * 1.5) * pp.scale * 0.5;
      const pul = this.fx.pulse ? (0.8 + 0.2 * Math.sin(t * p.animSpeed + p.animOffset)) : 1;
      if (this.fx.bloom) this._drawGlowPoint(pp.x, pp.y, sz * pul, col, 0.6);
      this.ctx.beginPath();
      this.ctx.arc(pp.x, pp.y, Math.max(1, sz * pul), 0, Math.PI * 2);
      this.ctx.fillStyle = `rgba(${col[0]},${col[1]},${col[2]},0.9)`;
      this.ctx.fill();
      if (this.fx.labels) {
        this.ctx.fillStyle = `rgba(${col[0]},${col[1]},${col[2]},0.5)`;
        this.ctx.font = '8px monospace';
        this.ctx.fillText(`N${i}`, pp.x + sz + 2, pp.y + 3);
      }
    });
  }

  _drawParticles(pts, palette, t) {
    pts.forEach(p => {
      p.x += (p.vx || 0) * this.config.speed;
      p.y += (p.vy || 0) * this.config.speed;
      p.z += (p.vz || 0) * this.config.speed;
      const sp = this.config.spread;
      if (Math.abs(p.x) > sp) p.vx *= -1;
      if (Math.abs(p.y) > sp) p.vy *= -1;
      if (Math.abs(p.z) > sp) p.vz *= -1;
    });

    const sorted = pts.map((p, i) => {
      const p3 = this._transform([p.x, p.y, p.z]);
      const proj = this._project(p3);
      return { p, i, p3, proj };
    }).filter(d => d.proj).sort((a, b) => a.p3[2] - b.p3[2]);

    if (this.fx.connect) {
      const MAX = this.config.spread * 0.5;
      for (let i = 0; i < sorted.length; i++) {
        for (let j = i + 1; j < Math.min(sorted.length, i + 6); j++) {
          const dx = sorted[i].p.x - sorted[j].p.x;
          const dy = sorted[i].p.y - sorted[j].p.y;
          const dz = sorted[i].p.z - sorted[j].p.z;
          const d = Math.sqrt(dx * dx + dy * dy + dz * dz);
          if (d < MAX) {
            const col = this._getColor(sorted[i].p, sorted[i].i, pts.length, palette, this.config.colorMode, t);
            this.ctx.beginPath();
            this.ctx.moveTo(sorted[i].proj.x, sorted[i].proj.y);
            this.ctx.lineTo(sorted[j].proj.x, sorted[j].proj.y);
            this.ctx.strokeStyle = `rgba(${col[0]},${col[1]},${col[2]},${0.07 * (1 - d / MAX)})`;
            this.ctx.lineWidth = 0.5;
            this.ctx.stroke();
          }
        }
      }
    }

    sorted.forEach(({ p, i, p3, proj }) => {
      const col = this._getColor(p, i, pts.length, palette, this.config.colorMode, t);
      const fogA = this.fx.fog ? Math.max(0.1, 1 - Math.abs(p3[2]) / (this.config.spread * 2)) : 1;
      const sz = this.config.pointSize * proj.scale * 0.4;
      if (this.fx.bloom) this._drawGlowPoint(proj.x, proj.y, sz, col, fogA * 0.4);
      this.ctx.beginPath();
      this.ctx.arc(proj.x, proj.y, Math.max(0.5, sz), 0, Math.PI * 2);
      this.ctx.fillStyle = `rgba(${col[0]},${col[1]},${col[2]},${fogA})`;
      this.ctx.fill();
    });
  }

  _drawSpiral(pts, palette, t) {
    const sorted = pts.map((p, i) => {
      const p3 = this._transform([p.x, p.y, p.z]);
      const proj = this._project(p3);
      return { p, i, p3, proj };
    }).filter(d => d.proj).sort((a, b) => a.p3[2] - b.p3[2]);

    const byArm = {};
    pts.forEach((p, i) => {
      if (!byArm[p.arm]) byArm[p.arm] = [];
      byArm[p.arm].push(p);
    });

    Object.values(byArm).forEach(arm => {
      const armSorted = arm.sort((a, b) => a.i - b.i);
      for (let i = 1; i < armSorted.length; i++) {
        const ap = this._project(this._transform([armSorted[i - 1].x, armSorted[i - 1].y, armSorted[i - 1].z]));
        const bp = this._project(this._transform([armSorted[i].x, armSorted[i].y, armSorted[i].z]));
        if (!ap || !bp) continue;
        const col = this._samplePalette(armSorted[i].v, palette);
        this.ctx.beginPath();
        this.ctx.moveTo(ap.x, ap.y);
        this.ctx.lineTo(bp.x, bp.y);
        this.ctx.strokeStyle = `rgba(${col[0]},${col[1]},${col[2]},0.2)`;
        this.ctx.lineWidth = 0.8;
        this.ctx.stroke();
      }
    });

    sorted.forEach(({ p, i, p3, proj }) => {
      const col = this._getColor(p, i, pts.length, palette, this.config.colorMode, t);
      const fogA = this.fx.fog ? Math.max(0.15, 1 - Math.abs(p3[2]) / (this.config.spread * 2)) : 1;
      const pul = this.fx.pulse ? (0.7 + 0.3 * Math.sin(t * p.animSpeed + p.animOffset)) : 1;
      const sz = this.config.pointSize * proj.scale * 0.4 * pul;
      if (this.fx.bloom) this._drawGlowPoint(proj.x, proj.y, sz, col, fogA * 0.5);
      this.ctx.beginPath();
      this.ctx.arc(proj.x, proj.y, Math.max(0.4, sz), 0, Math.PI * 2);
      this.ctx.fillStyle = `rgba(${col[0]},${col[1]},${col[2]},${fogA})`;
      this.ctx.fill();
    });
  }

  _drawTerrain(pts, palette, t) {
    const res = Math.ceil(Math.sqrt(pts.length));
    for (let r = 0; r < res - 1; r++) {
      for (let c = 0; c < res - 1; c++) {
        const idx = r * res + c;
        if (idx + res + 1 >= pts.length) continue;
        const a = pts[idx], b = pts[idx + 1];
        const d = pts[idx + res], e = pts[idx + res + 1];
        const pul = this.fx.pulse ? (1 + 0.02 * Math.sin(t + a.x * 0.5 + a.z * 0.3)) : 1;
        const ap = this._project(this._transform([a.x, a.y * pul, a.z]));
        const bp = this._project(this._transform([b.x, b.y * pul, b.z]));
        const dp = this._project(this._transform([d.x, d.y * pul, d.z]));
        const ep = this._project(this._transform([e.x, e.y * pul, e.z]));
        if (!ap || !bp || !dp || !ep) continue;

        [[ap, bp, ep], [ap, ep, dp]].forEach(tri => {
          const avgV = (a.v + b.v + d.v) / 3;
          const col = this._samplePalette(avgV, palette);
          this.ctx.beginPath();
          this.ctx.moveTo(tri[0].x, tri[0].y);
          this.ctx.lineTo(tri[1].x, tri[1].y);
          this.ctx.lineTo(tri[2].x, tri[2].y);
          this.ctx.closePath();
          if (this.fx.wireframe) {
            this.ctx.strokeStyle = `rgba(${col[0]},${col[1]},${col[2]},0.4)`;
            this.ctx.lineWidth = 0.4;
            this.ctx.stroke();
          } else {
            this.ctx.fillStyle = `rgba(${col[0]},${col[1]},${col[2]},0.75)`;
            this.ctx.fill();
            this.ctx.strokeStyle = `rgba(${col[0]},${col[1]},${col[2]},0.06)`;
            this.ctx.lineWidth = 0.2;
            this.ctx.stroke();
          }
        });
      }
    }
  }

  _drawConstellation(pts, palette, t) {
    const bright = pts.filter(p => p.bright > 0.7);
    const MAX = this.config.spread * 0.9;
    for (let i = 0; i < bright.length; i++) {
      for (let j = i + 1; j < bright.length; j++) {
        const dx = bright[i].x - bright[j].x;
        const dy = bright[i].y - bright[j].y;
        const dz = bright[i].z - bright[j].z;
        const d = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (d < MAX) {
          const ap = this._project(this._transform([bright[i].x, bright[i].y, bright[i].z]));
          const bp = this._project(this._transform([bright[j].x, bright[j].y, bright[j].z]));
          if (!ap || !bp) continue;
          const col = this._samplePalette(bright[i].v, palette);
          this.ctx.beginPath();
          this.ctx.moveTo(ap.x, ap.y);
          this.ctx.lineTo(bp.x, bp.y);
          this.ctx.strokeStyle = `rgba(${col[0]},${col[1]},${col[2]},0.12)`;
          this.ctx.lineWidth = 0.6;
          this.ctx.stroke();
        }
      }
    }

    pts.forEach((p, i) => {
      const pp = this._project(this._transform([p.x, p.y, p.z]));
      if (!pp) return;
      const col = this._getColor(p, i, pts.length, palette, this.config.colorMode, t);
      const fogA = this.fx.fog ? Math.max(0.05, 1 - Math.abs(this._transform([p.x, p.y, p.z])[2]) / (this.config.spread * 2.5)) : 1;
      const pul = this.fx.pulse ? (0.5 + 0.5 * Math.sin(t * p.animSpeed * 0.5 + p.animOffset)) : 1;
      const sz = (0.5 + (p.bright || 0.5) * this.config.pointSize * 0.5) * pp.scale * pul;
      if ((p.bright || 0.5) > 0.7 && this.fx.bloom) this._drawGlowPoint(pp.x, pp.y, sz, col, fogA * 0.7);
      this.ctx.beginPath();
      this.ctx.arc(pp.x, pp.y, Math.max(0.3, sz), 0, Math.PI * 2);
      this.ctx.fillStyle = `rgba(${col[0]},${col[1]},${col[2]},${fogA * (0.3 + (p.bright || 0.5) * 0.7)})`;
      this.ctx.fill();
    });
  }

  _drawVoxels(pts, palette, t) {
    const sz = this.config.pointSize * 0.18;
    const sorted = pts.map((p, i) => {
      const p3 = this._transform([p.x, p.y, p.z]);
      const proj = this._project(p3);
      return { p, i, p3, proj };
    }).filter(d => d.proj).sort((a, b) => a.p3[2] - b.p3[2]);

    sorted.forEach(({ p, i, p3, proj }) => {
      const col = this._getColor(p, i, pts.length, palette, this.config.colorMode, t);
      const fogA = this.fx.fog ? Math.max(0.15, 1 - Math.abs(p3[2]) / (this.config.spread * 2)) : 1;
      const pul = this.fx.pulse ? (0.85 + 0.15 * Math.sin(t * p.animSpeed * 0.8 + p.animOffset)) : 1;
      const s = sz * proj.scale * pul * 30;
      const half = s / 2;

      if (this.fx.bloom) this._drawGlowPoint(proj.x, proj.y, s * 0.6, col, fogA * 0.3);

      if (this.fx.wireframe) {
        this.ctx.strokeStyle = `rgba(${col[0]},${col[1]},${col[2]},${fogA})`;
        this.ctx.lineWidth = 0.7;
        this.ctx.strokeRect(proj.x - half, proj.y - half, s, s);
      } else {
        this.ctx.fillStyle = `rgba(${col[0]},${col[1]},${col[2]},${fogA * 0.9})`;
        this.ctx.fillRect(proj.x - half, proj.y - half, s, s);
        this.ctx.fillStyle = `rgba(255,255,255,${fogA * 0.12})`;
        this.ctx.fillRect(proj.x - half, proj.y - half, s, half * 0.4);
        this.ctx.strokeStyle = `rgba(${col[0]},${col[1]},${col[2]},${fogA * 0.3})`;
        this.ctx.lineWidth = 0.5;
        this.ctx.strokeRect(proj.x - half, proj.y - half, s, s);
      }
    });
  }

  // ── Data generation ──

  _generatePoints(type, count, spread) {
    const pts = [];
    const s = spread;
    const tau = this.tau;

    const gen = {
      scatter3d: () => {
        for (let i = 0; i < count; i++) {
          pts.push({
            x: (Math.random() * 2 - 1) * s,
            y: (Math.random() * 2 - 1) * s,
            z: (Math.random() * 2 - 1) * s,
            v: Math.random(),
            i,
          });
        }
      },
      bars3d: () => {
        const cols = Math.ceil(Math.sqrt(count));
        const rows = Math.ceil(count / cols);
        for (let r = 0; r < rows; r++) {
          for (let c = 0; c < cols; c++) {
            if (pts.length >= count) break;
            const nx = (c / cols * 2 - 1) * s;
            const nz = (r / rows * 2 - 1) * s;
            const h = (Math.sin(nx * 1.5) * Math.cos(nz * 1.5) + 1) * 0.5;
            pts.push({ x: nx, y: 0, z: nz, h, v: h, i: pts.length, barBase: -s * 0.1 });
          }
        }
      },
      surface: () => {
        const res = Math.ceil(Math.sqrt(count));
        for (let r = 0; r < res; r++) {
          for (let c = 0; c < res; c++) {
            const nx = (c / res * 2 - 1) * s;
            const nz = (r / res * 2 - 1) * s;
            const d = Math.sqrt(nx * nx + nz * nz);
            const ny = Math.sin(d * 1.5) * (s * 0.5) * Math.exp(-d * 0.15);
            pts.push({ x: nx, y: ny, z: nz, v: (ny / s + 0.5), i: pts.length });
          }
        }
      },
      helix: () => {
        const turns = 5;
        for (let i = 0; i < count; i++) {
          const t = (i / count) * turns * tau;
          const r2 = s * 0.7;
          const y = (i / count * 2 - 1) * s;
          pts.push({ x: Math.cos(t) * r2, y, z: Math.sin(t) * r2, v: i / count, strand: 0, i });
          if (i % 2 === 0) {
            pts.push({ x: Math.cos(t + Math.PI) * r2, y, z: Math.sin(t + Math.PI) * r2, v: i / count, strand: 1, i: i + 0.5 });
          }
        }
      },
      network: () => {
        const nodes = Math.min(count, 80);
        for (let i = 0; i < nodes; i++) {
          const theta = Math.random() * tau;
          const phi = Math.acos(2 * Math.random() - 1);
          const r = Math.random() * s;
          pts.push({
            x: r * Math.sin(phi) * Math.cos(theta),
            y: r * Math.cos(phi),
            z: r * Math.sin(phi) * Math.sin(theta),
            v: Math.random(),
            connections: Math.floor(Math.random() * 3) + 1,
            i,
          });
        }
      },
      particles: () => {
        for (let i = 0; i < count; i++) {
          const theta = Math.random() * tau;
          const phi = Math.acos(2 * Math.random() - 1);
          const r = Math.pow(Math.random(), 0.5) * s;
          pts.push({
            x: r * Math.sin(phi) * Math.cos(theta),
            y: r * Math.cos(phi),
            z: r * Math.sin(phi) * Math.sin(theta),
            vx: (Math.random() - 0.5) * 0.02,
            vy: (Math.random() - 0.5) * 0.02,
            vz: (Math.random() - 0.5) * 0.02,
            v: Math.random(),
            i,
          });
        }
      },
      spiral: () => {
        const arms = 3;
        const turns = 3;
        for (let i = 0; i < count; i++) {
          const arm = i % arms;
          const tAngle = (i / count) * turns * tau;
          const r = (i / count) * s;
          const angle = tAngle + (arm * tau / arms);
          const noise = (Math.random() - 0.5) * s * 0.15;
          pts.push({
            x: Math.cos(angle) * r + noise,
            y: (Math.random() - 0.5) * s * 0.15,
            z: Math.sin(angle) * r + noise,
            v: i / count,
            arm, i,
          });
        }
      },
      terrain: () => {
        const res = Math.ceil(Math.sqrt(count));
        const hmap = [];
        for (let r = 0; r <= res; r++) {
          hmap[r] = [];
          for (let c = 0; c <= res; c++) {
            const nx = c / res * 4;
            const nz = r / res * 4;
            hmap[r][c] =
              Math.sin(nx * 1.1) * Math.cos(nz * 0.9) * 0.5 +
              Math.sin(nx * 2.3 + 0.5) * Math.cos(nz * 2.1) * 0.25 +
              Math.sin(nx * 4.7 + 1.2) * Math.cos(nz * 4.3) * 0.125 +
              Math.sin(nx * 9.1) * Math.cos(nz * 8.7) * 0.0625;
          }
        }
        for (let r = 0; r < res; r++) {
          for (let c = 0; c < res; c++) {
            const nx = (c / res * 2 - 1) * s;
            const nz = (r / res * 2 - 1) * s;
            const ny = hmap[r][c] * s * 0.8;
            pts.push({ x: nx, y: ny, z: nz, v: (ny / s + 0.5) * 0.5 + 0.25, r, c, i: pts.length });
          }
        }
      },
      constellation: () => {
        for (let i = 0; i < count; i++) {
          const phi = Math.acos(2 * Math.random() - 1);
          const theta = Math.random() * tau;
          const r = s * (0.7 + Math.random() * 0.3);
          pts.push({
            x: r * Math.sin(phi) * Math.cos(theta),
            y: r * Math.cos(phi),
            z: r * Math.sin(phi) * Math.sin(theta),
            bright: Math.random(),
            v: Math.random(),
            i,
          });
        }
      },
      voxels: () => {
        const res = Math.ceil(Math.cbrt(count));
        outer: for (let x = 0; x < res; x++) {
          for (let y = 0; y < res; y++) {
            for (let z2 = 0; z2 < res; z2++) {
              if (pts.length >= count) break outer;
              const nx = (x / res * 2 - 1) * s;
              const ny = (y / res * 2 - 1) * s;
              const nz = (z2 / res * 2 - 1) * s;
              const d = Math.sqrt(nx * nx + ny * ny + nz * nz);
              if (Math.random() < Math.exp(-d * 0.3)) {
                pts.push({ x: nx, y: ny, z: nz, v: 1 - d / (s * 1.73), i: pts.length });
              }
            }
          }
        }
      },
    };

    if (gen[type]) gen[type]();

    pts.forEach((p, i) => {
      p.animOffset = Math.random() * tau;
      p.animSpeed = 0.5 + Math.random() * 1.5;
    });

    return pts;
  }
}

// Export for CommonJS, ES modules, and browser global
if (typeof module !== 'undefined' && module.exports) {
  module.exports = DataViz3D;
}
if (typeof window !== 'undefined') {
  window.DataViz3D = DataViz3D;
}
