# DataViz3D v2.0 — JavaScript 3D Data Visualization Library

**Zero dependencies. Works everywhere. Security-first design.**

## Overview

DataViz3D is a pure JavaScript library for creating 3D data visualizations and visual art. It features 10 visualization types, 10 color palettes, multiple projection modes, post-processing effects, and full interactivity. Perfect for dashboards, art installations, scientific visualization, and generative art.

- ✅ **Zero dependencies** — no three.js, babylonjs, or canvas libraries required
- ✅ **7KB minified** — ultra-lightweight, single file
- ✅ **All environments** — browsers, Node.js+canvas, bundlers
- ✅ **10 viz types** — scatter, bars, surface, helix, network, particles, spiral, terrain, constellation, voxels
- ✅ **10 palettes** — Cyber, Inferno, Ocean, Forest, Lava, Neon, Pastel, Monochrome, Gold, Blood
- ✅ **Interactive** — drag to rotate, scroll to zoom, shift+drag to pan, touch/pinch support
- ✅ **Exportable** — PNG, SVG, JSON

## Installation

### Browser (Global)
```html
<canvas id="viz"></canvas>
<script src="dataviz3d-library.js"></script>
<script>
  const viz = new DataViz3D(document.getElementById('viz'));
  viz.generateData();
  viz.start();
</script>
```

### ES Module
```js
import DataViz3D from './dataviz3d-library.js';

const canvas = document.getElementById('canvas');
const viz = new DataViz3D(canvas, { vizType: 'bars3d' });
viz.start();
```

### CommonJS / Node.js
```js
const DataViz3D = require('./dataviz3d-library.js');
const { createCanvas } = require('canvas');

const canvas = createCanvas(800, 600);
const viz = new DataViz3D(canvas);
viz.generateData();
```

## Quick Start

```js
// Create instance
const viz = new DataViz3D(canvasElement, {
  vizType: 'scatter3d',
  pointSize: 4,
  spread: 5,
  background: 'dark',
});

// Set or generate data
viz.generateData(300, 5);
// or
viz.setData([
  { x: 1, y: 2, z: 3, v: 0.5 },
  { x: -1, y: 1, z: 2, v: 0.8 },
]);

// Configure appearance
viz.setPalette('Cyber');
viz.setFX('bloom', true);
viz.setFX('trails', false);

// Control animation
viz.setAutoRotate(true);
viz.setRotation(0.4, 0.3, 0);
viz.setZoom(1.0);

// Render
viz.start();

// Later: export
const pngDataUrl = viz.exportPNG();
const svgString = viz.exportSVG();
const jsonData = viz.exportJSON();
```

---

## API Reference

### Constructor

```js
new DataViz3D(canvas, config)
```

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `canvas` | HTMLCanvasElement | — | Canvas element to render into |
| `config.vizType` | string | `'scatter3d'` | Visualization type |
| `config.width` | number | container width | Canvas width |
| `config.height` | number | container height | Canvas height |
| `config.pointSize` | number | `4` | Point size (1-20) |
| `config.count` | number | `300` | Default point count for generation |
| `config.spread` | number | `5` | 3D space spread (1-20) |
| `config.speed` | number | `1.0` | Animation multiplier (0-50) |
| `config.colorMode` | string | `'palette'` | Color mode: `palette`, `depth`, `velocity`, `index`, `rainbow`, `mono` |
| `config.projection` | string | `'perspective'` | Projection: `perspective`, `orthographic`, `isometric` |
| `config.background` | string | `'dark'` | Background: `dark`, `void`, `nebula`, `grid_bg`, `gradient` |
| `config.autoplay` | boolean | `true` | Start rendering immediately |
| `config.fpsTarget` | number | `60` | Target frame rate cap |

### Data Methods

#### `setData(points)`
Set visualization data.
```js
viz.setData([
  { x: 0, y: 1, z: 2, v: 0.5 },
  { x: 1, y: 2, z: 3, v: 0.7 },
]);
```

#### `generateData(count, spread)`
Generate random data for current viz type.
```js
viz.generateData(500, 8);  // 500 points, spread of 8
```

#### `static parseData(raw)`
Parse data from CSV, JSON, or plain text.
```js
const data = DataViz3D.parseData('1,2,3\n4,5,6');
const data2 = DataViz3D.parseData('[[1,2,3],[4,5,6]]');
const data3 = DataViz3D.parseData('1\n2\n3');
```

### Visualization Methods

#### `setVizType(type)`
Change visualization type. Valid types: `scatter3d`, `bars3d`, `surface`, `helix`, `network`, `particles`, `spiral`, `terrain`, `constellation`, `voxels`.
```js
viz.setVizType('network');
```

#### `setPalette(name)`
Set color palette by name. See `DataViz3D.getPalettes()` for available palettes.
```js
viz.setPalette('Cyber');
viz.setPalette('Ocean');
```

#### `static getPalettes()`
Get array of all available palettes.
```js
DataViz3D.getPalettes().forEach(p => console.log(p.name));
// Output: Cyber, Inferno, Ocean, Forest, Lava, Neon, ...
```

#### `setFX(effect, enabled)`
Toggle post-processing effect.
```js
viz.setFX('bloom', true);
viz.setFX('trails', false);
viz.setFX('scanlines', true);
```

Available effects: `bloom`, `trails`, `grid`, `axes`, `scanlines`, `connect`, `labels`, `fog`, `pulse`, `wireframe`.

#### `setParam(param, value)`
Set animation parameter.
```js
viz.setParam('pointSize', 8);
viz.setParam('spread', 10);
viz.setParam('speed', 2.5);
viz.setParam('colorMode', 'rainbow');
viz.setParam('projection', 'isometric');
viz.setParam('background', 'nebula');
```

### Camera Control

#### `setRotation(x, y, z)`
Set rotation in radians.
```js
viz.setRotation(0.4, Math.PI / 4, 0);
```

#### `getRotation()`
Get current rotation.
```js
const { x, y, z } = viz.getRotation();
```

#### `setZoom(level)`
Set zoom level (0.1 to 10).
```js
viz.setZoom(2.0);  // 2x zoom
```

#### `getZoom()`
Get current zoom level.
```js
const zoom = viz.getZoom();
```

#### `setPan(x, y)`
Set pan offset in screen pixels.
```js
viz.setPan(50, -30);
```

#### `getPan()`
Get current pan.
```js
const { x, y } = viz.getPan();
```

### Animation Control

#### `setAutoRotate(enabled)`
Enable/disable automatic rotation.
```js
viz.setAutoRotate(true);
```

#### `start()`
Start the render loop.
```js
viz.start();
```

#### `stop()`
Stop the render loop.
```js
viz.stop();
```

### Export Methods

#### `exportPNG()`
Export current frame as PNG data URL.
```js
const url = viz.exportPNG();
const link = document.createElement('a');
link.href = url;
link.download = 'visualization.png';
link.click();
```

#### `exportSVG()`
Export current frame as SVG markup.
```js
const svgString = viz.exportSVG();
const blob = new Blob([svgString], { type: 'image/svg+xml' });
const url = URL.createObjectURL(blob);
```

#### `exportJSON()`
Export data as JSON.
```js
const jsonString = viz.exportJSON();
console.log(jsonString);
```

### Config Access

#### `getConfig()`
Get current configuration.
```js
const config = viz.getConfig();
console.log(config.vizType, config.pointSize);
```

#### `getFX()`
Get current FX state.
```js
const fx = viz.getFX();
console.log(fx.bloom, fx.trails);
```

---

## Visualization Types

### `scatter3d`
Classic 3D point cloud. Points colored by value, with optional bloom glow and connecting lines.

**Best for**: General 3D data, statistical distributions, multi-dimensional analysis.

### `bars3d`
Height field as 3D bar forest. Each point becomes a vertical bar with gradient shading.

**Best for**: Terrain visualization, height maps, spatial density.

### `surface`
Mesh surface with quad rendering. Points form a connected surface.

**Best for**: Parametric surfaces, wave functions, topology.

### `helix`
Dual-strand helix (like DNA). Two intertwined spirals with connecting rungs.

**Best for**: Periodic data, helical/cyclic structures, artistic representation.

### `network`
Proximity graph with weighted edges. Points connect if nearby.

**Best for**: Graph data, network topology, social networks, spatial relationships.

### `particles`
Physics-simulated particles with velocity. Bounces off boundaries.

**Best for**: Particle systems, fluid simulation, dynamic data.

### `spiral`
Multi-arm spiral galaxy. Points arranged along spiraling arms.

**Best for**: Rotational data, astronomical simulation, artistic spirals.

### `terrain`
Procedurally generated heightmap terrain using multi-octave noise.

**Best for**: Landscape simulation, topographic data, procedural generation.

### `constellation`
Spherical star field. Bright stars connect into constellations.

**Best for**: Astronomical data, spherical distributions, sky maps.

### `voxels`
Isometric voxel grid. Density-based cube rendering.

**Best for**: 3D volumetric data, medical imaging, voxel art.

---

## Color Modes

| Mode | Description |
|------|-------------|
| `palette` | Color by point value (v property) |
| `depth` | Color by Z depth (far = dark, near = bright) |
| `velocity` | Color by particle velocity magnitude |
| `index` | Color by point index (rainbow gradient) |
| `rainbow` | Rainbow cycling animation |
| `mono` | Single grayscale color |

---

## Post-Processing Effects

| Effect | Description |
|--------|-------------|
| `bloom` | Radial glow around points |
| `trails` | Motion trail fade (persistent frame buffer) |
| `grid` | Floor grid in 3D space |
| `axes` | XYZ axis guides |
| `scanlines` | CRT scanlines + vignette |
| `connect` | Lines between nearby points |
| `labels` | Data point index labels |
| `fog` | Depth-based opacity fade |
| `pulse` | Pulsing animation on points |
| `wireframe` | Wireframe-only rendering (no fill) |

---

## Projections

| Projection | Description |
|------------|-------------|
| `perspective` | Classic perspective (3D vanishing point) |
| `orthographic` | Parallel projection (isometric-ready) |
| `isometric` | True isometric 45° view |

---

## Backgrounds

| Background | Description |
|------------|-------------|
| `dark` | Deep space with stars |
| `void` | Pure black |
| `nebula` | Radial gradient nebula |
| `grid_bg` | 2D grid room floor |
| `gradient` | Linear gradient fade |

---

## Examples

### Basic Dashboard
```js
const canvas = document.getElementById('viz');
const viz = new DataViz3D(canvas, {
  vizType: 'scatter3d',
  background: 'grid_bg',
  autoplay: true,
});

// Fetch real data
fetch('/api/data.json')
  .then(r => r.json())
  .then(data => {
    viz.setData(data);
    viz.setPalette('Ocean');
  });

// Update on interval
setInterval(() => {
  fetch('/api/data.json').then(r => r.json()).then(data => viz.setData(data));
}, 5000);
```

### Generative Art
```js
const viz = new DataViz3D(canvas, { autoplay: true });

// Randomize every 3 seconds
setInterval(() => {
  const types = DataViz3D.VIZ_TYPES;
  viz.setVizType(types[Math.floor(Math.random() * types.length)]);
  
  const palettes = DataViz3D.getPalettes();
  viz.setPalette(palettes[Math.floor(Math.random() * palettes.length)].name);
  
  viz.generateData(Math.floor(Math.random() * 1000 + 100), Math.random() * 10 + 2);
}, 3000);
```

### Interactive Controls
```js
const viz = new DataViz3D(canvas);

// Slider for point size
document.getElementById('sizeSlider').addEventListener('input', e => {
  viz.setParam('pointSize', parseInt(e.target.value));
});

// Buttons for palettes
DataViz3D.getPalettes().forEach(pal => {
  const btn = document.createElement('button');
  btn.textContent = pal.name;
  btn.addEventListener('click', () => viz.setPalette(pal.name));
  document.getElementById('palette-buttons').appendChild(btn);
});

// Checkbox for bloom
document.getElementById('bloomCheck').addEventListener('change', e => {
  viz.setFX('bloom', e.target.checked);
});
```

### Data from CSV
```js
const csv = `x,y,z,v
1,2,3,0.5
-1,1,2,0.8
2,-1,1,0.3`;

const data = DataViz3D.parseData(csv);
viz.setData(data);
```

### Export to File
```js
// Export PNG
const pngUrl = viz.exportPNG();
const link = document.createElement('a');
link.href = pngUrl;
link.download = `viz-${Date.now()}.png`;
link.click();

// Export SVG
const svgUrl = URL.createObjectURL(new Blob([viz.exportSVG()], { type: 'image/svg+xml' }));
const link2 = document.createElement('a');
link2.href = svgUrl;
link2.download = `viz-${Date.now()}.svg`;
link2.click();
```

---

## Security & Performance

### Security
- ✅ **Zero eval/script injection** — no `eval`, `innerHTML` parsing, or dynamic script execution
- ✅ **CSP-compliant** — works with strict Content Security Policy
- ✅ **Input validation** — all user inputs validated and sanitized
- ✅ **No external calls** — zero network requests (pure local rendering)

### Performance
- ✅ **60 FPS target** — requestAnimationFrame with dt throttling
- ✅ **Depth sorting** — only 1 full sort per frame
- ✅ **Early exit** — frustum culling, null-check guards
- ✅ **Single canvas** — no shadow DOM or iframe overhead
- ✅ **Reusable buffers** — minimal GC allocations

### Browser Support
- ✅ Chrome 60+
- ✅ Firefox 55+
- ✅ Safari 11+
- ✅ Edge 79+
- ✅ Mobile browsers (iOS Safari 13+, Android Chrome 60+)

---

## Troubleshooting

### Canvas is blank
- Check canvas element exists and has width/height
- Call `viz.start()` to begin rendering
- Verify `generateData()` or `setData()` called with valid data

### Data not showing
- Ensure points have `x`, `y`, `z` properties
- Check `spread` parameter isn't too small (data normalized to fit in 3D space)
- Verify current viz type supports your data shape

### Performance is slow
- Reduce point count (set `count` lower)
- Disable `bloom` and `trails` effects
- Set `fpsTarget` lower (e.g., 30 instead of 60)
- Use smaller `pointSize`

### Interactive rotation is jerky
- Check browser developer tools for heavy JS on main thread
- Disable other animations/auto-rotate while dragging
- Reduce visual complexity (disable fog, scanlines, etc.)

---

## License

MIT. Use freely in commercial and personal projects.

---

## See Also

- **DARM-ANN** — Distributed Agentic Recursive Memory Networks (architectural framework)
- **SENTINEL EDR** — Personal SOC overlay with data visualization
- **Cybopsec** — Security research organization using DataViz3D for threat analysis

---

## Contributing

Found a bug? Have a feature request? Open an issue or submit a PR.

**Development philosophy:**
- Zero dependencies (always)
- Single file deployment
- Security first
- Performance optimized
- Full JSDoc type hints
