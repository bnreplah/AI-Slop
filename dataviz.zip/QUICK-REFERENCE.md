# DataViz3D — Quick Reference

## Installation

```html
<!-- Browser -->
<script src="dataviz3d-library.js"></script>

<!-- NPM -->
npm install dataviz3d
import DataViz3D from 'dataviz3d';
```

## Minimal Example

```js
const viz = new DataViz3D(document.getElementById('canvas'));
viz.generateData();
viz.start();
```

## Constructor Options

```js
new DataViz3D(canvas, {
  vizType: 'scatter3d',      // scatter3d, bars3d, surface, helix, network, particles, spiral, terrain, constellation, voxels
  pointSize: 4,              // 1-20
  spread: 5,                 // 1-20
  speed: 1.0,                // 0-50
  colorMode: 'palette',      // palette, depth, velocity, index, rainbow, mono
  projection: 'perspective', // perspective, orthographic, isometric
  background: 'dark',        // dark, void, nebula, grid_bg, gradient
  autoplay: true,
  fpsTarget: 60,
});
```

## Common Tasks

### Load & Display Data
```js
viz.setData([
  { x: 1, y: 2, z: 3, v: 0.5 },
  { x: -1, y: 1, z: 2, v: 0.8 },
]);
```

### Generate Random Data
```js
viz.generateData(300, 5);  // 300 points, spread 5
```

### Parse CSV/JSON
```js
const csv = '1,2,3\n4,5,6';
const data = DataViz3D.parseData(csv);
viz.setData(data);
```

### Change Visualization
```js
viz.setVizType('network');
```

### Set Color Palette
```js
viz.setPalette('Ocean');
// Options: Cyber, Inferno, Ocean, Forest, Lava, Neon, Pastel, Monochrome, Gold, Blood
```

### Toggle Effects
```js
viz.setFX('bloom', true);
viz.setFX('trails', false);
viz.setFX('scanlines', true);
// Options: bloom, trails, grid, axes, scanlines, connect, labels, fog, pulse, wireframe
```

### Set Parameters
```js
viz.setParam('pointSize', 8);
viz.setParam('spread', 10);
viz.setParam('speed', 2.0);
viz.setParam('colorMode', 'rainbow');
viz.setParam('projection', 'isometric');
viz.setParam('background', 'nebula');
```

### Camera Control
```js
viz.setRotation(0.4, Math.PI / 4, 0);  // x, y, z radians
viz.setZoom(2.0);                       // 0.1 to 10
viz.setPan(50, -30);                    // x, y pixels
viz.setAutoRotate(true);
```

### Render Control
```js
viz.start();  // Begin rendering
viz.stop();   // Stop rendering
```

### Export
```js
const png = viz.exportPNG();     // Data URL
const svg = viz.exportSVG();     // SVG string
const json = viz.exportJSON();   // JSON string
```

### Get State
```js
viz.getConfig();      // Current configuration
viz.getFX();          // Effect states
viz.getRotation();    // { x, y, z } radians
viz.getZoom();        // Number
viz.getPan();         // { x, y } pixels
```

## Visualization Types

| Type | Use Case |
|------|----------|
| `scatter3d` | General 3D data |
| `bars3d` | Terrain, height maps |
| `surface` | Parametric surfaces |
| `helix` | Cyclic/periodic data |
| `network` | Graph topology |
| `particles` | Physics simulation |
| `spiral` | Rotational data |
| `terrain` | Landscapes |
| `constellation` | Spherical distributions |
| `voxels` | Volumetric data |

## Color Modes

| Mode | Description |
|------|-------------|
| `palette` | Color by point value |
| `depth` | Color by Z depth |
| `velocity` | Color by speed |
| `index` | Rainbow by position |
| `rainbow` | Animated cycle |
| `mono` | Grayscale |

## Effects

| Effect | What It Does |
|--------|-------------|
| `bloom` | Glow around points |
| `trails` | Motion blur |
| `grid` | Floor grid lines |
| `axes` | XYZ guides |
| `scanlines` | CRT effect |
| `connect` | Lines between points |
| `labels` | Point indices |
| `fog` | Depth fade |
| `pulse` | Pulsing animation |
| `wireframe` | Outline only |

## Projections

| Projection | Effect |
|-----------|--------|
| `perspective` | Vanishing point 3D |
| `orthographic` | Parallel view |
| `isometric` | 45° isometric |

## Backgrounds

| Background | Effect |
|-----------|--------|
| `dark` | Deep space |
| `void` | Black |
| `nebula` | Radial gradient |
| `grid_bg` | Grid room |
| `gradient` | Linear fade |

## Palettes

- Cyber
- Inferno
- Ocean
- Forest
- Lava
- Neon
- Pastel
- Monochrome
- Gold
- Blood

## React Example

```jsx
import { useEffect, useRef } from 'react';
import DataViz3D from 'dataviz3d';

export function Viz({ data, vizType = 'scatter3d' }) {
  const ref = useRef(null);
  const vizRef = useRef(null);

  useEffect(() => {
    if (!ref.current) return;
    vizRef.current = new DataViz3D(ref.current);
    vizRef.current.setVizType(vizType);
    vizRef.current.start();
    return () => vizRef.current?.stop();
  }, []);

  useEffect(() => {
    if (vizRef.current && data) {
      vizRef.current.setData(data);
    }
  }, [data]);

  return <canvas ref={ref} style={{ width: '100%', height: '100vh' }} />;
}
```

## Vue Example

```vue
<template>
  <canvas ref="canvas" class="viz-canvas"></canvas>
</template>

<script setup>
import { ref, onMounted, watch } from 'vue';
import DataViz3D from 'dataviz3d';

const canvas = ref(null);
const viz = ref(null);

const props = defineProps({ data: Array });

onMounted(() => {
  viz.value = new DataViz3D(canvas.value);
  viz.value.start();
});

watch(() => props.data, (newData) => {
  if (viz.value && newData) {
    viz.value.setData(newData);
  }
});
</script>
```

## Vue + Svelte Quick Snippets

```svelte
<!-- Svelte -->
<script>
  import { onMount } from 'svelte';
  import DataViz3D from 'dataviz3d';

  let canvas;
  let viz;

  onMount(() => {
    viz = new DataViz3D(canvas);
    viz.start();
    return () => viz.stop();
  });
</script>

<canvas bind:this={canvas}></canvas>
```

## Performance Tips

- Disable `bloom`, `trails` on large datasets
- Reduce `count` parameter
- Use `particles` type for 1000+ points
- Set `fpsTarget: 30` on mobile
- Use `projection: 'orthographic'` for speed

## Keyboard Shortcuts (Built-in)

- **Drag** — Rotate
- **Scroll** — Zoom
- **Shift + Drag** — Pan
- **Touch + Pinch** — Zoom (mobile)
- **Touch + Drag** — Rotate (mobile)

## Common Patterns

### Auto-updating dashboard
```js
const viz = new DataViz3D(canvas);
setInterval(() => {
  fetch('/data.json')
    .then(r => r.json())
    .then(data => viz.setData(data));
}, 5000);
viz.start();
```

### Random visualization generator
```js
const viz = new DataViz3D(canvas, { autoplay: true });
setInterval(() => {
  const types = DataViz3D.VIZ_TYPES;
  viz.setVizType(types[Math.floor(Math.random() * types.length)]);
  viz.generateData();
}, 3000);
```

### Controlled mode
```js
const viz = new DataViz3D(canvas, { autoplay: false });
document.getElementById('startBtn').onclick = () => viz.start();
document.getElementById('stopBtn').onclick = () => viz.stop();
```

### Export on demand
```js
document.getElementById('exportBtn').onclick = () => {
  const url = viz.exportPNG();
  const a = document.createElement('a');
  a.href = url;
  a.download = `viz-${Date.now()}.png`;
  a.click();
};
```

---

**File Size:** ~7KB minified  
**Dependencies:** 0  
**Browser Support:** Chrome 60+, Firefox 55+, Safari 11+, Edge 79+

---

For complete API documentation, see `DATAVIZ3D-API.md`
