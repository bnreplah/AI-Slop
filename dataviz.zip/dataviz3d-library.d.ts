/**
 * DataViz3D v2.0 TypeScript Type Definitions
 */

export interface Point3D {
  x: number;
  y: number;
  z: number;
  v?: number;
  vx?: number;
  vy?: number;
  vz?: number;
  [key: string]: any;
}

export interface Palette {
  name: string;
  colors: string[];
}

export interface Config {
  vizType?: 'scatter3d' | 'bars3d' | 'surface' | 'helix' | 'network' | 'particles' | 'spiral' | 'terrain' | 'constellation' | 'voxels';
  width?: number;
  height?: number;
  pointSize?: number;
  count?: number;
  spread?: number;
  speed?: number;
  colorMode?: 'palette' | 'depth' | 'velocity' | 'index' | 'rainbow' | 'mono';
  projection?: 'perspective' | 'orthographic' | 'isometric';
  background?: 'dark' | 'void' | 'nebula' | 'grid_bg' | 'gradient';
  autoplay?: boolean;
  fpsTarget?: number;
}

export interface FX {
  bloom: boolean;
  trails: boolean;
  grid: boolean;
  axes: boolean;
  scanlines: boolean;
  connect: boolean;
  labels: boolean;
  fog: boolean;
  pulse: boolean;
  wireframe: boolean;
}

export interface Rotation {
  x: number;
  y: number;
  z: number;
}

export interface Pan {
  x: number;
  y: number;
}

declare class DataViz3D {
  constructor(canvas: HTMLCanvasElement, config?: Config);

  // Static methods
  static getPalettes(): Palette[];
  static parseData(raw: string): Point3D[];
  static readonly PALETTES: Palette[];
  static readonly VIZ_TYPES: string[];

  // Instance properties
  canvas: HTMLCanvasElement;
  points: Point3D[];
  rotation: Rotation;
  pan: Pan;
  zoom: number;
  autoRotate: boolean;
  fps: number;
  frame: number;

  // Data methods
  setData(points: Point3D[]): void;
  generateData(count?: number, spread?: number): void;

  // Visualization methods
  setVizType(type: string): void;
  setPalette(name: string): void;
  setFX(effect: keyof FX, enabled: boolean): void;
  setParam(param: 'pointSize' | 'spread' | 'speed' | 'colorMode' | 'projection' | 'background', value: any): void;

  // Camera methods
  setRotation(x: number, y: number, z?: number): void;
  getRotation(): Rotation;
  setZoom(level: number): void;
  getZoom(): number;
  setPan(x: number, y: number): void;
  getPan(): Pan;

  // Animation methods
  setAutoRotate(enabled: boolean): void;
  start(): void;
  stop(): void;

  // Export methods
  exportPNG(): string;
  exportSVG(): string;
  exportJSON(): string;

  // Config access
  getConfig(): Config;
  getFX(): FX;
}

export default DataViz3D;
