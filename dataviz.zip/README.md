# DataViz3D v2.0

> **Zero-dependency 3D data visualization library. Pure JavaScript. For browsers, Node.js, and bundlers.**

[![MIT License](https://img.shields.io/badge/license-MIT-green)](LICENSE)
![Size](https://img.shields.io/badge/size-~7KB%20minified-blue)
![No Dependencies](https://img.shields.io/badge/dependencies-0-brightgreen)

Create stunning 3D visualizations, networks, particle systems, and visual art with **pure JavaScript**.

- 🎨 **10 visualization types** — scatter, bars, surface, helix, network, particles, spiral, terrain, constellation, voxels
- 🌈 **10 color palettes** — cyberpunk, ocean, lava, neon, and more
- ⚡ **Zero dependencies** — works everywhere, ultra-lightweight
- 🎮 **Fully interactive** — drag to rotate, scroll to zoom, touch support
- 📊 **Export-ready** — PNG, SVG, JSON
- 🔒 **Security-first** — no eval, no injections, CSP-compliant
- 📱 **Responsive** — mobile-friendly, touch gestures

## Quick Start

### Browser

```html
<canvas id="viz"></canvas>
<script src="dataviz3d-library.js"></script>
<script>
  const viz = new DataViz3D(document.getElementById('viz'));
  viz.generateData(300, 5);
  viz.start();
</script>
```

### NPM

```bash
npm install dataviz3d
```

```js
import DataViz3D from 'dataviz3d';

const canvas = document.getElementById('canvas');
const viz = new DataViz3D(canvas, {
  vizType: 'network',
  background: 'nebula',
});

viz.generateData();
viz.start();
```

### Node.js + Canvas

```js
const DataViz3D = require('dataviz3d');
const { createCanvas } = require('canvas');

const canvas = createCanvas(800, 600);
const viz = new DataViz3D(canvas);
viz.generateData();

// Render to PNG
const buffer = canvas.toBuffer('image/png');
fs.writeFileSync('output.png', buffer);
```

---

## Features

### Visualization Types

| Type | Description | Best For |
|------|-------------|----------|
| `scatter3d` | 3D point cloud | Statistical data, multi-dimensional |
| `bars3d` | Height field bars | Terrain, density maps |
| `surface` | Mesh surface | Parametric surfaces, functions |
| `helix` | DNA-like double helix | Cyclic data, periodic structures |
| `network` | Proximity graph | Networks, relationships, graphs |
| `particles` | Physics particles | Simulations, fluid dynamics |
| `spiral` | Galaxy spiral | Rotational data, artistic |
| `terrain` | Procedural terrain | Landscapes, topography |
| `constellation` | Star field | Astronomical data, spherical |
| `voxels` | 3D cubes | Volumetric, medical imaging |

### Color Modes

- `palette` — Color by data value
- `depth` — Color by Z depth
- `velocity` — Color by speed
- `index` — Rainbow gradient
- `rainbow` — Animated color cycle
- `mono` — Monochrome

### Post-Processing Effects

- **Bloom** — Radial glow around points
- **Trails** — Motion blur effect
- **Grid** — 3D floor grid
- **Axes** — XYZ reference axes
- **Scanlines** — CRT effect + vignette
- **Connect** — Lines between nearby points
- **Labels** — Point index labels
- **Fog** — Depth-based fade
- **Pulse** — Pulsing animation
- **Wireframe** — Outline-only rendering

### Projections

- **Perspective** — Classic 3D vanishing point
- **Orthographic** — Parallel projection
- **Isometric** — True isometric view

---

## API Reference

### Constructor

```js
const viz = new DataViz3D(canvas, {
  vizType: 'scatter3d',
  pointSize: 4,
  spread: 5,
  speed: 1.0,
  colorMode: 'palette',
  projection: 'perspective',
  background: 'dark',
  autoplay: true,
  fpsTarget: 60,
});
```

### Data

```js
// Set data
viz.setData([
  { x: 1, y: 2, z: 3, v: 0.5 },
  { x: -1, y: 1, z: 2, v: 0.8 },
]);

// Generate random data
viz.generateData(500, 8);

// Parse from CSV/JSON
const data = DataViz3D.parseData('1,2,3\n4,5,6');
viz.setData(data);
```

### Visualization

```js
// Change type
viz.setVizType('network');

// Set color palette
viz.setPalette('Ocean');

// Toggle effects
viz.setFX('bloom', true);
viz.setFX('trails', false);

// Set parameters
viz.setParam('pointSize', 8);
viz.setParam('spread', 10);
viz.setParam('colorMode', 'rainbow');
```

### Camera Control

```js
// Rotation (radians)
viz.setRotation(0.4, Math.PI / 4, 0);

// Zoom (0.1 to 10)
viz.setZoom(2.0);

// Pan (pixels)
viz.setPan(50, -30);

// Auto-rotation
viz.setAutoRotate(true);
```

### Animation

```js
// Start/stop rendering
viz.start();
viz.stop();

// Get state
const fps = viz.fps;
const frame = viz.frame;
```

### Export

```js
// PNG data URL
const pngUrl = viz.exportPNG();

// SVG markup
const svgString = viz.exportSVG();

// JSON data
const jsonString = viz.exportJSON();
```

---

## Examples

### Basic Dashboard

```js
const viz = new DataViz3D(document.getElementById('canvas'));

// Load data
fetch('/api/data.json')
  .then(r => r.json())
  .then(data => viz.setData(data));

// Auto-update
setInterval(() => {
  fetch('/api/data.json')
    .then(r => r.json())
    .then(data => viz.setData(data));
}, 5000);

viz.start();
```

### Generative Art

```js
const viz = new DataViz3D(canvas, { autoplay: true });

// Randomize every 3 seconds
setInterval(() => {
  const types = DataViz3D.VIZ_TYPES;
  viz.setVizType(types[Math.floor(Math.random() * types.length)]);

  const palettes = DataViz3D.getPalettes();
  viz.setPalette(palettes[Math.floor(Math.random() * palettes.length)].name);

  viz.generateData(Math.random() * 1000 + 100, Math.random() * 10 + 2);
}, 3000);
```

### Interactive Controls

```js
const viz = new DataViz3D(canvas);

// Slider for point size
document.getElementById('sizeSlider').addEventListener('input', e => {
  viz.setParam('pointSize', parseInt(e.target.value));
});

// Buttons for palettes
DataViz3D.getPalettes().forEach(pal => {
  const btn = document.createElement('button');
  btn.textContent = pal.name;
  btn.addEventListener('click', () => viz.setPalette(pal.name));
  document.body.appendChild(btn);
});

viz.start();
```

### Data from CSV

```js
const csv = `x,y,z,value
1,2,3,0.5
-1,1,2,0.8
2,-1,1,0.3`;

const data = DataViz3D.parseData(csv);
viz.setData(data);
```

### Export to File

```js
// Export PNG
const pngUrl = viz.exportPNG();
const link = document.createElement('a');
link.href = pngUrl;
link.download = 'visualization.png';
link.click();

// Export SVG
const svgString = viz.exportSVG();
const blob = new Blob([svgString], { type: 'image/svg+xml' });
const url = URL.createObjectURL(blob);
const link2 = document.createElement('a');
link2.href = url;
link2.download = 'visualization.svg';
link2.click();
```

---

## Browser Support

- ✅ Chrome 60+
- ✅ Firefox 55+
- ✅ Safari 11+
- ✅ Edge 79+
- ✅ iOS Safari 13+
- ✅ Android Chrome 60+

---

## Performance

- **60 FPS target** on modern devices
- **Optimized rendering** with depth sorting, frustum culling
- **Minimal allocations** — reusable buffers, GC-friendly
- **Scales to 10,000+ points** depending on effects

### Tips for Better Performance

- Disable `bloom` and `trails` effects
- Reduce point count
- Set `fpsTarget` to 30 if targeting mobile
- Simplify visualization (e.g., avoid `connect` on large datasets)

---

## Security

✅ **Zero eval/script injection**  
✅ **CSP-compliant**  
✅ **No external network calls**  
✅ **Input validated**  
✅ **No dependencies to audit**

---

## Files

| File | Purpose |
|------|---------|
| `dataviz3d-library.js` | Main library (7KB minified) |
| `dataviz3d-library.d.ts` | TypeScript definitions |
| `dataviz3d-demo.html` | Interactive playground |
| `DATAVIZ3D-API.md` | Complete API documentation |
| `package.json` | NPM package config |

---

## License

MIT. Use freely in commercial and personal projects.

---

## Contributing

Found a bug? Have an idea? Open an issue or submit a PR.

**Development philosophy:**
- Zero dependencies (always)
- Single-file deployment
- Security first
- Performance optimized
- Full JSDoc + TypeScript definitions

---

## See Also

- **DARM-ANN** — Distributed Agentic Recursive Memory Networks
- **SENTINEL EDR** — Personal SOC with visualizations
- **Cybopsec** — Security research organization

---

## FAQ

### Can I use this in production?
Yes. DataViz3D is production-ready, well-tested, and used in real dashboards.

### Does it work with React/Vue/Angular?
Yes. It works with any JavaScript framework. Just pass a canvas ref.

```jsx
// React example
import { useEffect, useRef } from 'react';
import DataViz3D from 'dataviz3d';

export function Viz({ data }) {
  const ref = useRef(null);

  useEffect(() => {
    const viz = new DataViz3D(ref.current);
    viz.setData(data);
    viz.start();
    return () => viz.stop();
  }, [data]);

  return <canvas ref={ref} style={{ width: '100%', height: '100%' }} />;
}
```

### How do I handle large datasets?
Use the `particles` type for physics-based simulation, or reduce point count. For 10,000+ points, consider aggregation or filtering.

### Can I customize colors?
Yes. Use `setFX('bloom', ...)` and `setParam('colorMode', ...)`. For complete control, modify palette arrays in the source.

### Does it work offline?
Yes. Completely offline. No CDN, no API calls.

### Can I export to video?
Not directly, but you can capture frames and encode with ffmpeg:

```bash
for i in {0..300}; do
  # Render frame i to PNG
  node render-frame.js $i output-$i.png
done
ffmpeg -framerate 30 -i output-%d.png -c:v libx264 video.mp4
```

---

Made with 🔒 security-first design and ❤️ for data art.
