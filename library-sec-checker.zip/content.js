// content.js - Auto-detect packages on registry websites and GitHub

(function() {
  'use strict';

  let scannedPackages = new Set();

  // Detect which site we're on and extract package info
  function detectPackage() {
    const url = window.location.href;
    let packageInfo = null;

    if (url.includes('npmjs.com/package/')) {
      packageInfo = extractNpmPackage();
    } else if (url.includes('pypi.org/project/')) {
      packageInfo = extractPyPiPackage();
    } else if (url.includes('github.com') && url.includes('/blob/') || url.includes('/tree/')) {
      packageInfo = extractGitHubPackage();
    } else if (url.includes('crates.io/crates/')) {
      packageInfo = extractCargoPackage();
    } else if (url.includes('rubygems.org/gems/')) {
      packageInfo = extractRubyGemsPackage();
    } else if (url.includes('nuget.org/packages/')) {
      packageInfo = extractNuGetPackage();
    } else if (url.includes('packagist.org/packages/')) {
      packageInfo = extractPackagistPackage();
    } else if (url.includes('mvnrepository.com/artifact/')) {
      packageInfo = extractMavenPackage();
    }

    if (packageInfo && !scannedPackages.has(packageInfo.key)) {
      scannedPackages.add(packageInfo.key);
      injectSecurityBanner(packageInfo);
    }
  }

  // Extract npm package info
  function extractNpmPackage() {
    const match = window.location.pathname.match(/\/package\/([@\w-]+(?:\/[@\w-]+)?)/);
    if (!match) return null;

    const packageName = match[1];
    const versionElement = document.querySelector('[data-test="current-version"]');
    const version = versionElement?.textContent?.trim() || 'latest';

    return {
      key: `npm:${packageName}:${version}`,
      ecosystem: 'npm',
      name: packageName,
      version: version
    };
  }

  // Extract PyPI package info
  function extractPyPiPackage() {
    const match = window.location.pathname.match(/\/project\/([\w-]+)/);
    if (!match) return null;

    const packageName = match[1];
    const versionElement = document.querySelector('.release__version');
    const version = versionElement?.textContent?.trim() || 'latest';

    return {
      key: `pypi:${packageName}:${version}`,
      ecosystem: 'pypi',
      name: packageName,
      version: version
    };
  }

  // Extract package from GitHub repository
  function extractGitHubPackage() {
    // Look for package.json, requirements.txt, Cargo.toml, etc.
    const pathElements = window.location.pathname.split('/');
    
    // Check if viewing package.json
    if (window.location.pathname.includes('package.json')) {
      const content = document.querySelector('.blob-code-inner')?.textContent;
      if (content) {
        try {
          const pkg = JSON.parse(content);
          return {
            key: `npm:${pkg.name}:${pkg.version}`,
            ecosystem: 'npm',
            name: pkg.name,
            version: pkg.version || 'latest'
          };
        } catch (e) {}
      }
    }

    return null;
  }

  // Extract Cargo package info
  function extractCargoPackage() {
    const match = window.location.pathname.match(/\/crates\/([\w-]+)/);
    if (!match) return null;

    const packageName = match[1];
    const versionElement = document.querySelector('.version');
    const version = versionElement?.textContent?.trim() || 'latest';

    return {
      key: `cargo:${packageName}:${version}`,
      ecosystem: 'cargo',
      name: packageName,
      version: version
    };
  }

  // Extract RubyGems package info
  function extractRubyGemsPackage() {
    const match = window.location.pathname.match(/\/gems\/([\w-]+)/);
    if (!match) return null;

    const packageName = match[1];
    const versionElement = document.querySelector('.page__subheading');
    const version = versionElement?.textContent?.trim().split(' ')[0] || 'latest';

    return {
      key: `rubygems:${packageName}:${version}`,
      ecosystem: 'rubygems',
      name: packageName,
      version: version
    };
  }

  // Extract NuGet package info
  function extractNuGetPackage() {
    const match = window.location.pathname.match(/\/packages\/([\w.-]+)/);
    if (!match) return null;

    const packageName = match[1];
    const versionElement = document.querySelector('.version-title');
    const version = versionElement?.textContent?.trim() || 'latest';

    return {
      key: `nuget:${packageName}:${version}`,
      ecosystem: 'nuget',
      name: packageName,
      version: version
    };
  }

  // Extract Packagist package info
  function extractPackagistPackage() {
    const match = window.location.pathname.match(/\/packages\/([\w-]+\/[\w-]+)/);
    if (!match) return null;

    const packageName = match[1];
    const versionElement = document.querySelector('.version-number');
    const version = versionElement?.textContent?.trim() || 'latest';

    return {
      key: `packagist:${packageName}:${version}`,
      ecosystem: 'packagist',
      name: packageName,
      version: version
    };
  }

  // Extract Maven package info
  function extractMavenPackage() {
    const match = window.location.pathname.match(/\/artifact\/([\w.-]+)\/([\w.-]+)/);
    if (!match) return null;

    const groupId = match[1];
    const artifactId = match[2];
    const packageName = `${groupId}:${artifactId}`;
    
    const versionElement = document.querySelector('.vbtn.release');
    const version = versionElement?.textContent?.trim() || 'latest';

    return {
      key: `maven:${packageName}:${version}`,
      ecosystem: 'maven',
      name: packageName,
      version: version
    };
  }

  // Inject security banner at top of page
  function injectSecurityBanner(packageInfo) {
    // Create banner container
    const banner = document.createElement('div');
    banner.id = 'securelib-banner';
    banner.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      z-index: 999999;
      background: linear-gradient(135deg, #0a0e27 0%, #141b3d 100%);
      border-bottom: 2px solid #00ff9f;
      box-shadow: 0 4px 12px rgba(0, 255, 159, 0.2);
      padding: 12px 20px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      font-family: 'JetBrains Mono', 'Courier New', monospace;
      font-size: 13px;
      color: #e0e6ff;
      animation: slideDown 0.3s ease-out;
    `;

    banner.innerHTML = `
      <div style="display: flex; align-items: center; gap: 12px;">
        <span style="font-size: 18px;">🛡️</span>
        <div>
          <div style="font-weight: 600; color: #00ff9f; margin-bottom: 2px;">
            SecureLib Guardian
          </div>
          <div style="font-size: 11px; color: #8892b3;">
            Scanning ${packageInfo.name}@${packageInfo.version}...
          </div>
        </div>
      </div>
      <div style="display: flex; align-items: center; gap: 12px;">
        <div id="securelib-status" style="display: flex; align-items: center; gap: 8px;">
          <div class="securelib-spinner"></div>
          <span style="font-size: 11px; color: #8892b3;">Checking databases...</span>
        </div>
        <button id="securelib-close" style="
          background: none;
          border: 1px solid #1e2954;
          color: #8892b3;
          padding: 4px 8px;
          border-radius: 3px;
          cursor: pointer;
          font-size: 11px;
          font-family: inherit;
        ">✕</button>
      </div>
    `;

    // Add spinner animation
    const style = document.createElement('style');
    style.textContent = `
      @keyframes slideDown {
        from { transform: translateY(-100%); }
        to { transform: translateY(0); }
      }
      @keyframes spin {
        to { transform: rotate(360deg); }
      }
      .securelib-spinner {
        width: 14px;
        height: 14px;
        border: 2px solid #1e2954;
        border-top-color: #00ff9f;
        border-radius: 50%;
        animation: spin 1s linear infinite;
      }
    `;
    document.head.appendChild(style);

    // Add to page
    document.body.insertBefore(banner, document.body.firstChild);
    document.body.style.paddingTop = '80px';

    // Close button handler
    document.getElementById('securelib-close').addEventListener('click', () => {
      banner.remove();
      document.body.style.paddingTop = '';
    });

    // Trigger scan
    scanPackageAndUpdate(packageInfo, banner);
  }

  // Scan package and update banner
  async function scanPackageAndUpdate(packageInfo, banner) {
    try {
      const response = await chrome.runtime.sendMessage({
        action: 'scanPackage',
        data: packageInfo
      });

      const statusDiv = document.getElementById('securelib-status');
      if (!statusDiv) return;

      const totalVulns = response.vulnerabilities?.length || 0;
      const critical = response.vulnerabilities?.filter(v => v.severity === 'CRITICAL').length || 0;
      const high = response.vulnerabilities?.filter(v => v.severity === 'HIGH').length || 0;
      const hasMalicious = response.maliciousPackages?.length > 0;

      let statusHTML = '';
      let backgroundColor = '';

      if (hasMalicious) {
        statusHTML = `
          <span style="font-size: 16px;">⚠️</span>
          <div>
            <div style="font-weight: 600; color: #ff0055;">MALICIOUS PACKAGE DETECTED</div>
            <div style="font-size: 11px; color: #ff0055;">Do NOT use this package!</div>
          </div>
        `;
        backgroundColor = 'linear-gradient(135deg, #2a0a0f 0%, #3d1419 100%)';
        banner.style.borderBottom = '2px solid #ff0055';
      } else if (critical > 0 || high > 0) {
        statusHTML = `
          <span style="font-size: 16px;">⚠️</span>
          <div>
            <div style="font-weight: 600; color: #ff0055;">
              ${critical > 0 ? `${critical} CRITICAL` : `${high} HIGH`} Risk
            </div>
            <div style="font-size: 11px; color: #8892b3;">
              ${totalVulns} vulnerabilities found
            </div>
          </div>
        `;
        backgroundColor = 'linear-gradient(135deg, #2a0a0f 0%, #3d1419 100%)';
        banner.style.borderBottom = '2px solid #ff0055';
      } else if (totalVulns > 0) {
        statusHTML = `
          <span style="font-size: 16px;">⚠️</span>
          <div>
            <div style="font-weight: 600; color: #ffaa00;">
              ${totalVulns} vulnerabilities found
            </div>
            <div style="font-size: 11px; color: #8892b3;">
              Medium/Low risk
            </div>
          </div>
        `;
        backgroundColor = 'linear-gradient(135deg, #2a1a0a 0%, #3d2814 100%)';
        banner.style.borderBottom = '2px solid #ffaa00';
      } else {
        statusHTML = `
          <span style="font-size: 16px;">✓</span>
          <div>
            <div style="font-weight: 600; color: #00ff9f;">
              No vulnerabilities found
            </div>
            <div style="font-size: 11px; color: #8892b3;">
              ${response.sourcesChecked} databases checked
            </div>
          </div>
        `;
      }

      banner.style.background = backgroundColor || banner.style.background;
      statusDiv.innerHTML = statusHTML;
      statusDiv.style.display = 'flex';
      statusDiv.style.alignItems = 'center';
      statusDiv.style.gap = '8px';

      // Auto-hide after 10 seconds if safe
      if (totalVulns === 0 && !hasMalicious) {
        setTimeout(() => {
          banner.style.animation = 'slideDown 0.3s ease-out reverse';
          setTimeout(() => {
            banner.remove();
            document.body.style.paddingTop = '';
          }, 300);
        }, 10000);
      }

    } catch (error) {
      console.error('SecureLib Guardian scan error:', error);
      const statusDiv = document.getElementById('securelib-status');
      if (statusDiv) {
        statusDiv.innerHTML = `
          <span style="color: #ff0055;">✗</span>
          <span style="font-size: 11px; color: #8892b3;">Scan failed</span>
        `;
      }
    }
  }

  // Run detection on page load and URL changes
  detectPackage();

  // Monitor for URL changes (SPA navigation)
  let lastUrl = location.href;
  new MutationObserver(() => {
    const url = location.href;
    if (url !== lastUrl) {
      lastUrl = url;
      scannedPackages.clear();
      detectPackage();
    }
  }).observe(document, { subtree: true, childList: true });

})();
