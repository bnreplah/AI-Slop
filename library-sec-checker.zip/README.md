# SecureLib Guardian 🛡️

A comprehensive Chrome extension that cross-references libraries against multiple vulnerability databases and malicious package feeds before you use them. Built with a cyberpunk/hacker aesthetic by Cybopsec.

## Features

### Multi-Source Vulnerability Scanning
- **OSV (Open Source Vulnerabilities)** - Google's aggregated vulnerability database
- **NVD (National Vulnerability Database)** - NIST's CVE database  
- **GitHub Security Advisory** - GitHub's curated vulnerability database
- **Snyk Vulnerability Database** - Commercial security intelligence
- **Veracode SCA** - Software composition analysis with malicious package detection
- **Socket.dev** - Supply chain security and malicious package detection
- **deps.dev** - Google's dependency insights and advisories

### Supported Ecosystems
- npm (JavaScript/Node.js)
- PyPI (Python)
- Maven (Java)
- NuGet (.NET)
- Cargo (Rust)
- RubyGems (Ruby)
- Packagist (PHP)
- Go Modules

### Auto-Detection
Automatically scans packages when you visit:
- npmjs.com
- pypi.org
- crates.io
- rubygems.org
- nuget.org
- packagist.org
- mvnrepository.com
- GitHub (when viewing package manifests)

## Installation

### 1. Clone or Download
```bash
git clone https://github.com/your-username/securelib-guardian.git
cd securelib-guardian
```

### 2. Add Extension Icons
Create an `icons/` directory and add three icon files:
- `icon16.png` (16x16px)
- `icon48.png` (48x48px)
- `icon128.png` (128x128px)

You can use any shield or security-themed icon.

### 3. Configure API Keys

The extension works with free-tier access for most services, but you'll get better results with API keys.

Edit `background.js` and add your API keys:

```javascript
// Line 82 - NVD API Key (optional but recommended)
headers: {
  'apiKey': 'YOUR_NVD_API_KEY_HERE'
}

// Line 115 - GitHub Token (required for GitHub Advisory)
headers: {
  'Authorization': 'Bearer YOUR_GITHUB_TOKEN_HERE'
}

// Line 143 - Snyk Token (optional)
headers: {
  'Authorization': 'token YOUR_SNYK_TOKEN_HERE'
}

// Line 165 - Veracode Token (optional)
headers: {
  'Authorization': 'Bearer YOUR_VERACODE_TOKEN_HERE'
}

// Line 202 - Socket.dev Token (optional)
headers: {
  'Authorization': 'Bearer YOUR_SOCKET_TOKEN_HERE'
}
```

### 4. Load Extension in Chrome

1. Open Chrome and navigate to `chrome://extensions/`
2. Enable "Developer mode" (toggle in top right)
3. Click "Load unpacked"
4. Select the `securelib-guardian` directory
5. The extension should now appear in your toolbar

## Getting API Keys

### NVD (National Vulnerability Database)
- **URL**: https://nvd.nist.gov/developers/request-an-api-key
- **Free Tier**: 5 requests per 30 seconds
- **With Key**: 50 requests per 30 seconds
- **Required**: No, but highly recommended

### GitHub Personal Access Token
- **URL**: https://github.com/settings/tokens
- **Required Scopes**: `public_repo`, `read:security_events`
- **Free Tier**: 5,000 requests per hour
- **Required**: Yes, for GitHub Advisory scanning

### Snyk
- **URL**: https://app.snyk.io/account
- **Free Tier**: 200 tests per month
- **Required**: No, but adds commercial intelligence

### Veracode
- **URL**: https://web.analysiscenter.veracode.com/login/
- **Required**: Enterprise account needed
- **Required**: No, but provides SCA-specific insights

### Socket.dev
- **URL**: https://socket.dev/
- **Free Tier**: Available for open source projects
- **Required**: No, but excellent for supply chain security

## Usage

### Manual Scanning
1. Click the SecureLib Guardian icon in your toolbar
2. Select the ecosystem (npm, PyPI, etc.)
3. Enter the package name
4. Optionally enter a specific version (or leave blank for latest)
5. Click "Scan Package"

The extension will:
- Query all configured vulnerability databases in parallel
- Check for known CVEs and security advisories
- Detect malicious packages
- Display a risk assessment with severity levels
- Show detailed vulnerability information

### Auto-Scanning
Simply visit any supported package registry:
- Navigate to a package page on npmjs.com, pypi.org, etc.
- The extension automatically detects the package
- A banner appears at the top showing scan results
- Banner color indicates risk level:
  - **Green border**: No vulnerabilities found
  - **Orange border**: Medium/Low vulnerabilities
  - **Red border**: Critical/High vulnerabilities or malicious package

## Understanding Results

### Risk Levels
- **Safe**: No known vulnerabilities
- **Low Risk**: Low severity vulnerabilities present
- **Medium Risk**: Medium severity vulnerabilities
- **High Risk**: High severity vulnerabilities
- **Critical Risk**: Critical severity or malicious package detected

### Severity Ratings
Based on CVSS scores:
- **CRITICAL**: CVSS 9.0-10.0
- **HIGH**: CVSS 7.0-8.9
- **MEDIUM**: CVSS 4.0-6.9
- **LOW**: CVSS 0.1-3.9

## Privacy & Data

- All API calls are made directly from your browser to vulnerability databases
- No data is sent to Cybopsec or third-party tracking services
- Package names and scan results are stored locally in Chrome storage only
- API keys are stored in the extension code (local to your machine)

## Troubleshooting

### "API Error" messages
- Check that your API keys are correctly configured
- Verify you haven't exceeded rate limits
- Some APIs may be temporarily unavailable

### Banner doesn't appear on package pages
- Check that the extension is enabled
- Some sites use dynamic content - try refreshing the page
- Check browser console for any errors

### No results from certain databases
- Some databases require API keys to function
- Rate limits may be preventing requests
- The package may not exist in that particular database

## Development

### Project Structure
```
securelib-guardian/
├── manifest.json          # Extension configuration
├── background.js          # Service worker with API integrations
├── popup.html            # Extension popup interface
├── popup.js              # Popup logic
├── content.js            # Auto-detection on package sites
├── content.css           # Content script styles
├── icons/                # Extension icons
│   ├── icon16.png
│   ├── icon48.png
│   └── icon128.png
└── README.md
```

### Adding New Databases

To add a new vulnerability database:

1. Add the API endpoint to `host_permissions` in `manifest.json`
2. Create a scan function in `background.js`:
```javascript
async function scanNewDB(packageName, version, ecosystem) {
  // API call logic
  return { vulnerabilities: [] };
}
```
3. Add to the scan orchestrator in `handlePackageScan()`
4. Add ecosystem mapping function if needed

### Testing

Test the extension by scanning known vulnerable packages:
- `lodash@4.17.20` (npm) - Has known vulnerabilities
- `requests@2.6.0` (PyPI) - Has known vulnerabilities  
- `jackson-databind@2.9.8` (Maven) - Has known vulnerabilities

## Contributing

Built by Cybopsec. Contributions welcome!

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

## License

MIT License - See LICENSE file for details

## Disclaimer

This tool provides information from public vulnerability databases. It should be used as part of a comprehensive security strategy, not as the sole security measure. Always:

- Review vulnerability details and assess impact on your use case
- Keep dependencies updated
- Follow security best practices
- Conduct thorough security testing
- Consult security professionals for critical applications

## Credits

Developed by **Cybopsec** - Security Engineering & Research

Vulnerability data sources:
- Open Source Vulnerabilities (OSV)
- National Vulnerability Database (NVD)
- GitHub Security Advisory Database
- Snyk Vulnerability Database
- Veracode SCA
- Socket.dev
- deps.dev (Google)

---

**Stay secure. Scan before you code.** 🛡️
