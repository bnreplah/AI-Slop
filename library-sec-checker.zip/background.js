// background.js - Service worker for SecureLib Guardian
// Handles API calls to multiple vulnerability databases

// Listen for messages from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'scanPackage') {
    handlePackageScan(request.data).then(sendResponse);
    return true; // Keep channel open for async response
  }
});

// Main scan orchestrator
async function handlePackageScan(data) {
  const { packageName, version, ecosystem } = data;
  
  // Save to storage for persistence
  chrome.storage.local.set({
    lastPackage: packageName,
    lastVersion: version,
    lastEcosystem: ecosystem
  });

  const results = {
    packageName,
    version,
    ecosystem,
    vulnerabilities: [],
    maliciousPackages: [],
    sourceResults: {},
    sourcesChecked: 0
  };

  // Parallel scanning across all sources
  const scanPromises = [
    scanOSV(packageName, version, ecosystem),
    scanNVD(packageName, version, ecosystem),
    scanGitHubAdvisory(packageName, version, ecosystem),
    scanSnyk(packageName, version, ecosystem),
    scanVeracode(packageName, version, ecosystem),
    scanSocketDev(packageName, version, ecosystem),
    scanDepsDev(packageName, version, ecosystem)
  ];

  const scanResults = await Promise.allSettled(scanPromises);

  // Process results from each source
  scanResults.forEach((result, index) => {
    const sourceNames = ['osv', 'nvd', 'github', 'snyk', 'veracode', 'socket', 'deps'];
    const sourceName = sourceNames[index];

    if (result.status === 'fulfilled' && result.value) {
      results.sourceResults[sourceName] = { success: true };
      results.sourcesChecked++;
      
      if (result.value.vulnerabilities) {
        results.vulnerabilities.push(...result.value.vulnerabilities);
      }
      
      if (result.value.malicious) {
        results.maliciousPackages.push(...result.value.malicious);
      }
    } else {
      results.sourceResults[sourceName] = { 
        success: false, 
        error: result.reason?.message 
      };
    }
  });

  // Deduplicate vulnerabilities by ID
  results.vulnerabilities = deduplicateVulnerabilities(results.vulnerabilities);

  return results;
}

// OSV (Open Source Vulnerabilities) API
async function scanOSV(packageName, version, ecosystem) {
  try {
    const osvEcosystem = mapEcosystemToOSV(ecosystem);
    const response = await fetch('https://api.osv.dev/v1/query', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        package: {
          name: packageName,
          ecosystem: osvEcosystem
        },
        version: version !== 'latest' ? version : undefined
      })
    });

    if (!response.ok) throw new Error('OSV API error');

    const data = await response.json();
    const vulnerabilities = (data.vulns || []).map(vuln => ({
      id: vuln.id,
      source: 'OSV',
      severity: vuln.severity?.[0]?.score ? 
        getSeverityFromScore(vuln.severity[0].score) : 
        'UNKNOWN',
      summary: vuln.summary || vuln.details || 'No description',
      published: vuln.published,
      modified: vuln.modified
    }));

    return { vulnerabilities };
  } catch (error) {
    console.error('OSV scan error:', error);
    throw error;
  }
}

// NVD (National Vulnerability Database) API
async function scanNVD(packageName, version, ecosystem) {
  try {
    // NVD API requires keyword search
    const response = await fetch(
      `https://services.nvd.nist.gov/rest/json/cves/2.0?keywordSearch=${encodeURIComponent(packageName)}&resultsPerPage=20`,
      {
        headers: {
          'apiKey': '' // Users should add their own NVD API key for better rate limits
        }
      }
    );

    if (!response.ok) throw new Error('NVD API error');

    const data = await response.json();
    const vulnerabilities = (data.vulnerabilities || [])
      .filter(item => {
        // Filter to only include relevant CVEs for this package
        const desc = item.cve?.descriptions?.[0]?.value?.toLowerCase() || '';
        return desc.includes(packageName.toLowerCase());
      })
      .map(item => ({
        id: item.cve?.id,
        source: 'NVD',
        severity: item.cve?.metrics?.cvssMetricV31?.[0]?.cvssData?.baseSeverity || 
                  item.cve?.metrics?.cvssMetricV2?.[0]?.baseSeverity || 
                  'UNKNOWN',
        summary: item.cve?.descriptions?.[0]?.value,
        published: item.cve?.published,
        modified: item.cve?.lastModified
      }));

    return { vulnerabilities };
  } catch (error) {
    console.error('NVD scan error:', error);
    throw error;
  }
}

// GitHub Security Advisory API
async function scanGitHubAdvisory(packageName, version, ecosystem) {
  try {
    const ghEcosystem = mapEcosystemToGitHub(ecosystem);
    
    // GraphQL query for GitHub Advisory Database
    const query = `
      query($ecosystem: SecurityAdvisoryEcosystem!, $package: String!) {
        securityVulnerabilities(first: 20, ecosystem: $ecosystem, package: $package) {
          nodes {
            advisory {
              ghsaId
              summary
              severity
              publishedAt
            }
            vulnerableVersionRange
            firstPatchedVersion {
              identifier
            }
          }
        }
      }
    `;

    const response = await fetch('https://api.github.com/graphql', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ghp_YOUR_TOKEN_HERE' // Users should add their GitHub token
      },
      body: JSON.stringify({
        query,
        variables: {
          ecosystem: ghEcosystem,
          package: packageName
        }
      })
    });

    if (!response.ok) throw new Error('GitHub API error');

    const data = await response.json();
    const vulnerabilities = (data.data?.securityVulnerabilities?.nodes || []).map(node => ({
      id: node.advisory.ghsaId,
      source: 'GitHub Advisory',
      severity: node.advisory.severity,
      summary: node.advisory.summary,
      published: node.advisory.publishedAt,
      affectedVersions: node.vulnerableVersionRange,
      patched: node.firstPatchedVersion?.identifier
    }));

    return { vulnerabilities };
  } catch (error) {
    console.error('GitHub Advisory scan error:', error);
    throw error;
  }
}

// Snyk Vulnerability Database
async function scanSnyk(packageName, version, ecosystem) {
  try {
    const snykEcosystem = mapEcosystemToSnyk(ecosystem);
    const packageSpec = `${snykEcosystem}/${packageName}`;
    
    // Snyk API requires authentication
    const response = await fetch(
      `https://snyk.io/api/v1/test/${packageSpec}/${version}`,
      {
        headers: {
          'Authorization': 'token YOUR_SNYK_TOKEN_HERE' // Users should add their Snyk token
        }
      }
    );

    if (!response.ok) throw new Error('Snyk API error');

    const data = await response.json();
    const vulnerabilities = (data.issues?.vulnerabilities || []).map(vuln => ({
      id: vuln.id,
      source: 'Snyk',
      severity: vuln.severity?.toUpperCase() || 'UNKNOWN',
      summary: vuln.title,
      published: vuln.publicationTime,
      cvssScore: vuln.cvssScore
    }));

    return { vulnerabilities };
  } catch (error) {
    console.error('Snyk scan error:', error);
    throw error;
  }
}

// Veracode SCA (Software Composition Analysis)
async function scanVeracode(packageName, version, ecosystem) {
  try {
    // Veracode SCA API - requires authentication
    // This is a simplified example - actual implementation needs proper auth
    const veracodeEcosystem = mapEcosystemToVeracode(ecosystem);
    
    const response = await fetch(
      `https://api.veracode.com/srcclr/v3/libraries/${veracodeEcosystem}/${packageName}/${version}/vulnerabilities`,
      {
        headers: {
          'Authorization': 'Bearer YOUR_VERACODE_TOKEN_HERE' // Users should add their Veracode token
        }
      }
    );

    if (!response.ok) throw new Error('Veracode API error');

    const data = await response.json();
    const vulnerabilities = (data.vulnerabilities || []).map(vuln => ({
      id: vuln.cve || vuln.id,
      source: 'Veracode SCA',
      severity: vuln.cvssScore >= 9.0 ? 'CRITICAL' :
                vuln.cvssScore >= 7.0 ? 'HIGH' :
                vuln.cvssScore >= 4.0 ? 'MEDIUM' : 'LOW',
      summary: vuln.title || vuln.overview,
      published: vuln.publishDate,
      cvssScore: vuln.cvssScore,
      exploitability: vuln.exploitMaturity
    }));

    // Check for malicious libraries
    const malicious = [];
    if (data.malicious || data.suspicious) {
      malicious.push({
        source: 'Veracode SCA',
        reason: 'Package flagged as malicious or suspicious by Veracode'
      });
    }

    return { vulnerabilities, malicious };
  } catch (error) {
    console.error('Veracode scan error:', error);
    throw error;
  }
}

// Socket.dev - Malicious package detection
async function scanSocketDev(packageName, version, ecosystem) {
  try {
    if (ecosystem !== 'npm' && ecosystem !== 'pypi') {
      // Socket.dev primarily supports npm and PyPI
      return { vulnerabilities: [], malicious: [] };
    }

    const response = await fetch(
      `https://socket.dev/api/v0/report/${ecosystem}/${packageName}/${version}`,
      {
        headers: {
          'Authorization': 'Bearer YOUR_SOCKET_TOKEN_HERE' // Users should add their Socket token
        }
      }
    );

    if (!response.ok) throw new Error('Socket.dev API error');

    const data = await response.json();
    const malicious = [];

    // Check for supply chain issues
    if (data.alerts && data.alerts.length > 0) {
      const criticalAlerts = data.alerts.filter(alert => 
        alert.type === 'malware' || 
        alert.type === 'install-scripts' ||
        alert.type === 'suspicious'
      );

      if (criticalAlerts.length > 0) {
        malicious.push({
          source: 'Socket.dev',
          reason: criticalAlerts.map(a => a.description).join('; ')
        });
      }
    }

    return { vulnerabilities: [], malicious };
  } catch (error) {
    console.error('Socket.dev scan error:', error);
    throw error;
  }
}

// deps.dev (Google Open Source Insights)
async function scanDepsDev(packageName, version, ecosystem) {
  try {
    const depsEcosystem = mapEcosystemToDeps(ecosystem);
    const packagePath = encodeURIComponent(`${depsEcosystem}/${packageName}`);
    
    const response = await fetch(
      `https://api.deps.dev/v3alpha/systems/${depsEcosystem}/packages/${packageName}/versions/${version}`,
      {
        headers: {
          'Accept': 'application/json'
        }
      }
    );

    if (!response.ok) throw new Error('deps.dev API error');

    const data = await response.json();
    const vulnerabilities = (data.advisories || []).map(advisory => ({
      id: advisory.key?.id,
      source: 'deps.dev',
      severity: advisory.severity || 'UNKNOWN',
      summary: advisory.title || advisory.description,
      url: advisory.url
    }));

    return { vulnerabilities };
  } catch (error) {
    console.error('deps.dev scan error:', error);
    throw error;
  }
}

// Helper functions
function mapEcosystemToOSV(ecosystem) {
  const mapping = {
    'npm': 'npm',
    'pypi': 'PyPI',
    'maven': 'Maven',
    'nuget': 'NuGet',
    'cargo': 'crates.io',
    'rubygems': 'RubyGems',
    'packagist': 'Packagist',
    'go': 'Go'
  };
  return mapping[ecosystem] || ecosystem;
}

function mapEcosystemToGitHub(ecosystem) {
  const mapping = {
    'npm': 'NPM',
    'pypi': 'PIP',
    'maven': 'MAVEN',
    'nuget': 'NUGET',
    'cargo': 'RUST',
    'rubygems': 'RUBYGEMS',
    'packagist': 'COMPOSER',
    'go': 'GO'
  };
  return mapping[ecosystem] || 'NPM';
}

function mapEcosystemToSnyk(ecosystem) {
  const mapping = {
    'npm': 'npm',
    'pypi': 'pip',
    'maven': 'maven',
    'nuget': 'nuget',
    'cargo': 'cargo',
    'rubygems': 'rubygems',
    'packagist': 'composer',
    'go': 'golang'
  };
  return mapping[ecosystem] || 'npm';
}

function mapEcosystemToVeracode(ecosystem) {
  const mapping = {
    'npm': 'npm',
    'pypi': 'pypi',
    'maven': 'maven',
    'nuget': 'nuget',
    'cargo': 'cargo',
    'rubygems': 'rubygems',
    'packagist': 'packagist',
    'go': 'golang'
  };
  return mapping[ecosystem] || 'npm';
}

function mapEcosystemToDeps(ecosystem) {
  const mapping = {
    'npm': 'npm',
    'pypi': 'pypi',
    'maven': 'maven',
    'cargo': 'cargo',
    'go': 'go'
  };
  return mapping[ecosystem] || 'npm';
}

function getSeverityFromScore(cvssScore) {
  if (cvssScore >= 9.0) return 'CRITICAL';
  if (cvssScore >= 7.0) return 'HIGH';
  if (cvssScore >= 4.0) return 'MEDIUM';
  return 'LOW';
}

function deduplicateVulnerabilities(vulnerabilities) {
  const seen = new Map();
  const deduplicated = [];

  vulnerabilities.forEach(vuln => {
    if (!seen.has(vuln.id)) {
      seen.set(vuln.id, true);
      deduplicated.push(vuln);
    }
  });

  return deduplicated;
}

// Install/update handler
chrome.runtime.onInstalled.addListener(() => {
  console.log('SecureLib Guardian installed');
  
  // Set default settings
  chrome.storage.local.set({
    settings: {
      autoScan: true,
      notifications: true,
      theme: 'dark'
    }
  });
});
