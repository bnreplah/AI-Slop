# SecureLib Guardian - Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                     SECURELIB GUARDIAN EXTENSION                    │
└─────────────────────────────────────────────────────────────────────┘

┌──────────────────────┐         ┌──────────────────────────────────┐
│   USER INTERFACE     │         │     CONTENT SCRIPT               │
│                      │         │                                  │
│  ┌────────────────┐  │         │  • Auto-detect packages on:      │
│  │  Popup Window  │  │         │    - npmjs.com                   │
│  │  (420x600px)   │  │         │    - pypi.org                    │
│  │                │  │         │    - github.com                  │
│  │  • Ecosystem   │  │         │    - crates.io                   │
│  │  • Package     │  │         │    - rubygems.org                │
│  │  • Version     │  │         │    - nuget.org                   │
│  │  • Scan Button │  │         │    - packagist.org               │
│  └────────────────┘  │         │    - mvnrepository.com           │
│          │           │         │                                  │
│          ▼           │         │  • Inject security banner        │
│  ┌────────────────┐  │         │  • Parse package metadata        │
│  │ Results Display│  │         │  • Trigger auto-scan             │
│  │                │  │         │                                  │
│  │  • Summary     │  │         └──────────────────────────────────┘
│  │  • Risk Level  │  │                      │
│  │  • Vuln List   │  │                      │
│  │  • Sources     │  │                      ▼
│  └────────────────┘  │         ┌──────────────────────────────────┐
└──────────────────────┘         │   BACKGROUND SERVICE WORKER      │
           │                     │                                  │
           │                     │  ┌────────────────────────────┐  │
           └────────────────────▶│  │  Scan Orchestrator         │  │
                                 │  │                            │  │
                                 │  │  • Parallel API calls      │  │
                                 │  │  • Result aggregation      │  │
                                 │  │  • Deduplication           │  │
                                 │  │  • Error handling          │  │
                                 │  └────────────────────────────┘  │
                                 │              ▼                   │
                                 │  ┌─────────────────────────────┐ │
                                 │  │   API Integration Layer     │ │
                                 │  └─────────────────────────────┘ │
                                 └──────────────────────────────────┘
                                              │
                ┌─────────────────────────────┼─────────────────────────────┐
                │                             │                             │
                ▼                             ▼                             ▼
    ┌─────────────────────┐      ┌─────────────────────┐      ┌─────────────────────┐
    │   OSV DATABASE      │      │   NVD DATABASE      │      │  GITHUB ADVISORY    │
    │                     │      │                     │      │                     │
    │  • api.osv.dev      │      │  • services.nvd     │      │  • api.github.com   │
    │  • Open Source      │      │    .nist.gov        │      │  • GraphQL API      │
    │  • All ecosystems   │      │  • CVE records      │      │  • GHSA IDs         │
    │  • Free access      │      │  • CVSS scores      │      │  • Requires token   │
    └─────────────────────┘      └─────────────────────┘      └─────────────────────┘
                │
    ┌───────────┴───────────────────────────────────┐
    │                                               │
    ▼                                               ▼
┌─────────────────────┐                ┌─────────────────────┐
│  SNYK DATABASE      │                │  VERACODE SCA       │
│                     │                │                     │
│  • snyk.io          │                │  • api.veracode.com │
│  • Commercial       │                │  • SCA analysis     │
│  • Requires token   │                │  • Malicious detect │
│  • Deep analysis    │                │  • Enterprise only  │
└─────────────────────┘                └─────────────────────┘
                │
    ┌───────────┴──────────────┐
    │                          │
    ▼                          ▼
┌─────────────────────┐   ┌─────────────────────┐
│  SOCKET.DEV         │   │    DEPS.DEV         │
│                     │   │                     │
│  • socket.dev       │   │  • api.deps.dev     │
│  • Supply chain     │   │  • Google insights  │
│  • Malicious detect │   │  • Free access      │
│  • npm/PyPI focus   │   │  • Multi-ecosystem  │
└─────────────────────┘   └─────────────────────┘

┌─────────────────────────────────────────────────────────────────────┐
│                          DATA FLOW                                  │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  1. User inputs package → Popup.js                                 │
│  2. Message sent → Background.js                                   │
│  3. Parallel API calls → 7 databases                               │
│  4. Results aggregated → Deduplication                             │
│  5. Response sent → Popup.js                                       │
│  6. UI updated → Display results                                   │
│                                                                     │
│  AUTO-SCAN FLOW:                                                   │
│  1. Content script detects package page                            │
│  2. Extract metadata (name, version, ecosystem)                    │
│  3. Message to background → Same as above                          │
│  4. Inject banner → Color-coded risk level                         │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────┐
│                       SECURITY FEATURES                             │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ✓ No telemetry or tracking                                        │
│  ✓ API keys stored locally only                                    │
│  ✓ Direct API calls (no proxy servers)                             │
│  ✓ Content Security Policy enforced                                │
│  ✓ Minimal permissions requested                                   │
│  ✓ Open source and auditable                                       │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────┐
│                         TECH STACK                                  │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  Frontend:  Vanilla JavaScript, CSS3, HTML5                        │
│  APIs:      REST, GraphQL (GitHub)                                 │
│  Storage:   Chrome Storage API                                     │
│  Manifest:  Chrome Extension Manifest V3                           │
│  Design:    Cyberpunk/Hacker aesthetic                             │
│  Fonts:     JetBrains Mono (monospace)                             │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

## API Response Flow

```
┌─────────────┐
│   Scan      │
│  Request    │
└──────┬──────┘
       │
       ▼
┌─────────────────────────────────────────┐
│  Promise.allSettled([                   │
│    scanOSV(),                            │
│    scanNVD(),                            │
│    scanGitHub(),                         │
│    scanSnyk(),                           │
│    scanVeracode(),    ← Including        │
│    scanSocket(),        Veracode!        │
│    scanDeps()                            │
│  ])                                      │
└─────────────────────────────────────────┘
       │
       ▼
┌─────────────────────────────────────────┐
│  Each returns:                          │
│  {                                      │
│    vulnerabilities: [...],              │
│    malicious: [...]                     │
│  }                                      │
└─────────────────────────────────────────┘
       │
       ▼
┌─────────────────────────────────────────┐
│  Aggregate & Deduplicate                │
│  • Merge all vulnerability arrays       │
│  • Remove duplicates by CVE ID          │
│  • Combine malicious flags              │
└─────────────────────────────────────────┘
       │
       ▼
┌─────────────────────────────────────────┐
│  Return to UI:                          │
│  {                                      │
│    packageName,                         │
│    version,                             │
│    vulnerabilities: [...],              │
│    maliciousPackages: [...],            │
│    sourcesChecked: 7,                   │
│    sourceResults: {...}                 │
│  }                                      │
└─────────────────────────────────────────┘
```

## Vulnerability Data Structure

```javascript
{
  id: "CVE-2023-1234",           // CVE or GHSA ID
  source: "NVD",                  // Database name
  severity: "HIGH",               // CRITICAL|HIGH|MEDIUM|LOW
  summary: "Description...",      // Human-readable
  published: "2023-01-15",        // ISO date
  modified: "2023-02-20",         // Last update
  cvssScore: 8.5,                 // Optional score
  affectedVersions: "< 4.0.0",    // Version range
  patched: "4.0.1"                // Fix version
}
```

## Color Coding System

```
Risk Level         │ Color      │ Condition
───────────────────┼────────────┼──────────────────────────
Safe               │ Green      │ 0 vulnerabilities
Low Risk           │ Blue       │ Only LOW severity
Medium Risk        │ Orange     │ MEDIUM severity present
High Risk          │ Red        │ HIGH severity present
Critical Risk      │ Red        │ CRITICAL or malicious
```
