// popup.js - Frontend logic for SecureLib Guardian

const scanBtn = document.getElementById('scanBtn');
const packageInput = document.getElementById('package');
const versionInput = document.getElementById('version');
const ecosystemSelect = document.getElementById('ecosystem');
const loading = document.getElementById('loading');
const results = document.getElementById('results');
const sourceChecks = document.getElementById('sourceChecks');
const summary = document.getElementById('summary');
const vulnerabilities = document.getElementById('vulnerabilities');

scanBtn.addEventListener('click', async () => {
  const packageName = packageInput.value.trim();
  const version = versionInput.value.trim() || 'latest';
  const ecosystem = ecosystemSelect.value;

  if (!packageName) {
    showNotification('Please enter a package name', 'warning');
    return;
  }

  await scanPackage(packageName, version, ecosystem);
});

// Allow Enter key to trigger scan
packageInput.addEventListener('keypress', (e) => {
  if (e.key === 'Enter') scanBtn.click();
});

versionInput.addEventListener('keypress', (e) => {
  if (e.key === 'Enter') scanBtn.click();
});

async function scanPackage(packageName, version, ecosystem) {
  // Show loading state
  loading.classList.add('active');
  results.classList.remove('visible');
  scanBtn.disabled = true;
  sourceChecks.innerHTML = '';

  // Initialize source checks display
  const sources = [
    { id: 'osv', name: 'OSV Database' },
    { id: 'nvd', name: 'NVD Database' },
    { id: 'github', name: 'GitHub Advisory' },
    { id: 'snyk', name: 'Snyk Database' },
    { id: 'veracode', name: 'Veracode SCA' },
    { id: 'socket', name: 'Socket.dev' },
    { id: 'deps', name: 'deps.dev' }
  ];

  sources.forEach(source => {
    const checkDiv = document.createElement('div');
    checkDiv.className = 'source-check';
    checkDiv.innerHTML = `
      <span class="check-icon loading" id="${source.id}-icon"></span>
      <span>${source.name}</span>
    `;
    sourceChecks.appendChild(checkDiv);
  });

  try {
    // Send message to background script
    const response = await chrome.runtime.sendMessage({
      action: 'scanPackage',
      data: { packageName, version, ecosystem }
    });

    // Update source check statuses
    if (response.sourceResults) {
      Object.keys(response.sourceResults).forEach(sourceId => {
        const icon = document.getElementById(`${sourceId}-icon`);
        if (icon) {
          const result = response.sourceResults[sourceId];
          icon.className = `check-icon ${result.success ? 'success' : 'error'}`;
        }
      });
    }

    // Display results
    displayResults(response);

  } catch (error) {
    console.error('Scan error:', error);
    showNotification('Scan failed: ' + error.message, 'danger');
  } finally {
    loading.classList.remove('active');
    scanBtn.disabled = false;
  }
}

function displayResults(data) {
  results.classList.add('visible');

  // Display summary
  const totalVulns = data.vulnerabilities?.length || 0;
  const critical = data.vulnerabilities?.filter(v => v.severity === 'CRITICAL').length || 0;
  const high = data.vulnerabilities?.filter(v => v.severity === 'HIGH').length || 0;
  const medium = data.vulnerabilities?.filter(v => v.severity === 'MEDIUM').length || 0;
  const low = data.vulnerabilities?.filter(v => v.severity === 'LOW').length || 0;

  let riskLevel = 'Safe';
  let riskClass = 'safe';
  
  if (critical > 0) {
    riskLevel = 'Critical Risk';
    riskClass = 'danger';
  } else if (high > 0) {
    riskLevel = 'High Risk';
    riskClass = 'danger';
  } else if (medium > 0) {
    riskLevel = 'Medium Risk';
    riskClass = 'warning';
  } else if (low > 0) {
    riskLevel = 'Low Risk';
    riskClass = 'warning';
  }

  summary.innerHTML = `
    <div class="summary-row">
      <span class="summary-label">Package</span>
      <span class="summary-value">${data.packageName}@${data.version}</span>
    </div>
    <div class="summary-row">
      <span class="summary-label">Risk Level</span>
      <span class="summary-value status-badge badge-${riskClass}">${riskLevel}</span>
    </div>
    <div class="summary-row">
      <span class="summary-label">Total Vulnerabilities</span>
      <span class="summary-value">${totalVulns}</span>
    </div>
    ${critical > 0 ? `
    <div class="summary-row">
      <span class="summary-label">Critical</span>
      <span class="summary-value" style="color: var(--cyber-danger)">${critical}</span>
    </div>` : ''}
    ${high > 0 ? `
    <div class="summary-row">
      <span class="summary-label">High</span>
      <span class="summary-value" style="color: #ff6b00">${high}</span>
    </div>` : ''}
    ${medium > 0 ? `
    <div class="summary-row">
      <span class="summary-label">Medium</span>
      <span class="summary-value" style="color: var(--cyber-warning)">${medium}</span>
    </div>` : ''}
    ${low > 0 ? `
    <div class="summary-row">
      <span class="summary-label">Low</span>
      <span class="summary-value" style="color: #4a90e2">${low}</span>
    </div>` : ''}
    <div class="summary-row">
      <span class="summary-label">Sources Checked</span>
      <span class="summary-value">${data.sourcesChecked || 0}</span>
    </div>
  `;

  // Display vulnerabilities
  if (totalVulns > 0) {
    const vulnsBySource = groupVulnerabilitiesBySource(data.vulnerabilities);
    vulnerabilities.innerHTML = '';

    Object.keys(vulnsBySource).forEach(source => {
      const sourceVulns = vulnsBySource[source];
      const cardClass = getCardClass(sourceVulns);
      
      const card = document.createElement('div');
      card.className = `status-card ${cardClass}`;
      card.innerHTML = `
        <div class="status-header">
          <div class="status-title">${source}</div>
          <div class="status-badge badge-${cardClass === 'danger' ? 'danger' : 'warning'}">
            ${sourceVulns.length} Found
          </div>
        </div>
        <ul class="vuln-list">
          ${sourceVulns.map(vuln => `
            <li class="vuln-item">
              <div class="vuln-id">
                ${vuln.id}
                <span class="severity severity-${(vuln.severity || 'unknown').toLowerCase()}">
                  ${vuln.severity || 'UNKNOWN'}
                </span>
              </div>
              <div class="vuln-desc">${vuln.summary || 'No description available'}</div>
            </li>
          `).join('')}
        </ul>
      `;
      vulnerabilities.appendChild(card);
    });
  } else {
    vulnerabilities.innerHTML = `
      <div class="status-card">
        <div class="status-header">
          <div class="status-title">No Vulnerabilities Found</div>
          <div class="status-badge badge-safe">✓ Safe</div>
        </div>
        <p style="color: var(--cyber-text-dim); font-size: 11px; margin-top: 8px;">
          This package has no known vulnerabilities across all checked databases.
        </p>
      </div>
    `;
  }

  // Display malicious package warnings
  if (data.maliciousPackages && data.maliciousPackages.length > 0) {
    const malCard = document.createElement('div');
    malCard.className = 'status-card danger';
    malCard.innerHTML = `
      <div class="status-header">
        <div class="status-title">⚠️ Malicious Package Alert</div>
        <div class="status-badge badge-danger">Blocked</div>
      </div>
      <p style="color: var(--cyber-danger); font-size: 11px; margin-top: 8px; line-height: 1.5;">
        This package has been flagged as malicious or suspicious. Do NOT use this package.
      </p>
      <ul class="vuln-list">
        ${data.maliciousPackages.map(pkg => `
          <li class="vuln-item">
            <div class="vuln-id">${pkg.source}</div>
            <div class="vuln-desc">${pkg.reason}</div>
          </li>
        `).join('')}
      </ul>
    `;
    vulnerabilities.insertBefore(malCard, vulnerabilities.firstChild);
  }
}

function groupVulnerabilitiesBySource(vulnerabilities) {
  const grouped = {};
  vulnerabilities.forEach(vuln => {
    const source = vuln.source || 'Unknown Source';
    if (!grouped[source]) {
      grouped[source] = [];
    }
    grouped[source].push(vuln);
  });
  return grouped;
}

function getCardClass(vulns) {
  const hasCritical = vulns.some(v => v.severity === 'CRITICAL');
  const hasHigh = vulns.some(v => v.severity === 'HIGH');
  
  if (hasCritical || hasHigh) return 'danger';
  return 'warning';
}

function showNotification(message, type = 'info') {
  chrome.notifications.create({
    type: 'basic',
    iconUrl: 'icons/icon128.png',
    title: 'SecureLib Guardian',
    message: message
  });
}

// Load last searched package on open
chrome.storage.local.get(['lastPackage', 'lastVersion', 'lastEcosystem'], (result) => {
  if (result.lastPackage) {
    packageInput.value = result.lastPackage;
    versionInput.value = result.lastVersion || '';
    ecosystemSelect.value = result.lastEcosystem || 'npm';
  }
});
