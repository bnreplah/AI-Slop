# SecureLib Guardian - Setup Instructions

## Quick Start

### Step 1: Generate Icons
You need to create PNG icons from the SVG template. You can use any of these methods:

**Option A: Using ImageMagick (Linux/Mac)**
```bash
cd icons
convert -background none -resize 16x16 icon.svg icon16.png
convert -background none -resize 48x48 icon.svg icon48.png
convert -background none -resize 128x128 icon.svg icon128.png
```

**Option B: Using Inkscape**
```bash
cd icons
inkscape icon.svg --export-filename=icon16.png --export-width=16
inkscape icon.svg --export-filename=icon48.png --export-width=48
inkscape icon.svg --export-filename=icon128.png --export-width=128
```

**Option C: Online Tool**
- Upload `icons/icon.svg` to https://cloudconvert.com/svg-to-png
- Convert to 16x16, 48x48, and 128x128 sizes
- Download and save as icon16.png, icon48.png, icon128.png

**Option D: Use Any Shield Icon**
Just find three PNG images of a shield/security icon in those sizes and place them in the icons folder.

### Step 2: Configure API Keys (Optional but Recommended)

Open `background.js` and add your API keys:

1. **NVD API Key** (Line 82) - Free, improves rate limits
   - Get at: https://nvd.nist.gov/developers/request-an-api-key
   - Replace: `'apiKey': ''` with `'apiKey': 'your-key-here'`

2. **GitHub Token** (Line 115) - **Required for GitHub Advisory scanning**
   - Get at: https://github.com/settings/tokens (select: public_repo, read:security_events)
   - Replace: `'Bearer ghp_YOUR_TOKEN_HERE'` with `'Bearer your-token-here'`

3. **Snyk Token** (Line 143) - Optional, adds commercial intelligence
   - Get at: https://app.snyk.io/account
   - Replace: `'token YOUR_SNYK_TOKEN_HERE'` with `'token your-token-here'`

4. **Veracode Token** (Line 165) - Optional, enterprise accounts only
   - Replace: `'Bearer YOUR_VERACODE_TOKEN_HERE'` with `'Bearer your-token-here'`

5. **Socket.dev Token** (Line 202) - Optional, excellent for npm/PyPI
   - Get at: https://socket.dev/
   - Replace: `'Bearer YOUR_SOCKET_TOKEN_HERE'` with `'Bearer your-token-here'`

### Step 3: Load in Chrome

1. Open Chrome
2. Navigate to `chrome://extensions/`
3. Enable "Developer mode" (toggle switch in top-right corner)
4. Click "Load unpacked"
5. Navigate to and select the `securelib-guardian` folder
6. Extension should now appear with your shield icon!

### Step 4: Test It

**Method 1: Manual Scan**
- Click the extension icon in your toolbar
- Enter: `lodash` (npm)
- Version: `4.17.20`
- Click "Scan Package"
- Should show known vulnerabilities

**Method 2: Auto-Scan**
- Visit: https://www.npmjs.com/package/lodash
- You should see a security banner appear at the top
- Banner will show scan results automatically

## Working Without API Keys

The extension will still work without API keys, but with limitations:

- ✅ **OSV** - Works fully without keys
- ⚠️ **NVD** - Works but with strict rate limits (5 requests per 30 seconds)
- ❌ **GitHub Advisory** - Requires token to function
- ❌ **Snyk** - Requires token to function  
- ❌ **Veracode** - Requires enterprise account
- ❌ **Socket.dev** - Requires token to function
- ✅ **deps.dev** - Works fully without keys

**Recommendation**: At minimum, add NVD and GitHub tokens for good coverage.

## Troubleshooting

### Icons not appearing
- Make sure you have icon16.png, icon48.png, and icon128.png in the icons/ folder
- Reload the extension after adding icons
- Check file names are exactly correct (case-sensitive)

### "Failed to load extension" error
- Check that manifest.json is valid JSON
- Make sure all required files exist
- Icons must be PNG format

### API errors in console
- Check your API keys are correctly formatted
- Verify API keys are valid and not expired
- Some APIs have rate limits - wait and try again

### Extension not scanning
- Check that the extension is enabled in chrome://extensions/
- Look for errors in the console (right-click extension icon → Inspect popup)
- Verify the page URL matches one of the content_scripts matches in manifest.json

## Next Steps

1. ⭐ Star the repository if you find it useful
2. 🐛 Report bugs or request features via GitHub issues
3. 🔒 Start scanning your dependencies before using them!
4. 📚 Read the full README.md for detailed documentation

---

Built by Cybopsec 🛡️
